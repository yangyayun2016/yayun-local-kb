'use strict';
const M = window.STUDIO_MANIFEST;
const $ = id => document.getElementById(id);
const esc = value => String(value ?? '—').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt = value => value == null || !Number.isFinite(value) ? '—' : value.toLocaleString('zh-CN',{maximumFractionDigits:2});
const dictionary = {Shipped:'已发货',SHIPPED:'已发货',Unshipped:'待发货',UNSHIPPED:'待发货',Pending:'待处理',PENDING:'待处理',PartiallyShipped:'部分发货',Canceled:'已取消',CANCELLED:'已取消',Cancelled:'已取消',ENABLED:'启用',PAUSED:'暂停',ARCHIVED:'归档',ACTIVE:'进行中',APPROVED:'审核通过',DRAFT:'草稿',SUBMITTED:'已提交',COMPLETED:'已完成',AVAILABLE:'可用',RESERVED:'预留',TOTAL:'合计',SUCCESS:'成功',NORMAL:'正常',GOOD:'良好',AT_RISK:'有风险',HEALTHY:'健康',Shipment:'发货',Refund:'退款',ServiceFee:'服务费',Adjustment:'调整',Removal:'移除',OTHER:'其他',TOP_OF_SEARCH:'搜索顶部',REST_OF_SEARCH:'其余搜索位置',PRODUCT_PAGE:'商品页',SPONSORED_PRODUCTS:'商品推广',SPONSORED_BRANDS:'品牌推广',SPONSORED_DISPLAY:'展示推广',SELLER:'卖家自配送',AMAZON:'亚马逊配送'};
const cn = value => dictionary[value] || String(value ?? '未返回');
Object.assign(dictionary,{'Top of Search on-Amazon':'亚马逊搜索顶部','Other on-Amazon':'亚马逊其他位置','Detail Page on-Amazon':'亚马逊商品详情页',WARNING:'警告',BAD:'异常',GREEN:'健康',YELLOW:'关注',RED:'高风险'});
Object.assign(dictionary,{Transfer:'资金划转',ProductAdsPayment:'广告付款',Principal:'商品本金',Tax:'税费',Commission:'销售佣金','MarketplaceFacilitatorVAT-Principal':'平台代扣商品增值税','Current Reserve Amount':'当期预留金额','Previous Reserve Amount Balance':'上期预留结转',FBAPerUnitFulfillmentFee:'FBA按件配送费',FBAStorageFee:'FBA仓储费',CustomerReturn:'顾客退货',Reimbursement_Reversal:'赔偿冲回',Lost_Warehouse:'仓库丢失',Damaged_Warehouse:'仓库损坏',Lost_Inbound:'入库丢失',Receipts:'入库接收',Shipments:'发货',CustomerReturns:'顾客退货',Adjustments:'库存调整',WhseTransfers:'仓库调拨',VendorReturns:'移除退回'});
Object.assign(dictionary,{Completed:'已完成',PAID:'已支付',FAILED:'失败',NO_PAYOUT:'本期无回款',WORKING:'处理中',CLOSED:'已关闭',BEST_DEAL:'最佳优惠',LIGHTNING_DEAL:'限时秒杀',KEYWORD:'关键词',PRODUCT:'商品',EXACT:'精准匹配',PHRASE:'词组匹配',BROAD:'广泛匹配',VALID_FOEP:'已返回预期报价',NO_COMPETING_OFFER:'没有竞争报价',OFFER_NOT_FOUND:'未找到报价',True:'是',False:'否',DAMAGED:'商品损坏',DEFECTIVE:'商品缺陷',LOST:'丢失',WRONG_ITEM:'错发商品'});
const categories = [...new Set(M.cards.map(c=>c.category))];
const descriptions = {'销售与流量':'看清销售、访问与商品转化，区分趋势与数据缺口。','广告投放':'从活动到搜索词，六个切面定位投入、产出和待核查对象。','订单与售后':'沿着订单、发货和退货，找到需要跟进的履约问题。','库存与供应链':'查看当前水位、库龄、库存变动和入库计划。','商品与促销':'先处理可售问题，再核查价格、内容和促销排期。','财务与回款':'区分已记账、已结算、已回款和预计回款，不把现金流当利润。','账户健康':'使用平台明确返回的绩效状态，不编造统一风险评分。'};
let storageAvailable=true, saved=[];
try {const value=JSON.parse(localStorage.getItem('dinzee-curated-studio-v1')||'[]');if(Array.isArray(value))saved=value.filter(b=>b&&typeof b.id==='string'&&typeof b.name==='string'&&Array.isArray(b.cards)).map(b=>({...b,cards:b.cards.filter(id=>M.cards.some(c=>c.id===id))}));} catch {storageAvailable=false;}
let category=categories[0], activeBoard=null, draft=null, filter={country:'FR',currency:'EUR',start:M.defaultPeriod.start,end:M.defaultPeriod.end,mode:'auto'}, version=0, currentViews=new Map(), detailState=null;
const loads=new Map();
const countries=[...new Set(M.cards.flatMap(c=>[...c.countries,...c.sampleCountries]))].filter(c=>!['ACCOUNT','ALL','UNATTRIBUTED'].includes(c));
$('country').innerHTML=countries.map(c=>`<option value="${esc(c)}">${esc(M.countries[c]||c)} · ${esc(c)}${M.cards.some(d=>d.countries.includes(c))?'':'（仅模拟）'}</option>`).join('');
$('country').value=filter.country;
if(!$('country').value)filter.country=$('country').value=countries[0]||'';
$('currency').innerHTML=['EUR','USD','GBP','PLN','SEK','AED','SAR','CAD','MXN','BRL'].map(c=>`<option>${c}</option>`).join('');
$('currency').value=filter.currency;$('start').value=filter.start;$('end').value=filter.end;
$('summary').innerHTML=[['高价值运营数据',M.cards.length,'按业务选接口，不以是否已取数删卡'],['业务分类',categories.length,'销售、投放、履约、库存、财务…'],['有真实记录的卡片',M.cards.filter(c=>c.count>0).length,'其他卡片提供模拟样例；非接口成功率'],['数据导出时间',M.generatedAt.slice(5,10).replace('-',' / '),'卡片另标来源及实际采集时间']].map(([l,v,n])=>`<article><span>${l}</span><strong>${v}</strong><small>${n}</small></article>`).join('');
$('gap-list').innerHTML=M.gaps.map(([title,note])=>`<article><h3>${esc(title)}</h3><p>${esc(note)}</p></article>`).join('');
$('generated').textContent=`${M.source}。导出于 ${new Date(M.generatedAt).toLocaleString('zh-CN',{hour12:false})}。包含真实商业数据，请仅向获授权人员分享。`;

async function loadDataset(c){
  if(!loads.has(c.id))loads.set(c.id,(async()=>{
    if(!window.STUDIO_DATA[c.id])await new Promise((resolve,reject)=>{const script=document.createElement('script');script.src=c.file;script.onload=resolve;script.onerror=()=>reject(new Error('数据文件未加载，请完整解压目录'));document.head.append(script);});
    if(!('DecompressionStream' in window))throw new Error('请使用新版Chrome或Edge打开离线数据');
    const bytes=Uint8Array.from(atob(window.STUDIO_DATA[c.id]),c=>c.charCodeAt(0));
    const stream=new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));
    return JSON.parse(await new Response(stream).text());
  })().catch(error=>{loads.delete(c.id);throw error;}));
  return loads.get(c.id);
}
function numberSum(rows,key){const known=rows.map(r=>r[key]).filter(v=>typeof v==='number'&&Number.isFinite(v));return known.length?known.reduce((a,b)=>a+b,0):null;}
function rangeRows(c,pack,scope){
  const monetary=c.unit==='原币'||c.id==='traffic'||c.id==='traffic_asin';
  let rows=pack.rows.filter(r=>(r.country===filter.country||r.country==='ALL'||r.country==='ACCOUNT')&&(!monetary||r.currency===filter.currency));
  // A country-mapped subset must never be added to a global/account total.
  const countryScope=rows.some(r=>r.country===filter.country)?filter.country:rows.some(r=>r.country==='ALL')?'ALL':'ACCOUNT';
  rows=rows.filter(r=>r.country===countryScope);
  if(!c.snapshot)rows=rows.filter(r=>c.id==='traffic_asin'?r.start>=filter.start&&r.end<=filter.end:r.date&&r.date>=filter.start&&r.date<=filter.end);
  if(c.id==='finance_summary')rows=pack.rows.filter(r=>(r.country===filter.country||r.country==='ACCOUNT')&&r.currency===filter.currency&&r.begin?.slice(0,10)===filter.start&&r.finish?.slice(0,10)===filter.end);
  if(c.id==='traffic_asin'){
    // Never combine a period total with its daily fragments.
    const daily=rows.filter(r=>r.start===r.end);
    rows=daily.length?daily:rows.filter(r=>r.start===filter.start&&r.end===filter.end);
  }
  const scopes=[...new Set(rows.map(r=>r.scope))];
  const selectedScope=scopes.includes(scope)?scope:scopes[0];
  rows=rows.filter(r=>r.scope===selectedScope);
  return {rows,scopes,scope:selectedScope};
}
function view(c,pack,scope){
  const real=rangeRows(c,pack,scope),mode=filter.mode||'auto';
  const chartable=real.rows.some(r=>c.metric==='count'||typeof r[c.metric]==='number');
  const simulated=mode==='sample'||mode==='auto'&&(!real.rows.length||!chartable);
  const chosen=simulated?rangeRows(c,{rows:pack.samples||[]},scope):real,rows=chosen.rows;
  const amount=numberSum(rows,'amount'),units=numberSum(rows,'units'),sales=numberSum(rows,'sales'),sessions=numberSum(rows,'sessions');
  const dates=[...new Set(rows.map(r=>r.date||r.start).filter(Boolean))].sort();
  const tasks=pack.jobs.filter(j=>(j.country===filter.country||['ALL','ACCOUNT'].includes(j.country))&&(c.snapshot||!j.start||!j.end||j.start<=filter.end&&j.end>=filter.start));
  const unfinished=tasks.filter(j=>j.status!=='done').length;
  const expected=Math.round((Date.parse(filter.end)-Date.parse(filter.start))/86400000)+1;
  let metrics=[];
  if(c.id.startsWith('ads_')&&!c.snapshot)metrics=[['广告花费',amount,filter.currency],['归因销售',sales,filter.currency],['ACOS',amount!=null&&sales>0?amount/sales*100:null,'%'],['归因购买数',units,'次']];
  else if(c.id.startsWith('ads_config_'))metrics=[['配置记录',rows.length||null,'条'],['启用',rows.length?rows.filter(r=>r.state==='ENABLED').length:null,'条'],['暂停',rows.length?rows.filter(r=>r.state==='PAUSED').length:null,'条'],['归档',rows.length?rows.filter(r=>r.state==='ARCHIVED').length:null,'条']];
  else if(c.id==='sales')metrics=[['销售额',amount,filter.currency],['订单数',numberSum(rows,'orders'),'单'],['销售件数',units,'件'],['有记录日期',dates.length,'天']];
  else if(['traffic','traffic_asin'].includes(c.id))metrics=[['访问次数',sessions,'次'],['销售件数',units,'件'],['件数 / 访问',units!=null&&sessions>0?units/sessions*100:null,'%'],['销售额',amount,filter.currency]];
  else if(c.id==='inventory')metrics=[['当前可售',units,'件'],['预留',numberSum(rows,'reserved'),'件'],['不可售',numberSum(rows,'unsellable'),'件'],['明确零可售',rows.length?rows.filter(r=>r.units===0).length:null,'SKU']];
  else if(c.id==='inventory_planning')metrics=[['规划SKU',rows.length||null,'个'],['0–90天库存',numberSum(rows,'age90'),'件'],['91–180天',numberSum(rows,'age180'),'件'],['181–270天',numberSum(rows,'age270'),'件']];
  else if(['prices','featured_offer','foep'].includes(c.id))metrics=[['有价格记录',rows.filter(r=>r.amount!=null).length||null,'条'],['最低参考价',rows.some(r=>r.amount!=null)?Math.min(...rows.filter(r=>r.amount!=null).map(r=>r.amount)):null,filter.currency]];
  else if(c.id==='coupons')metrics=[['领取次数',numberSum(rows,'clips'),'次'],['核销次数',units,'次'],['核销 / 领取',numberSum(rows,'clips')>0?units/numberSum(rows,'clips')*100:null,'%'],['活动累计销售',amount,filter.currency]];
  else if(c.id==='promotion_performance')metrics=[['活动数',rows.length||null,'个'],['浏览次数',numberSum(rows,'pageViews'),'次'],['销售件数',units,'件'],['活动累计销售',amount,filter.currency]];
  else if(c.id==='balance_history')metrics=[['有记录日期',dates.length||null,'天'],['最近余额',rows.length?rows.filter(r=>r.date===dates.at(-1)).reduce((s,r)=>s+(r.amount||0),0):null,filter.currency]];
  else if(c.id==='restock')metrics=[['建议补货件数',units,'件'],['建议商品',rows.length||null,'个'],['覆盖少于14天',rows.length?rows.filter(r=>r.coverage!=null&&r.coverage<14).length:null,'个']];
  else if(c.id==='stranded')metrics=[['滞留可履约件数',units,'件'],['商品记录',rows.length||null,'条'],['预留件数',numberSum(rows,'reserved'),'件']];
  else if(c.id==='catalog')metrics=[['商品记录',rows.length||null,'条'],['图片数量',numberSum(rows,'images'),'张'],['有关联关系',rows.length?rows.filter(r=>r.relations>0).length:null,'条']];
  else if(c.id==='aplus_content')metrics=[['内容记录',rows.length||null,'份'],['内容模块',numberSum(rows,'modules'),'个']];
  else if(c.id==='finance_balances')metrics=[['余额记录',rows.length||null,'条'],['可用',numberSum(rows,'available'),filter.currency],['预留',numberSum(rows,'reserved'),filter.currency]];
  else if(c.id==='health')metrics=[['返回指标',rows.length||null,'个'],['返回官方状态',rows.length?rows.filter(r=>r.state).length:null,'个']];
  else metrics=[['当前记录',rows.length||null,'条'],...(amount!=null?[['已取得金额小计',amount,filter.currency]]:[]),...(units!=null?[['已取得件数',units,'件']]:[])];
  const groups=new Map();
  for(const r of rows){
    const label=c.chart==='status'?r.state:r.label||r.sku||r.date||'未返回名称';
    const groupKey=['ads_campaign','ads_group'].includes(c.id)?JSON.stringify([r.campaign,label]):String(label);
    const value=c.metric==='count'?1:r[c.metric];
    if(typeof value!=='number'||!Number.isFinite(value))continue;
    const prior=groups.get(groupKey)||{label:cn(label),value:0};prior.value+=value;groups.set(groupKey,prior);
  }
  const points=[...groups.values()].sort((a,b)=>Math.abs(b.value)-Math.abs(a.value));
  const byDate=new Map();for(const r of rows){if(!r.date||typeof r[c.metric]!=='number')continue;byDate.set(r.date,(byDate.get(r.date)||0)+r[c.metric]);}
  const trend=[...byDate].sort((a,b)=>a[0].localeCompare(b[0]));
  const latest=rows.reduce((d,r)=>r.observed>d?r.observed:d,'');
  const countries=[...new Set(rows.map(r=>r.country))];
  const scopeLabel=countries.map(v=>M.countries[v]||v).join(' / ')||'当前范围无数据';
  const hasDaily=['sales','traffic'].includes(c.id)||c.id.startsWith('ads_')&&!c.snapshot;
  const realCoverage=c.snapshot?'最新成功快照 · 不受历史日期筛选':c.id==='traffic_asin'?`${dates.length} 个已提供报表起始日 · 未混入区间合计`:hasDaily?`有记录 ${dates.length}/${expected} 天 · 缺日不补零`:`已取得记录 ${rows.length.toLocaleString('zh-CN')} 条 · 非完整性保证`;
  const reason=mode==='sample'?'已选择仅模拟模式':real.rows.length?'真实记录的图表指标未返回':tasks.some(j=>j.status==='done')?'成功任务存在，但当前范围无真实记录':'当前范围尚未取得可展示的真实记录';
  const coverage=simulated?`模拟样例 · ${reason}；不代表真实店铺结果或接口可用性`:realCoverage;
  const state=simulated?'模拟样例':!rows.length?'当前范围无记录':unfinished||c.readErrors||hasDaily&&dates.length<expected?'已采集部分':'已有归档';
  return {...chosen,metrics,points,trend,latest,scopeLabel,coverage,state,unfinished,dates,provenance:simulated?'simulated':'real',realCount:real.rows.length,reason};
}
const colors=['#6d82ea','#9dabef','#bbc6f4','#ddb67f','#a7cbbb','#b8b3d2'];
function chart(c,v){
  if(!v.rows.length)return '<div class="empty-chart">当前范围没有可展示的数据<br>可切换优先真实或仅模拟；不把缺失显示为零</div>';
  if(c.chart==='trend'){
    if(!v.trend.length)return '<div class="empty-chart">已取得记录，但趋势指标未返回</div>';
    const values=v.trend.map(p=>p[1]),max=Math.max(1,...values),min=Math.min(0,...values),first=Date.parse(filter.start),last=Date.parse(filter.end),x=d=>12+(Date.parse(d)-first)/Math.max(86400000,last-first)*296,y=n=>112-(n-min)/(max-min)*90;
    let lines='';v.trend.forEach(([d,n],i)=>{const prior=v.trend[i-1];if(prior&&Date.parse(d)-Date.parse(prior[0])===86400000)lines+=`<line x1="${x(prior[0])}" y1="${y(prior[1])}" x2="${x(d)}" y2="${y(n)}" stroke="#7389e9" stroke-width="2.2"/>`;lines+=`<circle cx="${x(d)}" cy="${y(n)}" r="2.2" fill="#637be4"><title>${esc(d)}：${fmt(n)}</title></circle>`;});
    return `<svg class="trend" viewBox="0 0 320 145" role="img" aria-label="${esc(c.title)}趋势"><line x1="12" x2="308" y1="112" y2="112" stroke="#e7ecf5"/><text x="12" y="12">${fmt(max)}</text>${lines}<text x="12" y="139">${esc(filter.start.slice(5))}</text><text x="308" y="139" text-anchor="end">${esc(filter.end.slice(5))}</text></svg>`;
  }
  const top=v.points.slice(0,5);
  if(!top.length)return '<div class="empty-chart">记录已保存，当前指标未返回<br>请查看明细字段</div>';
  if(c.chart==='status'){
    const total=v.points.reduce((n,p)=>n+p.value,0),parts=v.points.slice(0,5);if(v.points.length>5)parts.push({label:'其他状态',value:v.points.slice(5).reduce((n,p)=>n+p.value,0)});
    let offset=0;const circles=parts.map((p,i)=>{const n=p.value/total*301.6,svg=`<circle cx="64" cy="64" r="48" fill="none" stroke="${colors[i]}" stroke-width="15" stroke-dasharray="${n} ${301.6-n}" stroke-dashoffset="${-offset}" transform="rotate(-90 64 64)"/>`;offset+=n;return svg;}).join('');
    return `<div class="ring"><svg viewBox="0 0 128 128" role="img" aria-label="状态分布">${circles}<text x="64" y="65" text-anchor="middle" fill="#253353" font-size="22">${total}</text><text x="64" y="83" text-anchor="middle" fill="#8d99ad" font-size="10">${esc(c.unit)}</text></svg><ul>${parts.map((p,i)=>`<li><i style="background:${colors[i]}"></i>${esc(p.label)} ${fmt(p.value)}</li>`).join('')}</ul></div>`;
  }
  const max=Math.max(1,...top.map(p=>Math.abs(p.value)));
  return `<div class="bars"><span class="meta">${esc(c.fields[c.metric]?.[0]||'记录数量')} · 前5项</span>${top.map(p=>`<div class="bar-line"><span title="${esc(p.label)}">${esc(p.label)}</span><b>${fmt(p.value)}</b><i><em class="${p.value<0?'negative':''}" style="width:${Math.abs(p.value)/max*100}%"></em></i></div>`).join('')}</div>`;
}
function cardHTML(c,v){
  const selected=draft?.cards.has(c.id),partial=v.state!=='已有归档';
  return `<article class="card${selected?' selected':''}" data-card="${esc(c.id)}" data-provenance="${v.provenance}"><div class="card-head"><span class="category">${esc(c.category)}</span><span class="badge${v.provenance==='simulated'?' simulated':partial?' partial':''}">${esc(v.state)}</span>${draft?`<input type="checkbox" aria-label="选择${esc(c.title)}" data-select="${c.id}" ${selected?'checked':''}>`:''}</div><h3>${esc(c.title)}</h3><p class="question">${esc(c.question)}</p><div class="meta">${esc(c.provider)} · ${v.provenance==='simulated'?'模拟站点：':''}${esc(v.scopeLabel)}${c.unit==='原币'?' · '+esc(filter.currency):''}</div><div class="metrics">${v.metrics.map(([l,n,u])=>`<div><small>${esc(l)}</small><strong>${fmt(n)}</strong><em>${esc(u)}</em></div>`).join('')}</div><div class="chart-title"><span>${v.provenance==='simulated'?'模拟 · ':''}${c.chart==='trend'?'日期趋势':c.chart==='status'?'状态分布':'主要对象排行 · 按绝对值'}</span><span>${esc(c.unit==='原币'?filter.currency:c.unit)}</span></div><div class="chart">${chart(c,v)}</div><p class="coverage">${esc(v.coverage)}${v.unfinished?`；相关范围有 ${v.unfinished} 个未完成/异常任务`:''}</p><div class="card-bottom"><span class="frequency">↻ ${esc(c.frequency)}<br>${v.provenance==='simulated'?'数值全部虚构 · 依据官方字段展示':`采集：${v.latest?esc(new Date(v.latest).toLocaleString('zh-CN',{hour12:false})):'当前范围未取得'}`}</span><button data-detail="${c.id}">查看数据与接口说明 ↗</button></div></article>`;
}
function visibleCards(){const q=$('search').value.trim().toLowerCase();const board=saved.find(b=>b.id===activeBoard);return M.cards.filter(c=>(draft||!board?category==='全部'||c.category===category:board.cards.includes(c.id))&&(!q||[c.title,c.question,c.operation,c.category].join(' ').toLowerCase().includes(q)));}
function renderNav(){
  $('categories').innerHTML=[...categories,'全部'].map(name=>`<button data-category="${esc(name)}" aria-current="${!activeBoard&&category===name}">${esc(name)}<span>${name==='全部'?M.cards.length:M.cards.filter(c=>c.category===name).length}</span></button>`).join('');
  $('boards').innerHTML=saved.length?saved.map(b=>`<button data-board="${esc(b.id)}" aria-current="${activeBoard===b.id}">${esc(b.name)}<span>${b.cards.length}</span></button>`).join(''):'<p class="meta">创建后将显示在这里</p>';
}
async function render(){
  const turn=++version;renderNav();const board=saved.find(b=>b.id===activeBoard);
  $('section-title').textContent=draft?'选择工作台数据':board?.name||category;
  $('section-description').textContent=draft?'跨业务分类勾选卡片，真实与模拟标记始终保留，完成后点击保存。':board?'已保存的数据组合。可编辑卡片或导出给看板制作人员。':descriptions[category]||'按运营价值精选，优先真实数据，缺失以模拟样例演示。';
  $('selection').hidden=!draft;$('selection-title').textContent=draft?`正在创建 / 编辑：${draft.name}`:'';
  $('selected-count').textContent=draft?`已选 ${draft.cards.size} 张`:'';$('save').disabled=!draft?.cards.size;
  $('export').disabled=!board||!!draft;
  $('status').innerHTML=board&&!draft?'<button id="edit-board">编辑卡片</button> <span>导出将使用当前筛选范围，并明确标记数据缺口。</span>':'';
  const cards=visibleCards();$('cards').innerHTML=cards.map(c=>`<article class="card"><h3>${esc(c.title)}</h3><div class="loading"></div><p class="meta">正在读取本地归档…</p></article>`).join('');
  if(!cards.length){$('cards').innerHTML='<p>没有匹配的数据卡片，请更换分类或搜索条件。</p>';return;}
  const results=await Promise.all(cards.map(async c=>{try{const pack=await loadDataset(c),v=view(c,pack);return {c,v,html:cardHTML(c,v)};}catch(e){return {c,html:`<article class="card"><h3>${esc(c.title)}</h3><div class="empty-chart">${esc(e.message)}</div><button data-retry="1">重试读取</button></article>`};}}));
  if(turn!==version)return;currentViews=new Map(results.filter(r=>r.v).map(r=>[r.c.id,r.v]));$('cards').innerHTML=results.map(r=>r.html).join('');
}
function fieldTable(c,rows,limit=80){const fields=Object.entries(c.fields);return `<div class="table-wrap"><table><thead><tr>${fields.map(([,f])=>`<th>${esc(f[0])}</th>`).join('')}<th>归属范围</th><th>数据来源</th><th>实际采集时刻</th></tr></thead><tbody>${rows.slice(0,limit).map(r=>`<tr>${fields.map(([k])=>`<td title="${esc(r[k])}">${typeof r[k]==='number'?fmt(r[k]):esc(cn(r[k]))}</td>`).join('')}<td>${esc(M.countries[r.country]||r.country)}</td><td>${r.provenance==='simulated'?'模拟样例':'真实归档'}</td><td>${r.provenance==='simulated'?'未进行真实采集':esc(r.observed)}</td></tr>`).join('')}</tbody></table></div>`;}
function docs(c){const official=c.official;const paths={'@title':'summaries[].itemName','@asin':'summaries[].asin','@status':'summaries[].status','@issues':'issues[].length（返回问题条数）','@price':'Product.Offers[0].BuyingPrice.ListingPrice.Amount','@currency':'Product.Offers[0].BuyingPrice.ListingPrice.CurrencyCode','@available':'balances[balanceType=AVAILABLE].amount.currencyAmount','@reserved':'balances[balanceType=RESERVED].amount.currencyAmount','@label':'performanceMetrics[].指标对象名称（中文映射）','@rate':'performanceMetrics[].指标.rate / ahrScore / defectsCount（各自单位）','@state':'performanceMetrics[].指标.status / ahrStatus','@target':'performanceMetrics[].指标.targetValue','@begin':'performanceMetrics[].指标.reportingDateRange.reportingDateFrom','@finish':'performanceMetrics[].指标.reportingDateRange.reportingDateTo'};return `<h3>接口作用</h3><p>${esc(c.question)}</p><pre>${esc(c.operation)}</pre><h3>请求与调用说明</h3><pre>${esc(JSON.stringify(c.request,null,2))}</pre><p>计划频率：${esc(c.frequency)}。仅复用现有采集器；本页不向Amazon发送请求。模拟数据不会证明接口已接入。</p><h3>返回数据字段</h3><div class="field-list">${Object.entries(c.fields).map(([,f])=>`<div>${esc(f[0])}<code>${esc(paths[f[1]]||f[1])}</code></div>`).join('')}</div><p>${esc(c.note)}</p><p>${esc(c.sampleBasis)}</p><a href="${official}" target="_blank" rel="noopener noreferrer">打开官方文档 ↗</a>`;}
async function openDetail(id,scope){const c=M.cards.find(c=>c.id===id);if(!c)return;const pack=await loadDataset(c),v=view(c,pack,scope);detailState={c,v};$('detail-title').textContent=c.title;
  $('detail-content').innerHTML=`<p>${esc(c.question)}</p><div class="notice">${v.provenance==='simulated'?'模拟样例，所有数值虚构。':'真实归档。'}${esc(v.scopeLabel)} · ${esc(v.coverage)}。${esc(c.note)}<br>当前筛选可匹配真实记录 ${v.realCount} 条；模拟不计入同步完成率。</div>${v.scopes.length>1?`<label>账户范围<select id="detail-scope">${v.scopes.map((s,i)=>`<option value="${esc(s)}" ${s===v.scope?'selected':''}>账户 ${i+1} · ${esc(s.slice(-6))}</option>`).join('')}</select>（各账户不混合）</label>`:''}<div class="detail-chart">${chart(c,v)}</div><div class="detail-tools"><p>当前展示${v.provenance==='simulated'?'模拟':'真实'}记录 ${v.rows.length.toLocaleString('zh-CN')} 条，预览前80条；导出保留数据来源。</p></div>${fieldTable(c,v.rows)}<details><summary>接口说明、请求参数与返回字段</summary>${docs(c)}</details><p>当前数据集全部真实任务：${esc(JSON.stringify(c.tasks))}。这些是下载任务数量，不是店铺/订单数量；不等于当前筛选期间完整。</p>`;
  if(!$('detail').open)$('detail').showModal();
}
function persist(next){try{localStorage.setItem('dinzee-curated-studio-v1',JSON.stringify(next));saved=next;return true;}catch{$('status').textContent='浏览器无法保存工作台，请使用新版Chrome/Edge并允许本地存储。当前选择仍保留。';return false;}}
function create(){if(draft&&!confirm('已有未保存选择，确定重新创建？'))return;$('board-name').value='';$('create-dialog').showModal();setTimeout(()=>$('board-name').focus(),0);}
$('create').onclick=create;$('create-small').onclick=create;$('create-cancel').onclick=()=>$('create-dialog').close();
$('create-form').onsubmit=e=>{e.preventDefault();const name=$('board-name').value.trim();if(!name){$('board-name').setCustomValidity('请输入工作台名称');$('board-name').reportValidity();return;}draft={id:crypto.randomUUID(),name,cards:new Set()};activeBoard=null;$('create-dialog').close();void render();};
$('board-name').oninput=()=>$('board-name').setCustomValidity('');
$('save').onclick=()=>{if(!draft?.cards.size)return;const board={id:draft.id,name:draft.name,cards:[...draft.cards]};const next=saved.filter(b=>b.id!==board.id).concat(board);if(persist(next)){activeBoard=board.id;draft=null;void render();}};
$('cancel').onclick=()=>{draft=null;void render();};
$('categories').onclick=e=>{const button=e.target.closest('[data-category]');if(button){category=button.dataset.category;activeBoard=null;void render();}};
$('boards').onclick=e=>{const button=e.target.closest('[data-board]');if(!button)return;if(draft&&!confirm('放弃未保存的选择，打开工作台？'))return;draft=null;activeBoard=button.dataset.board;void render();};
$('cards').onchange=e=>{const id=e.target.dataset.select;if(!id||!draft)return;if(e.target.checked)draft.cards.add(id);else draft.cards.delete(id);e.target.closest('.card').classList.toggle('selected',e.target.checked);$('selected-count').textContent=`已选 ${draft.cards.size} 张`;$('save').disabled=!draft.cards.size;};
$('cards').onclick=e=>{const b=e.target.closest('[data-detail]');if(b)void openDetail(b.dataset.detail).catch(error=>{$('status').textContent=error.message;});if(e.target.closest('[data-retry]'))void render();};
$('status').onclick=e=>{if(e.target.id==='edit-board'){const b=saved.find(b=>b.id===activeBoard);if(b){draft={...b,cards:new Set(b.cards)};activeBoard=null;category='全部';void render();}}};
$('search').oninput=()=>void render();
$('filters').onsubmit=e=>{e.preventDefault();if($('start').value>$('end').value){$('end').setCustomValidity('结束日期不能早于开始日期');$('end').reportValidity();return;}filter={country:$('country').value,currency:$('currency').value,start:$('start').value,end:$('end').value,mode:$('data-mode').value};void render();};
$('data-mode').onchange=()=>$('filters').requestSubmit();
$('end').oninput=()=>$('end').setCustomValidity('');$('start').oninput=()=>$('end').setCustomValidity('');
document.querySelectorAll('[data-days]').forEach(b=>b.onclick=()=>{const end=$('end').value;if(!end)return;const d=new Date(end+'T00:00:00Z');d.setUTCDate(d.getUTCDate()-Number(b.dataset.days)+1);$('start').value=d.toISOString().slice(0,10);$('filters').requestSubmit();});
$('detail-close').onclick=()=>$('detail').close();$('detail-content').onchange=e=>{if(e.target.id==='detail-scope'&&detailState)void openDetail(detailState.c.id,e.target.value);};
$('schedule').onclick=()=>$('schedule-dialog').showModal();$('schedule-close').onclick=()=>$('schedule-dialog').close();
for(const id of ['detail','schedule-dialog','create-dialog'])$(id).addEventListener('click',e=>{if(e.target!==$(id))return;const r=$(id).getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)$(id).close();});

// A small, standards-compliant UTF-8 ZIP writer; no server or third-party CDN.
function zip(files){const enc=new TextEncoder(),parts=[],central=[];let offset=0,size=0;const crc=bytes=>{let n=0xffffffff;for(const b of bytes){n^=b;for(let i=0;i<8;i++)n=(n>>>1)^((n&1)?0xedb88320:0);}return(n^0xffffffff)>>>0;};
  for(const file of files){const name=enc.encode(file.name),bytes=enc.encode(file.text),check=crc(bytes),local=new Uint8Array(30+name.length),v=new DataView(local.buffer);v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint16(6,0x800,true);v.setUint16(12,0x21,true);v.setUint32(14,check,true);v.setUint32(18,bytes.length,true);v.setUint32(22,bytes.length,true);v.setUint16(26,name.length,true);local.set(name,30);parts.push(local,bytes);const cd=new Uint8Array(46+name.length),d=new DataView(cd.buffer);d.setUint32(0,0x02014b50,true);d.setUint16(4,20,true);d.setUint16(6,20,true);d.setUint16(8,0x800,true);d.setUint16(14,0x21,true);d.setUint32(16,check,true);d.setUint32(20,bytes.length,true);d.setUint32(24,bytes.length,true);d.setUint16(28,name.length,true);d.setUint32(42,offset,true);cd.set(name,46);central.push(cd);size+=cd.length;offset+=local.length+bytes.length;}
  if(files.length>65535||offset+size>0xffffffff)throw new Error('导出过大，请缩短日期或拆分工作台');const end=new Uint8Array(22),v=new DataView(end.buffer);v.setUint32(0,0x06054b50,true);v.setUint16(8,files.length,true);v.setUint16(10,files.length,true);v.setUint32(12,size,true);v.setUint32(16,offset,true);return new Blob([...parts,...central,end],{type:'application/zip'});
}
$('export').onclick=async()=>{const board=saved.find(b=>b.id===activeBoard);if(!board)return;const button=$('export');button.disabled=true;button.textContent='正在打包…';try{
  const cards=M.cards.filter(c=>board.cards.includes(c.id)),datasets={},views=[];
  for(const c of cards){const pack=await loadDataset(c),v=view(c,pack);datasets[c.id]={definition:c,provenance:v.provenance,realRecordCount:v.realCount,rows:v.rows,coverage:v.coverage,scope:v.scopeLabel,jobs:pack.jobs.filter(j=>j.country===filter.country||['ALL','ACCOUNT'].includes(j.country))};views.push({c,v});}
  const brief={version:2,name:board.name,filter,exportedAt:new Date().toISOString(),source:M.source,complete:false,cards:board.cards,limitations:M.gaps,datasets};
  const html=`<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(board.name)}</title><style>body{font:14px system-ui;background:#f5f7fb;color:#23324b;margin:30px auto;max-width:1150px;padding:20px}article{background:white;border:1px solid #e2e7f0;border-radius:12px;padding:24px;margin:20px 0}svg{max-width:420px;width:100%;height:150px}.metrics{display:flex;gap:30px;flex-wrap:wrap;margin:18px 0}.metrics small{display:block;color:#75849b}.metrics strong{font-size:24px}.metrics em{font-size:12px;margin:5px}p{line-height:1.8;color:#63728b}table{border-collapse:collapse;white-space:nowrap;font-size:12px}td,th{padding:10px;border:1px solid #e5eaf0}.table-wrap{overflow:auto;max-height:420px}.bars{max-width:500px}.bar-line{margin:12px 0}.bar-line b{float:right}.bar-line i{display:block;height:8px;background:#eef1f8}.bar-line em{display:block;height:100%;background:#7b8ded}.ring{display:flex;gap:20px}.ring svg{width:140px}.ring ul{list-style:none}.field-list{display:grid;grid-template-columns:1fr 1fr;gap:12px}code{display:block;color:#75849b;overflow-wrap:anywhere}pre{white-space:pre-wrap;background:#f4f6fb;padding:15px}button{display:none}</style><h1>${esc(board.name)}</h1><p>数据选择包（逐卡标注真实 / 模拟） · ${esc(filter.start)}—${esc(filter.end)} · SP站点 ${esc(filter.country)} · 原币 ${esc(filter.currency)}<br>全球广告/区域账户单独标注；不是90天完整性证明。全部当前筛选记录及接口契约见「看板需求与数据.json」。</p>${views.map(({c,v})=>`<article><h2>${esc(c.title)} · ${v.provenance==='simulated'?'模拟样例（数值虚构）':'真实数据'}</h2><p>${esc(c.question)}<br>${esc(v.scopeLabel)} · ${esc(v.coverage)}</p><div class="metrics">${v.metrics.map(([l,n,u])=>`<div><small>${esc(l)}</small><strong>${fmt(n)}</strong><em>${esc(u)}</em></div>`).join('')}</div>${chart(c,v)}<details><summary>数据预览与接口说明</summary>${fieldTable(c,v.rows)}${docs(c)}</details></article>`).join('')}<p>包含真实商业数据，只向授权人员分享。未包含OAuth凭证、买家信息或完整原始响应。本包不会自动同步。</p></html>`;
  const blob=zip([{name:'index.html',text:html},{name:'看板需求与数据.json',text:JSON.stringify(brief,null,2)},{name:'使用说明.txt',text:'双击index.html查看图表；看板需求与数据.json包含选中接口、当前范围全部脱敏字段记录、来源与缺口，可交给看板制作人员。不得把不同广告维度重复相加。'}]);
  const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=board.name.replace(/[\\/:*?"<>|]/g,'_')+'.zip';a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);$('status').textContent='ZIP已生成，包含独立预览、所选接口说明和当前范围数据。';
  }catch(e){$('status').textContent='导出失败：'+e.message;}finally{button.disabled=false;button.textContent='导出工作台 ZIP';}};
if(!storageAvailable)$('status').textContent='本地存储暂不可用，浏览不受影响，但工作台可能无法保存。';
void render();
