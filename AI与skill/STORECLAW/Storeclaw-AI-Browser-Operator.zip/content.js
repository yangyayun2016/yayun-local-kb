// =============================================================
// Storeclaw AI Browser Operator - Content Script (slim shell)
// =============================================================
// All actions have moved to the background.js CDP path. Only __ping__ remains here,
// so legacy code and diagnostics can still use sendToTab for liveness checks.
// =============================================================

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const action = message?.action;
  if (action === "__ping__") {
    sendResponse({ ok: true, result: { loaded: true } });
    return false;
  }
  sendResponse({ ok: false, error: `Action handled by background CDP path: ${action}` });
  return false;
});

console.log("[StoreclawOperator] content script loaded (slim CDP shell)");
