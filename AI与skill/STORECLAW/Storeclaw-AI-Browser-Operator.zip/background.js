// =============================================================
// Storeclaw AI Browser Operator - Background Service Worker
// =============================================================
// Architecture:
//   1. Maintain a singleton WebSocket connection to the browser extension registry (/browser-ex/registry).
//   2. Keep only local browser state (tab/window/group), not server-side session bindings.
//   3. Use one message protocol, proxied by the gateway to blaze-agent-service.
// =============================================================

const DEFAULT_WS_URL = "wss://www.storeclaw.ai/browser-ex/registry";
const WS_URL_STORAGE_KEY = "gatewayWsUrl";

// Heartbeat detects silently broken connections quickly; reconnect pacing is
// still controlled separately by the exponential backoff below.
const HEARTBEAT_INTERVAL = 5000;
const HEARTBEAT_ACK_TIMEOUT = 15000;
const FULL_SNAPSHOT_INTERVAL = 60000;
const RECONNECT_BASE_DELAY = 1000;
const RECONNECT_MAX_DELAY = 30000;
const EVENT_LOG_LIMIT = 5;
const TAB_READY_TIMEOUT_MS = 10000;
const PAGE_INTERACTIVE_TIMEOUT_MS = 10000;
const SCROLL_SETTLE_TIMEOUT_MS = 2500;
const SCROLL_STABLE_WINDOW_MS = 350;
const SCREENSHOT_STABILIZE_DELAY_MS = 250;
const AUTOMATION_WINDOW_WIDTH = 1200;
const AUTOMATION_WINDOW_HEIGHT = 900;
const DEFAULT_SCREENSHOT_FORMAT = "jpeg";
const DEFAULT_SCREENSHOT_QUALITY = 70;
const HEADER_INJECT_RULE_ID = 1001;
const HEADER_INJECT_RULE_ID_LOCAL = 1002;
const RESTRICTED_URL_PREFIXES = [
  "chrome://",
  "chrome-extension://",
  "edge://",
  "about:",
  "file://"
];

// Keep the WS connection only while an http(s) tab points to the configured Storeclaw page paths.
// Hostname is not restricted, which makes environment switching and local debugging easier.
const TRIGGER_PATH_EXACT = "/app/chat";
const TRIGGER_PATH_PREFIX = "/app/chat/";
const TRIGGER_PATH_ADDITIONAL_EXACT = new Set([
  "/app/my-browser/settings"
]);
const TRIGGER_PROTOCOLS = new Set(["https:", "http:"]);
const AUTO_DISCONNECT_DELAY_MS = 10_000;

let deviceId = null;
let socket = null;
let wsUrl = DEFAULT_WS_URL;
let isConnected = false;
let isConnecting = false;
let isRegistered = false;
let manualDisconnect = false;
let heartbeatTimer = null;
let reconnectTimer = null;
let pendingDisconnectTimer = null;
let heartbeatInFlight = false;
let lastFullSnapshotAt = 0;
let reconnectAttempt = 0;
let lastError = "";
let statusText = "Disconnected";
let eventLog = [];
let lastHeartbeatAckAt = 0;
let lastRegisterSentAt = 0;
let heartbeatSequence = 0;

// Local browser state (in memory).
let groupStore = {};      // groupId -> { windowId, tabIds, placeholderId?, name }
let tabToGroupMap = {};   // tabId -> groupId

// When a page opens a new tab directly (missed target=_blank interception, sandboxed iframe,
// async window.open, etc.), openerTabId links it to the triggering action. The next completed
// action on that opener drains the buffer into result.new_tabs so Python/the LLM knows it happened.
const NEW_TAB_BUFFER_TTL_MS = 3000;
const NEW_TAB_WAIT_MS = 1500;
const NEW_TAB_GRACE_MS = 150;
const recentlyOpenedByOpener = new Map(); // openerTabId -> Array<{ tabId, openedAt, url }>

function drainNewTabsBuffer(openerTabId) {
  const buf = recentlyOpenedByOpener.get(openerTabId) || [];
  recentlyOpenedByOpener.delete(openerTabId);
  const now = Date.now();
  return buf.filter(e => now - e.openedAt < NEW_TAB_BUFFER_TTL_MS);
}

async function collectNewTabsForOpener(openerTabId) {
  if (!openerTabId) return [];
  // First collect leftovers from the previous action, where onCreated arrived after the wait window.
  // Do not return here: this action may also create a new tab, so keep waiting.
  const leftovers = drainNewTabsBuffer(openerTabId);

  await new Promise((resolve) => {
    let done = false;
    let graceTimer = null;
    const finalize = () => {
      if (done) return;
      done = true;
      if (graceTimer) clearTimeout(graceTimer);
      clearTimeout(hardTimer);
      chrome.tabs.onCreated.removeListener(listener);
      // Let the main onCreated listener push the last entry into the buffer before draining.
      setTimeout(resolve, 50);
    };
    const listener = (tab) => {
      if (tab.openerTabId !== openerTabId) return;
      // After the first new tab arrives, keep a short grace period to catch quick followers.
      if (!graceTimer) graceTimer = setTimeout(finalize, NEW_TAB_GRACE_MS);
    };
    chrome.tabs.onCreated.addListener(listener);
    const hardTimer = setTimeout(finalize, NEW_TAB_WAIT_MS);
  });

  const arrived = drainNewTabsBuffer(openerTabId);
  const seen = new Set();
  const merged = [];
  for (const e of [...leftovers, ...arrived]) {
    if (seen.has(e.tabId)) continue;
    seen.add(e.tabId);
    merged.push(e);
  }
  return await enrichNewTabs(merged);
}

function startNewTabsCapture({ sourceTabId, sourceWindowId, waitMs = NEW_TAB_WAIT_MS }) {
  const sourceId = Number(sourceTabId);
  const sourceWinId = sourceWindowId == null ? null : Number(sourceWindowId);
  const entries = [];
  const seen = new Set();
  let done = false;
  let finishResolve = null;
  let hardTimer = null;
  let graceTimer = null;

  const addEntry = (entry) => {
    const tabId = Number(entry?.tabId);
    if (!Number.isInteger(tabId) || tabId <= 0 || seen.has(tabId)) return;
    seen.add(tabId);
    entries.push({
      tabId,
      openedAt: Number(entry.openedAt) || Date.now(),
      url: entry.url || "",
      windowId: entry.windowId,
      openerTabId: entry.openerTabId
    });
    if (!done && finishResolve && !graceTimer) {
      graceTimer = setTimeout(finishResolve, NEW_TAB_GRACE_MS);
    }
  };

  for (const entry of drainNewTabsBuffer(sourceId)) addEntry(entry);

  const shouldCapture = (tab) => {
    if (!tab || !Number.isInteger(tab.id)) return false;
    if (tab.openerTabId === sourceId) return true;
    if (tab.openerTabId != null) return false;
    return sourceWinId != null && tab.windowId === sourceWinId;
  };

  const listener = (tab) => {
    if (!shouldCapture(tab)) return;
    addEntry({
      tabId: tab.id,
      openedAt: Date.now(),
      url: tab.pendingUrl || tab.url || "",
      windowId: tab.windowId,
      openerTabId: tab.openerTabId
    });
  };

  chrome.tabs.onCreated.addListener(listener);

  return {
    async finish() {
      if (done) return [];
      await new Promise((resolve) => {
        finishResolve = resolve;
        if (entries.length && !graceTimer) {
          graceTimer = setTimeout(resolve, NEW_TAB_GRACE_MS);
        }
        hardTimer = setTimeout(resolve, waitMs);
      });
      done = true;
      if (hardTimer) clearTimeout(hardTimer);
      if (graceTimer) clearTimeout(graceTimer);
      chrome.tabs.onCreated.removeListener(listener);
      for (const entry of drainNewTabsBuffer(sourceId)) addEntry(entry);
      entries.sort((a, b) => a.openedAt - b.openedAt);
      return await enrichNewTabs(entries);
    }
  };
}

async function enrichNewTabs(entries) {
  const out = [];
  for (const e of entries) {
    let url = e.url;
    let title = "";
    try {
      const t = await chrome.tabs.get(e.tabId);
      if (t) {
        url = t.url || t.pendingUrl || url;
        title = t.title || "";
      }
    } catch (_) {}
    out.push({ tab_id: e.tabId, url, title });
  }
  return out;
}

function attachNewTabs(result, newTabs) {
  if (!newTabs || !newTabs.length) return result;
  if (result && typeof result === "object") {
    if (!result.result || typeof result.result !== "object") result.result = {};
    result.result.new_tabs = newTabs;
  }
  return result;
}

// CDP manager (session-level long-lived connection).
// keepAlive=true (default): keep tabs attached after they enter a group and do not detach
// after each tool call. This avoids repeated debugger banners. Only cdpForceDetach truly
// detaches, and it is used when a tab closes or leaves a group.
// refCount only protects concurrent tool calls from detaching each other.
const cdpAttached = new Map(); // tabId → { refCount, keepAlive, consoleEntries, networkEntries }

// refId -> backendNodeId mapping, one per tab.
// read_page assigns ref_N values to visible/interactive AX nodes. cdp_mouse_event and similar
// calls use refId to look up backendNodeId here, then use CDP for live boxes and scrolling.
// The map is cleared on navigation or tab close.
const refMaps = new Map(); // tabId → { counter, refs: Map<refId, backendNodeId> }

function getRefMap(tabId, { reset = false } = {}) {
  let entry = refMaps.get(tabId);
  if (!entry || reset) {
    entry = { counter: 0, refs: new Map() };
    refMaps.set(tabId, entry);
  }
  return entry;
}

function clearRefMap(tabId) {
  refMaps.delete(tabId);
}

chrome.debugger.onEvent.addListener((src, method, params) => {
  const state = cdpAttached.get(src.tabId);
  if (!state) return;
  if (method === "Runtime.consoleAPICalled") {
    state.consoleEntries.push({ type: params.type, args: params.args, ts: Date.now() });
    if (state.consoleEntries.length > 500) state.consoleEntries.shift();
  } else if (method === "Network.responseReceived" || method === "Network.requestWillBeSent") {
    state.networkEntries.push({ method, params, ts: Date.now() });
    if (state.networkEntries.length > 500) state.networkEntries.shift();
  }
});

chrome.debugger.onDetach.addListener((src) => {
  cdpAttached.delete(src.tabId);
  clearRefMap(src.tabId);
});

// Clean CDP state when a tab closes. Chrome forces debugger detach; this only clears maps.
chrome.tabs.onRemoved.addListener((tabId) => {
  cdpAttached.delete(tabId);
  clearRefMap(tabId);
});

async function cdpAttach(tabId) {
  if (!cdpAttached.has(tabId)) {
    await chrome.debugger.attach({ tabId }, "1.3");
    cdpAttached.set(tabId, { refCount: 0, keepAlive: true, consoleEntries: [], networkEntries: [] });
    await chrome.debugger.sendCommand({ tabId }, "Runtime.enable");
    await chrome.debugger.sendCommand({ tabId }, "Network.enable");
  }
  cdpAttached.get(tabId).refCount++;
}

async function cdpDetach(tabId) {
  const state = cdpAttached.get(tabId);
  if (!state) return;
  state.refCount = Math.max(0, state.refCount - 1);
  // With keepAlive=true, keep the connection open; only cdpForceDetach actually detaches.
  if (state.refCount === 0 && !state.keepAlive) {
    cdpAttached.delete(tabId);
    await chrome.debugger.detach({ tabId }).catch(() => {});
  }
}

// Explicit detach, used when a tab closes, leaves a group, or is manually released.
async function cdpForceDetach(tabId) {
  cdpAttached.delete(tabId);
  await chrome.debugger.detach({ tabId }).catch(() => {});
}

// CDP helpers for selector-based actions (Phase B/C).
// Shared selector parsing, box calculation, and expression execution for runCdpSelectorAction.

function makeActionError(message, { code, suggestion, diagnostics } = {}) {
  const err = new Error(message);
  if (code) err.code = code;
  if (suggestion) err.suggestion = suggestion;
  if (diagnostics) err.diagnostics = diagnostics;
  return err;
}

async function cdpEval(tabId, expression, { awaitPromise = false, returnByValue = true, userGesture = true } = {}) {
  const res = await chrome.debugger.sendCommand(
    { tabId }, "Runtime.evaluate",
    { expression, awaitPromise, returnByValue, userGesture }
  );
  if (res.exceptionDetails) {
    const text = res.exceptionDetails.exception?.description
      || res.exceptionDetails.exception?.value
      || res.exceptionDetails.text
      || "Runtime.evaluate failed";
    throw makeActionError(text, { code: "EVAL_FAILED", diagnostics: { tabId, snippet: expression.slice(0, 200) } });
  }
  return res.result?.value;
}

async function cdpQuerySelectorBackend(tabId, selector, { index = 0, timeoutMs = 5000, requireVisible = false } = {}) {
  // Poll the page for the index-th matching element and return backendNodeId.
  // Bridging through Runtime.evaluate + a temporary window reference is too expensive.
  // DOM.performSearch/getSearchResults also cannot be used here because it does not support CSS.
  // Actual path: DOM.getDocument for the root nodeId, DOM.querySelectorAll for nodeIds, then index-th.
  const start = Date.now();
  let lastErr = null;
  while (true) {
    try {
      const { root } = await chrome.debugger.sendCommand({ tabId }, "DOM.getDocument", { depth: 0 });
      const { nodeIds } = await chrome.debugger.sendCommand({ tabId }, "DOM.querySelectorAll", { nodeId: root.nodeId, selector });
      if (Array.isArray(nodeIds) && nodeIds.length > 0 && !requireVisible && nodeIds.length > index) {
        const nodeId = nodeIds[index];
        const desc = await chrome.debugger.sendCommand({ tabId }, "DOM.describeNode", { nodeId });
        const backendNodeId = desc.node?.backendNodeId;
        if (backendNodeId) return { nodeId, backendNodeId };
      }
      if (Array.isArray(nodeIds) && nodeIds.length > 0 && requireVisible) {
        let visibleIndex = 0;
        for (const nodeId of nodeIds) {
          const desc = await chrome.debugger.sendCommand({ tabId }, "DOM.describeNode", { nodeId });
          const backendNodeId = desc.node?.backendNodeId;
          if (!backendNodeId) continue;
          const box = await cdpGetBox(tabId, backendNodeId);
          if (!box || box.width <= 0 || box.height <= 0) continue;
          if (visibleIndex === index) return { nodeId, backendNodeId };
          visibleIndex += 1;
        }
      }
    } catch (err) { lastErr = err; }
    if (Date.now() - start >= timeoutMs) {
      throw makeActionError(`Selector did not match in ${timeoutMs}ms: ${selector}`, {
        code: "ELEMENT_NOT_FOUND",
        suggestion: "Verify the selector or increase timeout; consider read_page to find the target.",
        diagnostics: { selector, index, lastError: lastErr?.message }
      });
    }
    await new Promise(r => setTimeout(r, 200));
  }
}

async function cdpGetBox(tabId, backendNodeId) {
  try {
    const r = await chrome.debugger.sendCommand({ tabId }, "DOM.getBoxModel", { backendNodeId });
    const border = r?.model?.border;
    if (!Array.isArray(border) || border.length < 8) return null;
    const xs = [border[0], border[2], border[4], border[6]];
    const ys = [border[1], border[3], border[5], border[7]];
    const x = Math.min(...xs), y = Math.min(...ys);
    return { x, y, width: Math.max(...xs) - x, height: Math.max(...ys) - y };
  } catch (_) {
    return null;
  }
}

async function cdpCallOnBackend(tabId, backendNodeId, fnDecl, args = [], opts = {}) {
  const { object } = await chrome.debugger.sendCommand({ tabId }, "DOM.resolveNode", { backendNodeId });
  const res = await chrome.debugger.sendCommand({ tabId }, "Runtime.callFunctionOn", {
    objectId: object.objectId,
    functionDeclaration: fnDecl,
    arguments: args.map(v => ({ value: v })),
    awaitPromise: !!opts.awaitPromise,
    returnByValue: opts.returnByValue !== false,
    userGesture: opts.userGesture !== false
  });
  if (res.exceptionDetails) {
    const text = res.exceptionDetails.exception?.description
      || res.exceptionDetails.exception?.value
      || res.exceptionDetails.text
      || "callFunctionOn failed";
    throw makeActionError(text, { code: "CALL_ON_NODE_FAILED" });
  }
  await chrome.debugger.sendCommand({ tabId }, "Runtime.releaseObject", { objectId: object.objectId }).catch(() => {});
  return res.result?.value;
}

async function cdpDispatchClick(tabId, cx, cy, { clickCount = 1, button = "left" } = {}) {
  const base = { x: cx, y: cy, modifiers: 0, button, clickCount };
  await chrome.debugger.sendCommand({ tabId }, "Input.dispatchMouseEvent", { type: "mouseMoved", ...base, button: "none", clickCount: 0 });
  await new Promise(r => setTimeout(r, 50));
  await chrome.debugger.sendCommand({ tabId }, "Input.dispatchMouseEvent", { type: "mousePressed", ...base });
  await chrome.debugger.sendCommand({ tabId }, "Input.dispatchMouseEvent", { type: "mouseReleased", ...base });
}

async function cdpDispatchKey(tabId, key) {
  // Simple key-name to CDP keyCode/code mapping for the common cases.
  const map = {
    Enter:    { code: "Enter",    key: "Enter",    windowsVirtualKeyCode: 13, text: "\r" },
    Tab:      { code: "Tab",      key: "Tab",      windowsVirtualKeyCode: 9 },
    Escape:   { code: "Escape",   key: "Escape",   windowsVirtualKeyCode: 27 },
    Backspace:{ code: "Backspace",key: "Backspace",windowsVirtualKeyCode: 8 },
    Delete:   { code: "Delete",   key: "Delete",   windowsVirtualKeyCode: 46 },
    ArrowUp:  { code: "ArrowUp",  key: "ArrowUp",  windowsVirtualKeyCode: 38 },
    ArrowDown:{ code: "ArrowDown",key: "ArrowDown",windowsVirtualKeyCode: 40 },
    ArrowLeft:{ code: "ArrowLeft",key: "ArrowLeft",windowsVirtualKeyCode: 37 },
    ArrowRight:{ code: "ArrowRight",key: "ArrowRight",windowsVirtualKeyCode: 39 },
    Space:    { code: "Space",    key: " ",        windowsVirtualKeyCode: 32, text: " " }
  };
  const def = map[key] || { code: key, key: key, text: key.length === 1 ? key : undefined };
  await chrome.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", { type: "keyDown", ...def });
  if (def.text) {
    await chrome.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", { type: "char", ...def });
  }
  await chrome.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", { type: "keyUp", ...def });
}

// Single entrypoint: route by action name. Each branch returns { ok: true, result: {...} }.
async function runCdpSelectorAction(action, tId, params) {
  const selectorOptions = () => ({
    index: Number.isFinite(Number(params.index)) ? Number(params.index) : 0,
    timeoutMs: Number.isFinite(Number(params.timeoutMs)) ? Number(params.timeoutMs) : (Number(params.timeout) * 1000 || 5000),
    requireVisible: params.visible !== false
  });

  if (action === "get_page_meta") {
    const v = await cdpEval(tId, "JSON.stringify({title: document.title, url: location.href})");
    const obj = JSON.parse(v);
    return { ok: true, result: obj };
  }
  if (action === "get_page_text") {
    const maxLen = Math.max(1, Math.min(Number(params.maxLength) || 8000, 200000));
    const v = await cdpEval(tId,
      `(() => {const t=(document.body?.innerText||"").replace(/\\n{3,}/g,"\\n\\n").trim().slice(0,${maxLen});return JSON.stringify({title:document.title,url:location.href,text:t})})()`
    );
    return { ok: true, result: JSON.parse(v) };
  }
  if (action === "get_page_snapshot") {
    const maxLen = Math.max(1, Math.min(Number(params.maxLength) || 8000, 200000));
    const linkLimit = Math.max(1, Math.min(Number(params.linkLimit || params.limit) || 30, 500));
    const v = await cdpEval(tId,
      `(() => {
        const text = (document.body?.innerText||"").replace(/\\n{3,}/g,"\\n\\n").trim().slice(0, ${maxLen});
        const links = Array.from(document.querySelectorAll("a[href]")).slice(0, ${linkLimit})
          .map(a => ({ text: (a.innerText||"").trim(), href: a.href }));
        return JSON.stringify({ title: document.title, url: location.href, text, links });
      })()`
    );
    return { ok: true, result: JSON.parse(v) };
  }
  if (action === "get_html") {
    const maxLen = Math.max(1, Math.min(Number(params.maxLength) || 20000, 500000));
    const v = await cdpEval(tId,
      `JSON.stringify({title:document.title,url:location.href,html:document.documentElement.outerHTML.slice(0,${maxLen})})`
    );
    return { ok: true, result: JSON.parse(v) };
  }
  if (action === "extract_links") {
    const limit = Math.max(1, Math.min(Number(params.limit) || 50, 500));
    const v = await cdpEval(tId,
      `JSON.stringify({title:document.title,url:location.href,links:Array.from(document.querySelectorAll("a[href]")).slice(0,${limit}).map(a=>({text:(a.innerText||"").trim(),href:a.href}))})`
    );
    return { ok: true, result: JSON.parse(v) };
  }

  if (action === "click" || action === "double_click" || action === "hover") {
    const opts = selectorOptions();
    const node = await cdpQuerySelectorBackend(tId, params.selector, { ...opts, requireVisible: true });
    await chrome.debugger.sendCommand({ tabId: tId }, "DOM.scrollIntoViewIfNeeded", { backendNodeId: node.backendNodeId }).catch(() => {});
    const box = await cdpGetBox(tId, node.backendNodeId);
    if (!box || box.width <= 0 || box.height <= 0) {
      throw makeActionError(`Element has no box: ${params.selector}`, { code: "ELEMENT_NOT_VISIBLE", diagnostics: { selector: params.selector } });
    }
    const cx = Math.round(box.x + box.width / 2);
    const cy = Math.round(box.y + box.height / 2);
    if (action === "hover") {
      await chrome.debugger.sendCommand({ tabId: tId }, "Input.dispatchMouseEvent",
        { type: "mouseMoved", x: cx, y: cy, button: "none", clickCount: 0, modifiers: 0 });
      return { ok: true, result: { hovered: true, selector: params.selector, x: cx, y: cy } };
    }
    const clickCount = action === "double_click" ? 2 : 1;
    await cdpDispatchClick(tId, cx, cy, { clickCount });
    return { ok: true, result: { clicked: true, selector: params.selector, x: cx, y: cy, clickCount } };
  }

  if (action === "press") {
    const opts = selectorOptions();
    const node = await cdpQuerySelectorBackend(tId, params.selector, opts);
    await chrome.debugger.sendCommand({ tabId: tId }, "DOM.focus", { backendNodeId: node.backendNodeId });
    const key = params.key || "Enter";
    await cdpDispatchKey(tId, key);
    return { ok: true, result: { pressed: true, selector: params.selector, key } };
  }

  if (action === "fill") {
    const opts = selectorOptions();
    const node = await cdpQuerySelectorBackend(tId, params.selector, opts);
    await chrome.debugger.sendCommand({ tabId: tId }, "DOM.scrollIntoViewIfNeeded", { backendNodeId: node.backendNodeId }).catch(() => {});
    await chrome.debugger.sendCommand({ tabId: tId }, "DOM.focus", { backendNodeId: node.backendNodeId });
    const value = params.value == null ? "" : String(params.value);
    await cdpCallOnBackend(tId, node.backendNodeId,
      `function(v){
        const proto = this.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
        if (setter && (this.tagName === "INPUT" || this.tagName === "TEXTAREA")) {
          setter.call(this, v);
        } else if (this.isContentEditable) {
          this.textContent = v;
        } else {
          this.value = v;
        }
        this.dispatchEvent(new InputEvent("input", { bubbles: true, data: v }));
        this.dispatchEvent(new Event("change", { bubbles: true }));
        return true;
      }`,
      [value]
    );
    return { ok: true, result: { filled: true, selector: params.selector, valueLength: value.length } };
  }

  if (action === "clear_input") {
    const opts = selectorOptions();
    const node = await cdpQuerySelectorBackend(tId, params.selector, opts);
    await chrome.debugger.sendCommand({ tabId: tId }, "DOM.focus", { backendNodeId: node.backendNodeId });
    await cdpCallOnBackend(tId, node.backendNodeId,
      `function(){
        const proto = this.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
        if (setter && (this.tagName === "INPUT" || this.tagName === "TEXTAREA")) setter.call(this, "");
        else if (this.isContentEditable) this.textContent = "";
        else this.value = "";
        this.dispatchEvent(new InputEvent("input", { bubbles: true, data: "" }));
        this.dispatchEvent(new Event("change", { bubbles: true }));
        return true;
      }`
    );
    return { ok: true, result: { cleared: true, selector: params.selector } };
  }

  if (action === "type_text") {
    const opts = selectorOptions();
    const node = await cdpQuerySelectorBackend(tId, params.selector, opts);
    await chrome.debugger.sendCommand({ tabId: tId }, "DOM.focus", { backendNodeId: node.backendNodeId });
    const text = String(params.text || "");
    // Input.insertText triggers composition and React state updates; fall back to dispatchKeyEvent char.
    try {
      await chrome.debugger.sendCommand({ tabId: tId }, "Input.insertText", { text });
    } catch (_) {
      for (const ch of text) {
        await chrome.debugger.sendCommand({ tabId: tId }, "Input.dispatchKeyEvent", { type: "char", text: ch, key: ch });
      }
    }
    return { ok: true, result: { typed: true, selector: params.selector, length: text.length } };
  }

  if (action === "select_option") {
    const opts = selectorOptions();
    const node = await cdpQuerySelectorBackend(tId, params.selector, opts);
    const v = await cdpCallOnBackend(tId, node.backendNodeId,
      `function(value, label){
        if (this.tagName !== "SELECT") return { ok: false, error: "Not a <select>" };
        let matched = false;
        for (const opt of this.options) {
          if ((value != null && opt.value === value) || (label != null && opt.label === label)) {
            this.value = opt.value;
            matched = true; break;
          }
        }
        if (!matched) return { ok: false, error: "No matching option" };
        this.dispatchEvent(new Event("input", { bubbles: true }));
        this.dispatchEvent(new Event("change", { bubbles: true }));
        return { ok: true, value: this.value };
      }`,
      [params.value ?? null, params.label ?? null]
    );
    if (!v?.ok) throw makeActionError(v?.error || "select_option failed", { code: "OPTION_NOT_FOUND", diagnostics: { selector: params.selector, value: params.value, label: params.label } });
    return { ok: true, result: { selected: true, selector: params.selector, value: v.value } };
  }

  if (action === "scroll") {
    await cdpEval(tId,
      `window.scrollBy({left: ${Number(params.x) || 0}, top: ${Number(params.y) || 0}, behavior: ${JSON.stringify(params.behavior || "smooth")}})`
    );
    const scrollSettled = await waitForScrollSettled(tId, SCROLL_SETTLE_TIMEOUT_MS);
    return { ok: true, result: { scrolled: true, x: Number(params.x) || 0, y: Number(params.y) || 0, scrollSettled } };
  }

  if (action === "scroll_to_element") {
    const opts = selectorOptions();
    const node = await cdpQuerySelectorBackend(tId, params.selector, { ...opts, requireVisible: false });
    await chrome.debugger.sendCommand({ tabId: tId }, "DOM.scrollIntoViewIfNeeded", { backendNodeId: node.backendNodeId });
    const scrollSettled = await waitForScrollSettled(tId, SCROLL_SETTLE_TIMEOUT_MS);
    return { ok: true, result: { scrolledToElement: true, selector: params.selector, scrollSettled } };
  }

  if (action === "wait_for") {
    const timeoutMs = Math.max(1, Math.min(Number(params.timeoutMs) || 15000, 120000));
    const selectorJson = JSON.stringify(params.selector || "");
    const wantVisible = params.visible ? "true" : "false";
    const expr = `new Promise((resolve, reject) => {
      const sel = ${selectorJson};
      const start = Date.now();
      const check = () => {
        const el = document.querySelector(sel);
        if (el) {
          const r = el.getBoundingClientRect();
          const visible = r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== "hidden";
          if (!${wantVisible} || visible) { resolve({ found: true, x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) }); return; }
        }
        if (Date.now() - start >= ${timeoutMs}) { reject(new Error("wait_for timed out: " + sel)); return; }
        setTimeout(check, 150);
      };
      check();
    })`;
    const v = await cdpEval(tId, expr, { awaitPromise: true });
    return { ok: true, result: { waited: true, ...v } };
  }

  if (action === "find_elements") {
    const sel = params.selector;
    const limit = Math.max(1, Math.min(Number(params.limit) || 20, 500));
    const includeHidden = !!params.includeHidden;
    const expr = `(() => {
      const all = Array.from(document.querySelectorAll(${JSON.stringify(sel)}));
      const filtered = ${includeHidden ? "all" : "all.filter(el => { const s = getComputedStyle(el); if (s.display==='none' || s.visibility==='hidden' || parseFloat(s.opacity)===0) return false; const r = el.getBoundingClientRect(); return r.width>0 && r.height>0; })"};
      const attrs = ["class", "name", "type", "role", "title", "aria-label", "aria-pressed", "aria-checked", "aria-expanded", "aria-disabled", "disabled", "data-testid"];
      const attrMap = (el) => Object.fromEntries(attrs.map(k => [k, el.getAttribute(k)]).filter(([, v]) => v !== null && v !== ""));
      const accessibleName = (el) => el.getAttribute("aria-label")
        || el.getAttribute("title")
        || (el.innerText || el.textContent || "").trim().replace(/\\s+/g, " ").slice(0, 200)
        || null;
      return JSON.stringify({
        selector: ${JSON.stringify(sel)},
        count: filtered.length,
        elements: filtered.slice(0, ${limit}).map((el, i) => {
          const r = el.getBoundingClientRect();
          const attributes = attrMap(el);
          return {
            index: i,
            tag: el.tagName.toLowerCase(),
            id: el.id || null,
            class: el.className && typeof el.className === "string" ? el.className.slice(0, 200) : null,
            role: el.getAttribute("role") || null,
            name: accessibleName(el),
            title: el.getAttribute("title") || null,
            ariaLabel: el.getAttribute("aria-label") || null,
            ariaPressed: el.getAttribute("aria-pressed") || null,
            ariaChecked: el.getAttribute("aria-checked") || null,
            ariaExpanded: el.getAttribute("aria-expanded") || null,
            ariaDisabled: el.getAttribute("aria-disabled") || null,
            disabled: !!el.disabled || el.getAttribute("disabled") !== null || el.getAttribute("aria-disabled") === "true",
            attributes,
            text: (el.innerText || el.textContent || "").trim().slice(0, 200),
            value: "value" in el ? el.value : undefined,
            href: el.getAttribute("href") || undefined,
            visible: r.width>0 && r.height>0,
            rect: { x: Math.round(r.x), y: Math.round(r.y), width: Math.round(r.width), height: Math.round(r.height) }
          };
        })
      });
    })()`;
    const v = await cdpEval(tId, expr);
    return { ok: true, result: JSON.parse(v) };
  }

  if (action === "get_text" || action === "get_attribute" || action === "is_visible" || action === "get_element_html" || action === "get_element_rect" || action === "get_input_value") {
    const opts = selectorOptions();
    const requireVisible = action === "click" || action === "hover" || action === "double_click";
    const node = await cdpQuerySelectorBackend(tId, params.selector, { ...opts, requireVisible: false });
    let fnDecl;
    let args = [];
    switch (action) {
      case "get_text":         fnDecl = `function(){ return (this.innerText || this.textContent || "").trim(); }`; break;
      case "get_attribute":    fnDecl = `function(name){ return this.getAttribute(name); }`; args = [params.name]; break;
      case "is_visible":       fnDecl = `function(){ const s=getComputedStyle(this); if(s.display==='none'||s.visibility==='hidden'||parseFloat(s.opacity)===0) return false; const r=this.getBoundingClientRect(); return r.width>0 && r.height>0; }`; break;
      case "get_element_html": fnDecl = `function(){ return this.outerHTML; }`; break;
      case "get_element_rect": fnDecl = `function(){ const r=this.getBoundingClientRect(); const s=getComputedStyle(this); const visible = !(s.display==='none'||s.visibility==='hidden'||parseFloat(s.opacity)===0) && r.width>0 && r.height>0; return { visible, rect: { x:Math.round(r.x), y:Math.round(r.y), width:Math.round(r.width), height:Math.round(r.height) } }; }`; break;
      case "get_input_value":  fnDecl = `function(){ return { value: this.value ?? null, tag: this.tagName.toLowerCase() }; }`; break;
    }
    const v = await cdpCallOnBackend(tId, node.backendNodeId, fnDecl, args);
    const baseResult = { selector: params.selector, index: opts.index };
    if (typeof v === "object" && v !== null) return { ok: true, result: { ...baseResult, ...v } };
    if (action === "get_text") return { ok: true, result: { ...baseResult, text: v } };
    if (action === "get_attribute") return { ok: true, result: { ...baseResult, name: params.name, value: v } };
    if (action === "is_visible") return { ok: true, result: { ...baseResult, visible: !!v } };
    if (action === "get_element_html") return { ok: true, result: { ...baseResult, html: v } };
    return { ok: true, result: { ...baseResult, value: v } };
  }

  if (action === "evaluate_js") {
    const code = params.code;
    if (!code || typeof code !== "string") {
      throw makeActionError("Missing or invalid code", { code: "MISSING_CODE", suggestion: "Pass params.code as a string." });
    }
    // Wrap with an async IIFE so await is allowed.
    const wrapped = `(async () => { const __r = await (async () => { ${code} \n})(); try { return JSON.parse(JSON.stringify(__r ?? null)); } catch { return String(__r); } })()`;
    const v = await cdpEval(tId, wrapped, { awaitPromise: true });
    return { ok: true, result: { result: v } };
  }

  throw makeActionError(`Unsupported CDP selector action: ${action}`, { code: "UNSUPPORTED_ACTION" });
}
// ─────────────────────────────────────────────────────────

function log(...args) {
  console.log("[StoreclawOperator]", ...args);
}

function nowIso() {
  return new Date().toISOString();
}

function compactError(err) {
  return err?.message || String(err || "");
}

function commandFailure(error, { code, suggestion, diagnostics, reason } = {}) {
  return {
    ok: false,
    error,
    errorCode: code,
    suggestion,
    diagnostics,
    reason
  };
}

function rememberEvent(type, message, extra = {}) {
  const event = { type, message, at: nowIso(), ...extra };
  eventLog = [event, ...eventLog].slice(0, EVENT_LOG_LIMIT);
  chrome.storage.local.set({ eventLog }).catch(() => {});
  chrome.runtime.sendMessage({ channel: "event_log", event, events: eventLog }).catch(() => {});
}

function updateStatus(connected, text, error = "") {
  isConnected = connected;
  lastError = error || "";
  statusText = text || (connected ? "Connected" : isConnecting ? "Connecting..." : "Disconnected");
  chrome.runtime.sendMessage({
    channel: "status",
    connected,
    connecting: isConnecting,
    text: statusText,
    error: lastError,
    wsUrl
  }).catch(() => {});
}

async function loadWsUrl() {
  const stored = await chrome.storage.local.get(WS_URL_STORAGE_KEY).catch(() => ({}));
  wsUrl = (stored[WS_URL_STORAGE_KEY] || DEFAULT_WS_URL).trim() || DEFAULT_WS_URL;
  return wsUrl;
}

async function setWsUrl(nextUrl) {
  const normalized = (nextUrl || DEFAULT_WS_URL).trim() || DEFAULT_WS_URL;
  await chrome.storage.local.set({ [WS_URL_STORAGE_KEY]: normalized });
  wsUrl = normalized;
  rememberEvent("config", "Gateway URL updated", { wsUrl });
  updateHeaderInjectRules().catch(() => {});
}

function clearHeartbeat() {
  if (heartbeatTimer) {
    clearInterval(heartbeatTimer);
    heartbeatTimer = null;
  }
}

function clearReconnect() {
  if (reconnectTimer) {
    clearTimeout(reconnectTimer);
    reconnectTimer = null;
  }
}

function getTriggerHostname() {
  try { return new URL(wsUrl).hostname; } catch { return ""; }
}

function urlMatchesTrigger(url) {
  if (typeof url !== "string" || !url) return false;
  let u;
  try { u = new URL(url); } catch { return false; }
  if (!TRIGGER_PROTOCOLS.has(u.protocol)) return false;
  const expectedHost = getTriggerHostname();
  if (!expectedHost || u.hostname !== expectedHost) return false;
  return u.pathname === TRIGGER_PATH_EXACT
    || u.pathname.startsWith(TRIGGER_PATH_PREFIX)
    || TRIGGER_PATH_ADDITIONAL_EXACT.has(u.pathname);
}

async function hasAnyTriggerTab() {
  const tabs = await chrome.tabs.query({}).catch(() => []);
  return tabs.some(t => urlMatchesTrigger(t.url || t.pendingUrl));
}

function cancelPendingDisconnect() {
  if (pendingDisconnectTimer) {
    clearTimeout(pendingDisconnectTimer);
    pendingDisconnectTimer = null;
  }
}

// After a matching tab closes, arm one 10s disconnect check. Repeated close events inside
// that window are ignored; when the timer fires, query live state and disconnect only if none remain.
function armDisconnectCheck() {
  if (!socket && !reconnectTimer) return;
  if (pendingDisconnectTimer) return;
  log("armDisconnectCheck: scheduling 10s disconnect probe");
  pendingDisconnectTimer = setTimeout(async () => {
    pendingDisconnectTimer = null;
    const stillHas = await hasAnyTriggerTab();
    log("armDisconnectCheck: timer fired, hasTriggerTab=", stillHas);
    if (!stillHas) {
      log("armDisconnectCheck: no trigger tab, disconnecting WS");
      disconnectSocket();
    }
  }, AUTO_DISCONNECT_DELAY_MS);
}

function resetSocketHealth() {
  isRegistered = false;
  lastHeartbeatAckAt = 0;
  lastRegisterSentAt = 0;
  heartbeatSequence = 0;
}

function scheduleReconnect() {
  if (manualDisconnect || reconnectTimer) return;
  const backoff = Math.min(RECONNECT_BASE_DELAY * (2 ** reconnectAttempt), RECONNECT_MAX_DELAY);
  const jitter = Math.floor(Math.random() * 500);
  const delay = backoff + jitter;
  reconnectAttempt += 1;
  rememberEvent("reconnect", `Reconnect scheduled in ${delay}ms`);
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    connectSocket();
  }, delay);
}

function safeSend(obj) {
  if (socket && socket.readyState === WebSocket.OPEN) {
    socket.send(JSON.stringify(obj));
    return true;
  }
  return false;
}

function isRestrictedUrl(url) {
  if (!url) return false;
  const lower = url.toLowerCase();
  return RESTRICTED_URL_PREFIXES.some(prefix => lower.startsWith(prefix)) && lower !== "about:blank";
}

function normalizeBrowserUrl(url) {
  const raw = String(url || "").trim();
  if (!raw) return { ok: false, error: "Missing url" };
  if (/\s/.test(raw)) return { ok: false, error: `Invalid URL contains whitespace: ${raw}` };
  if (/^https?:\/\//i.test(raw)) return { ok: true, url: raw };
  if (raw.startsWith("//")) return { ok: true, url: `https:${raw}` };
  if (/^(localhost|(?:\d{1,3}\.){3}\d{1,3}|\[::1\])(?::\d+)?(?:[/?#]|$)/i.test(raw)) {
    return { ok: true, url: `http://${raw}` };
  }
  if (/^[a-z][a-z0-9+.-]*:/i.test(raw)) {
    return { ok: false, error: `Unsupported browser URL scheme. Use http:// or https://: ${raw}` };
  }
  return { ok: true, url: `https://${raw}` };
}

async function queryGroupTabs(groupId) {
  if (!groupId) return [];
  try {
    const tabs = await chrome.tabs.query({ groupId });
    return tabs.map(t => ({
      id: t.id,
      groupId: normalizeChromeGroupId(t.groupId) ?? Number(groupId),
      title: t.title,
      url: t.url,
      active: t.active,
      status: t.status,
      windowId: t.windowId
    }));
  } catch (_) {
    return [];
  }
}

async function assertAutomatableTab(tabId) {
  const tab = await chrome.tabs.get(tabId);
  if (isRestrictedUrl(tab.url)) {
    throw new Error(`Refusing to automate restricted URL: ${tab.url}`);
  }
  return tab;
}

async function waitForTabReady(tabId, timeoutMs = TAB_READY_TIMEOUT_MS) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    if (!tab) return null;
    if (tab.status === "complete") return tab;
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  return chrome.tabs.get(tabId).catch(() => null);
}

async function waitForPageInteractive(tabId, timeoutMs = PAGE_INTERACTIVE_TIMEOUT_MS) {
  const startedAt = Date.now();
  const deadline = startedAt + timeoutMs;
  let sample = null;
  await waitForTabReady(tabId, Math.min(TAB_READY_TIMEOUT_MS, timeoutMs));
  while (Date.now() < deadline) {
    try {
      const injected = await chrome.scripting.executeScript({
        target: { tabId },
        func: () => ({
          readyState: document.readyState,
          url: location.href,
          title: document.title,
          bodyTextLength: (document.body?.innerText || "").trim().length,
          elementCount: document.body ? document.body.getElementsByTagName("*").length : 0,
          interactiveCount: document.querySelectorAll('button,a,input,textarea,select,[role="button"],[aria-label]').length,
          mediaReady: !!document.querySelector('video, ytd-watch-flexy, ytd-player, #movie_player'),
          appReady: !!document.querySelector('main button, ytd-watch-flexy button, #primary button, ytd-comments, ytd-item-section-renderer'),
          hasBody: !!document.body
        })
      });
      sample = injected?.[0]?.result || {};
      const hasMeaningfulText = sample.bodyTextLength >= 80;
      const hasUsableControls = sample.interactiveCount >= 3;
      const hasUsableBody = sample.hasBody && sample.elementCount > 0 && (hasMeaningfulText || hasUsableControls || sample.mediaReady || sample.appReady);
      const readyStateOk = sample.readyState === "interactive" || sample.readyState === "complete";
      if (readyStateOk && hasUsableBody) {
        return { ready: true, timedOut: false, stable: false, elapsedMs: Date.now() - startedAt, ...sample };
      }
    } catch (err) {
      sample = { error: compactError(err) };
    }
    await new Promise(resolve => setTimeout(resolve, 150));
  }
  return { ready: false, timedOut: true, elapsedMs: Date.now() - startedAt, ...(sample || {}) };
}

async function waitForScrollSettled(tabId, timeoutMs = SCROLL_SETTLE_TIMEOUT_MS) {
  const startedAt = Date.now();
  const deadline = startedAt + timeoutMs;
  let last = null;
  let stableSince = 0;
  let sample = null;
  try {
    await cdpAttach(tabId);
  } catch (err) {
    return { settled: false, timedOut: false, error: compactError(err), elapsedMs: Date.now() - startedAt };
  }
  while (Date.now() < deadline) {
    try {
      const raw = await cdpEval(tabId, `(() => JSON.stringify({
        scrollX: Math.round(window.scrollX || document.documentElement.scrollLeft || 0),
        scrollY: Math.round(window.scrollY || document.documentElement.scrollTop || 0),
        scrollHeight: Math.max(document.documentElement.scrollHeight || 0, document.body?.scrollHeight || 0),
        elementCount: document.body ? document.body.getElementsByTagName("*").length : 0
      }))()`);
      sample = JSON.parse(raw);
      const stable = last
        && Math.abs(sample.scrollX - last.scrollX) <= 1
        && Math.abs(sample.scrollY - last.scrollY) <= 1
        && Math.abs(sample.scrollHeight - last.scrollHeight) <= 4
        && Math.abs(sample.elementCount - last.elementCount) <= 2;
      if (stable) {
        if (!stableSince) stableSince = Date.now();
        if (Date.now() - stableSince >= SCROLL_STABLE_WINDOW_MS) {
          return { settled: true, timedOut: false, stableMs: Date.now() - stableSince, elapsedMs: Date.now() - startedAt, ...sample };
        }
      } else {
        stableSince = 0;
      }
      last = sample;
    } catch (err) {
      sample = { error: compactError(err) };
    }
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  return { settled: false, timedOut: true, elapsedMs: Date.now() - startedAt, ...(sample || {}) };
}

async function activateTabForScreenshot(tabId) {
  const before = await assertAutomatableTab(tabId);
  let tab = before;
  let focusSwitched = false;
  if (!before.active) {
    tab = await chrome.tabs.update(tabId, { active: true });
    focusSwitched = true;
  }
  // captureVisibleTab captures the active tab in the target window; focusing the
  // window is unnecessary and would interrupt the user's current view more often.
  await waitForTabReady(tabId, TAB_READY_TIMEOUT_MS);
  await new Promise(resolve => setTimeout(resolve, SCREENSHOT_STABILIZE_DELAY_MS));
  tab = await refreshTabContext(tabId);
  return { tab, focusSwitched, wasActive: !!before.active };
}

async function getOrCreateDeviceId() {
  if (deviceId) return deviceId;
  const stored = await chrome.storage.local.get(["deviceId", "clientId"]).catch(() => ({}));
  if (stored.deviceId || stored.clientId) {
    deviceId = stored.deviceId || stored.clientId;
    if (!stored.deviceId) {
      await chrome.storage.local.set({ deviceId }).catch(() => {});
    }
    updateHeaderInjectRules().catch(() => {});
    return deviceId;
  }
  deviceId = crypto.randomUUID();
  await chrome.storage.local.set({ deviceId }).catch(() => {});
  log("new deviceId:", deviceId);
  updateHeaderInjectRules().catch(() => {});
  return deviceId;
}

function buildUrlFilterFromWsUrl(url) {
  let host;
  try {
    host = new URL(url || DEFAULT_WS_URL).hostname;
  } catch (_) {
    host = "";
  }
  if (!host) return "";
  const escapedHost = host.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return `^https?://${escapedHost}(?:/app/api/ai-agent/sandbox/agents/runs|/app/api/browser-ex/auth/(?:getState|setState))(?:[?#].*)?$`;
}

async function updateHeaderInjectRules() {
  const id = deviceId || await getOrCreateDeviceId();
  const regexFilter = buildUrlFilterFromWsUrl(wsUrl);
  if (!regexFilter || !id) return;
  const headerAction = {
    type: "modifyHeaders",
    requestHeaders: [{ header: "x-storeclaw-device-id", operation: "set", value: id }]
  };
  const resourceTypes = ["xmlhttprequest", "other"];
  try {
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [HEADER_INJECT_RULE_ID, HEADER_INJECT_RULE_ID_LOCAL],
      addRules: [
        {
          id: HEADER_INJECT_RULE_ID,
          priority: 1,
          action: headerAction,
          condition: { regexFilter, resourceTypes }
        }
      ]
    });
    log("header inject rules updated", { regexFilter, deviceId: id });
  } catch (err) {
    log("failed to update header inject rules", compactError(err));
  }
}

async function getManagedWindowsSnapshot() {
  const windows = await chrome.windows.getAll({ populate: true, windowTypes: ["normal"] }).catch(() => []);
  return windows.map(win => ({
    id: win.id,
    focused: win.focused,
    state: win.state,
    tabs: (win.tabs || [])
      .filter(tab => normalizeChromeGroupId(tab.groupId) != null)
      .slice(0, 20)
      .map(tab => ({
      id: tab.id,
      windowId: tab.windowId,
      groupId: tab.groupId,
      active: tab.active,
      title: tab.title,
      url: tab.url
      }))
  })).filter(win => (win.tabs || []).length > 0);
}

async function getGroupsSnapshot(allowedGroupIds = null, allowedWindowIds = null) {
  const groups = await chrome.tabGroups.query({}).catch(() => []);
  return groups
    .filter(group => (allowedGroupIds == null || allowedGroupIds.has(group.id))
      && (allowedWindowIds == null || allowedWindowIds.has(group.windowId)))
    .map(group => ({
      id: group.id,
      windowId: group.windowId,
      title: group.title,
      color: group.color,
      collapsed: group.collapsed
    }));
}

function bindingsSnapshot() {
  return {
    groups: Object.entries(groupStore).map(([groupId, group]) => ({ groupId: Number(groupId), ...group })),
    tabToGroupMap
  };
}

function buildLightweightMeta() {
  return {
    browser: "chrome",
    extensionVersion: chrome.runtime.getManifest()?.version || "unknown",
    displayName: "Chrome Browser",
    bindings: bindingsSnapshot()
  };
}

async function buildDeviceMeta() {
  const windows = await getManagedWindowsSnapshot();
  const tabs = windows.flatMap(win => (win.tabs || []).map(tab => ({
    ...tab,
    windowId: tab.windowId ?? win.id
  })));
  const groupIds = new Set(tabs.map(tab => normalizeChromeGroupId(tab.groupId)).filter(groupId => groupId != null));
  const windowIds = new Set(windows.map(win => win.id));
  return {
    browser: "chrome",
    userAgent: navigator.userAgent,
    extensionVersion: chrome.runtime.getManifest()?.version || "unknown",
    displayName: "Chrome Browser",
    windows,
    tabs,
    groups: await getGroupsSnapshot(groupIds, windowIds),
    bindings: bindingsSnapshot()
  };
}

async function sendHeartbeat() {
  if (!socket || socket.readyState !== WebSocket.OPEN) return;
  if (heartbeatInFlight) return;
  const referenceTime = lastHeartbeatAckAt || lastRegisterSentAt;
  if (referenceTime && Date.now() - referenceTime > HEARTBEAT_ACK_TIMEOUT) {
    lastError = "Heartbeat ack timeout";
    rememberEvent("heartbeat_timeout", "No heartbeat ack from service");
    try {
      socket.close(4001, "heartbeat ack timeout");
    } catch (_) {}
    return;
  }
  heartbeatInFlight = true;
  try {
    const id = await getOrCreateDeviceId();
    const seq = ++heartbeatSequence;
    const now = Date.now();
    const needFullSnapshot = (now - lastFullSnapshotAt) >= FULL_SNAPSHOT_INTERVAL;
    const meta = needFullSnapshot ? await buildDeviceMeta() : buildLightweightMeta();
    if (needFullSnapshot) lastFullSnapshotAt = now;
    safeSend({
      id: `ping-${seq}-${now}`,
      type: "heartbeat",
      seq,
      deviceId: id,
      timestamp: nowIso(),
      ...meta
    });
  } finally {
    heartbeatInFlight = false;
  }
}

function startHeartbeat() {
  clearHeartbeat();
  heartbeatTimer = setInterval(() => {
    sendHeartbeat().catch(err => {
      lastError = compactError(err);
      rememberEvent("error", "Heartbeat failed", { error: lastError });
    });
  }, HEARTBEAT_INTERVAL);
}

async function sendRegisterFrame() {
  const id = await getOrCreateDeviceId();
  lastRegisterSentAt = Date.now();
  safeSend({
    type: "register",
    deviceId: id,
    timestamp: nowIso(),
    ...(await buildDeviceMeta())
  });
}

function handleControlFrame(message) {
  if (message?.type === "registered") {
    isConnecting = false;
    isRegistered = true;
    lastHeartbeatAckAt = Date.now();
    lastError = "";
    updateStatus(true, "Connected");
    rememberEvent("registered", "Browser service registered", { deviceId: message.deviceId || deviceId });
    return true;
  }
  if (message?.type === "heartbeat_ack") {
    lastHeartbeatAckAt = Date.now();
    return true;
  }
  return false;
}

async function readBrowserAuthGranted() {
  try {
    const stored = await chrome.storage.local.get("browserAuthorized");
    return !!(stored && stored.browserAuthorized);
  } catch (err) {
    log("browserAuthorized storage read failed", err);
    return false;
  }
}

async function writeBrowserAuthGranted(granted) {
  try {
    if (granted) {
      await chrome.storage.local.set({ browserAuthorized: { grantedAt: Date.now() } });
    } else {
      await chrome.storage.local.remove("browserAuthorized");
    }
    return true;
  } catch (err) {
    log("browserAuthorized storage write failed", err);
    return false;
  }
}

async function emitDeviceEvent(event, payload = {}) {
  const id = await getOrCreateDeviceId();
  const frame = {
    type: "device_event",
    event,
    deviceId: id,
    timestamp: nowIso(),
    payload,
    bindings: bindingsSnapshot()
  };
  safeSend(frame);
  rememberEvent("device_event", event, payload);
}

async function emitFullSnapshot() {
  const meta = await buildDeviceMeta();
  await emitDeviceEvent("full_snapshot", meta);
}

function validateDevice(msgDeviceId) {
  if (!msgDeviceId) return { valid: false, error: "Missing deviceId" };
  if (msgDeviceId !== deviceId) return { valid: false, error: "deviceId mismatch" };
  return { valid: true };
}

function cleanupSessionBindings({ tabId, groupId } = {}) {
  if (tabId != null) {
    delete tabToGroupMap[tabId];
  }
  if (groupId != null) {
    delete groupStore[groupId];
    for (const t in tabToGroupMap) {
      if (sameId(tabToGroupMap[t], groupId)) {
        delete tabToGroupMap[t];
      }
    }
  }
}

async function refreshTabContext(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    const gId = tab.groupId !== chrome.tabGroups.TAB_GROUP_ID_NONE ? tab.groupId : tabToGroupMap[tabId];
    if (gId != null && gId !== chrome.tabGroups.TAB_GROUP_ID_NONE) {
      tabToGroupMap[tabId] = gId;
      groupStore[gId] = groupStore[gId] || { windowId: tab.windowId, tabIds: [], name: "Storeclaw" };
      groupStore[gId].windowId = tab.windowId;
      groupStore[gId].tabIds = Array.from(new Set([...(groupStore[gId].tabIds || []), tabId]));
    }
    return tab;
  } catch (_) {
    cleanupSessionBindings({ tabId });
    return null;
  }
}

function firstValue(...values) {
  return values.find(value => value !== undefined && value !== null && value !== "");
}

function sameId(a, b) {
  return String(a) === String(b);
}

function normalizeChromeGroupId(groupId) {
  if (groupId === undefined || groupId === null || groupId === chrome.tabGroups.TAB_GROUP_ID_NONE) return null;
  return Number(groupId);
}

function equivalentPageUrl(a, b) {
  try {
    const ua = new URL(a);
    const ub = new URL(b);
    ua.hash = "";
    ub.hash = "";
    return ua.href === ub.href;
  } catch (_) {
    return String(a || "") === String(b || "");
  }
}

async function createAutomationWindow({ sessionName = "Storeclaw" } = {}) {
  const current = await chrome.windows.getCurrent().catch(() => null);
  const createParams = {
    url: "about:blank",
    type: "normal",
    focused: false,
    state: "normal",
    width: AUTOMATION_WINDOW_WIDTH,
    height: AUTOMATION_WINDOW_HEIGHT
  };
  if (current) {
    createParams.left = Math.max((current.left ?? 0) + 40, 0);
    createParams.top = Math.max((current.top ?? 0) + 40, 0);
  }
  const win = await chrome.windows.create(createParams);
  const firstTab = Array.isArray(win.tabs) ? win.tabs[0] : null;
  if (firstTab?.id) {
    setTimeout(() => chrome.tabs.remove(firstTab.id).catch(() => {}), 500);
  }
  await emitDeviceEvent("automation_window_created", { windowId: win.id, name: sessionName }).catch(() => {});
  return win.id;
}

async function resolveGroupTargetWindowId(...candidates) {
  for (const candidate of candidates) {
    if (candidate === undefined || candidate === null || candidate === "") continue;
    const win = await chrome.windows.get(Number(candidate)).catch(() => null);
    if (win && win.type === "normal" && win.state !== "minimized") return win.id;
  }

  const focused = await chrome.windows.getLastFocused({ windowTypes: ["normal"] }).catch(() => null);
  if (focused && focused.type === "normal" && focused.state !== "minimized") return focused.id;

  return null;
}

async function createPlaceholderGroup({ windowId, name = "Storeclaw" }) {
  const placeholder = await chrome.tabs.create({ url: "about:blank", active: false, windowId, index: 0 });
  const groupId = await chrome.tabs.group({ tabIds: [placeholder.id] });
  await chrome.tabGroups.update(groupId, { title: name, color: "grey", collapsed: false });
  await pinGroupLeft(groupId);
  groupStore[groupId] = { windowId, tabIds: [placeholder.id], placeholderId: placeholder.id, name };
  tabToGroupMap[placeholder.id] = groupId;
  await emitDeviceEvent("group_created", { groupId, tabId: placeholder.id, windowId });
  return { groupId, windowId, tabId: placeholder.id, targetGroup: groupStore[groupId] };
}

async function ensureGroupAutomationWindow(groupId, { sessionName = "Storeclaw" } = {}) {
  const group = groupStore[groupId];
  if (group?.windowId != null) {
    const existing = await chrome.windows.get(group.windowId).catch(() => null);
    if (existing && existing.type === "normal" && existing.state !== "minimized") {
      return group.windowId;
    }
  }
  const windowId = await createAutomationWindow({ sessionName });
  if (groupStore[groupId]) groupStore[groupId].windowId = windowId;
  return windowId;
}

async function pinGroupLeft(groupId) {
  if (groupId == null) return;
  const tabs = await chrome.tabs.query({ groupId: Number(groupId) }).catch(() => []);
  if (!tabs.length) return;
  const sorted = tabs.slice().sort((a, b) => a.index - b.index);
  await chrome.tabs.move(sorted.map(t => t.id), { index: 0 }).catch(() => {});
}

async function validateSandboxGroup(groupId) {
  if (groupId == null) {
    return commandFailure("No session group available for browser operation", {
      code: "NO_SESSION_GROUP",
      suggestion: "Open a URL in the browser first so the extension can create or bind a group."
    });
  }

  try {
    await chrome.tabGroups.get(Number(groupId));
  } catch (_) {
    cleanupSessionBindings({ groupId });
    return commandFailure("Session group is no longer available", {
      code: "GROUP_NOT_FOUND",
      suggestion: "Open the target page again to create a fresh browser group.",
      diagnostics: { groupId }
    });
  }
  return null;
}

async function getGroupCandidateTabId(groupId) {
  const stored = groupStore[groupId]?.tabIds || [];
  for (let i = stored.length - 1; i >= 0; i -= 1) {
    const tabId = stored[i];
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    if (tab && sameId(normalizeChromeGroupId(tab.groupId), groupId)) return tabId;
  }

  const tabs = await chrome.tabs.query({ groupId: Number(groupId) }).catch(() => []);
  if (!tabs.length) return null;
  const last = tabs[tabs.length - 1];
  groupStore[groupId] = groupStore[groupId] || { windowId: last.windowId, tabIds: [], name: "Storeclaw" };
  groupStore[groupId].windowId = last.windowId;
  groupStore[groupId].tabIds = tabs.map(t => t.id);
  return last.id;
}

async function getReusableGroupTab(groupId, preferredTabId) {
  const candidateIds = [];
  if (preferredTabId != null && preferredTabId !== "") candidateIds.push(Number(preferredTabId));

  const stored = groupStore[groupId]?.tabIds || [];
  for (let i = stored.length - 1; i >= 0; i -= 1) {
    candidateIds.push(Number(stored[i]));
  }

  const queriedTabs = await chrome.tabs.query({ groupId: Number(groupId) }).catch(() => []);
  for (let i = queriedTabs.length - 1; i >= 0; i -= 1) {
    candidateIds.push(Number(queriedTabs[i].id));
  }

  const seen = new Set();
  for (const candidateId of candidateIds) {
    if (!Number.isInteger(candidateId) || candidateId <= 0 || seen.has(candidateId)) continue;
    seen.add(candidateId);
    const tab = await chrome.tabs.get(candidateId).catch(() => null);
    if (!tab || !sameId(normalizeChromeGroupId(tab.groupId), groupId)) continue;
    const groupWindowId = groupStore[groupId]?.windowId;
    if (groupWindowId != null && tab.windowId !== groupWindowId) continue;
    if (isRestrictedUrl(tab.url)) continue;
    return tab;
  }
  return null;
}

async function createTabInsideGroup({ windowId, groupId, url, sessionName }) {
  const targetWindowId = windowId || await createAutomationWindow({ sessionName });
  const initialUrl = url && url !== "about:blank" ? url : "about:blank";
  const tab = await chrome.tabs.create({
    url: initialUrl,
    active: false,
    windowId: targetWindowId,
    index: 0
  });
  const actualGroupId = groupId != null
    ? await chrome.tabs.group({ tabIds: [tab.id], groupId })
    : await chrome.tabs.group({ tabIds: [tab.id] });
  if (groupId == null) {
    await chrome.tabGroups.update(actualGroupId, { title: sessionName || "Storeclaw", color: "grey", collapsed: false });
  }
  await pinGroupLeft(actualGroupId);
  if (initialUrl !== "about:blank") {
    await waitForTabReady(tab.id, TAB_READY_TIMEOUT_MS);
  }
  const refreshed = await refreshTabContext(tab.id);
  return {
    tabId: tab.id,
    groupId: normalizeChromeGroupId(refreshed?.groupId) ?? actualGroupId,
    windowId: refreshed?.windowId ?? targetWindowId
  };
}

async function resolveSandboxTab({ action, groupId, tabId, params = {}, allowFallback = true }) {
  const effectiveGroupId = firstValue(params.groupId, groupId, tabToGroupMap[params.tabId], tabToGroupMap[tabId]);
  const groupError = await validateSandboxGroup(effectiveGroupId);
  if (groupError) return { ok: false, failure: groupError };

  const explicitTabId = params.tabId !== undefined && params.tabId !== null && params.tabId !== "";
  let targetTabId = firstValue(params.tabId, tabId);
  if (targetTabId == null && allowFallback) {
    targetTabId = await getGroupCandidateTabId(effectiveGroupId);
  }

  if (targetTabId == null) {
    return {
      ok: false,
      failure: commandFailure("No tab available in the current browser group", {
        code: "NO_TARGET_TAB",
        suggestion: "Open a URL in the current browser group before interacting with the page.",
        diagnostics: { action, groupId: effectiveGroupId }
      })
    };
  }

  let tab = await chrome.tabs.get(Number(targetTabId)).catch(() => null);
  if (!tab) {
    cleanupSessionBindings({ tabId: targetTabId });
    if (allowFallback && !explicitTabId) {
      const fallbackTabId = await getGroupCandidateTabId(effectiveGroupId);
      if (fallbackTabId != null && !sameId(fallbackTabId, targetTabId)) {
        targetTabId = fallbackTabId;
        tab = await chrome.tabs.get(Number(targetTabId)).catch(() => null);
      }
    }
  }
  if (!tab) {
    return {
      ok: false,
      failure: commandFailure("Target tab is no longer available", {
        code: "TAB_NOT_FOUND",
        suggestion: "Refresh the tab list and retry on a live tab in the current group.",
        diagnostics: { action, tabId: targetTabId, groupId: effectiveGroupId }
      })
    };
  }

  const actualGroupId = normalizeChromeGroupId(tab.groupId);
  if (!sameId(actualGroupId, effectiveGroupId)) {
    if (allowFallback && !explicitTabId) {
      const fallbackTabId = await getGroupCandidateTabId(effectiveGroupId);
      if (fallbackTabId != null && !sameId(fallbackTabId, targetTabId)) {
        targetTabId = fallbackTabId;
        tab = await chrome.tabs.get(Number(targetTabId)).catch(() => null);
        const fallbackGroupId = normalizeChromeGroupId(tab?.groupId);
        if (tab && sameId(fallbackGroupId, effectiveGroupId) && !isRestrictedUrl(tab.url)) {
          tabToGroupMap[Number(targetTabId)] = Number(effectiveGroupId);
          groupStore[effectiveGroupId] = groupStore[effectiveGroupId] || { windowId: tab.windowId, tabIds: [], name: "Storeclaw" };
          groupStore[effectiveGroupId].windowId = tab.windowId;
          groupStore[effectiveGroupId].tabIds = Array.from(new Set([...(groupStore[effectiveGroupId].tabIds || []), Number(targetTabId)]));
          return { ok: true, tab, tabId: Number(targetTabId), groupId: Number(effectiveGroupId), windowId: tab.windowId };
        }
      }
    }
    return {
      ok: false,
      failure: commandFailure("Target tab is outside the current browser group sandbox", {
        code: "TAB_OUT_OF_GROUP",
        suggestion: "Open or switch to a tab inside the current browser group before retrying.",
        diagnostics: { action, tabId: Number(targetTabId), actualGroupId, expectedGroupId: Number(effectiveGroupId) },
        reason: "invalid_context"
      })
    };
  }

  if (isRestrictedUrl(tab.url)) {
    return {
      ok: false,
      failure: commandFailure(`Refusing to automate restricted URL: ${tab.url}`, {
        code: "RESTRICTED_URL",
        suggestion: "Open a normal http:// or https:// page inside the current browser group.",
        diagnostics: { action, tabId: Number(targetTabId), groupId: Number(effectiveGroupId) }
      })
    };
  }

  tabToGroupMap[Number(targetTabId)] = Number(effectiveGroupId);
  groupStore[effectiveGroupId] = groupStore[effectiveGroupId] || { windowId: tab.windowId, tabIds: [], name: "Storeclaw" };
  groupStore[effectiveGroupId].windowId = tab.windowId;
  groupStore[effectiveGroupId].tabIds = Array.from(new Set([...(groupStore[effectiveGroupId].tabIds || []), Number(targetTabId)]));
  return { ok: true, tab, tabId: Number(targetTabId), groupId: Number(effectiveGroupId), windowId: tab.windowId };
}

async function ensureContentScript(tabId) {
  const tab = await assertAutomatableTab(tabId);
  try {
    // Add a 2s timeout: sendMessage can hang forever when an old content script is mid-teardown
    // (known Chrome issue). On timeout, the catch path reinjects to avoid a 60s call-chain stall.
    await Promise.race([
      chrome.tabs.sendMessage(tabId, { action: "__ping__", params: {} }),
      new Promise((_, reject) => setTimeout(() => reject(new Error("ping timeout")), 2000))
    ]);
  } catch (_) {
    // Wait for the tab to finish loading before injection so the script is not destroyed mid-navigation.
    await waitForTabReady(tabId, TAB_READY_TIMEOUT_MS);
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
    await new Promise(resolve => setTimeout(resolve, 150));
  }
  // Interceptor scripts are idempotent via the top-level __claude*Installed guards, so injection
  // can be retried each time to cover SPA route changes, iframe refreshes, and lost scripts.
  ensureNewTabInterceptors(tabId).catch(() => {});
  return tab;
}

async function ensureNewTabInterceptors(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      files: ["intercept_isolated.js"]
    });
  } catch (_) {}
  try {
    await chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      files: ["intercept_main.js"],
      world: "MAIN"
    });
  } catch (_) {}
}

const CONTENT_SCRIPT_TIMEOUT_MS = 60_000;

function withTimeout(promise, timeoutMs, label) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => {
      const err = new Error(`${label} timed out after ${timeoutMs}ms`);
      err.code = "CONTENT_SCRIPT_TIMEOUT";
      reject(err);
    }, timeoutMs);
  });
  return Promise.race([
    promise.finally(() => clearTimeout(timer)),
    timeout
  ]);
}

async function sendToTab(tabId, message) {
  const send = async () => {
    try {
      await ensureContentScript(tabId);
      return await chrome.tabs.sendMessage(tabId, message);
    } catch (err) {
      const msg = compactError(err);
      if (msg.includes("Receiving end does not exist")) {
        await ensureContentScript(tabId);
        return await chrome.tabs.sendMessage(tabId, message);
      }
      throw err;
    }
  };
  return withTimeout(send(), CONTENT_SCRIPT_TIMEOUT_MS, `sendToTab(${tabId}, ${message?.action || "?"})`);
}

function normalizeContentResult(response) {
  if (response && response.ok === false) {
    if (!response.errorCode && response.reason) {
      response.errorCode = response.reason.toUpperCase();
    }
    return response;
  }
  if (response && response.ok === true) return response;
  return { ok: true, result: response || {} };
}

// Command idempotency: the gateway retries on timeout, and some network paths
// can duplicate a command frame. Cache the last reply for each commandId for a
// short window so re-delivery returns the original result instead of re-running
// (e.g. avoids double-click when a click ack was lost in flight).
const COMMAND_DEDUPE_WINDOW_MS = 60_000;
const COMMAND_DEDUPE_MAX_ENTRIES = 128;
const processedCommands = new Map();

function dedupePrune() {
  const now = Date.now();
  for (const [id, entry] of processedCommands) {
    if (entry.expireAt < now) processedCommands.delete(id);
  }
  while (processedCommands.size > COMMAND_DEDUPE_MAX_ENTRIES) {
    const firstKey = processedCommands.keys().next().value;
    if (firstKey === undefined) break;
    processedCommands.delete(firstKey);
  }
}

function dedupeLookup(commandId) {
  if (!commandId) return null;
  const entry = processedCommands.get(commandId);
  if (!entry) return null;
  if (entry.expireAt < Date.now()) {
    processedCommands.delete(commandId);
    return null;
  }
  return entry.reply;
}

function dedupeRecord(commandId, reply) {
  if (!commandId) return;
  processedCommands.set(commandId, { reply, expireAt: Date.now() + COMMAND_DEDUPE_WINDOW_MS });
  dedupePrune();
}

function commandReply(message, result, elapsedMs) {
  const reply = result && typeof result === "object" ? { ...result } : { ok: true, result };
  if (reply.ok == null) reply.ok = true;
  reply.id = message.id;
  reply.deviceId = deviceId;
  const commandResult = reply.result && typeof reply.result === "object" ? reply.result : {};
  reply.groupId = commandResult.groupId ?? message.groupId ?? null;
  reply.tabId = commandResult.tabId ?? message.tabId ?? null;
  reply.windowId = commandResult.windowId ?? message.windowId ?? null;
  reply.timestamp = nowIso();
  reply.elapsedMs = elapsedMs;
  return reply;
}

async function handleCommand(message) {
  const { type, payload = {}, windowId, tabId, groupId } = message;
  const msgDeviceId = message.deviceId || message.clientId;
  const action = payload?.action;
  const params = payload?.params || {};
  const hasExplicitParamTabId = params.tabId !== undefined && params.tabId !== null && params.tabId !== "";
  const hasExplicitParamTabIds = Array.isArray(params.tabIds) && params.tabIds.length > 0;

  if (type === "ping" || action === "ping") {
    return { ok: true, result: { pong: true, deviceId } };
  }

  if (action === "get_browser_auth") {
    const granted = await readBrowserAuthGranted();
    return { ok: true, result: { granted }, granted };
  }

  if (action === "set_browser_auth") {
    const desired = !!params.granted;
    const ok = await writeBrowserAuthGranted(desired);
    return { ok, result: { granted: desired }, granted: desired };
  }

  if (action === "list_tabs") {
    const tabs = await chrome.tabs.query({});
    return {
      ok: true,
      result: tabs.map(t => ({ id: t.id, title: t.title, url: t.url, active: t.active, windowId: t.windowId, groupId: t.groupId }))
    };
  }

  if (!action) return commandFailure(`Missing action, type=${type}`, {
    code: "MISSING_ACTION",
    suggestion: "Provide a supported browser action before dispatching the command."
  });

  const cv = validateDevice(msgDeviceId);
  if (!cv.valid) {
    return commandFailure(cv.error, {
      code: "INVALID_DEVICE",
      suggestion: "Refresh the browser lease or re-bind the session to the currently connected browser.",
      reason: "invalid_client"
    });
  }

  if (action === "register_session") {
    return commandFailure("register_session is no longer supported in the extension", {
      code: "UNSUPPORTED_ACTION",
      suggestion: "Let the service manage session binding and issue browser commands with explicit device/group/tab context."
    });
  }

  if (action === "create_group") {
    const winId = params.windowId;
    if (!winId) return { ok: false, error: "Missing windowId" };
    const created = await createPlaceholderGroup({ windowId: winId, name: params.name || "Storeclaw" });
    return { ok: true, result: { groupId: created.groupId, windowId: created.windowId, tabId: created.tabId, deviceId } };
  }

  if (action === "create_tab_in_group") {
    const gId = firstValue(params.groupId, groupId);
    const { sessionName = "Storeclaw" } = params;
    const shouldOpenNewTab = params.newTab === true;
    const normalized = normalizeBrowserUrl(params.url);
    if (!normalized.ok) return { ok: false, error: normalized.error };
    const url = normalized.url;
    if (isRestrictedUrl(url)) return { ok: false, error: `Refusing to open restricted URL: ${url}` };

    let actualGroupId = null;
    let targetGroup = null;
    if (gId != null) {
      try {
        await chrome.tabGroups.get(gId);
        actualGroupId = gId;
        targetGroup = groupStore[gId];
        if (!targetGroup) {
          const existingTabs = await chrome.tabs.query({ groupId: Number(gId) });
          targetGroup = {
            windowId: existingTabs[0]?.windowId,
            tabIds: existingTabs.map(t => t.id),
            name: sessionName
          };
          groupStore[gId] = targetGroup;
        }
        if (targetGroup?.tabIds?.length) {
          const liveTab = await refreshTabContext(targetGroup.tabIds[targetGroup.tabIds.length - 1]);
          if (liveTab?.windowId) targetGroup.windowId = liveTab.windowId;
        }
      } catch (_) {
        cleanupSessionBindings({ groupId: gId });
      }
    }

    if (!actualGroupId) {
      const targetWindowId = await resolveGroupTargetWindowId(params.windowId, windowId);
      if (!targetWindowId) {
        return commandFailure("No available browser window for creating a group", {
          code: "TARGET_WINDOW_NOT_FOUND",
          suggestion: "Open a normal Chrome window or provide windowId before creating a browser group."
        });
      }
      const createdGroup = await createPlaceholderGroup({ windowId: targetWindowId, name: sessionName });
      actualGroupId = createdGroup.groupId;
      targetGroup = createdGroup.targetGroup;
    }

    if (targetGroup?.placeholderId) {
      try {
        const placeholder = await chrome.tabs.get(targetGroup.placeholderId);
        const groupWindowId = await ensureGroupAutomationWindow(actualGroupId, { sessionName });
        if (placeholder.windowId !== groupWindowId) {
          delete targetGroup.placeholderId;
        } else {
          await chrome.tabs.update(targetGroup.placeholderId, { url });
          const pid = targetGroup.placeholderId;
          delete targetGroup.placeholderId;
          await waitForTabReady(pid, TAB_READY_TIMEOUT_MS);
          const tab = await refreshTabContext(pid);
          await emitDeviceEvent("tab_updated", { groupId: actualGroupId, tabId: pid, windowId: tab?.windowId });
          const tabs1 = await queryGroupTabs(actualGroupId);
          return { ok: true, result: { groupId: actualGroupId, tabId: pid, windowId: tab?.windowId || targetGroup.windowId, deviceId, reused: true, tabs: tabs1 } };
        }
      } catch (_) {
        delete targetGroup.placeholderId;
      }
    }

    if (!shouldOpenNewTab) {
      await ensureGroupAutomationWindow(actualGroupId, { sessionName });
      const reusableTab = await getReusableGroupTab(actualGroupId, tabId);
      if (reusableTab) {
        const sameUrl = equivalentPageUrl(reusableTab.url, url);
        if (!sameUrl) {
          await chrome.tabs.update(reusableTab.id, { url });
          await waitForTabReady(reusableTab.id, TAB_READY_TIMEOUT_MS);
        }
        const tab = await refreshTabContext(reusableTab.id);
        const effectiveGroupId = normalizeChromeGroupId(tab?.groupId) ?? actualGroupId;
        if (!tab) {
          return commandFailure("Reused tab is no longer available after navigation", {
            code: "TAB_NOT_FOUND",
            suggestion: "Open a fresh tab in the browser group and retry.",
            diagnostics: { tabId: reusableTab.id, groupId: actualGroupId }
          });
        }
        if (!sameId(effectiveGroupId, actualGroupId)) {
          return commandFailure("Reused tab moved outside the current browser group sandbox", {
            code: "TAB_OUT_OF_GROUP",
            suggestion: "Open or switch to a tab inside the current browser group before retrying.",
            diagnostics: { tabId: reusableTab.id, actualGroupId: effectiveGroupId, expectedGroupId: actualGroupId },
            reason: "invalid_context"
          });
        }
        if (isRestrictedUrl(tab.url)) {
          return commandFailure(`Refusing to automate restricted URL after navigation: ${tab.url}`, {
            code: "RESTRICTED_URL",
            suggestion: "Open a normal http:// or https:// page inside the current browser group.",
            diagnostics: { tabId: reusableTab.id, groupId: actualGroupId }
          });
        }
        await emitDeviceEvent("tab_updated", { groupId: effectiveGroupId, tabId: reusableTab.id, windowId: tab?.windowId, url });
        const tabs = await queryGroupTabs(effectiveGroupId);
        return {
          ok: true,
          result: {
            groupId: effectiveGroupId,
            tabId: reusableTab.id,
            windowId: tab?.windowId || reusableTab.windowId || targetGroup.windowId,
            deviceId,
            reused: true,
            reusedExistingTab: true,
            skippedNavigation: sameUrl,
            tabs
          }
        };
      }
    }

    const groupWindowId = await ensureGroupAutomationWindow(actualGroupId, { sessionName });
    const created = await createTabInsideGroup({ windowId: groupWindowId, groupId: actualGroupId, url, sessionName });
    targetGroup.tabIds = Array.from(new Set([...(targetGroup.tabIds || []), created.tabId]));
    tabToGroupMap[created.tabId] = actualGroupId;
    await emitDeviceEvent("tab_created", { groupId: actualGroupId, tabId: created.tabId, windowId: created.windowId });
    await emitFullSnapshot();
    const tabs2 = await queryGroupTabs(actualGroupId);
    return { ok: true, result: { groupId: actualGroupId, tabId: created.tabId, windowId: created.windowId, deviceId, tabs: tabs2 } };
  }

  if (action === "update_tab_url") {
    const requestedGroupId = firstValue(params.groupId, groupId);
    // If no group exists, create one and navigate automatically to avoid a NO_SESSION_GROUP round trip.
    if (requestedGroupId == null) {
      const normalized = normalizeBrowserUrl(params.url);
      if (!normalized.ok) return { ok: false, error: normalized.error };
      const url = normalized.url;
      if (isRestrictedUrl(url)) return { ok: false, error: `Refusing to open restricted URL: ${url}` };
      const created = await createTabInsideGroup({ windowId: await createAutomationWindow({ sessionName: "Storeclaw" }), url, sessionName: "Storeclaw" });
      groupStore[created.groupId] = { windowId: created.windowId, tabIds: [created.tabId], name: "Storeclaw" };
      tabToGroupMap[created.tabId] = created.groupId;
      await emitDeviceEvent("tab_created", { groupId: created.groupId, tabId: created.tabId, windowId: created.windowId, url });
      await emitFullSnapshot();
      const tabs = await queryGroupTabs(created.groupId);
      return { ok: true, result: { groupId: created.groupId, tabId: created.tabId, windowId: created.windowId, deviceId, url, isNewGroup: true, tabs } };
    }
    const target = await resolveSandboxTab({ action, groupId: requestedGroupId, tabId, params });
    if (!target.ok) return target.failure;
    const tId = target.tabId;
    const normalized = normalizeBrowserUrl(params.url);
    if (!normalized.ok) return { ok: false, error: normalized.error };
    const url = normalized.url;
    if (isRestrictedUrl(url)) return { ok: false, error: `Refusing to open restricted URL: ${url}` };
    await chrome.tabs.update(tId, { url, active: true });
    await waitForTabReady(tId, TAB_READY_TIMEOUT_MS);
    const tab = await refreshTabContext(tId);
    const effectiveGroupId = normalizeChromeGroupId(tab?.groupId) ?? target.groupId;
    await emitDeviceEvent("tab_updated", { groupId: effectiveGroupId, tabId: tId, windowId: tab?.windowId, url });
    return { ok: true, result: { groupId: effectiveGroupId, tabId: tId, url, windowId: tab?.windowId, deviceId } };
  }

  if (action === "activate_tab") {
    const target = await resolveSandboxTab({ action, groupId, tabId, params });
    if (!target.ok) return target.failure;
    const tId = target.tabId;
    await chrome.tabs.update(tId, { active: true });
    const tab = await refreshTabContext(tId);
    const effectiveGroupId = normalizeChromeGroupId(tab?.groupId) ?? target.groupId;
    const tabs = await queryGroupTabs(effectiveGroupId);
    return { ok: true, result: { groupId: effectiveGroupId, tabId: tId, windowId: tab?.windowId, deviceId, tabs } };
  }

  if (action === "list_tabs_in_group") {
    const gId = firstValue(params.groupId, groupId);
    const groupError = await validateSandboxGroup(gId);
    if (groupError) return groupError;
    const tabs = await chrome.tabs.query({ groupId: Number(gId) });
    return {
      ok: true,
      result: {
        groupId: Number(gId),
        tabs: tabs.map(t => ({
          id: t.id,
          title: t.title,
          url: t.url,
          active: t.active,
          status: t.status,
          windowId: t.windowId
        }))
      }
    };
  }

  if (action === "close_tab") {
    const target = await resolveSandboxTab({ action, groupId, tabId, params, allowFallback: false });
    if (!target.ok) return target.failure;
    const tId = target.tabId;
    const closedGroupId = target.groupId;
    // Refuse to close the last tab in a group: Chrome would also destroy the group, causing later
    // list_tabs_in_group/new open_url calls to lose their group anchor. Require opening another tab first.
    const existingTabs = await queryGroupTabs(closedGroupId);
    if (existingTabs.length <= 1) {
      return commandFailure("Refusing to close the last tab in the browser group", {
        code: "LAST_TAB_IN_GROUP",
        suggestion: "Open another tab inside this group (open_url without tab_id, or with a different tab_id) before closing this one.",
        diagnostics: { tabId: tId, groupId: closedGroupId, groupTabCount: existingTabs.length }
      });
    }
    await chrome.tabs.remove(tId);
    cleanupSessionBindings({ tabId: tId });
    const tabs = await queryGroupTabs(closedGroupId);
    const nextTab = tabs[tabs.length - 1];
    if (nextTab) {
      if (groupStore[closedGroupId]) {
        groupStore[closedGroupId].tabIds = tabs.map(t => t.id);
        groupStore[closedGroupId].windowId = nextTab.windowId;
      }
    } else {
      // Group is now empty; Chrome will auto-dispose it. Drop local bookkeeping so
      // future lookups don't resurrect stale state.
      cleanupSessionBindings({ groupId: closedGroupId });
    }
    return { ok: true, result: { tabId: nextTab?.id, closedTabId: tId, closed: true, groupId: closedGroupId, tabs } };
  }

  if (action === "close_tabs") {
    const rawIds = Array.isArray(params.tabIds) ? params.tabIds : [];
    const tabIds = rawIds.map(id => Number(id)).filter(id => Number.isInteger(id) && id > 0);
    if (!tabIds.length) {
      return commandFailure("Missing tabIds", {
        code: "MISSING_TAB_IDS",
        suggestion: "Pass the IDs of tabs that are confirmed no longer useful."
      });
    }

    const closed = [];
    const failed = [];
    const affectedGroupIds = new Set();
    for (const tId of tabIds) {
      const target = await resolveSandboxTab({ action, groupId, tabId: tId, params: { tabId: tId }, allowFallback: false });
      if (!target.ok) {
        failed.push({ tabId: tId, error: target.failure.error, errorCode: target.failure.errorCode, diagnostics: target.failure.diagnostics });
        continue;
      }
      const closedGroupId = target.groupId;
      if (closedGroupId != null) affectedGroupIds.add(closedGroupId);
      try {
        await chrome.tabs.remove(tId);
        cleanupSessionBindings({ tabId: tId });
        closed.push(tId);
      } catch (err) {
        failed.push({ tabId: tId, error: compactError(err) });
      }
    }

    const effectiveGroupId = groupId || Array.from(affectedGroupIds)[0];
    const tabs = await queryGroupTabs(effectiveGroupId);
    const nextTab = tabs[tabs.length - 1];
    if (nextTab) {
      if (groupStore[effectiveGroupId]) {
        groupStore[effectiveGroupId].tabIds = tabs.map(t => t.id);
        groupStore[effectiveGroupId].windowId = nextTab.windowId;
      }
    } else if (effectiveGroupId != null) {
      // Same empty-group cleanup as close_tab: drop stale bookkeeping for the gone group.
      cleanupSessionBindings({ groupId: effectiveGroupId });
    }
    return {
      ok: failed.length === 0,
      result: {
        closed,
        failed,
        partialFailure: failed.length > 0,
        tabId: nextTab?.id,
        groupId: effectiveGroupId,
        tabs
      },
      error: failed.length ? "Some tabs could not be closed" : undefined,
      errorCode: failed.length ? "PARTIAL_TAB_CLOSE_FAILURE" : undefined
    };
  }

  if (action === "reload_tab") {
    const target = await resolveSandboxTab({ action, groupId, tabId, params });
    if (!target.ok) return target.failure;
    const tId = target.tabId;
    await chrome.tabs.reload(tId, { bypassCache: params.bypassCache || false });
    return { ok: true, result: { tabId: tId, groupId: target.groupId, windowId: target.windowId, reloaded: true, deviceId } };
  }

  if (action === "go_back") {
    const target = await resolveSandboxTab({ action, groupId, tabId, params });
    if (!target.ok) return target.failure;
    const tId = target.tabId;
    await chrome.tabs.goBack(tId);
    return { ok: true, result: { tabId: tId, groupId: target.groupId, windowId: target.windowId, deviceId } };
  }

  if (action === "go_forward") {
    const target = await resolveSandboxTab({ action, groupId, tabId, params });
    if (!target.ok) return target.failure;
    const tId = target.tabId;
    await chrome.tabs.goForward(tId);
    return { ok: true, result: { tabId: tId, groupId: target.groupId, windowId: target.windowId, deviceId } };
  }

  if (action === "capture_visible_tab") {
    const target = await resolveSandboxTab({ action, groupId, tabId, params });
    if (!target.ok) return target.failure;
    const tId = target.tabId;
    let winId = firstValue(params.windowId, windowId, target.windowId);
    let effectiveGroupId = target.groupId;
    let focusSwitched = false;
    let wasActive = false;
    const activation = await activateTabForScreenshot(tId);
    const tab = activation?.tab;
    focusSwitched = !!activation?.focusSwitched;
    wasActive = !!activation?.wasActive;
    if (!tab) {
      return commandFailure("Target tab is no longer available for screenshot", {
        code: "TAB_NOT_FOUND",
        suggestion: "Open the page again or switch to an existing tab in the current group before retrying.",
        diagnostics: { tabId: tId, groupId: effectiveGroupId, focusRequired: true, focusSwitched }
      });
    }
    const actualGroupId = normalizeChromeGroupId(tab.groupId);
    if (!sameId(actualGroupId, effectiveGroupId)) {
      return commandFailure("Target tab moved outside the current browser group sandbox", {
        code: "TAB_OUT_OF_GROUP",
        suggestion: "Open or switch to a tab inside the current browser group before retrying.",
        diagnostics: { tabId: tId, actualGroupId, expectedGroupId: effectiveGroupId, focusRequired: true, focusSwitched },
        reason: "invalid_context"
      });
    }
    winId = tab.windowId || winId;
    effectiveGroupId = actualGroupId;
    if (!winId) {
      const wins = await chrome.windows.getAll({ windowTypes: ["normal"] });
      winId = wins[0]?.id;
    }
    if (!winId) {
      return commandFailure("No window found for screenshot", {
        code: "NO_WINDOW_FOR_SCREENSHOT",
        suggestion: "Ensure at least one normal browser window is open before retrying."
      });
    }
    const requestedFormat = String(params.format || DEFAULT_SCREENSHOT_FORMAT).toLowerCase();
    const captureOptions = {
      format: requestedFormat === "png" ? "png" : "jpeg"
    };
    if (captureOptions.format === "jpeg") {
      const requestedQuality = Number(params.quality);
      captureOptions.quality = Number.isFinite(requestedQuality)
        ? Math.min(Math.max(Math.round(requestedQuality), 1), 100)
        : DEFAULT_SCREENSHOT_QUALITY;
    }
    let dataUrl;
    try {
      dataUrl = await chrome.tabs.captureVisibleTab(winId, captureOptions);
    } catch (err) {
      return commandFailure("Screenshot capture failed: " + compactError(err), {
        code: "CAPTURE_FAILED",
        suggestion: "Ensure the target window is visible and not minimized, then retry.",
        diagnostics: {
          windowId: winId,
          tabId: tId,
          groupId: effectiveGroupId,
          format: captureOptions.format,
          quality: captureOptions.quality,
          focusRequired: true,
          focusSwitched,
          wasActive
        }
      });
    }
    if (!dataUrl || typeof dataUrl !== "string" || !dataUrl.startsWith("data:")) {
      return commandFailure("Screenshot capture returned empty or malformed image", {
        code: "CAPTURE_EMPTY",
        suggestion: "Try again after bringing the target tab into the foreground.",
        diagnostics: {
          windowId: winId,
          tabId: tId,
          groupId: effectiveGroupId,
          format: captureOptions.format,
          focusRequired: true,
          focusSwitched,
          wasActive,
          imagePresent: !!dataUrl
        }
      });
    }
    return {
      ok: true,
      result: {
        image: dataUrl,
        format: captureOptions.format,
        quality: captureOptions.quality,
        focusRequired: true,
        focusSwitched,
        diagnostics: {
          focusRequired: true,
          focusSwitched,
          wasActive
        },
        groupId: effectiveGroupId,
        windowId: winId,
        tabId: tId,
        deviceId
      }
    };
  }

  // CDP command: screenshot.
  if (action === "screenshot") {
    const target = await resolveSandboxTab({ action, groupId, tabId, params });
    if (!target.ok) return target.failure;
    const tId = target.tabId;
    let activation = null;
    const tabBeforeCapture = await chrome.tabs.get(tId).catch(() => null);
    const urlForCapture = tabBeforeCapture?.url || "";
    const shouldActivateForCapture = params.activate === true;
    if (shouldActivateForCapture) {
      activation = await activateTabForScreenshot(tId);
      await waitForPageInteractive(tId, Math.min(PAGE_INTERACTIVE_TIMEOUT_MS, 3000));
    }
    await cdpAttach(tId);
    try {
      // Prefer jpeg; use png only when requested.
      const fmt = String(params.format || "jpeg").toLowerCase() === "png" ? "png" : "jpeg";
      const rawQ = Number(params.quality);
      const quality = fmt === "jpeg"
        ? (Number.isFinite(rawQ) ? Math.min(Math.max(Math.round(rawQ), 1), 100) : 70)
        : undefined;
      const fullPage = Boolean(params.fullPage);
      const maxWidth  = Number(params.maxWidth)  || 2000;
      const maxHeight = Number(params.maxHeight) || 2000;

      await new Promise(r => setTimeout(r, SCREENSHOT_STABILIZE_DELAY_MS));

      // Get page/viewport size in CSS pixels and devicePixelRatio.
      // CDP Page.captureScreenshot(fromSurface:true) outputs pixels as CSS * scale * DPR.
      // If DPR is not included in scale, retina screens can double maxWidth and hit upstream image limits.
      let srcW = 1280, srcH = 900, dpr = 1;
      try {
        const { result: dr } = await chrome.debugger.sendCommand(
          { tabId: tId }, "Runtime.evaluate",
          {
            expression: fullPage
              ? `[Math.max(document.documentElement.scrollWidth, window.innerWidth), Math.max(document.documentElement.scrollHeight, window.innerHeight), window.devicePixelRatio || 1]`
              : `[window.innerWidth, window.innerHeight, window.devicePixelRatio || 1]`,
            returnByValue: true
          }
        );
        if (Array.isArray(dr?.value) && dr.value[0] > 0) {
          srcW = dr.value[0];
          srcH = dr.value[1];
          dpr  = Number(dr.value[2]) || 1;
        }
      } catch (_) { /* Fall back to defaults. */ }

      // Goal: image_px == CSS_px (scale*dpr == 1). Scale down only when the CSS viewport exceeds maxW/maxH.
      // 1) 1:1: scale = 1/dpr, so image pixels equal CSS pixels and image-picked coordinates are click coordinates.
      // 2) Over limit: choose a smaller downsampling scale and expose cssPerImagePx for coordinate conversion.
      const oneToOne = 1 / dpr;
      const scale = Math.min(oneToOne, maxWidth / (srcW * dpr), maxHeight / (srcH * dpr));

      const cdpParams = {
        format: fmt,
        fromSurface: true,
        clip: { x: 0, y: 0, width: srcW, height: srcH, scale }
      };
      if (quality !== undefined) cdpParams.quality = quality;
      if (fullPage) cdpParams.captureBeyondViewport = true;

      const { data } = await chrome.debugger.sendCommand({ tabId: tId }, "Page.captureScreenshot", cdpParams);

      const outW = Math.round(srcW * scale * dpr);
      const outH = Math.round(srcH * scale * dpr);
      const cssPerImagePx = 1 / (scale * dpr); // 1 means image and CSS are 1:1; >1 means the image was further downscaled.
      return { ok: true, result: { data, format: fmt, quality, fullPage, width: outW, height: outH, scale, dpr, cssPerImagePx, activatedForCapture: !!activation?.focusSwitched, activationSuggested: !shouldActivateForCapture && /youtube\.com|youtu\.be/i.test(urlForCapture), tabId: tId, groupId: target.groupId, windowId: target.windowId, deviceId } };
    } catch (err) {
      return commandFailure("CDP screenshot failed: " + compactError(err), {
        code: "CDP_SCREENSHOT_FAILED",
        suggestion: "Ensure the debugger can attach to this tab (chrome-extension:// URLs are not supported).",
        diagnostics: { tabId: tId, groupId: target.groupId }
      });
    } finally {
      await cdpDetach(tId);
    }
  }

  // CDP command: cdp_mouse_event.
  if (action === "cdp_mouse_event") {
    const target = await resolveSandboxTab({ action, groupId, tabId, params });
    if (!target.ok) return target.failure;
    const tId = target.tabId;

    // Prefer refId: resolve through the internal CDP ref path based on backendNodeId.
    // Scroll into view if needed, use DOM.getBoxModel for the live center point, then send
    // the normal CDP mouse event chain at (x, y) while preserving isTrusted=true.
    let resolvedTarget = null;
    let eventParams = params;
    if (params.refId) {
      const refId = params.refId;
      const refMap = refMaps.get(tId);
      const backendNodeId = refMap?.refs?.get(refId);
      if (!backendNodeId) {
        return commandFailure(`Element ref "${refId}" not found (call read_page again)`, {
          code: "REF_NOT_FOUND",
          suggestion: "Call read_page to get fresh ref IDs, then retry."
        });
      }
      await cdpAttach(tId);
      try {
        await chrome.debugger.sendCommand({ tabId: tId }, "DOM.scrollIntoViewIfNeeded", { backendNodeId }).catch(() => {});
        const boxRes = await chrome.debugger.sendCommand({ tabId: tId }, "DOM.getBoxModel", { backendNodeId });
        const border = boxRes?.model?.border;
        if (!Array.isArray(border) || border.length < 8) {
          return commandFailure(`Element ref "${refId}" has no box (detached?)`, {
            code: "REF_NO_BOX",
            suggestion: "Call read_page again — the element may have been removed or moved offscreen.",
            diagnostics: { refId }
          });
        }
        const xs = [border[0], border[2], border[4], border[6]];
        const ys = [border[1], border[3], border[5], border[7]];
        const cx = Math.round((Math.min(...xs) + Math.max(...xs)) / 2);
        const cy = Math.round((Math.min(...ys) + Math.max(...ys)) / 2);
        resolvedTarget = { refId, x: cx, y: cy, rect: { x: Math.round(Math.min(...xs)), y: Math.round(Math.min(...ys)), width: Math.round(Math.max(...xs) - Math.min(...xs)), height: Math.round(Math.max(...ys) - Math.min(...ys)) } };
        eventParams = { ...eventParams, x: cx, y: cy };
      } catch (err) {
        return commandFailure("CDP refId resolve failed: " + compactError(err), {
          code: "CDP_RESOLVE_REF_FAILED",
          diagnostics: { tabId: tId, refId }
        });
      }
    }

    await cdpAttach(tId);
    let newTabsCapture = null;
    let scrollSettled = null;
    try {
      const { mouseEventType, x = 0, y = 0, button = "left", clickCount = 1, deltaX = 0, deltaY = 0 } = eventParams;
      const base = { x: Number(x), y: Number(y), modifiers: 0, button, clickCount: Number(clickCount) };
      let mayOpenNewTab = false;
      let didClickRelease = false;
      if (mouseEventType === "hover") {
        await chrome.debugger.sendCommand({ tabId: tId }, "Input.dispatchMouseEvent", { type: "mouseMoved", ...base, button: "none", clickCount: 0 });
      } else if (mouseEventType === "mouseWheel") {
        await chrome.debugger.sendCommand({ tabId: tId }, "Input.dispatchMouseEvent", { type: "mouseWheel", x: Number(x), y: Number(y), deltaX: Number(deltaX), deltaY: Number(deltaY) });
        scrollSettled = await waitForScrollSettled(tId, SCROLL_SETTLE_TIMEOUT_MS);
      } else if (mouseEventType === "mousePressed") {
        await chrome.debugger.sendCommand({ tabId: tId }, "Input.dispatchMouseEvent", { type: "mousePressed", ...base });
      } else {
        ensureNewTabInterceptors(tId).catch(() => {});
        newTabsCapture = startNewTabsCapture({ sourceTabId: tId, sourceWindowId: target.windowId });
        await chrome.debugger.sendCommand({ tabId: tId }, "Input.dispatchMouseEvent", { type: "mouseMoved", ...base, button: "none", clickCount: 0 });
        await new Promise(r => setTimeout(r, 100));
        await chrome.debugger.sendCommand({ tabId: tId }, "Input.dispatchMouseEvent", { type: "mousePressed", ...base });
        await chrome.debugger.sendCommand({ tabId: tId }, "Input.dispatchMouseEvent", { type: "mouseReleased", ...base });
        mayOpenNewTab = true;
        didClickRelease = true;
      }

      // Hit-test after click/release so callers know which DOM node was hit without another screenshot guess.
      let hit = null;
      if (didClickRelease) {
        try {
          const nodeRes = await chrome.debugger.sendCommand(
            { tabId: tId }, "DOM.getNodeForLocation",
            { x: Number(x), y: Number(y), includeUserAgentShadowDOM: true }
          );
          if (nodeRes?.backendNodeId) {
            let nodeName = null, attrs = null;
            try {
              const desc = await chrome.debugger.sendCommand(
                { tabId: tId }, "DOM.describeNode",
                { backendNodeId: nodeRes.backendNodeId }
              );
              nodeName = desc?.node?.nodeName || null;
              const a = desc?.node?.attributes;
              if (Array.isArray(a)) {
                attrs = {};
                for (let i = 0; i + 1 < a.length; i += 2) attrs[a[i]] = a[i + 1];
              }
            } catch (_) { /* Keep backendNodeId even if describeNode fails. */ }
            hit = { backendNodeId: nodeRes.backendNodeId, nodeName, attrs };
          }
        } catch (_) { /* Hit-test failure should not affect the main flow. */ }
      }

      const result = { tabId: tId, groupId: target.groupId, windowId: target.windowId, deviceId };
      if (resolvedTarget) result.target = resolvedTarget;
      if (scrollSettled) result.scrollSettled = scrollSettled;
      if (hit) result.hit = hit;
      const out = { ok: true, result };
      if (mayOpenNewTab) {
        const newTabs = newTabsCapture ? await newTabsCapture.finish() : await collectNewTabsForOpener(tId);
        attachNewTabs(out, newTabs);
      }
      return out;
    } catch (err) {
      const failure = commandFailure("CDP mouse event failed: " + compactError(err), {
        code: "CDP_MOUSE_FAILED",
        suggestion: "Ensure the debugger can attach to this tab.",
        diagnostics: { tabId: tId, groupId: target.groupId, params }
      });
      if (newTabsCapture) attachNewTabs(failure, await newTabsCapture.finish());
      return failure;
    } finally {
      await cdpDetach(tId);
    }
  }

  // CDP command: cdp_type.
  if (action === "cdp_type") {
    const target = await resolveSandboxTab({ action, groupId, tabId, params });
    if (!target.ok) return target.failure;
    const tId = target.tabId;
    await cdpAttach(tId);
    try {
      await chrome.debugger.sendCommand({ tabId: tId }, "Input.insertText", { text: String(params.text || "") });
      return { ok: true, result: { tabId: tId, groupId: target.groupId, windowId: target.windowId, deviceId } };
    } catch (err) {
      return commandFailure("CDP insertText failed: " + compactError(err), {
        code: "CDP_TYPE_FAILED",
        suggestion: "Focus an input element before calling cdp_type.",
        diagnostics: { tabId: tId, groupId: target.groupId }
      });
    } finally {
      await cdpDetach(tId);
    }
  }

  // CDP command: cdp_key.
  if (action === "cdp_key") {
    const target = await resolveSandboxTab({ action, groupId, tabId, params });
    if (!target.ok) return target.failure;
    const tId = target.tabId;
    await cdpAttach(tId);
    let newTabsCapture = null;
    try {
      const KEY_MODIFIERS = { Alt: 1, Control: 2, Meta: 4, Shift: 8 };
      // Mapping -> { key, code, vk, text? }
      // key  = KeyboardEvent.key standard value ("Return" must be converted to "Enter").
      // code = KeyboardEvent.code physical key name.
      // vk   = Windows/native virtualKeyCode; required for function keys or browser side effects will not run.
      // text = Enter/character keys need text to trigger the full input/submit event chain.
      const KEY_SPEC = {
        Return:    { key: "Enter",     code: "Enter",       vk: 13, text: "\r" },
        Enter:     { key: "Enter",     code: "Enter",       vk: 13, text: "\r" },
        Escape:    { key: "Escape",    code: "Escape",      vk: 27 },
        Backspace: { key: "Backspace", code: "Backspace",   vk: 8 },
        Delete:    { key: "Delete",    code: "Delete",      vk: 46 },
        Tab:       { key: "Tab",       code: "Tab",         vk: 9 },
        Space:     { key: " ",         code: "Space",       vk: 32, text: " " },
        ArrowUp:    { key: "ArrowUp",    code: "ArrowUp",    vk: 38 },
        ArrowDown:  { key: "ArrowDown",  code: "ArrowDown",  vk: 40 },
        ArrowLeft:  { key: "ArrowLeft",  code: "ArrowLeft",  vk: 37 },
        ArrowRight: { key: "ArrowRight", code: "ArrowRight", vk: 39 },
        Home:     { key: "Home",     code: "Home",     vk: 36 },
        End:      { key: "End",      code: "End",      vk: 35 },
        PageUp:   { key: "PageUp",   code: "PageUp",   vk: 33 },
        PageDown: { key: "PageDown", code: "PageDown", vk: 34 },
        F1:  { key: "F1",  code: "F1",  vk: 112 }, F2:  { key: "F2",  code: "F2",  vk: 113 },
        F3:  { key: "F3",  code: "F3",  vk: 114 }, F4:  { key: "F4",  code: "F4",  vk: 115 },
        F5:  { key: "F5",  code: "F5",  vk: 116 }, F6:  { key: "F6",  code: "F6",  vk: 117 },
        F7:  { key: "F7",  code: "F7",  vk: 118 }, F8:  { key: "F8",  code: "F8",  vk: 119 },
        F9:  { key: "F9",  code: "F9",  vk: 120 }, F10: { key: "F10", code: "F10", vk: 121 },
        F11: { key: "F11", code: "F11", vk: 122 }, F12: { key: "F12", code: "F12", vk: 123 },
      };
      const parts = String(params.keys || "").split("+");
      const last = parts[parts.length - 1];
      const modifiers = parts.slice(0, -1).reduce((m, k) => m | (KEY_MODIFIERS[k] || 0), 0);
      let spec;
      if (KEY_SPEC[last]) {
        spec = KEY_SPEC[last];
      } else if (last.length === 1) {
        // Single character: letters -> KeyX, digits -> DigitN; vk uses uppercase ASCII (A=65, 0=48).
        const ch = last;
        const up = ch.toUpperCase();
        const isLetter = /[A-Z]/.test(up);
        const isDigit = /[0-9]/.test(up);
        const code = isLetter ? `Key${up}` : isDigit ? `Digit${up}` : up;
        // Pass text only when there are no behavior-changing modifiers such as Ctrl/Meta.
        const noTextMods = (modifiers & ~8) === 0; // Allow Shift.
        spec = { key: ch, code, vk: up.charCodeAt(0), text: noTextMods ? ch : undefined };
      } else {
        spec = { key: last, code: last, vk: 0 };
      }
      const baseEvent = {
        key: spec.key,
        code: spec.code,
        modifiers,
        windowsVirtualKeyCode: spec.vk,
        nativeVirtualKeyCode: spec.vk,
      };
      newTabsCapture = startNewTabsCapture({ sourceTabId: tId, sourceWindowId: target.windowId });
      // text triggers input/keypress; function keys without text let CDP handle side effects.
      const downType = spec.text ? "keyDown" : "rawKeyDown";
      const downEvent = { type: downType, ...baseEvent };
      if (spec.text) {
        downEvent.text = spec.text;
        downEvent.unmodifiedText = spec.text;
      }
      await chrome.debugger.sendCommand({ tabId: tId }, "Input.dispatchKeyEvent", downEvent);
      await chrome.debugger.sendCommand({ tabId: tId }, "Input.dispatchKeyEvent", { type: "keyUp", ...baseEvent });
      const out = { ok: true, result: { tabId: tId, groupId: target.groupId, windowId: target.windowId, deviceId } };
      // Enter/Space can activate links/buttons, so check for new tabs opportunistically.
      const newTabs = await newTabsCapture.finish();
      attachNewTabs(out, newTabs);
      return out;
    } catch (err) {
      const failure = commandFailure("CDP key event failed: " + compactError(err), {
        code: "CDP_KEY_FAILED",
        suggestion: "Check the key name format (e.g. 'Return', 'Control+a').",
        diagnostics: { tabId: tId, groupId: target.groupId, keys: params.keys }
      });
      if (newTabsCapture) attachNewTabs(failure, await newTabsCapture.finish());
      return failure;
    } finally {
      await cdpDetach(tId);
    }
  }

  // CDP command: cdp_evaluate (bypasses CSP).
  if (action === "cdp_evaluate") {
    const target = await resolveSandboxTab({ action, groupId, tabId, params });
    if (!target.ok) return target.failure;
    const tId = target.tabId;
    await cdpAttach(tId);
    try {
      const { result: evalResult, exceptionDetails } = await chrome.debugger.sendCommand(
        { tabId: tId }, "Runtime.evaluate",
        { expression: String(params.code || ""), returnByValue: true, awaitPromise: true }
      );
      if (exceptionDetails) {
        return commandFailure("JS execution error: " + (exceptionDetails.exception?.description || exceptionDetails.text), {
          code: "CDP_EVALUATE_ERROR",
          diagnostics: { tabId: tId, groupId: target.groupId, exceptionDetails }
        });
      }
      return { ok: true, result: { value: evalResult?.value, type: evalResult?.type, tabId: tId, groupId: target.groupId, windowId: target.windowId, deviceId } };
    } catch (err) {
      return commandFailure("CDP evaluate failed: " + compactError(err), {
        code: "CDP_EVALUATE_FAILED",
        suggestion: "Ensure the debugger can attach to this tab.",
        diagnostics: { tabId: tId, groupId: target.groupId }
      });
    } finally {
      await cdpDetach(tId);
    }
  }

  // CDP command: read_console.
  if (action === "read_console") {
    const target = await resolveSandboxTab({ action, groupId, tabId, params });
    if (!target.ok) return target.failure;
    const tId = target.tabId;
    if (!cdpAttached.has(tId)) await cdpAttach(tId);
    const state = cdpAttached.get(tId);
    let entries = [...state.consoleEntries];
    if (params.onlyErrors) entries = entries.filter(e => e.type === "error" || e.type === "warning");
    if (params.pattern) {
      try {
        const re = new RegExp(params.pattern, "i");
        entries = entries.filter(e => e.args?.some(a => re.test(String(a?.value ?? ""))));
      } catch (_) {}
    }
    const limit = Math.min(Number(params.limit) || 100, 500);
    entries = entries.slice(-limit);
    if (params.clear) state.consoleEntries = [];
    return { ok: true, result: { entries, count: entries.length, tabId: tId, groupId: target.groupId, deviceId } };
  }

  // CDP command: read_network.
  if (action === "read_network") {
    const target = await resolveSandboxTab({ action, groupId, tabId, params });
    if (!target.ok) return target.failure;
    const tId = target.tabId;
    if (!cdpAttached.has(tId)) await cdpAttach(tId);
    const state = cdpAttached.get(tId);
    let entries = [...state.networkEntries];
    if (params.urlPattern) {
      try {
        const re = new RegExp(params.urlPattern, "i");
        entries = entries.filter(e => {
          const url = e.params?.request?.url || e.params?.response?.url || "";
          return re.test(url);
        });
      } catch (_) {}
    }
    const limit = Math.min(Number(params.limit) || 100, 500);
    entries = entries.slice(-limit);
    if (params.clear) state.networkEntries = [];
    return { ok: true, result: { entries, count: entries.length, tabId: tId, groupId: target.groupId, deviceId } };
  }

  // CDP command: zoom (crop screenshot to a coordinate region).
  if (action === "zoom") {
    const target = await resolveSandboxTab({ action, groupId, tabId, params });
    if (!target.ok) return target.failure;
    const tId = target.tabId;
    let activation = null;
    const tabBeforeCapture = await chrome.tabs.get(tId).catch(() => null);
    const urlForCapture = tabBeforeCapture?.url || "";
    const shouldActivateForCapture = params.activate === true;
    if (shouldActivateForCapture) {
      activation = await activateTabForScreenshot(tId);
      await waitForPageInteractive(tId, Math.min(PAGE_INTERACTIVE_TIMEOUT_MS, 3000));
    }
    const { x1 = 0, y1 = 0, x2, y2 } = params;
    if (x2 == null || y2 == null) {
      return commandFailure("zoom requires x1, y1, x2, y2", { code: "MISSING_PARAMS",
        suggestion: "Pass the top-left (x1,y1) and bottom-right (x2,y2) corners of the region." });
    }
    await cdpAttach(tId);
    try {
      await new Promise(r => setTimeout(r, SCREENSHOT_STABILIZE_DELAY_MS));
      const cssW = Number(x2) - Number(x1);
      const cssH = Number(y2) - Number(y1);
      // Read DPR to prevent retina output pixels (CSS * DPR) from exceeding the model's 2000px limit.
      let dpr = 1;
      try {
        const { result: dr } = await chrome.debugger.sendCommand(
          { tabId: tId }, "Runtime.evaluate",
          { expression: "window.devicePixelRatio || 1", returnByValue: true }
        );
        dpr = Number(dr?.value) || 1;
      } catch (_) {}
      // Default to 1:1 (scale=1/dpr, output pixels = CSS pixels), then scale down if over ZOOM_MAX_PIXELS.
      const ZOOM_MAX_PIXELS = 1800;
      const longestCss = Math.max(cssW, cssH);
      const oneToOne = 1 / dpr;
      const fitScale = ZOOM_MAX_PIXELS / (longestCss * dpr);
      const scale = Math.min(oneToOne, fitScale);
      const clip = { x: Number(x1), y: Number(y1), width: cssW, height: cssH, scale };
      const { data } = await chrome.debugger.sendCommand({ tabId: tId }, "Page.captureScreenshot",
        { format: "png", clip, fromSurface: true });
      const outW = Math.round(cssW * scale * dpr);
      const outH = Math.round(cssH * scale * dpr);
      const cssPerImagePx = 1 / (scale * dpr);
      return { ok: true, result: { data, format: "png", clip, width: outW, height: outH, scale, dpr, cssPerImagePx, activatedForCapture: !!activation?.focusSwitched, activationSuggested: !shouldActivateForCapture && /youtube\.com|youtu\.be/i.test(urlForCapture), tabId: tId, groupId: target.groupId, windowId: target.windowId, deviceId } };
    } catch (err) {
      return commandFailure("CDP zoom screenshot failed: " + compactError(err), {
        code: "CDP_ZOOM_FAILED", diagnostics: { tabId: tId, groupId: target.groupId }
      });
    } finally {
      await cdpDetach(tId);
    }
  }

  // Command: wait (fixed delay).
  if (action === "wait") {
    const seconds = Math.min(Math.max(Number(params.seconds) || 1, 0.1), 30);
    await new Promise(r => setTimeout(r, Math.round(seconds * 1000)));
    return { ok: true, result: { waited: true, seconds, deviceId } };
  }

  // CDP command: read_page (based on Accessibility.getFullAXTree).
  // Full CDP path Phase A: replace the content.js manual traversal with Chrome's accessibility tree.
  // It pierces Shadow DOM, resolves aria-labelledby, recognizes contenteditable, assigns ref_N
  // to each meaningful node, and stores backendNodeId for later cdp_mouse_event calls.
  if (action === "read_page") {
    const target = await resolveSandboxTab({ action, groupId, tabId, params });
    if (!target.ok) return target.failure;
    const tId = target.tabId;
    const maxChars = Number.isFinite(Number(params.maxChars)) ? Math.max(1000, Math.min(Number(params.maxChars), 200000)) : 50000;
    const depthCap = Number.isFinite(Number(params.depth)) ? Math.max(1, Math.min(Number(params.depth), 60)) : 40;
    await cdpAttach(tId);
    try {
      // 1) Viewport size, used to filter fully off-screen nodes.
      let viewW = 1280, viewH = 900;
      try {
        const { result: vr } = await chrome.debugger.sendCommand(
          { tabId: tId }, "Runtime.evaluate",
          { expression: "[window.innerWidth, window.innerHeight]", returnByValue: true }
        );
        if (Array.isArray(vr?.value) && vr.value[0] > 0) {
          viewW = vr.value[0]; viewH = vr.value[1];
        }
      } catch (_) { /* Use defaults. */ }

      // 2) Read the full AX tree.
      await chrome.debugger.sendCommand({ tabId: tId }, "Accessibility.enable").catch(() => {});
      const axRes = await chrome.debugger.sendCommand(
        { tabId: tId }, "Accessibility.getFullAXTree", { depth: -1 }
      );
      const axNodes = Array.isArray(axRes?.nodes) ? axRes.nodes : [];
      if (!axNodes.length) {
        return { ok: true, result: { tree: "", truncated: false, url: null, title: null, refCount: 0, deviceId } };
      }

      // 3) Build indexes and find roots.
      const byId = new Map();
      for (const n of axNodes) byId.set(n.nodeId, n);
      const roots = axNodes.filter(n => !n.parentId || !byId.has(n.parentId));

      // 4) First pass: decide which nodes to output.
      //   Rules:
      //   - ignored=true nodes are not output themselves, but their children are still traversed.
      //   - Other nodes: include roles in the interactive/semantic allowlist, accessibleName,
      //     or editable/focusable properties.
      const INTERESTING_ROLES = new Set([
        "button", "link", "textbox", "searchbox", "combobox", "checkbox", "radio",
        "switch", "slider", "spinbutton", "menuitem", "menuitemcheckbox", "menuitemradio",
        "tab", "treeitem", "option", "listbox", "heading", "image", "img", "video", "audio",
        "dialog", "alertdialog", "alert", "tooltip", "navigation", "main", "banner",
        "contentinfo", "form", "search", "region", "article", "table", "grid", "row",
        "cell", "columnheader", "rowheader"
      ]);
      function propMap(n) {
        const m = {};
        for (const p of (n.properties || [])) m[p.name] = p.value?.value;
        return m;
      }
      function isInteresting(n) {
        if (n.ignored) return false;
        const role = n.role?.value;
        if (!role) return false;
        const name = (n.name?.value || "").trim();
        if (INTERESTING_ROLES.has(role)) return true;
        if (name) return true;
        const props = propMap(n);
        if (props.editable === "plaintext" || props.editable === "richtext") return true;
        if (props.focusable && (props.focusable === true || props.focusable === "true")) {
          // Count focusable containers as interesting only when they also have a name.
          return Boolean(name);
        }
        return false;
      }

      // 5) Second pass: collect candidate nodeIds for box lookup and record tree depth for indentation.
      //   Parent-child relationships still follow AX childIds, but only isInteresting nodes enter the
      //   output list. displayDepth controls indentation and increments per interesting ancestor.
      const order = [];   // [{ axNode, displayDepth }]
      function walk(n, displayDepth, structuralDepth) {
        if (!n || structuralDepth > depthCap) return;
        const include = isInteresting(n);
        if (include) order.push({ axNode: n, displayDepth });
        const nextDisplay = include ? displayDepth + 1 : displayDepth;
        for (const cid of (n.childIds || [])) {
          walk(byId.get(cid), nextDisplay, structuralDepth + 1);
        }
      }
      for (const r of roots) walk(r, 0, 0);

      // 6) Batch box reads with chunked concurrency.
      async function getBox(backendNodeId) {
        if (!backendNodeId) return null;
        try {
          const r = await chrome.debugger.sendCommand(
            { tabId: tId }, "DOM.getBoxModel", { backendNodeId }
          );
          const border = r?.model?.border;
          if (!Array.isArray(border) || border.length < 8) return null;
          // border = [x1,y1, x2,y1, x2,y2, x1,y2]; convert it to a bounding box.
          const xs = [border[0], border[2], border[4], border[6]];
          const ys = [border[1], border[3], border[5], border[7]];
          const x = Math.min(...xs), y = Math.min(...ys);
          const w = Math.max(...xs) - x, h = Math.max(...ys) - y;
          return { x: Math.round(x), y: Math.round(y), w: Math.round(w), h: Math.round(h) };
        } catch (_) {
          return null;
        }
      }
      const CONCURRENCY = 25;
      const boxes = new Array(order.length).fill(null);
      for (let i = 0; i < order.length; i += CONCURRENCY) {
        const slice = order.slice(i, i + CONCURRENCY);
        const got = await Promise.all(slice.map(e => getBox(e.axNode.backendDOMNodeId)));
        for (let j = 0; j < got.length; j++) boxes[i + j] = got[j];
      }

      // 7) Filter nodes with no box, fully outside the viewport, or zero area; assign ref_id; build output.
      //   Filtering allows an 800px buffer beyond the viewport to help locate nearby elements after scroll.
      const refMap = getRefMap(tId, { reset: true });
      const VIEW_BUFFER = 800;
      const minX = -VIEW_BUFFER, maxX = viewW + VIEW_BUFFER;
      const minY = -VIEW_BUFFER, maxY = viewH + VIEW_BUFFER;
      let out = "";
      let truncated = false;
      let kept = 0;
      for (let i = 0; i < order.length; i++) {
        const entry = order[i];
        const box = boxes[i];
        if (!box || box.w <= 0 || box.h <= 0) continue;
        if (box.x + box.w < minX || box.x > maxX || box.y + box.h < minY || box.y > maxY) continue;

        const n = entry.axNode;
        refMap.counter += 1;
        const refId = `ref_${refMap.counter}`;
        refMap.refs.set(refId, n.backendDOMNodeId);

        const role = n.role?.value || "generic";
        const name = (n.name?.value || "").trim().replace(/\s+/g, " ").slice(0, 120);
        const nameStr = name ? ` "${name.replace(/"/g, '\\"')}"` : "";
        const props = propMap(n);
        const flags = [];
        if (props.focused === true) flags.push("focused");
        if (props.disabled === true) flags.push("disabled");
        if (props.editable === "plaintext" || props.editable === "richtext") flags.push("editable");
        if (props.checked === true) flags.push("checked");
        if (props.pressed === true) flags.push("pressed");
        if (props.pressed === false) flags.push("not-pressed");
        if (props.selected === true) flags.push("selected");
        if (props.expanded === true) flags.push("expanded");
        if (props.expanded === false && role === "combobox") flags.push("collapsed");
        const flagStr = flags.length ? ` (${flags.join(",")})` : "";

        const line = "  ".repeat(Math.min(entry.displayDepth, 20))
          + `[${refId}] ${role}${nameStr} @${box.x},${box.y},${box.w},${box.h}${flagStr}\n`;
        if (out.length + line.length > maxChars) { truncated = true; break; }
        out += line;
        kept += 1;
      }

      // 8) Metadata.
      let url = null, title = null;
      try {
        const { result: meta } = await chrome.debugger.sendCommand(
          { tabId: tId }, "Runtime.evaluate",
          { expression: "[location.href, document.title]", returnByValue: true }
        );
        if (Array.isArray(meta?.value)) { url = meta.value[0]; title = meta.value[1]; }
      } catch (_) { /* Optional metadata can be omitted. */ }
      let warning = null;
      let suggestion = null;
      if (kept <= 3 && /youtube\.com\/watch/i.test(url || "")) {
        warning = "Accessibility tree only contains the page shell; YouTube content is likely still hydrating.";
        suggestion = "Wait for a YouTube selector such as ytd-watch-flexy button or use find_elements('button[aria-label], button[title]') before looking for the like button.";
      }

      return {
        ok: true,
        result: {
          tree: out,
          truncated,
          refCount: kept,
          totalCandidates: order.length,
          warning,
          suggestion,
          url, title,
          viewport: { width: viewW, height: viewH },
          tabId: tId, groupId: target.groupId, windowId: target.windowId, deviceId
        }
      };
    } catch (err) {
      return commandFailure("CDP read_page failed: " + compactError(err), {
        code: "CDP_READ_PAGE_FAILED",
        suggestion: "Ensure the debugger can attach to this tab (chrome-extension:// URLs are not supported).",
        diagnostics: { tabId: tId, groupId: target.groupId }
      });
    }
    // Note: with keepAlive=true, there is no need to detach after cdpAttach, matching other CDP commands.
  }

  // CDP command: resolve_ref (internal and used by cdp_mouse_event).
  // Input refId -> use backendNodeId for a live box, scroll into view if needed, and return the center point.
  if (action === "resolve_ref") {
    const target = await resolveSandboxTab({ action, groupId, tabId, params });
    if (!target.ok) return target.failure;
    const tId = target.tabId;
    const refId = params.refId;
    if (!refId) {
      return commandFailure("Missing refId", { code: "MISSING_REF_ID" });
    }
    const refMap = refMaps.get(tId);
    const backendNodeId = refMap?.refs?.get(refId);
    if (!backendNodeId) {
      return commandFailure(`Element ref "${refId}" not found (call read_page again)`, {
        code: "REF_NOT_FOUND",
        suggestion: "Call read_page to get fresh ref IDs, then retry."
      });
    }
    await cdpAttach(tId);
    try {
      // Scroll into view. Continue on failure because the node may already be in the viewport.
      let scrolledIntoView = false;
      try {
        await chrome.debugger.sendCommand(
          { tabId: tId }, "DOM.scrollIntoViewIfNeeded", { backendNodeId }
        );
        scrolledIntoView = true;
      } catch (_) { /* The node may have been removed; getBoxModel below will report it. */ }

      const boxRes = await chrome.debugger.sendCommand(
        { tabId: tId }, "DOM.getBoxModel", { backendNodeId }
      ).catch(err => { throw err; });
      const border = boxRes?.model?.border;
      if (!Array.isArray(border) || border.length < 8) {
        return commandFailure(`Element ref "${refId}" has no box (detached?)`, {
          code: "REF_NO_BOX",
          suggestion: "Call read_page again — the element may have been removed or moved offscreen.",
          diagnostics: { refId }
        });
      }
      const xs = [border[0], border[2], border[4], border[6]];
      const ys = [border[1], border[3], border[5], border[7]];
      const x = Math.min(...xs), y = Math.min(...ys);
      const w = Math.max(...xs) - x, h = Math.max(...ys) - y;
      const cx = Math.round(x + w / 2);
      const cy = Math.round(y + h / 2);
      return {
        ok: true,
        result: {
          refId,
          x: cx, y: cy,
          rect: { x: Math.round(x), y: Math.round(y), width: Math.round(w), height: Math.round(h) },
          scrolledIntoView,
          tabId: tId, groupId: target.groupId, windowId: target.windowId, deviceId
        }
      };
    } catch (err) {
      return commandFailure("CDP resolve_ref failed: " + compactError(err), {
        code: "CDP_RESOLVE_REF_FAILED",
        diagnostics: { tabId: tId, refId }
      });
    }
  }

  // CDP command: scroll_to_ref.
  if (action === "scroll_to_ref") {
    const target = await resolveSandboxTab({ action, groupId, tabId, params });
    if (!target.ok) return target.failure;
    const tId = target.tabId;
    const refId = params.refId;
    if (!refId) return commandFailure("Missing refId", { code: "MISSING_REF_ID" });
    const refMap = refMaps.get(tId);
    const backendNodeId = refMap?.refs?.get(refId);
    if (!backendNodeId) {
      return commandFailure(`Element ref "${refId}" not found (call read_page again)`, {
        code: "REF_NOT_FOUND"
      });
    }
    await cdpAttach(tId);
    try {
      await chrome.debugger.sendCommand({ tabId: tId }, "DOM.scrollIntoViewIfNeeded", { backendNodeId });
      const scrollSettled = await waitForScrollSettled(tId, SCROLL_SETTLE_TIMEOUT_MS);
      const boxRes = await chrome.debugger.sendCommand({ tabId: tId }, "DOM.getBoxModel", { backendNodeId });
      const border = boxRes?.model?.border;
      let x = null, y = null;
      if (Array.isArray(border) && border.length >= 8) {
        x = Math.round(Math.min(border[0], border[2], border[4], border[6]));
        y = Math.round(Math.min(border[1], border[3], border[5], border[7]));
      }
      return { ok: true, result: { scrolledToRef: true, refId, x, y, scrollSettled, tabId: tId, groupId: target.groupId, windowId: target.windowId, deviceId } };
    } catch (err) {
      return commandFailure("CDP scroll_to_ref failed: " + compactError(err), {
        code: "CDP_SCROLL_TO_REF_FAILED", diagnostics: { tabId: tId, refId }
      });
    }
  }

  // Phase B/C: route all remaining DOM actions through CDP.
  // Historically these actions were handled by content.js through sendToTab. They now use CDP:
  //   - Resource reads (meta/text/html/links/get_attribute/is_visible/get_*_rect/get_input_value/get_element_html) -> Runtime.evaluate
  //   - Interactions (click/double_click/hover/press) -> DOM.querySelector + Input.dispatchMouseEvent/KeyEvent with isTrusted=true
  //   - State changes (fill/clear_input/type_text/select_option/scroll/scroll_to_element/wait_for/find_elements/evaluate_js) -> Runtime.evaluate(awaitPromise)
  // Benefits: no content script injection dependency, consistent cross-page state, and background tab operation.
  const CDP_SELECTOR_ACTIONS = new Set([
    "get_page_meta", "get_page_text", "get_page_snapshot", "get_html", "extract_links",
    "click", "fill", "press", "scroll", "wait_for", "get_text",
    "get_attribute", "is_visible", "get_element_html", "scroll_to_element",
    "select_option", "evaluate_js", "find_elements", "hover", "double_click",
    "get_element_rect", "get_input_value", "clear_input", "type_text"
  ]);
  const NAV_TRIGGER_DOM_ACTIONS = new Set([
    "click", "double_click", "press", "type_text", "fill", "select_option"
  ]);

  if (CDP_SELECTOR_ACTIONS.has(action)) {
    const target = await resolveSandboxTab({ action, groupId, tabId, params });
    if (!target.ok) return target.failure;
    const tId = target.tabId;
    const tab = await refreshTabContext(tId);
    await cdpAttach(tId);
    const newTabsCapture = NAV_TRIGGER_DOM_ACTIONS.has(action)
      ? startNewTabsCapture({ sourceTabId: tId, sourceWindowId: tab?.windowId ?? target.windowId })
      : null;
    if (newTabsCapture) ensureNewTabInterceptors(tId).catch(() => {});

    const finish = (payload) => {
      if (payload?.ok && payload.result && typeof payload.result === "object") {
        payload.result.groupId = normalizeChromeGroupId(tab?.groupId) ?? target.groupId;
        payload.result.tabId = tId;
        payload.result.windowId = tab?.windowId;
        payload.result.deviceId = deviceId;
      }
      return payload;
    };
    const attachNav = async (payload) => {
      if (newTabsCapture) attachNewTabs(payload, await newTabsCapture.finish());
      return payload;
    };

    try {
      const result = await runCdpSelectorAction(action, tId, params);
      return await attachNav(finish(result));
    } catch (err) {
      const failure = commandFailure(compactError(err), {
        code: err?.code || "COMMAND_FAILED",
        suggestion: err?.suggestion,
        diagnostics: err?.diagnostics
      });
      return await attachNav(failure);
    }
  }

  return { ok: false, error: `Unknown action: ${action}` };
}

async function connectSocket() {
  if (socket && [WebSocket.OPEN, WebSocket.CONNECTING].includes(socket.readyState)) return;
  if (isConnecting) return;
  isConnecting = true;
  clearReconnect();
  cancelPendingDisconnect();
  manualDisconnect = false;
  await loadWsUrl();

  log("connecting to", wsUrl);
  updateStatus(false, "Connecting...");

  try {
    socket = new WebSocket(wsUrl);

    socket.onopen = async () => {
      resetSocketHealth();
      reconnectAttempt = 0;
      updateStatus(false, "Registering...");
      rememberEvent("connected", "WebSocket opened", { wsUrl });
      await sendRegisterFrame();
      startHeartbeat();
    };

    socket.onclose = event => {
      isConnecting = false;
      clearHeartbeat();
      resetSocketHealth();
      socket = null;
      const reason = event?.reason || `code=${event?.code || "unknown"}`;
      rememberEvent("disconnected", reason);
      updateStatus(false, manualDisconnect ? "Disconnected" : "Reconnecting...", manualDisconnect ? "" : reason);
      if (!manualDisconnect) scheduleReconnect();
    };

    socket.onerror = () => {
      isConnecting = false;
      lastError = "WebSocket connection error";
      rememberEvent("error", lastError);
      updateStatus(false, "Connection error", lastError);
    };

    socket.onmessage = async event => {
      let message;
      try {
        message = JSON.parse(event.data);
      } catch (_) {
        return;
      }
      if (handleControlFrame(message)) {
        return;
      }
      if (message?.id) {
        const cached = dedupeLookup(message.id);
        if (cached) {
          log("replay cached reply for duplicate command", message.id);
          safeSend(cached);
          return;
        }
      }
      const start = Date.now();
      try {
        const result = await handleCommand(message);
        if (result !== null && message.id) {
          const reply = commandReply(message, result, Date.now() - start);
          safeSend(reply);
          dedupeRecord(message.id, reply);
          rememberEvent("command", message.payload?.action || message.type || "unknown", { ok: result?.ok !== false });
        }
      } catch (err) {
        const reply = commandReply(message, commandFailure(compactError(err), {
          code: err?.code || "COMMAND_FAILED",
          suggestion: err?.suggestion,
          diagnostics: err?.diagnostics
        }), Date.now() - start);
        safeSend(reply);
        dedupeRecord(message.id, reply);
        rememberEvent("error", "Command failed", {
          error: compactError(err),
          action: message.payload?.action,
          errorCode: err?.code
        });
      }
    };
  } catch (err) {
    isConnecting = false;
    lastError = compactError(err);
    rememberEvent("error", "WebSocket create failed", { error: lastError });
    updateStatus(false, "Connection error", lastError);
    scheduleReconnect();
  }
}

function disconnectSocket() {
  manualDisconnect = true;
  clearHeartbeat();
  clearReconnect();
  cancelPendingDisconnect();
  isConnecting = false;
  resetSocketHealth();
  if (socket) {
    try { socket.close(); } catch (_) {}
    socket = null;
  }
  rememberEvent("disconnected", "Manual disconnect");
  updateStatus(false, "Disconnected");
}

// MV3 service workers are evicted on idle; chrome.alarms periodically wakes us up so we
// can reconnect a dropped WebSocket and resume heartbeat even after the SW was killed.
// Minimum periodic interval in MV3 is 30 seconds.
const WATCHDOG_ALARM_NAME = "storeclaw-operator-watchdog";

function ensureWatchdogAlarm() {
  try {
    chrome.alarms.create(WATCHDOG_ALARM_NAME, { periodInMinutes: 0.5 });
  } catch (err) {
    log("alarms.create failed", compactError(err));
  }
}

chrome.alarms.onAlarm.addListener(async alarm => {
  if (alarm?.name !== WATCHDOG_ALARM_NAME) return;
  // Matching tab exists => must be connected. Even if the earlier 10s timer called disconnectSocket
  // (manualDisconnect=true), connectSocket resets it internally. This covers missed onCreated events.
  if (!(await hasAnyTriggerTab())) return;
  if (!socket || socket.readyState === WebSocket.CLOSED || socket.readyState === WebSocket.CLOSING) {
    connectSocket().catch(err => log("watchdog reconnect failed", compactError(err)));
    return;
  }
  if (socket.readyState === WebSocket.OPEN) {
    sendHeartbeat().catch(err => log("watchdog heartbeat failed", compactError(err)));
  }
});

chrome.runtime.onInstalled.addListener(async () => {
  ensureWatchdogAlarm();
  if (await hasAnyTriggerTab()) connectSocket();

  // Inject handshake into already-open matching tabs so users do not need to refresh after installation.
  try {
    const tabs = await chrome.tabs.query({
      url: [
        'https://www.storeclaw.ai/*',
      ],
    });
    for (const tab of tabs) {
      if (tab.id) {
        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ['handshake.js'],
        }).catch(() => {});
      }
    }
  } catch (_) {}
});
chrome.runtime.onStartup.addListener(async () => {
  ensureWatchdogAlarm();
  if (await hasAnyTriggerTab()) connectSocket();
});
// Also run on every service-worker cold-start so the watchdog survives unexpected evictions.
ensureWatchdogAlarm();

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.action === "connect_socket") {
    connectSocket().then(() => sendResponse({ ok: true })).catch(err => sendResponse({ ok: false, error: compactError(err) }));
    return true;
  }
  if (message?.action === "disconnect_socket") {
    disconnectSocket();
    sendResponse({ ok: true });
    return true;
  }
  if (message?.action === "socket_status") {
    sendResponse({ ok: true, connected: isConnected, connecting: isConnecting, wsUrl, lastError, reconnectAttempt, text: statusText });
    return true;
  }
  if (message?.action === "get_gateway_ws_url") {
    loadWsUrl().then(url => sendResponse({ ok: true, wsUrl: url })).catch(err => sendResponse({ ok: false, error: compactError(err) }));
    return true;
  }
  if (message?.action === "set_gateway_ws_url") {
    setWsUrl(message.wsUrl)
      .then(() => {
        disconnectSocket();
        manualDisconnect = false;
        return connectSocket();
      })
      .then(() => sendResponse({ ok: true, wsUrl }))
      .catch(err => sendResponse({ ok: false, error: compactError(err) }));
    return true;
  }
  if (message?.action === "get_event_log") {
    chrome.storage.local.get("eventLog").then(stored => sendResponse({ ok: true, events: stored.eventLog || eventLog }));
    return true;
  }
  if (message?.action === "get_device_id" || message?.action === "get_client_id") {
    getOrCreateDeviceId().then(id => sendResponse({ ok: true, deviceId: id }));
    return true;
  }
  if (message?.action === "__ping__") {
    sendResponse({ ok: true });
    return false;
  }
  if (message?.action === "get_current_tab_info") {
    const senderTabId = sender?.tab?.id;
    const query = senderTabId
      ? chrome.tabs.get(senderTabId)
      : chrome.tabs.query({ active: true, currentWindow: true }).then(ts => ts[0]);
    query.then(t => sendResponse({ ok: true, tabId: t?.id, windowId: t?.windowId }))
         .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
});

// New matching tab => establish WS immediately. connectSocket is idempotent.
chrome.tabs.onCreated.addListener((tab) => {
  if (urlMatchesTrigger(tab.pendingUrl || tab.url)) {
    cancelPendingDisconnect();
    connectSocket().catch(err => log("connectSocket from tab.onCreated failed", compactError(err)));
  }
});

// Matching URL change => trigger WS connection for address-bar navigation, login redirects, SPA chat entry, etc.
// Note: tab focus changes go through onActivated and do not trigger this listener. This listener only connects.
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (!changeInfo.url) return;
  if (urlMatchesTrigger(changeInfo.url)) {
    cancelPendingDisconnect();
    connectSocket().catch(err => log("connectSocket from tab.onUpdated failed", compactError(err)));
  }
});

chrome.tabs.onCreated.addListener((tab) => {
  const opener = tab.openerTabId;
  if (!opener) return;
  const groupId = tabToGroupMap[opener];

  const entry = { tabId: tab.id, openedAt: Date.now(), url: tab.pendingUrl || tab.url || "", windowId: tab.windowId, openerTabId: opener };
  const buf = recentlyOpenedByOpener.get(opener) || [];
  buf.push(entry);
  recentlyOpenedByOpener.set(opener, buf);

  emitDeviceEvent("tab_opened", { tabId: tab.id, openerTabId: opener, groupId, windowId: tab.windowId }).catch(() => {});
});

chrome.tabs.onRemoved.addListener(tabId => {
  const groupId = tabToGroupMap[tabId];
  cleanupSessionBindings({ tabId });
  if (groupId && groupStore[groupId]) {
    groupStore[groupId].tabIds = groupStore[groupId].tabIds.filter(id => id !== tabId);
    if (!groupStore[groupId].tabIds.length) cleanupSessionBindings({ groupId });
  }
  recentlyOpenedByOpener.delete(tabId);
  for (const [opener, buf] of recentlyOpenedByOpener) {
    const next = buf.filter(e => e.tabId !== tabId);
    if (next.length) recentlyOpenedByOpener.set(opener, next);
    else recentlyOpenedByOpener.delete(opener);
  }
  emitDeviceEvent("tab_removed", { tabId, groupId }).catch(() => {});
  armDisconnectCheck();
});

chrome.tabs.onAttached.addListener((tabId, attachInfo) => {
  const groupId = tabToGroupMap[tabId];
  if (!groupId) return;
  if (groupStore[groupId]) groupStore[groupId].windowId = attachInfo.newWindowId;
  refreshTabContext(tabId).catch(() => {});
});

chrome.tabs.onMoved.addListener(tabId => {
  if (!tabToGroupMap[tabId]) return;
  refreshTabContext(tabId).catch(() => {});
});

chrome.tabs.onActivated.addListener(activeInfo => {
  const groupId = tabToGroupMap[activeInfo.tabId];
  if (!groupId) return;
  refreshTabContext(activeInfo.tabId).then(() => emitDeviceEvent("tab_activated", { tabId: activeInfo.tabId, windowId: activeInfo.windowId, groupId })).catch(() => {});
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (!tabToGroupMap[tabId]) return;
  // URL changes mean real navigation; all old refIds are invalid. SPA history changes also flow through here.
  if (changeInfo.url) clearRefMap(tabId);
  if (changeInfo.status || changeInfo.url || tab.windowId != null) {
    refreshTabContext(tabId).catch(() => {});
  }
});


chrome.tabGroups.onRemoved.addListener(group => {
  const groupId = typeof group === "object" ? group.id : group;
  // Tabs may remain after a group is removed, so proactively detach CDP to avoid stale debugger banners.
  const tabIds = groupStore[groupId]?.tabIds || [];
  for (const tId of tabIds) cdpForceDetach(tId).catch(() => {});
  cleanupSessionBindings({ groupId });
  emitDeviceEvent("group_removed", { groupId }).catch(() => {});
});

chrome.windows.onRemoved.addListener(windowId => {
  for (const [groupId, group] of Object.entries(groupStore)) {
    if (group.windowId === windowId) cleanupSessionBindings({ groupId });
  }
  emitDeviceEvent("window_removed", { windowId }).catch(() => {});
});

log("Service worker starting...");
loadWsUrl()
  .then(() => updateHeaderInjectRules().catch(() => {}))
  .catch(() => {})
  .finally(async () => {
    if (await hasAnyTriggerTab()) connectSocket();
  });
