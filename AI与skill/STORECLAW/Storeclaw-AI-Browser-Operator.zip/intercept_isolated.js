// =============================================================
// Storeclaw AI Browser Operator - target=_blank interception (ISOLATED world)
// =============================================================
// Purpose: keep agent-controlled tabs from opening a new tab when target=_blank is clicked.
// Otherwise the LLM keeps watching the old tab and may think the action did nothing.
// =============================================================

(() => {
  if (window.__claudeBlankInterceptorInstalled) return;
  window.__claudeBlankInterceptorInstalled = true;

  function findAnchor(target) {
    let el = target;
    while (el && el !== document) {
      if (el.tagName === "A" && el.href) return el;
      el = el.parentNode;
    }
    return null;
  }

  document.addEventListener(
    "click",
    (event) => {
      // Preserve intentional user tab-opening with modifier keys or the middle mouse button.
      if (event.button !== 0) return;
      if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;

      const anchor = findAnchor(event.target);
      if (!anchor) return;
      const target = (anchor.getAttribute("target") || "").toLowerCase();
      if (target !== "_blank") return;

      const href = anchor.href;
      if (!href || href.startsWith("javascript:")) return;

      event.preventDefault();
      event.stopPropagation();
      try {
        window.location.assign(href);
      } catch (_) {
        window.location.href = href;
      }
    },
    true
  );
})();
