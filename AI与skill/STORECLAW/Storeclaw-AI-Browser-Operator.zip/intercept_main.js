// =============================================================
// Storeclaw AI Browser Operator - window.open interception (MAIN world)
// =============================================================
// Must run in MAIN world to patch the actual window.open used by the page.
// =============================================================

(() => {
  if (window.__claudeWindowOpenPatched) return;
  window.__claudeWindowOpenPatched = true;

  const originalOpen = window.open;

  window.open = function (url, _name, _features) {
    try {
      if (url) {
        const target = String(url);
        if (target && !target.startsWith("javascript:")) {
          window.location.assign(target);
        }
      }
    } catch (_) {
      try {
        return originalOpen.apply(window, arguments);
      } catch (__) {}
    }
    return window;
  };
})();
