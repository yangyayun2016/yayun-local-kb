const menuItems = Array.from(document.querySelectorAll(".menu-item"));

const ACTION_URLS = {
  "new-task": "https://www.storeclaw.ai/app/my-browser?step=new",
  "settings": "https://www.storeclaw.ai/app/my-browser/settings",
  "security": "https://www.storeclaw.ai/my-browser?step=security",
  "tutorial": "https://www.storeclaw.ai/my-browser?step=usage",
  "feedback": "https://www.storeclaw.ai/help-center/articles/browser-extension-install"
};

for (const item of menuItems) {
  item.addEventListener("click", async () => {
    const action = item.dataset.action;
    const url = ACTION_URLS[action];
    if (url) {
      await chrome.tabs.create({ url });
    }

    chrome.runtime.sendMessage({
      channel: "popup_menu_click",
      action,
      clickedAt: new Date().toISOString()
    }).catch(() => {});
  });
}
