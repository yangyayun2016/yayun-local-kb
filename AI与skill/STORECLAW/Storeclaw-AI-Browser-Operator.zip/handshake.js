// =============================================================
// Storeclaw AI Browser Operator - Handshake (ISOLATED world)
// =============================================================
// Use postMessage to let the Storeclaw web app detect that the extension is installed.
// Injection timing: document_start, so the ready signal is broadcast as early as possible.
// =============================================================

(() => {
  const VERSION = chrome.runtime.getManifest().version;
  const EXTENSION_ID = chrome.runtime.id;

  // Active broadcast.
  window.postMessage(
    {
      source: 'storeclaw-browser-extension',
      type: 'STORECLAW_EXTENSION_READY',
      version: VERSION,
      extensionId: EXTENSION_ID,
    },
    '*',
  );

  // Respond to page queries after pinging background to avoid stale scripts replying after uninstall.
  window.addEventListener('message', (event) => {
    if (
      event.data?.source === 'storeclaw-web-app' &&
      event.data?.type === 'STORECLAW_EXTENSION_QUERY'
    ) {
      try {
        chrome.runtime.sendMessage({ action: '__ping__' }).then(() => {
          window.postMessage(
            {
              source: 'storeclaw-browser-extension',
              type: 'STORECLAW_EXTENSION_ACK',
              version: VERSION,
              extensionId: EXTENSION_ID,
            },
            '*',
          );
        }).catch(() => {});
      } catch (_) {}
    }
  });
})();
