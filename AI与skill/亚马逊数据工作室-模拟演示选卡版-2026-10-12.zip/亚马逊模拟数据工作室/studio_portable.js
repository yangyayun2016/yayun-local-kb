// Local script loading works without a web server or fetch(file://).
window.STUDIO_FILES=window.STUDIO_FILES||{};
const shareLoads=new Map();
async function decodeShare(path){const bytes=Uint8Array.from(atob(window.STUDIO_FILES[path]),c=>c.charCodeAt(0));const stream=new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));return JSON.parse(await new Response(stream).text())}
function shareFile(path){
  if(!SHARE.files.includes(path))return Promise.reject(new Error('交付档案未包含 '+path));
  if(!shareLoads.has(path))shareLoads.set(path,new Promise((resolve,reject)=>{const script=document.createElement('script');script.src=path;script.onload=()=>{if(window.STUDIO_FILES[path])decodeShare(path).then(resolve,reject);else reject(new Error('数据文件格式不正确'))};script.onerror=()=>{shareLoads.delete(path);reject(new Error('无法打开 '+path+'，请完整解压，不要单独移动页面'))};document.head.appendChild(script)}));return shareLoads.get(path);
}
async function shareDataset(id){const path=SHARE.datasets[id];if(!path)throw new Error('档案不含数据集 '+id);return shareFile(path)}
function shareSourceEntries(ids,cards){return SHARE.sources.filter(s=>s.dataset?ids.includes(s.dataset):s.cardId?cards.some(c=>c.id===s.cardId):cards.some(c=>s.provider===c.provider&&s.operation===c.operation&&(!s.path||c.provider!=='SP-API'||s.path===c.path)))}
async function shareSources(ids,cards){const result=[];for(const s of shareSourceEntries(ids,cards))result.push({id:s.id,value:await shareFile(s.file)});return result}
function rowPeriod(r){const date=r['date.value']||r.date||r.interval||r.postedDate||r.createdTime||r.scheduledDate||r.asOfDate||r['posted-date'];return date?[String(date).slice(0,10),String(date).slice(0,10)]:[r._from||'',r._to||'']}
async function offlineDataset(params){
  const id=params.get('id'),d=await shareDataset(id),base=dataset(id),country=params.get('country'),currency=params.get('currency'),start=params.get('start'),end=params.get('end');
  const rows=d.rows.filter(r=>{if(country&&r._country!==country)return false;const unit=r['budgetCurrency.value']||r['totalSales.currencyCode']||r['salesByDate.orderedProductSales.currencyCode']||r['salesByAsin.orderedProductSales.currencyCode']||r['amount.currencyCode']||r['netProceeds.currencyCode']||r['totalAmount.currencyCode']||r.currency;if(currency&&unit!==currency)return false;const [a,b]=rowPeriod(r);if(start&&b<start||end&&a>end)return false;if(['ads_campaign_standard','finance_summary','traffic_asin'].includes(id)&&(start&&a<start||end&&b>end))return false;return true});
  const summary=DATA.simulated?demoSummary(base,rows):rows.length===d.rows.length?base:{...base,count:rows.length,metrics:[['当前筛选已保存记录',rows.length,'条']],bars:[],trend:[],samples:rows.slice(0,60),modules:[],note:'离线筛选展示实际记录；原始汇总不直接套到筛选结果，金额与效率由后续经营看板按统一口径计算。'};
  const page=Number(params.get('page')||0);return {summary,rows:rows.slice(page*20,(page+1)*20),total:rows.length,jobs:d.jobs,offline:true};
}
function demoSummary(base,rows){
  const d={...base,count:rows.length,countries:[...new Set(rows.map(r=>r._country))],samples:rows.slice(0,60),trend:[],bars:[],metrics:[],note:'纯模拟演示 · 按所选日期、站点与币种计算；不代表真实店铺经营结果。'},sum=k=>rows.reduce((n,r)=>n+(Number(r[k])||0),0),id=base.id;
  const groups=(labelKey,metric)=>{const buckets=new Map();for(const r of rows){const label=r[labelKey]||'未分类';buckets.set(label,(buckets.get(label)||0)+(metric?Number(r[metric])||0:1))}return [...buckets].map(([label,value])=>({label,value})).sort((a,b)=>b.value-a.value).slice(0,5)};
  if(['sales','traffic','traffic_asin'].includes(id)){
    const prefix=id==='sales'?'totalSales':id==='traffic'?'salesByDate.orderedProductSales':'salesByAsin.orderedProductSales',amount=prefix+'.amount',unit=rows[0]?.[prefix+'.currencyCode']||base.currency;
    d.currency=unit;d.metrics=[['销售额',sum(amount),unit],[id==='sales'?'订单数':id==='traffic'?'订单商品项数':'成交件数',sum(id==='sales'?'orderCount':id==='traffic'?'salesByDate.totalOrderItems':'salesByAsin.unitsOrdered'),id==='sales'?'单':id==='traffic'?'项':'件']];
    if(id==='traffic'){const sessions=sum('trafficByDate.sessions');d.metrics.push(['访问次数',sessions,'次'],['成交件数 / 访问次数',sessions?sum('salesByDate.unitsOrdered')/sessions*100:null,'%'])}
    if(id==='traffic_asin'){d.bars=groups('sku',amount);d.barTitle='商品销售贡献';d.barUnit=unit}
    else{const buckets=new Map();for(const r of rows){const date=rowPeriod(r)[0];buckets.set(date,(buckets.get(date)||0)+(Number(r[amount])||0))}d.trend=[...buckets].map(([date,value])=>({date,value})).sort((a,b)=>a.date.localeCompare(b.date))}
  }else if(id.startsWith('ads_')&&!id.startsWith('ads_config_')){
    const spend=sum('metric.totalCost'),sales=sum('metric.sales'),unit=rows[0]?.['budgetCurrency.value']||base.currency;d.currency=unit;
    d.metrics=[['广告花费',spend,unit],['归因销售',sales,unit],['ACOS',sales?spend/sales*100:null,'%'],['广告订单',sum('metric.purchases'),'单']];
    const key={ads_group:'adGroup.name',ads_target:'targeting.value',ads_search_term:'searchTerm.value',ads_placement:'placementClassification.value',ads_product:'advertisedProduct.name'}[id]||'campaign.name';d.bars=groups(key,id==='ads_product'?'metric.sales':'metric.totalCost');
    const buckets=new Map();for(const r of rows)if(r['date.value'])buckets.set(r['date.value'],(buckets.get(r['date.value'])||0)+(Number(r['metric.totalCost'])||0));d.trend=[...buckets].map(([date,value])=>({date,value})).sort((a,b)=>a.date.localeCompare(b.date));
    d.zeroOrderSpend=rows.filter(r=>r['metric.purchases']===0).reduce((n,r)=>n+r['metric.totalCost'],0);
  }else if(id==='inventory'){
    const country=rows[0]?._country,scopeRows=rows.filter(r=>r._country===country);const total=k=>scopeRows.reduce((n,r)=>n+(Number(r[k])||0),0);
    d.metrics=[['可售',total('inventoryDetails.fulfillableQuantity'),'件'],['预留',total('inventoryDetails.reservedQuantity.totalReservedQuantity'),'件'],['不可售',total('inventoryDetails.unfulfillableQuantity.totalUnfulfillableQuantity'),'件']];d.zeroAvailable=scopeRows.filter(r=>r['inventoryDetails.fulfillableQuantity']===0).length;d.note+=' 库存只按'+(CN[country]||'当前')+'站口径计算，不跨站累加。';
  }else if(id==='finance_transactions'){
    const unit=rows[0]?.['totalAmount.currencyCode']||base.currency;d.metrics=[['交易净额',sum('totalAmount.currencyAmount'),unit],['交易记录',rows.length,'条']];d.bars=groups('transactionType');
  }else if(['aplus','aplus_content'].includes(id)){
    const key=id==='aplus'?'contentMetadata.status':'status';d.bars=groups(key);d.metrics=d.bars.map(x=>[displayValue(x.label),x.value,'份']);d.modules=rows.slice(0,6).map(r=>({name:r.name,country:r._country,modules:r.modules||[]}));
  }else{
    // No old financial totals are reused after a filter changes scope.
    const unchanged=rows.length===base.count;d.metrics=unchanged?base.metrics:[['当前演示记录',rows.length,'条']];d.bars=unchanged?base.bars:groups(['state','status','reason','fulfillment.fulfillmentStatus'].find(k=>rows.some(r=>r[k]))||'_country');
  }
  return d;
}
function crc32(bytes){let crc=0xffffffff;for(const b of bytes){crc^=b;for(let i=0;i<8;i++)crc=(crc>>>1)^((crc&1)?0xedb88320:0)}return (crc^0xffffffff)>>>0}
function zipBytes(files){
  const encoder=new TextEncoder(),parts=[],central=[];let offset=0,centralSize=0;
  for(const file of files){const name=encoder.encode(file.name),bytes=encoder.encode(file.text);if(bytes.length>0xffffffff)throw new Error('单个文件过大');const crc=crc32(bytes),local=new Uint8Array(30+name.length),view=new DataView(local.buffer);view.setUint32(0,0x04034b50,true);view.setUint16(4,20,true);view.setUint16(6,0x800,true);view.setUint16(12,0x21,true);view.setUint32(14,crc,true);view.setUint32(18,bytes.length,true);view.setUint32(22,bytes.length,true);view.setUint16(26,name.length,true);local.set(name,30);parts.push(local,bytes);
    const directory=new Uint8Array(46+name.length),dv=new DataView(directory.buffer);dv.setUint32(0,0x02014b50,true);dv.setUint16(4,20,true);dv.setUint16(6,20,true);dv.setUint16(8,0x800,true);dv.setUint16(14,0x21,true);dv.setUint32(16,crc,true);dv.setUint32(20,bytes.length,true);dv.setUint32(24,bytes.length,true);dv.setUint16(28,name.length,true);dv.setUint32(42,offset,true);directory.set(name,46);central.push(directory);centralSize+=directory.length;offset+=local.length+bytes.length;
  }
  if(files.length>65535||offset+centralSize>0xffffffff)throw new Error('导出规模过大，请拆分看板');const end=new Uint8Array(22),v=new DataView(end.buffer);v.setUint32(0,0x06054b50,true);v.setUint16(8,files.length,true);v.setUint16(10,files.length,true);v.setUint32(12,centralSize,true);v.setUint32(16,offset,true);return new Blob([...parts,...central,end],{type:'application/zip'});
}
async function downloadZip(files,name,dataIds=[],sourceIds=[]){
  name=name.replace(/[\\/:*?"<>|]/g,'_');let url;
  if(location.protocol==='file:'){url=URL.createObjectURL(zipBytes(files))}else{const r=await fetch(DATA.simulated?'/demo-export-board':'/export-board',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({files,name,dataIds,sourceIds})});if(!r.ok)throw new Error('本地压缩包生成失败');url=(await r.json()).url}
  const a=document.createElement('a');a.href=url;a.download=name;a.textContent='点击下载压缩包';a.className='zip-download';a.style.marginLeft='12px';return a;
}
