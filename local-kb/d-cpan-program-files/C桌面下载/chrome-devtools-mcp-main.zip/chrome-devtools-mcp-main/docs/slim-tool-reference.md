<!-- AUTO GENERATED DO NOT EDIT - run 'npm run gen' to update-->

# Chrome DevTools MCP Slim Tool Reference (~359 cl100k_base tokens)

- **[Navigation automation](#navigation-automation)** (1 tools)
  - [`navigate`](#navigate)
- **[Debugging](#debugging)** (2 tools)
  - [`evaluate`](#evaluate)
  - [`screenshot`](#screenshot)

## Navigation automation

### `navigate`

**Description:** Loads a URL

**Parameters:**

- **url** (string) **(required)**: URL to [`navigate`](#navigate) to

---

## Debugging

### `evaluate`

**Description:** Evaluates a JavaScript script

**Parameters:**

- **script** (string) **(required)**: JS script to run on the page

---

### `screenshot`

**Description:** Takes a [`screenshot`](#screenshot)

**Parameters:** None

---
