# 选品条件参数说明与字段映射

## 核心筛选条件与工具字段对应关系

| 用户条件 | 对应工具 | 字段名 | 备注 |
|----------|----------|--------|------|
| PPC 竞价 < $1 | sellersprite_market_research_statistics | avgBid | 类目均值；或来自 keyword_miner 的 bid |
| 售价 < $50 | sellersprite_product_research | maxPrice=50 | 直接过滤参数 |
| 退款率 < 6% | sellersprite_market_product_demand_trend | returnRate | 类目级，非 ASIN 级 |
| 月销量 ≥ 200 | sellersprite_product_research | minUnits=200 | 直接过滤参数 |
| 毛利率 ≥ 25% | sellersprite_product_research | minProfit=0.25 | 含 FBA 费用估算 |
| 评分数 ≤ 500 | sellersprite_product_research | maxRatings=500 | 新品可追赶空间 |

---

## 工具调用顺序与依赖关系

```
[1] sellersprite_product_node        ← 类目名称 → nodeIdPath（可选）
        ↓
[2] sellersprite_product_research    ← 主筛选，获取候选 ASIN 列表
        ↓
[3] sellersprite_market_research_statistics  ← 类目健康度验证（退款率、PPC）
        ↓
[4] sellersprite_competitor_lookup   ← 竞品结构补充
        ↓
[5] 综合打分 → 输出报告
```

---

## 综合评分公式

```
Score = 
  毛利率得分 × 0.30
+ 竞争强度得分 × 0.25
+ 销量规模得分 × 0.20
+ 广告成本得分 × 0.15
+ 退款风险得分 × 0.10
```

### 各维度评分细则

**毛利率得分（profit）**
- ≥ 40%：100 分
- 30-39%：75 分
- 25-29%：50 分
- < 25%：0 分（不入选）

**竞争强度得分（reviews + sellers）**
- reviews ≤ 100 且 sellers ≤ 2：100 分
- reviews ≤ 300 且 sellers ≤ 3：75 分
- reviews ≤ 500 且 sellers ≤ 5：50 分
- 超出以上：25 分

**销量规模得分（totalUnits）**
- ≥ 1000：100 分
- 500-999：75 分
- 200-499：50 分

**广告成本得分（avgBid）**
- < $0.50：100 分
- $0.50-$0.79：75 分
- $0.80-$0.99：50 分
- ≥ $1.00：不入选

**退款风险得分（returnRate）**
- < 2%：100 分
- 2-3.9%：75 分
- 4-5.9%：50 分
- ≥ 6%：不入选

---

## 风险标注规则

在输出表格的"风险标注"列中，当以下条件满足时自动标注：

| 风险标注 | 触发条件 |
|----------|----------|
| ⚠️ 竞争集中 | goodsCrn（商品集中度）> 60% |
| ⚠️ 评分壁垒 | 头部 ASIN 平均评分数 > 2000 |
| ⚠️ 大牌占据 | 品牌为已知头部品牌（如 Instant Pot、YETI 等） |
| ⚠️ 季节性强 | Google Trends 或搜索量同比波动 > 50% |
| ✅ 蓝海机会 | 评分数 < 100 + 月销量 > 300 + 竞价 < $0.6 |

---

## 常见问题

**Q：退款率字段来自哪里，准确吗？**  
A：退款率来自 `sellersprite_market_product_demand_trend` 的 `returnRate` 字段，是该类目节点的整体退款率均值，不是单个 ASIN 的真实退款率。用于初步排除高退款类目，不代表具体产品表现。

**Q：PPC 竞价来源是什么？**  
A：优先使用 `market_research_statistics` 返回的 `avgBid`，其次从 `keyword_miner` 取类目核心词的 bid 均值。两者均为市场估算值，与广告后台实际数据存在偏差。

**Q：毛利率怎么估算？**  
A：`product_research` 返回的 `profit` 字段已含卖家精灵的 FBA 费用估算模型，包含参考售价、FBA 费用、货值比例等，但不含头程运费和汇率损耗，实际利润会略低。

**Q：能筛选日本站或欧洲站吗？**  
A：可以，将 marketplace 参数设为对应站点代码（JP/DE/UK/FR 等），筛选逻辑不变，但竞价和售价单位为对应货币。