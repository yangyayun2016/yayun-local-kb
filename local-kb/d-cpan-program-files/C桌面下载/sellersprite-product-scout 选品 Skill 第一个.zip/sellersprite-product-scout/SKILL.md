---
name: sellersprite-product-scout
description: |
  基于卖家精灵 MCP 工具的亚马逊选品分析 Skill。
  自动调用 product_research、market_research、competitor_lookup 等工具，
  按用户指定条件（PPC竞价、售价、退款率等）筛选潜力 ASIN，
  输出符合标准的候选清单与市场分析报告。
  Use when:
  (1) 用户想找满足价格/竞价/退款率等自定义条件的潜力选品
  (2) 用户说"帮我找 PPC 低、售价便宜的产品"或"筛选有潜力的 ASIN"
  (3) 用户需要从某类目出发做竞争度与盈利空间的快速评估
  (4) 用户想生成一份含 ASIN 数据的选品分析报告

---

## Purpose

帮助亚马逊卖家或选品团队，通过设定多维条件（PPC 竞价上限、售价区间、退款率上限等），
自动从亚马逊市场数据中筛选出符合盈利预期且竞争压力可控的潜力产品，
输出 ASIN 候选清单 + 市场竞争分析报告，辅助快速立项决策。

默认筛选标准（用户未指定时使用）：
- PPC 建议竞价 < $1.00
- 售价 < $50
- 退款率 < 6%
- 月销量 ≥ 200 件
- 评分数 ≤ 500（新品可追赶空间）

---

## Instructions

### 执行流程

**Step 1 — 确认筛选参数**

收集以下参数（未提供则使用默认值）：
| 参数 | 默认值 | 说明 |
|------|--------|------|
| 站点 marketplace | US | 亚马逊站点 |
| 最高 PPC 竞价 | $1.00 | 控制广告成本 |
| 最高售价 | $50 | 价格带筛选 |
| 最高退款率 | 6% | 控制售后风险 |
| 最低月销量 | 200 | 确保有真实需求 |
| 类目关键词 | 用户指定或不限 | 可选，缩小范围 |
| 查询月份 | 最近月份 | yyyyMM 格式 |

若用户未指定类目，先询问一次："请问您想聚焦哪个品类，或直接全站筛选？"

---

**Step 2 — 调用 product_research 获取候选产品**

调用 `sellersprite_product_research`：
```
marketplace: {用户指定}
maxPrice: {最高售价}
minUnits: {最低月销量}
maxRatings: 500            ← 控制竞争门槛
minProfit: 0.25            ← 至少 25% 毛利率
variation: Y               ← 排除变体，只看父 ASIN
size: 20
order: { field: "total_units", desc: true }
nodeIdPath: {如有类目则传入}
returnFields: asin,title,price,totalUnits,totalAmount,profit,rating,reviews,brand,fulfillment,bsrRank,availableDate
```

> 若用户给出类目名称但未给 nodeIdPath，先调用 `sellersprite_product_node` 查询节点 ID。

---

**Step 3 — 逐批调用 market_research 验证市场健康度**

对 Step 2 返回的前 10 个 ASIN 所属类目节点调用 `sellersprite_market_research_statistics`：

重点关注字段：
- `avgReturnRate`（退款率）→ 过滤 > 6% 的类目
- `avgBid`（平均 PPC 竞价）→ 过滤 > $1.00 的类目
- `goodsCrn`（商品集中度）→ > 60% 说明垄断严重，标注风险
- `newAvgUnits`（新品月均销量）→ 新品生存能力参考

---

**Step 4 — 调用 competitor_lookup 补充竞品维度**

针对已过滤的候选 ASIN 列表（最多 10 个），调用 `sellersprite_competitor_lookup`：
```
marketplace: {同上}
asins: [候选 ASIN 列表]
returnFields: asin,title,price,totalUnits,brand,sellers,rating,reviews,profit,fulfillment
```

提取以下信号：
- 卖家数量 sellers ≤ 3：供给端竞争小，利好
- FBA 比例高：物流成本可预期
- 无大牌垄断（brand 非已知头部品牌）

---

**Step 5 — 综合打分与输出**

对每个通过筛选的 ASIN 按以下维度综合打分（满分 100）：

| 维度 | 权重 | 评分逻辑 |
|------|------|----------|
| 盈利空间 | 30% | 毛利率越高越好，≥40% 满分 |
| 竞争强度 | 25% | 评分数越少、卖家越少越好 |
| 销量规模 | 20% | 月销量越高越好 |
| 广告成本 | 15% | PPC 竞价越低越好 |
| 退款风险 | 10% | 退款率越低越好 |

**输出格式（Markdown 表格 + 分析摘要）：**

```
## 🎯 选品筛选结果报告
筛选条件：PPC < $X | 售价 < $X | 退款率 < X%
数据月份：YYYYMM | 站点：XX

### 候选 ASIN 清单
| 综合评分 | ASIN | 标题 | 售价 | 月销量 | 估算毛利率 | 评分数 | PPC竞价 | 市场退款率 | 风险标注 |
...

### 各 ASIN 简析
逐条输出 2-3 句分析，说明入选理由和需关注的风险点。

### 市场总结
3-5 句整体判断：需求趋势、竞争格局、推荐切入策略。
```

---

**Step 6 — 可选深化分析**

若用户希望进一步分析某个 ASIN，可：
- 调用 `sellersprite_traffic_keyword` 获取流量关键词
- 调用 `sellersprite_keepa_info` 查看历史趋势
- 调用 `sellersprite_review` 分析差评，挖掘产品改进点

---

## Examples

**输入：** "帮我找 PPC 低于 1 块、售价在 50 以内的潜力品，美国站，厨房类目"
**输出：** 自动调用三个工具后，输出含 8-12 个 ASIN 的清单表格 + 每款 2-3 句简析 + 市场总结

**输入：** "我想找退款率低的产品，要求月销量至少 500 件"
**输出：** 询问类目偏好后，调整 minUnits=500、maxReturnRate=6%，完整执行 Step 1-5

---

## Guardrails

- **不做什么**：不做 Listing 撰写、不做广告投放操作、不做库存决策
- **数据依赖**：所有数据来自卖家精灵 MCP 工具，无法连接时给出友好提示
- **退款率说明**：`sellersprite_market_product_demand_trend` 返回的是类目级退款率，非 ASIN 级；向用户说明这一局限性
- **PPC 竞价说明**：来自 `sellersprite_keyword_miner` 或 `market_research` 的 `avgBid` 字段，为市场均值估算，非精确广告后台数据
- **结果上限**：单次最多输出 15 个候选 ASIN，避免信息过载
- **不适用场景**：不适合用于非亚马逊平台选品；不做专利/合规风险排查