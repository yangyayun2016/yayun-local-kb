"use client";

/**
 * 亚马逊流量瀑布 / 广告分析看板 — 单文件 React 组件
 * Amazon Traffic Waterfall & Ads Analytics Dashboard
 *
 * 说明：本文件由 HTML 原型转换为标准 React + TypeScript，供 v0.dev 读取与二次编辑。
 * - 纯 React（useState / useRef / useLayoutEffect），无第三方依赖。
 * - 所有样式为内联 style 对象（React.CSSProperties），方便逐块调整或改写为 Tailwind。
 * - 全部数据为示例数据，集中在文件顶部的「数据区」，替换为真实接口数据即可。
 *
 * 6 个页面（顶部标签切换）：
 *   1) 大盘流量瀑布   Market vs My-store waterfall
 *   2) 流量结构拆解   Traffic structure breakdown (店铺维度 + ASIN 维度)
 *   3) eCPM · 提升自然  eCPM factor decomposition
 *   4) 每日趋势        Daily trend line charts
 *   5) 24 小时热力图    Hourly heatmap (流量维度)
 *   6) 广告 24 小时热力图 Hourly heatmap (广告维度)
 */

import React, {
  useCallback,
  useLayoutEffect,
  useRef,
  useState,
} from "react";

/* ============================================================
 * 调色板 PALETTE
 * ========================================================== */
const C = {
  bg: "#F6F7F9",
  ink: "#1B1D29",
  sub: "#8A8DA0",
  line: "#E7E9EF",
  indigo: "#2F2C7E", // 广告 / 大盘 primary
  teal: "#1E7A6B", // 自然 / 我的店铺
  amber: "#E8A063", // 站外
  loss: "#F0AC72", // 流失
  // ribbon tints
  ribInd: "#B7B3E3",
  ribTeal: "#A9CDC5",
  ribAmb: "#F6D7B4",
  // detail chip fills
  indFill: "#EDECF8",
  tealFill: "#E3EFEB",
  amberFill: "#FBEBD9",
} as const;

const FONT =
  "'Noto Sans SC', -apple-system, 'PingFang SC', 'Microsoft YaHei', sans-serif";

/* ============================================================
 * 数据区 DATA  —— 替换为真实数据即可
 * ========================================================== */

type WFNode = {
  key: string;
  left: number;
  top: number;
  w: number;
  h: number;
  color: string;
  title: string;
  value: string;
  sub: string;
};

// —— 页面 1：大盘流量瀑布 —— //
const P1_NODES_MARKET: WFNode[] = [
  { key: "search", left: 40, top: 330, w: 230, h: 180, color: C.indigo, title: "搜索查询", value: "19.4M", sub: "大盘入口" },
  { key: "mimp", left: 430, top: 130, w: 230, h: 190, color: C.indigo, title: "大盘曝光", value: "513.9M", sub: "曝光/搜索 2651.50%" },
  { key: "mclk", left: 830, top: 230, w: 230, h: 170, color: C.indigo, title: "大盘点击", value: "9.2M", sub: "CTR 1.78%" },
  { key: "matc", left: 1210, top: 300, w: 230, h: 160, color: C.indigo, title: "大盘加购", value: "1.2M", sub: "加购/点击 12.71%" },
  { key: "mbuy", left: 1520, top: 330, w: 240, h: 160, color: C.indigo, title: "大盘购买", value: "262.7K", sub: "购买/加购 22.58%" },
];
const P1_NODES_LOSS: WFNode[] = [
  { key: "lclk", left: 830, top: 540, w: 230, h: 180, color: C.loss, title: "点击前流失", value: "504.8M", sub: "曝光未点击" },
  { key: "latc", left: 1210, top: 560, w: 230, h: 160, color: C.loss, title: "加购前流失", value: "8.0M", sub: "点击未加购" },
  { key: "lbuy", left: 1520, top: 560, w: 240, h: 170, color: C.loss, title: "购买前流失", value: "900.4K", sub: "加购未购买" },
];
const P1_NODES_MINE: WFNode[] = [
  { key: "yimp", left: 430, top: 760, w: 230, h: 190, color: C.teal, title: "我的曝光", value: "5.6M", sub: "曝光/搜索 28.68%｜市占 1.08%" },
  { key: "yclk", left: 830, top: 760, w: 230, h: 190, color: C.teal, title: "我的点击", value: "95.4K", sub: "点击/曝光 1.72%｜市占 1.04%" },
  { key: "yatc", left: 1210, top: 760, w: 230, h: 190, color: C.teal, title: "我的加购", value: "10.6K", sub: "加购/点击 11.15%｜市占 0.91%" },
  { key: "ybuy", left: 1520, top: 760, w: 240, h: 190, color: C.teal, title: "我的购买", value: "3.2K", sub: "购买/加购 30.29%｜市占 1.23%" },
];

type Link = { f: string; t: string; c: string; w: number; fy?: number; ty?: number };
const P1_LINKS: Link[] = [
  { f: "search", t: "mimp", c: C.ribInd, w: 44, fy: 0.5, ty: 0.55 },
  { f: "mimp", t: "mclk", c: C.ribInd, w: 20, fy: 0.28, ty: 0.4 },
  { f: "mimp", t: "lclk", c: C.ribAmb, w: 42, fy: 0.72, ty: 0.45 },
  { f: "mclk", t: "matc", c: C.ribInd, w: 14, fy: 0.32, ty: 0.4 },
  { f: "mclk", t: "latc", c: C.ribAmb, w: 20, fy: 0.72, ty: 0.45 },
  { f: "matc", t: "mbuy", c: C.ribInd, w: 11, fy: 0.35, ty: 0.4 },
  { f: "matc", t: "lbuy", c: C.ribAmb, w: 13, fy: 0.75, ty: 0.4 },
  { f: "yimp", t: "yclk", c: C.ribTeal, w: 15, fy: 0.5, ty: 0.5 },
  { f: "yclk", t: "yatc", c: C.ribTeal, w: 12, fy: 0.5, ty: 0.5 },
  { f: "yatc", t: "ybuy", c: C.ribTeal, w: 10, fy: 0.5, ty: 0.5 },
];

// —— 页面 2：流量结构拆解 —— //
type DetailItem = { n: string; e: string; v: string; p: string };
type Dimension = {
  rootTitle: string;
  rootValue: string;
  badge: string;
  ads: { value: string; pct: string; items: DetailItem[] };
  org: { value: string; pct: string; items: DetailItem[] };
  off: { value: string; pct: string; items: DetailItem[] };
};

const SHOP: Dimension = {
  rootTitle: "全店全部流量",
  rootValue: "512.7K",
  badge: "全店 Sessions 512.7K",
  ads: {
    value: "199.9K",
    pct: "占全部流量 39.0%",
    items: [
      { n: "SP 商品广告", e: "Sponsored Products", v: "128.7K", p: "占比 64.4%" },
      { n: "SB 品牌广告", e: "Sponsored Brands", v: "34.2K", p: "占比 17.1%" },
      { n: "SBV 品牌视频广告", e: "Sponsored Brands Video", v: "18.6K", p: "占比 9.3%" },
      { n: "SD 展示型广告", e: "Sponsored Display", v: "18.4K", p: "占比 9.2%" },
    ],
  },
  org: {
    value: "256.4K",
    pct: "占全部流量 50.0%",
    items: [
      { n: "关键词自然搜索", e: "Organic Keyword Search", v: "133.3K", p: "占比 52.0%" },
      { n: "类目节点流量", e: "Category / Browse Node", v: "33.3K", p: "占比 13.0%" },
      { n: "关联流量", e: "FBT · 4★ & Above · Related to this item", v: "46.2K", p: "占比 18.0%" },
      { n: "排行榜流量", e: "BS · NR · MS · Most Wished For", v: "25.6K", p: "占比 10.0%" },
      { n: "促销活动流量", e: "BD · TD · LD · DOTD", v: "17.9K", p: "占比 7.0%" },
    ],
  },
  off: {
    value: "56.4K",
    pct: "占全部流量 11.0%",
    items: [
      { n: "Amazon Attribution", e: "站外归因链接", v: "16.0K", p: "占比 28.4%" },
      { n: "社媒流量", e: "Facebook · Instagram · TikTok", v: "12.4K", p: "占比 22.0%" },
      { n: "网红 / KOL 营销", e: "Influencer Marketing", v: "11.3K", p: "占比 20.0%" },
      { n: "Deal / Coupon 折扣站", e: "Slickdeals · DealNews", v: "9.9K", p: "占比 17.6%" },
      { n: "EDM 邮件营销", e: "Email Marketing", v: "6.8K", p: "占比 12.0%" },
    ],
  },
};

const ASIN: Dimension = {
  rootTitle: "单品全部流量",
  rootValue: "86.4K",
  badge: "ASIN B08XYZ1234 · 86.4K Sessions",
  ads: {
    value: "38.9K",
    pct: "占全部流量 45.0%",
    items: [
      { n: "SP 商品广告", e: "Sponsored Products", v: "26.2K", p: "占比 67.4%" },
      { n: "SB 品牌广告", e: "Sponsored Brands", v: "6.1K", p: "占比 15.7%" },
      { n: "SBV 品牌视频广告", e: "Sponsored Brands Video", v: "3.4K", p: "占比 8.7%" },
      { n: "SD 展示型广告", e: "Sponsored Display", v: "3.2K", p: "占比 8.2%" },
    ],
  },
  org: {
    value: "38.0K",
    pct: "占全部流量 44.0%",
    items: [
      { n: "关键词自然搜索", e: "Organic Keyword Search", v: "19.8K", p: "占比 52.1%" },
      { n: "类目节点流量", e: "Category / Browse Node", v: "4.6K", p: "占比 12.1%" },
      { n: "关联流量", e: "FBT · 4★ & Above · Related to this item", v: "6.9K", p: "占比 18.2%" },
      { n: "排行榜流量", e: "BS · NR · MS · Most Wished For", v: "3.8K", p: "占比 10.0%" },
      { n: "促销活动流量", e: "BD · TD · LD · DOTD", v: "2.9K", p: "占比 7.6%" },
    ],
  },
  off: {
    value: "9.5K",
    pct: "占全部流量 11.0%",
    items: [
      { n: "Amazon Attribution", e: "站外归因链接", v: "2.7K", p: "占比 28.4%" },
      { n: "社媒流量", e: "Facebook · Instagram · TikTok", v: "2.1K", p: "占比 22.1%" },
      { n: "网红 / KOL 营销", e: "Influencer Marketing", v: "1.9K", p: "占比 20.0%" },
      { n: "Deal / Coupon 折扣站", e: "Slickdeals · DealNews", v: "1.7K", p: "占比 17.9%" },
      { n: "EDM 邮件营销", e: "Email Marketing", v: "1.1K", p: "占比 11.6%" },
    ],
  },
};

// 页面 2 瀑布连线（按 data-node key）
function structureLinks(): Link[] {
  const L: Link[] = [
    { f: "root", t: "ads", c: C.ribInd, w: 34, fy: 0.24, ty: 0.5 },
    { f: "root", t: "org", c: C.ribTeal, w: 36, fy: 0.52, ty: 0.5 },
    { f: "root", t: "off", c: C.ribAmb, w: 16, fy: 0.82, ty: 0.5 },
  ];
  for (let i = 0; i < 4; i++) L.push({ f: "ads", t: `ads-${i}`, c: C.ribInd, w: 9, fy: 0.2 + 0.2 * i, ty: 0.5 });
  for (let i = 0; i < 5; i++) L.push({ f: "org", t: `org-${i}`, c: C.ribTeal, w: 9, fy: 0.14 + 0.18 * i, ty: 0.5 });
  for (let i = 0; i < 5; i++) L.push({ f: "off", t: `off-${i}`, c: C.ribAmb, w: 9, fy: 0.14 + 0.18 * i, ty: 0.5 });
  return L;
}

// —— 页面 3：eCPM 因子卡 + 拆解卡 —— //
const ECPM_FACTORS = [
  { label: "整体点击率 CTR", value: "1.72%", note: "方差项 · 决定流量波动", color: C.indigo },
  { label: "整体转化率 CVR", value: "12.4%", note: "期望项 · 决定收入均值", color: C.teal },
  { label: "客单价 Price", value: "$29.99", note: "平均成交单价", color: C.ink },
  { label: "佣金比例 Referral", value: "15%", note: "平台销售佣金", color: C.ink },
  { label: "FBA 费用", value: "$5.60", note: "配送履约费 / 单", color: "#C97E3B" },
];

type BreakRow = { name: string; value: string; tone: "ind" | "teal" | "amber" };
type BreakCard = { title: string; total: string; totalColor: string; rows: BreakRow[]; note?: string };
const ECPM_CARDS: BreakCard[] = [
  {
    title: "全部流量", total: "86.4K", totalColor: C.indigo,
    rows: [
      { name: "广告流量", value: "38.9K · 45.0%", tone: "ind" },
      { name: "自然流量", value: "38.0K · 44.0%", tone: "teal" },
      { name: "站外流量", value: "9.5K · 11.0%", tone: "amber" },
    ],
  },
  {
    title: "全部订单", total: "3.2K", totalColor: C.indigo,
    rows: [
      { name: "广告订单", value: "1.5K · 46.9%", tone: "ind" },
      { name: "自然订单", value: "1.4K · 43.8%", tone: "teal" },
      { name: "站外订单", value: "0.3K · 9.3%", tone: "amber" },
    ],
  },
  {
    title: "全部转化率 CVR", total: "12.4%", totalColor: C.teal,
    rows: [
      { name: "广告转化率", value: "10.8%", tone: "ind" },
      { name: "自然转化率", value: "14.6%", tone: "teal" },
    ],
    note: "自然 CVR 高于广告 → 提升自然占比可拉高整体期望（均值）",
  },
  {
    title: "全部点击率 CTR", total: "1.72%", totalColor: C.indigo,
    rows: [
      { name: "广告点击率", value: "1.35%", tone: "ind" },
      { name: "自然点击率", value: "2.10%", tone: "teal" },
    ],
    note: "CTR 波动大（方差项）→ 主图 / 价格 / 评分是收敛方差的关键",
  },
  {
    title: "全部关键词排名", total: "470 词", totalColor: C.indigo,
    rows: [
      { name: "广告排名坑位", value: "平均 #6.8 · 128 词", tone: "ind" },
      { name: "自然排名坑位", value: "平均 #12.4 · 342 词", tone: "teal" },
    ],
    note: "广告坑位打词 → 带动同词自然坑位上移",
  },
  {
    title: "SIF 关键词收录词数量", total: "1,286", totalColor: C.teal,
    rows: [
      { name: "首页收录词", value: "96", tone: "ind" },
      { name: "前三页收录词", value: "342", tone: "teal" },
      { name: "收录总词数", value: "1,286 · 周环比 +4.2%", tone: "amber" },
    ],
  },
];

/* ============================================================
 * 派生数据 helpers（趋势 / 热力图 —— 示例数值生成，可整体替换）
 * ========================================================== */
function buildDaily() {
  const N = 30;
  const s = Math.sin;
  const adCtr: number[] = [], orgCtr: number[] = [], allCtr: number[] = [];
  const adCvr: number[] = [], orgCvr: number[] = [], allCvr: number[] = [];
  const price: number[] = [], ecpm: number[] = [];
  for (let i = 0; i < N; i++) {
    adCtr.push(1.35 + 0.22 * s(i / 4.2) + 0.09 * s(i * 1.7 + 2));
    orgCtr.push(2.1 + 0.28 * s(i / 5.1 + 1) + 0.11 * s(i * 1.3 + 5));
    allCtr.push((adCtr[i] + orgCtr[i]) / 2 - 0.005 + 0.05 * s(i * 0.9));
    adCvr.push(10.8 + 1.1 * s(i / 4.6 + 3) + 0.5 * s(i * 1.5 + 1));
    orgCvr.push(14.6 + 1.3 * s(i / 5.4 + 2) + 0.6 * s(i * 1.1 + 4));
    allCvr.push((adCvr[i] + orgCvr[i]) / 2 + 0.3 * s(i * 0.7 + 2));
    price.push(29.99 + 1.2 * s(i / 6 + 1) + 0.6 * s(i * 1.9));
    ecpm.push(((allCtr[i] / 100) * (allCvr[i] / 100) * price[i] * 0.15 * 1000));
  }
  return { adCtr, orgCtr, allCtr, adCvr, orgCvr, allCvr, price, ecpm };
}
const DAILY = buildDaily();

type MetricCfg = { base: number; amp: number; fmt: (v: number) => string };
const HEAT_CFG: Record<string, MetricCfg> = {
  IMP: { base: 42000, amp: 30000, fmt: (v) => (v / 1000).toFixed(1) + "K" },
  CLK: { base: 720, amp: 520, fmt: (v) => Math.round(v) + "" },
  CTR: { base: 1.7, amp: 0.9, fmt: (v) => v.toFixed(1) + "%" },
  CVR: { base: 12.5, amp: 5.5, fmt: (v) => v.toFixed(1) + "%" },
  CPC: { base: 1.05, amp: 0.55, fmt: (v) => "$" + v.toFixed(2) },
  ACOS: { base: 28, amp: 14, fmt: (v) => v.toFixed(0) + "%" },
  CPA: { base: 9.5, amp: 4.5, fmt: (v) => "$" + v.toFixed(1) },
  ORDER: { base: 14, amp: 11, fmt: (v) => Math.round(v) + "" },
  eCPM: { base: 9.5, amp: 5, fmt: (v) => "$" + v.toFixed(1) },
};
const HEAT_DAYS = 14; // 06-16 → 06-29

function buildHeat(key: string): number[][] {
  const cfg = HEAT_CFG[key];
  const s = Math.sin;
  const grid: number[][] = [];
  let seed = key.length * 7.3;
  for (let h = 0; h < 24; h++) {
    const row: number[] = [];
    const diurnal = s(((h - 6) / 24) * Math.PI * 2);
    for (let d = 0; d < HEAT_DAYS; d++) {
      seed = (seed * 9301 + 49297) % 233280;
      const noise = seed / 233280 - 0.5;
      row.push(cfg.base + cfg.amp * (0.55 * diurnal + 0.25 * s(d / 2.3 + h / 5) + 0.55 * noise));
    }
    grid.push(row);
  }
  return grid;
}

/* ============================================================
 * 小组件 UI PRIMITIVES
 * ========================================================== */
function WaterfallCard({ node }: { node: WFNode }) {
  const twoLine = node.sub.includes("｜");
  return (
    <div
      data-node={node.key}
      style={{
        position: "absolute", left: node.left, top: node.top, width: node.w, height: node.h,
        background: node.color, borderRadius: 10, padding: "20px 22px", boxSizing: "border-box",
        display: "flex", flexDirection: "column", justifyContent: "center", gap: 5, zIndex: 2,
      }}
    >
      <div style={{ color: "#fff", fontSize: 19, fontWeight: 700 }}>{node.title}</div>
      <div style={{ color: "#fff", fontSize: 32, fontWeight: 800 }}>{node.value}</div>
      <div style={{ color: "rgba(255,255,255,.78)", fontSize: 13.5, lineHeight: twoLine ? 1.5 : undefined }}>
        {node.sub}
      </div>
    </div>
  );
}

// 瀑布连线：测量 data-node 元素位置，绘制贝塞尔飘带
function Ribbons({
  containerRef, links, curvature = 0.45, opacity = 0.8,
}: {
  containerRef: React.RefObject<HTMLDivElement>;
  links: Link[];
  curvature?: number;
  opacity?: number;
}) {
  const [paths, setPaths] = useState<{ d: string; c: string; w: number }[]>([]);
  const [vb, setVb] = useState("0 0 100 100");

  const draw = useCallback(() => {
    const wrap = containerRef.current;
    if (!wrap) return;
    const wr = wrap.getBoundingClientRect();
    if (!wr.width) return;
    const k = wrap.offsetWidth / wr.width;
    setVb(`0 0 ${wrap.offsetWidth} ${wrap.offsetHeight}`);
    const node = (key: string) => wrap.querySelector<HTMLElement>(`[data-node="${key}"]`);
    const out: { d: string; c: string; w: number }[] = [];
    for (const l of links) {
      const a = node(l.f), b = node(l.t);
      if (!a || !b) continue;
      const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
      const x1 = (ra.right - wr.left) * k;
      const y1 = (ra.top - wr.top + ra.height * (l.fy ?? 0.5)) * k;
      const x2 = (rb.left - wr.left) * k;
      const y2 = (rb.top - wr.top + rb.height * (l.ty ?? 0.5)) * k;
      const dx = Math.max(40, (x2 - x1) * curvature);
      out.push({
        d: `M ${x1} ${y1} C ${x1 + dx} ${y1}, ${x2 - dx} ${y2}, ${x2} ${y2}`,
        c: l.c, w: l.w,
      });
    }
    setPaths(out);
  }, [containerRef, links, curvature, opacity]);

  useLayoutEffect(() => {
    draw();
    const t = setTimeout(draw, 350);
    const ro = new ResizeObserver(draw);
    if (containerRef.current) ro.observe(containerRef.current);
    window.addEventListener("resize", draw);
    return () => {
      clearTimeout(t);
      ro.disconnect();
      window.removeEventListener("resize", draw);
    };
  }, [draw, containerRef]);

  return (
    <svg
      viewBox={vb}
      preserveAspectRatio="none"
      style={{ position: "absolute", inset: 0, width: "100%", height: "100%", zIndex: 1, pointerEvents: "none" }}
    >
      {paths.map((p, i) => (
        <path key={i} d={p.d} fill="none" stroke={p.c} strokeWidth={p.w} opacity={opacity} />
      ))}
    </svg>
  );
}

// 结构拆解：类目主卡
function CategoryCard({
  nodeKey, left, top, w, h, color, no, name, en, enColor, value, pct,
}: {
  nodeKey: string; left: number; top: number; w: number; h: number; color: string;
  no: string; name: string; en: string; enColor: string; value: string; pct: string;
}) {
  return (
    <div
      data-node={nodeKey}
      style={{
        position: "absolute", left, top, width: w, height: h, background: color, borderRadius: 10,
        padding: "18px 22px", boxSizing: "border-box", display: "flex", flexDirection: "column",
        justifyContent: "center", gap: 3, zIndex: 2,
      }}
    >
      <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}>
        <span style={{ color: "#fff", fontSize: 17, fontWeight: 700 }}>{no} {name}</span>
        <span style={{ color: enColor, fontSize: 11.5 }}>{en}</span>
      </div>
      <div style={{ color: "#fff", fontSize: 28, fontWeight: 800 }}>{value}</div>
      <div style={{ color: "rgba(255,255,255,.8)", fontSize: 13 }}>{pct}</div>
    </div>
  );
}

// 结构拆解：明细行
function DetailRow({
  nodeKey, item, fill, nameColor, enColor, valColor,
}: {
  nodeKey: string; item: DetailItem; fill: string; nameColor: string; enColor: string; valColor: string;
}) {
  return (
    <div
      data-node={nodeKey}
      style={{
        height: 62, background: fill, borderRadius: 8, display: "flex", alignItems: "center",
        justifyContent: "space-between", padding: "0 18px", boxSizing: "border-box",
      }}
    >
      <div>
        <div style={{ fontSize: 15, fontWeight: 600, color: nameColor }}>{item.n}</div>
        <div style={{ fontSize: 11.5, color: enColor, marginTop: 2 }}>{item.e}</div>
      </div>
      <div style={{ display: "flex", alignItems: "baseline", gap: 10 }}>
        <span style={{ fontSize: 20, fontWeight: 800, color: valColor }}>{item.v}</span>
        <span style={{ fontSize: 12.5, color: enColor }}>{item.p}</span>
      </div>
    </div>
  );
}

// 折线图（纯 SVG，固定 viewBox 缩放）
function LineChart({
  series, fmt,
}: {
  series: { color: string; data: number[]; area?: boolean }[];
  fmt: (v: number) => string;
}) {
  const W = 820, H = 300, pl = 58, pr = 18, pt = 14, pb = 30;
  const N = series[0]?.data.length ?? 0;
  let mn = Infinity, mx = -Infinity;
  for (const s of series) for (const v of s.data) { if (v < mn) mn = v; if (v > mx) mx = v; }
  const pad = (mx - mn) * 0.18 || 1;
  mn -= pad; mx += pad;
  const X = (i: number) => pl + ((W - pl - pr) * i) / (N - 1);
  const Y = (v: number) => pt + (H - pt - pb) * (1 - (v - mn) / (mx - mn));
  const end = new Date(2026, 6, 4);

  const grid = [];
  for (let t = 0; t <= 4; t++) {
    const v = mn + ((mx - mn) * t) / 4;
    const y = Y(v);
    grid.push(
      <g key={t}>
        <line x1={pl} y1={y} x2={W - pr} y2={y} stroke="#ECEEF3" strokeWidth={1} />
        <text x={pl - 10} y={y + 4} textAnchor="end" fontSize={11} fill={C.sub} fontFamily={FONT}>{fmt(v)}</text>
      </g>
    );
  }
  const xlabels = [];
  for (let i = 0; i < N; i += 5) {
    const d = new Date(end);
    d.setDate(d.getDate() - (N - 1 - i));
    xlabels.push(
      <text key={i} x={X(i)} y={H - 8} textAnchor="middle" fontSize={11} fill={C.sub} fontFamily={FONT}>
        {d.getMonth() + 1}/{d.getDate()}
      </text>
    );
  }
  return (
    <svg viewBox={`0 0 ${W} ${H}`} style={{ width: "100%", height: 300, display: "block", marginTop: 14 }}>
      {grid}
      {xlabels}
      {series.map((s, si) => {
        let p = "";
        for (let i = 0; i < N; i++) p += (i ? " L " : "M ") + X(i).toFixed(1) + " " + Y(s.data[i]).toFixed(1);
        return (
          <g key={si}>
            {s.area && (
              <path d={`${p} L ${X(N - 1)} ${H - pb} L ${pl} ${H - pb} Z`} fill={s.color} opacity={0.08} />
            )}
            <path d={p} fill="none" stroke={s.color} strokeWidth={2.5} strokeLinejoin="round" strokeLinecap="round" />
            <circle cx={X(N - 1)} cy={Y(s.data[N - 1])} r={4} fill={s.color} />
          </g>
        );
      })}
    </svg>
  );
}

// 24 小时热力图
function Heatmap({ metric, extended }: { metric: string; extended?: boolean }) {
  const grid = buildHeat(metric);
  const fmt = HEAT_CFG[metric].fmt;
  const selDay = HEAT_DAYS - 1;
  let mn = Infinity, mx = -Infinity;
  const dayMaxH = new Array(HEAT_DAYS).fill(0);
  const dayMax = new Array(HEAT_DAYS).fill(0);
  for (let d = 0; d < HEAT_DAYS; d++) {
    for (let h = 0; h < 24; h++) {
      const v = grid[h][d];
      if (v < mn) mn = v;
      if (v > mx) mx = v;
      if (v > dayMax[d]) { dayMax[d] = v; dayMaxH[d] = h; }
    }
  }
  const rows = [];
  for (let h = 0; h < 24; h++) {
    const cells = [];
    for (let d = 0; d < HEAT_DAYS; d++) {
      const v = grid[h][d];
      const t = (v - mn) / (mx - mn);
      const isMax = dayMaxH[d] === h;
      const base: React.CSSProperties = {
        flex: 1, height: 30, borderRadius: 4, display: "flex", alignItems: "center", justifyContent: "center",
        fontSize: 11, fontWeight: 700, fontVariantNumeric: "tabular-nums", boxSizing: "border-box",
        ...(isMax
          ? { background: C.teal, color: "#fff" }
          : { background: `rgba(47,44,126,${(0.06 + 0.72 * t).toFixed(3)})`, color: t > 0.55 ? "rgba(255,255,255,.92)" : "transparent" }),
        ...(d === selDay ? { outline: `2px solid ${C.teal}`, outlineOffset: -1 } : {}),
      };
      cells.push(
        <div key={d} style={base} title={`06-${16 + d} ${String(h).padStart(2, "0")}:00 · ${metric} ${fmt(v)}`}>
          {isMax ? `MAX ${fmt(v)}` : fmt(v)}
        </div>
      );
    }
    rows.push(
      <div key={h} style={{ display: "flex", alignItems: "center", gap: 3 }}>
        <div style={{ width: 52, flex: "none", fontSize: 12, color: C.sub, textAlign: "right", paddingRight: 8, fontVariantNumeric: "tabular-nums" }}>
          {String(h).padStart(2, "0")}:00
        </div>
        {cells}
      </div>
    );
  }
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
      {rows}
      <div style={{ display: "flex", alignItems: "center", gap: 3, marginTop: 8 }}>
        <div style={{ width: 52, flex: "none" }} />
        {Array.from({ length: HEAT_DAYS }, (_, d) => (
          <div key={d} style={{
            flex: 1, textAlign: "center", fontSize: 12, fontVariantNumeric: "tabular-nums",
            color: d === selDay ? C.teal : C.sub, fontWeight: d === selDay ? 800 : 400,
          }}>
            06-{16 + d}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ============================================================
 * 页面 PAGES
 * ========================================================== */
const PAGE_TITLE_STYLE: React.CSSProperties = { fontSize: 24, fontWeight: 800, color: C.ink };
const PAGE_SUB_STYLE: React.CSSProperties = { fontSize: 13.5, color: C.sub, marginTop: 4 };
const CANVAS_STYLE: React.CSSProperties = { padding: "30px 40px 70px", overflowX: "auto" };
const CARD_STYLE: React.CSSProperties = { background: "#fff", border: `1px solid ${C.line}`, borderRadius: 12 };

function LegendDot({ color, label }: { color: string; label: string }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
      <span style={{ width: 11, height: 11, borderRadius: 3, background: color, display: "inline-block" }} />
      <span style={{ fontSize: 13, color: "#5A5D6E" }}>{label}</span>
    </div>
  );
}

function Page1Waterfall({ showLoss, curvature, opacity }: { showLoss: boolean; curvature: number; opacity: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const links = showLoss ? P1_LINKS : P1_LINKS.filter((l) => !["lclk", "latc", "lbuy"].includes(l.t));
  return (
    <div data-screen-label="大盘流量瀑布" style={CANVAS_STYLE}>
      <div style={{ width: 1780, display: "flex", alignItems: "flex-end", justifyContent: "space-between" }}>
        <div>
          <div style={PAGE_TITLE_STYLE}>大盘流量 vs 我的流量</div>
          <div style={PAGE_SUB_STYLE}>搜索查询 → 曝光 → 点击 → 加购 → 购买 · 逐级转化与流失</div>
        </div>
        <div style={{ display: "flex", gap: 22, alignItems: "center" }}>
          <LegendDot color={C.indigo} label="大盘" />
          <LegendDot color={C.teal} label="我的店铺" />
          <LegendDot color={C.loss} label="流失" />
        </div>
      </div>

      <div ref={ref} style={{ position: "relative", width: 1780, height: 980, marginTop: 26 }}>
        <Ribbons containerRef={ref} links={links} curvature={curvature} opacity={opacity} />
        {P1_NODES_MARKET.map((n) => <WaterfallCard key={n.key} node={n} />)}
        {showLoss && P1_NODES_LOSS.map((n) => <WaterfallCard key={n.key} node={n} />)}
        {P1_NODES_MINE.map((n) => <WaterfallCard key={n.key} node={n} />)}
      </div>
    </div>
  );
}

function StructureWaterfall({ dim, curvature, opacity }: { dim: Dimension; curvature: number; opacity: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const links = structureLinks();
  return (
    <div ref={ref} style={{ position: "relative", width: 1780, height: 1150, marginTop: 18 }}>
      <Ribbons containerRef={ref} links={links} curvature={curvature} opacity={opacity} />

      <div data-node="root" style={{
        position: "absolute", left: 40, top: 470, width: 260, height: 210, background: C.indigo, borderRadius: 10,
        padding: "22px 24px", boxSizing: "border-box", display: "flex", flexDirection: "column", justifyContent: "center", gap: 6, zIndex: 2,
      }}>
        <div style={{ color: "#fff", fontSize: 19, fontWeight: 700 }}>{dim.rootTitle}</div>
        <div style={{ color: "#fff", fontSize: 34, fontWeight: 800 }}>{dim.rootValue}</div>
        <div style={{ color: "rgba(255,255,255,.72)", fontSize: 13.5 }}>Sessions · 100%</div>
      </div>

      <CategoryCard nodeKey="ads" left={440} top={90} w={290} h={140} color={C.indigo} no="①" name="广告流量" en="Ad Traffic" enColor="rgba(255,255,255,.6)" value={dim.ads.value} pct={dim.ads.pct} />
      <CategoryCard nodeKey="org" left={440} top={470} w={290} h={150} color={C.teal} no="②" name="自然流量" en="Organic Traffic" enColor="rgba(255,255,255,.6)" value={dim.org.value} pct={dim.org.pct} />
      <CategoryCard nodeKey="off" left={440} top={880} w={290} h={140} color={C.amber} no="③" name="站外流量" en="External Traffic" enColor="rgba(255,255,255,.75)" value={dim.off.value} pct={dim.off.pct} />

      <div style={{ position: "absolute", left: 960, top: 8, width: 460, display: "flex", flexDirection: "column", gap: 12, zIndex: 2 }}>
        {dim.ads.items.map((it, i) => (
          <DetailRow key={i} nodeKey={`ads-${i}`} item={it} fill={C.indFill} nameColor={C.indigo} enColor="#6B69A0" valColor="#211E66" />
        ))}
      </div>
      <div style={{ position: "absolute", left: 960, top: 352, width: 460, display: "flex", flexDirection: "column", gap: 12, zIndex: 2 }}>
        {dim.org.items.map((it, i) => (
          <DetailRow key={i} nodeKey={`org-${i}`} item={it} fill={C.tealFill} nameColor="#16594E" enColor="#4E8378" valColor="#0C443B" />
        ))}
      </div>
      <div style={{ position: "absolute", left: 960, top: 770, width: 460, display: "flex", flexDirection: "column", gap: 12, zIndex: 2 }}>
        {dim.off.items.map((it, i) => (
          <DetailRow key={i} nodeKey={`off-${i}`} item={it} fill={C.amberFill} nameColor="#8A4E14" enColor="#B07C46" valColor="#6E3A0C" />
        ))}
      </div>
    </div>
  );
}

function Page2Structure({ curvature, opacity }: { curvature: number; opacity: number }) {
  return (
    <div style={CANVAS_STYLE}>
      <div style={{ width: 1780, display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 16 }}>
        <div>
          <div style={PAGE_TITLE_STYLE}>流量结构拆解</div>
          <div style={PAGE_SUB_STYLE}>店铺维度与 ASIN 维度结构一致 · Sessions · 近30天</div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 10, background: "#fff", border: `1px solid ${C.line}`, borderRadius: 999, padding: "10px 20px", whiteSpace: "nowrap" }}>
          <span style={{ fontSize: 14, fontWeight: 800, color: C.ink }}>全部流量</span>
          <span style={{ fontSize: 14, color: C.sub }}>=</span>
          <span style={{ fontSize: 14, fontWeight: 700, color: C.indigo }}>① 广告流量</span>
          <span style={{ fontSize: 14, color: C.sub }}>+</span>
          <span style={{ fontSize: 14, fontWeight: 700, color: C.teal }}>② 自然流量</span>
          <span style={{ fontSize: 14, color: C.sub }}>+</span>
          <span style={{ fontSize: 14, fontWeight: 700, color: "#C97E3B" }}>③ 站外流量</span>
        </div>
      </div>

      <div data-screen-label="店铺维度流量拆解" style={{ marginTop: 30, width: 1780 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{ fontSize: 18, fontWeight: 800, color: C.ink }}>店铺维度 · 全店流量拆解</div>
          <div style={{ fontSize: 12.5, fontWeight: 600, color: C.indigo, background: C.indFill, borderRadius: 999, padding: "5px 14px" }}>{SHOP.badge}</div>
        </div>
        <StructureWaterfall dim={SHOP} curvature={curvature} opacity={opacity} />
      </div>

      <div data-screen-label="ASIN流量瀑布" style={{ marginTop: 40, width: 1780 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{ fontSize: 18, fontWeight: 800, color: C.ink }}>ASIN 维度 · 单品流量瀑布</div>
          <div style={{ fontSize: 12.5, fontWeight: 600, color: "#16594E", background: C.tealFill, borderRadius: 999, padding: "5px 14px" }}>{ASIN.badge}</div>
        </div>
        <StructureWaterfall dim={ASIN} curvature={curvature} opacity={opacity} />
      </div>
    </div>
  );
}

function Page3Ecpm() {
  const toneFill = { ind: C.indFill, teal: C.tealFill, amber: C.amberFill };
  const toneName = { ind: C.indigo, teal: "#16594E", amber: "#8A4E14" };
  const toneVal = { ind: "#211E66", teal: "#0C443B", amber: "#6E3A0C" };
  return (
    <div data-screen-label="eCPM提升自然" style={CANVAS_STYLE}>
      <div style={{ width: 1780, display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 16 }}>
        <div>
          <div style={PAGE_TITLE_STYLE}>eCPM · 提升自然流量</div>
          <div style={PAGE_SUB_STYLE}>eCPM 越高，平台越愿意分配自然坑位 · 示例 ASIN B08XYZ1234 · 近30天</div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 10, background: "#fff", border: `1px solid ${C.line}`, borderRadius: 999, padding: "10px 20px", whiteSpace: "nowrap" }}>
          <span style={{ fontSize: 14, fontWeight: 800, color: C.ink }}>eCPM</span>
          <span style={{ fontSize: 14, color: C.sub }}>=</span>
          <span style={{ fontSize: 14, fontWeight: 700, color: C.indigo }}>CTR</span>
          <span style={{ fontSize: 14, color: C.sub }}>×</span>
          <span style={{ fontSize: 14, fontWeight: 700, color: C.teal }}>CVR</span>
          <span style={{ fontSize: 14, color: C.sub }}>×</span>
          <span style={{ fontSize: 14, fontWeight: 700, color: C.indigo }}>客单价</span>
          <span style={{ fontSize: 14, color: C.sub }}>×</span>
          <span style={{ fontSize: 14, fontWeight: 700, color: C.teal }}>佣金比例</span>
          <span style={{ fontSize: 14, color: C.sub }}>+</span>
          <span style={{ fontSize: 14, fontWeight: 700, color: "#C97E3B" }}>FBA费用</span>
        </div>
      </div>

      <div style={{ width: 1780, marginTop: 26, display: "grid", gridTemplateColumns: "400px repeat(5,1fr)", gap: 16 }}>
        <div style={{ background: C.indigo, borderRadius: 12, padding: "24px 26px", display: "flex", flexDirection: "column", justifyContent: "center", gap: 6 }}>
          <div style={{ color: "rgba(255,255,255,.72)", fontSize: 14, fontWeight: 600 }}>当前 eCPM（千次曝光价值）</div>
          <div style={{ color: "#fff", fontSize: 42, fontWeight: 800 }}>$9.59</div>
          <div style={{ color: "rgba(255,255,255,.72)", fontSize: 13, lineHeight: 1.6 }}>千次曝光为平台创造的收入 · 决定自然坑位分配权重</div>
        </div>
        {ECPM_FACTORS.map((f, i) => (
          <div key={i} style={{ ...CARD_STYLE, padding: "20px 22px", display: "flex", flexDirection: "column", justifyContent: "center", gap: 4 }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: C.sub, whiteSpace: "nowrap" }}>{f.label}</div>
            <div style={{ fontSize: 28, fontWeight: 800, color: f.color }}>{f.value}</div>
            <div style={{ fontSize: 12, color: C.sub, lineHeight: 1.5 }}>{f.note}</div>
          </div>
        ))}
      </div>

      <div style={{ width: 1780, marginTop: 16, display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 16 }}>
        {ECPM_CARDS.map((card, i) => (
          <div key={i} style={{ ...CARD_STYLE, padding: "22px 24px", display: "flex", flexDirection: "column", gap: 14 }}>
            <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between" }}>
              <div style={{ fontSize: 16, fontWeight: 800, color: C.ink }}>{card.title}</div>
              <div style={{ fontSize: 24, fontWeight: 800, color: card.totalColor }}>{card.total}</div>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {card.rows.map((r, j) => (
                <div key={j} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", background: toneFill[r.tone], borderRadius: 8, padding: "10px 16px" }}>
                  <span style={{ fontSize: 14, fontWeight: 600, color: toneName[r.tone] }}>{r.name}</span>
                  <span style={{ fontSize: 15, fontWeight: 800, color: toneVal[r.tone] }}>{r.value}</span>
                </div>
              ))}
            </div>
            {card.note && <div style={{ fontSize: 12, color: C.sub, lineHeight: 1.6 }}>{card.note}</div>}
          </div>
        ))}
      </div>
    </div>
  );
}

function TrendCard({
  title, legend, series, fmt,
}: {
  title: string;
  legend: { color: string; label: string }[];
  series: { color: string; data: number[]; area?: boolean }[];
  fmt: (v: number) => string;
}) {
  return (
    <div style={{ ...CARD_STYLE, padding: "22px 24px" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 10 }}>
        <div style={{ fontSize: 16, fontWeight: 800, color: C.ink }}>{title}</div>
        <div style={{ display: "flex", gap: 18, alignItems: "center" }}>
          {legend.map((l, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <span style={{ width: 10, height: 10, borderRadius: "50%", background: l.color, display: "inline-block" }} />
              <span style={{ fontSize: 12.5, color: "#5A5D6E", whiteSpace: "nowrap" }}>{l.label}</span>
            </div>
          ))}
        </div>
      </div>
      <LineChart series={series} fmt={fmt} />
    </div>
  );
}

function Page4Trend() {
  return (
    <div data-screen-label="每日趋势" style={CANVAS_STYLE}>
      <div style={{ width: 1780 }}>
        <div style={PAGE_TITLE_STYLE}>每日趋势</div>
        <div style={PAGE_SUB_STYLE}>点击率 · 转化率 · 客单价 · eCPM · 近30天 · 示例 ASIN B08XYZ1234</div>
      </div>
      <div style={{ width: 1780, marginTop: 24, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        <TrendCard
          title="点击率 CTR"
          legend={[{ color: C.ink, label: "整体 1.72%" }, { color: C.indigo, label: "广告 1.35%" }, { color: C.teal, label: "自然 2.10%" }]}
          series={[{ color: C.ink, data: DAILY.allCtr }, { color: C.indigo, data: DAILY.adCtr }, { color: C.teal, data: DAILY.orgCtr }]}
          fmt={(v) => v.toFixed(2) + "%"}
        />
        <TrendCard
          title="转化率 CVR"
          legend={[{ color: C.ink, label: "整体 12.4%" }, { color: C.indigo, label: "广告 10.8%" }, { color: C.teal, label: "自然 14.6%" }]}
          series={[{ color: C.ink, data: DAILY.allCvr }, { color: C.indigo, data: DAILY.adCvr }, { color: C.teal, data: DAILY.orgCvr }]}
          fmt={(v) => v.toFixed(1) + "%"}
        />
        <TrendCard
          title="客单价 Price"
          legend={[{ color: "#C97E3B", label: "均值 $29.99" }]}
          series={[{ color: "#C97E3B", data: DAILY.price, area: true }]}
          fmt={(v) => "$" + v.toFixed(1)}
        />
        <TrendCard
          title="eCPM"
          legend={[{ color: C.indigo, label: "CTR × CVR × 客单价 × 佣金 · 均值 $9.59" }]}
          series={[{ color: C.indigo, data: DAILY.ecpm, area: true }]}
          fmt={(v) => "$" + v.toFixed(1)}
        />
      </div>
    </div>
  );
}

function MetricPills({ options, current, onPick }: { options: string[]; current: string; onPick: (m: string) => void }) {
  const LB: Record<string, string> = { IMP: "IMP 曝光", CLK: "CLK 点击", ORDER: "ORDER 订单量" };
  return (
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "flex-end", maxWidth: 900 }}>
      {options.map((m) => {
        const active = m === current;
        return (
          <button
            key={m}
            onClick={() => onPick(m)}
            style={{
              padding: "7px 16px", borderRadius: 999, cursor: "pointer", fontSize: 13, fontWeight: 600,
              fontFamily: FONT, whiteSpace: "nowrap",
              border: `1px solid ${active ? C.indigo : "#D8DAE3"}`,
              background: active ? C.indigo : "#fff",
              color: active ? "#fff" : "#4A4D5C",
            }}
          >
            {LB[m] || m}
          </button>
        );
      })}
    </div>
  );
}

function HeatLegend() {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
      <span style={{ fontSize: 12, color: C.sub }}>低</span>
      <span style={{ width: 130, height: 10, borderRadius: 5, background: "linear-gradient(90deg,#F1F0FA,#2F2C7E)", display: "inline-block" }} />
      <span style={{ fontSize: 12, color: C.sub }}>高</span>
      <span style={{ width: 12 }} />
      <span style={{ width: 11, height: 11, borderRadius: 3, background: C.teal, display: "inline-block" }} />
      <span style={{ fontSize: 12, color: C.sub }}>当日极值 MAX</span>
    </div>
  );
}

function HeatPage({
  screenLabel, title, subtitle, options, current, onPick,
}: {
  screenLabel: string; title: string; subtitle: string;
  options: string[]; current: string; onPick: (m: string) => void;
}) {
  const label = ({ IMP: "IMP", CLK: "CLK" } as Record<string, string>)[current] || current;
  return (
    <div data-screen-label={screenLabel} style={CANVAS_STYLE}>
      <div style={{ width: 1780, display: "flex", alignItems: "flex-start", justifyContent: "space-between", flexWrap: "wrap", gap: 16 }}>
        <div>
          <div style={PAGE_TITLE_STYLE}>{title}</div>
          <div style={PAGE_SUB_STYLE}>{subtitle}</div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 10 }}>
          <div style={{ fontSize: 13.5, color: "#5A5D6E", whiteSpace: "nowrap" }}>
            当前 <b style={{ color: C.ink }}>Jun 29, 2026</b> · 前一日 <b style={{ color: C.ink }}>Jun 28, 2026</b> · <span style={{ color: C.sub }}>无后一日</span>
          </div>
          <MetricPills options={options} current={current} onPick={onPick} />
        </div>
      </div>

      <div style={{ ...CARD_STYLE, width: 1780, marginTop: 22, padding: "24px 26px", boxSizing: "border-box" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
          <div style={{ fontSize: 15, fontWeight: 800, color: C.ink }}>每日×小时热力图 · {label}</div>
          <HeatLegend />
        </div>
        <Heatmap metric={current} />
      </div>
    </div>
  );
}

/* ============================================================
 * 顶部导航 + 根组件 ROOT
 * ========================================================== */
const TABS = [
  "大盘流量瀑布", "流量结构拆解", "eCPM · 提升自然", "每日趋势", "24小时热力图", "广告24小时热力图",
];

export default function AmazonTrafficDashboard() {
  const [page, setPage] = useState(1);
  const [metric, setMetric] = useState("CTR");
  const [adMetric, setAdMetric] = useState("IMP");

  // 页面 1 瀑布连线可调参数（原 Tweaks）
  const curvature = 0.45;
  const opacity = 0.8;
  const showLoss = true;

  return (
    <div style={{ minHeight: "100vh", background: C.bg, fontFamily: FONT }}>
      {/* App bar */}
      <div style={{ background: "#fff", borderBottom: `1px solid ${C.line}`, padding: "18px 40px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 24, flexWrap: "wrap" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          <div style={{ width: 38, height: 38, borderRadius: 10, background: C.indigo, color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, fontWeight: 800 }}>流</div>
          <div>
            <div style={{ fontSize: 19, fontWeight: 800, color: C.ink }}>亚马逊流量瀑布分析</div>
            <div style={{ fontSize: 12.5, color: C.sub, marginTop: 2, whiteSpace: "nowrap" }}>Traffic Waterfall · 近30天 · US 站点</div>
          </div>
        </div>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          {TABS.map((t, i) => {
            const active = page === i + 1;
            return (
              <button
                key={t}
                onClick={() => setPage(i + 1)}
                style={{
                  padding: "10px 24px", borderRadius: 999, cursor: "pointer", fontSize: 15, whiteSpace: "nowrap",
                  fontWeight: 600, fontFamily: FONT,
                  border: `1px solid ${active ? C.indigo : "#D8DAE3"}`,
                  background: active ? C.indigo : "#fff",
                  color: active ? "#fff" : "#4A4D5C",
                }}
              >
                {t}
              </button>
            );
          })}
        </div>
      </div>

      {page === 1 && <Page1Waterfall showLoss={showLoss} curvature={curvature} opacity={opacity} />}
      {page === 2 && <Page2Structure curvature={curvature} opacity={opacity} />}
      {page === 3 && <Page3Ecpm />}
      {page === 4 && <Page4Trend />}
      {page === 5 && (
        <HeatPage
          screenLabel="24小时热力图"
          title="每日 24 小时对比表 · 热力图 + 极值"
          subtitle="每行是选中日期的一个小时区间，并展示前一天、后一天同小时数据；每列标出当日极值 MAX"
          options={["CTR", "CVR", "CPC", "ACOS", "CPA", "ORDER", "eCPM"]}
          current={metric}
          onPick={setMetric}
        />
      )}
      {page === 6 && (
        <HeatPage
          screenLabel="广告24小时热力图"
          title="广告 · 每日 24 小时对比表 · 热力图 + 极值"
          subtitle="分析每日每小时的广告指标；每列标出当日极值 MAX · 曝光量/点击量/CTR/CVR/CPC/ACOS/CPA/订单量/eCPM"
          options={["IMP", "CLK", "CTR", "CVR", "CPC", "ACOS", "CPA", "ORDER", "eCPM"]}
          current={adMetric}
          onPick={setAdMetric}
        />
      )}
    </div>
  );
}
