# 亚马逊流量看板 · v0.dev 导入包

这是一个从 HTML 原型转换而来的**标准 React + TypeScript 组件**，可直接粘贴进 [v0.dev](https://v0.dev) 读取、预览与二次编辑。

## 文件

- `amazon-traffic-dashboard.tsx` — 全部代码（单文件，无第三方依赖）

## 怎么用 v0.dev 打开

1. 打开 v0.dev，新建一个 chat。
2. 把 `amazon-traffic-dashboard.tsx` 的内容整段粘贴进去，或直接上传该文件。
3. 提示词示例：
   > 这是我的亚马逊流量分析看板组件，请帮我预览，并在保持视觉风格的前提下继续优化 / 增加页面。
4. v0 会渲染出 6 个页面，用顶部标签切换。

## 组件结构（都在同一个文件里，方便查找）

| 区块 | 说明 |
|---|---|
| `C` | 调色板（深蓝=广告/大盘，墨绿=自然/我的店铺，琥珀=站外，橙=流失） |
| 数据区 | `P1_NODES_*` / `SHOP` / `ASIN` / `ECPM_*` 等常量，**换成真实数据即可** |
| `buildDaily` / `buildHeat` | 趋势线与热力图的示例数值生成（接真实数据时整体替换这两个函数） |
| UI 小组件 | `WaterfallCard` `Ribbons` `CategoryCard` `DetailRow` `LineChart` `Heatmap` `MetricPills` 等 |
| 页面 | `Page1Waterfall` `Page2Structure` `Page3Ecpm` `Page4Trend` `HeatPage` |
| `AmazonTrafficDashboard` | 默认导出：顶部导航 + 页面路由 |

## 6 个页面

1. **大盘流量瀑布** — 大盘 vs 我的店铺，搜索→曝光→点击→加购→购买，含流失飘带（Sankey 连线用 SVG 实测坐标绘制）。
2. **流量结构拆解** — 店铺维度 + ASIN 维度，全部流量 = ①广告 + ②自然 + ③站外，右侧明细。
3. **eCPM · 提升自然** — eCPM 因子卡 + 全部流量/订单/CVR/CTR/关键词排名/SIF 收录 拆解。
4. **每日趋势** — CTR / CVR / 客单价 / eCPM 近 30 天折线。
5. **24 小时热力图** — 14 天 × 24 小时，每列标 MAX 极值，指标可切换。
6. **广告 24 小时热力图** — 同上，广告维度（含曝光量/点击量）。

## 技术说明

- 纯 React hooks（`useState` / `useRef` / `useLayoutEffect`），无 npm 依赖，无自定义运行时。
- 样式为内联 `style` 对象；若想改成 Tailwind，可让 v0 「把内联样式转成 Tailwind class」。
- 字体使用 `Noto Sans SC`，请在项目中引入（Next.js 用 `next/font` 或在 `layout` 里加 Google Fonts）。
- 瀑布连线依赖布局实测尺寸，画布固定宽 1780px；小屏时容器横向滚动。
- 组件顶部有 `"use client";`，适配 Next.js App Router。
