import { NextResponse } from "next/server"
import { ensureSchema } from "@/lib/db"
import { findByUsername, touchLogin } from "@/lib/auth/users"
import { verifyPassword } from "@/lib/auth/password"
import { encodeSession, COOKIE_NAME, sessionCookieOptions, isSecureRequest } from "@/lib/auth/session"

export async function POST(req: Request) {
  try {
    await ensureSchema()
    let body: any
    try {
      body = await req.json()
    } catch {
      return NextResponse.json({ error: "请求格式错误" }, { status: 400 })
    }
    const username = String(body?.username || "").trim()
    const password = String(body?.password || "")
    if (!username || !password) {
      return NextResponse.json({ error: "请输入用户名和密码" }, { status: 400 })
    }

    const user = await findByUsername(username)
    if (!user || !verifyPassword(password, user.password_hash)) {
      return NextResponse.json({ error: "用户名或密码错误" }, { status: 401 })
    }
    if (!user.role) {
      return NextResponse.json({ error: "该账号未分配 TIANJIOS 访问权限，请联系管理员" }, { status: 403 })
    }
    if (user.status === "disabled") {
      return NextResponse.json({ error: "账号已被禁用，请联系管理员" }, { status: 403 })
    }

    await touchLogin(user.id)
    const token = encodeSession(user.id, user.username, user.role)
    const res = NextResponse.json({ ok: true, role: user.role })
    res.cookies.set(COOKIE_NAME, token, sessionCookieOptions(isSecureRequest(req)))
    return res
  } catch (e: any) {
    // ── 临时诊断补丁：把服务端真实错误暴露出来，定位 500 根因后请移除 ──
    console.error("[login] 500:", e)
    return NextResponse.json(
      {
        error: "服务端异常（诊断模式）",
        name: e?.name ?? null,
        code: e?.code ?? null, // 如 ECONNREFUSED / ETIMEDOUT / ER_ACCESS_DENIED_ERROR
        message: e?.message ?? String(e),
        // 帮助确认环境变量是否注入（不回显密码/密钥本身）
        env: {
          MYSQL_HOST: process.env.MYSQL_HOST ?? null,
          MYSQL_PORT: process.env.MYSQL_PORT ?? null,
          MYSQL_DATABASE: process.env.MYSQL_DATABASE ?? null,
          MYSQL_USER: process.env.MYSQL_USER ?? null,
          MYSQL_PASSWORD_set: Boolean(process.env.MYSQL_PASSWORD),
          SESSION_SECRET_set: Boolean(process.env.SESSION_SECRET),
        },
      },
      { status: 500 },
    )
  }
}
