import { Wrench } from "lucide-react"
import { PlaceholderPage } from "@/components/layout/placeholder-page"

export default function ToolsPage() {
  return (
    <PlaceholderPage
      title="工具箱"
      icon={Wrench}
      modules={["利润计算器", "FBA 费用估算", "关键词反查", "Review 分析", "汇率换算", "二维码生成"]}
    />
  )
}
