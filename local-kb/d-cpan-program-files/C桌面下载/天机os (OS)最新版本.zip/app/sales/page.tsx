import { PageHeader } from "@/components/ui/page-header"
import { Delta } from "@/components/ui/delta"
import { SalesTrendChart, ShopShareChart } from "@/components/sales/sales-charts"
import { AsinTable } from "@/components/sales/asin-table"
import { salesKpis } from "@/lib/mock/sales"

export default function SalesPage() {
  return (
    <div>
      <PageHeader title="销售中心" description="多店铺销售数据概览（近 7 天 vs 上一周期）" />

      {/* KPI row */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
        {salesKpis.map((k) => (
          <div key={k.label} className="rounded-lg border border-border bg-card p-4 shadow-sm">
            <p className="text-xs text-muted-foreground">{k.label}</p>
            <p className="mt-2 text-xl font-semibold tabular-nums text-foreground">{k.value}</p>
            <Delta value={k.delta} lowerIsBetter={k.lowerIsBetter} className="mt-1" />
          </div>
        ))}
      </div>

      <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <SalesTrendChart />
        </div>
        <ShopShareChart />
      </div>

      <div className="mt-4">
        <AsinTable />
      </div>
    </div>
  )
}
