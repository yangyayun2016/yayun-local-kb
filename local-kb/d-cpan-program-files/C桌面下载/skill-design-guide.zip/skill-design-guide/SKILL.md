---
name: skill-design-guide
description: |
  StoreClaw Skill 设计指南。帮助开发者写出结构规范、质量达标的 Skill，覆盖 SKILL.md 格式要求、目录结构、五维质量评测框架（TRACE）。
  Use when: (1) 创建或优化 Skill 文件时需要格式参考, (2) 评估已有 Skill 的质量, (3) 学习 Skill 设计规范与最佳实践

---

## Purpose

帮助开发者快速掌握 StoreClaw Skill 的写作规范，避免常见错误，并通过 TRACE 五维框架衡量和改进 Skill 质量。适合：

- 第一次编写 Skill 的新开发者
- 想要提升已有 Skill 质量评分的开发者
- 需要做 Skill 质量审查的团队负责人

---

## Instructions

### 第一步：确认 Skill 包结构

每个 Skill 是一个 `.zip` 压缩包，解压后结构如下：

```
<skill-name>.zip
└── <skill-name>/          ← 文件夹名必须与 SKILL.md 中的 name 字段完全一致
    ├── SKILL.md            ← 必需
    ├── agents/
    │   └── openai.yaml    ← 自动生成，可覆盖
    ├── scripts/           ← 可选：Python/Shell 自动化脚本
    ├── references/        ← 可选：详细文档、知识库、业务规则
    └── assets/            ← 可选：模板、图片、字体等
```

**规则：**
- `SKILL.md` 是唯一必需文件
- 只添加真正会被使用的目录，删除空目录
- `name` 只允许小写字母、数字和连字符

---

### 第二步：编写 SKILL.md

**标准模板：**

```markdown
---
name: skill-name
description: |
  一句话说明该 Skill 的核心功能。
  Use when: (1) 场景一, (2) 场景二, (3) 场景三

---

## Purpose
该 Skill 解决什么问题，为谁服务，能带来什么价值。

## Instructions
执行步骤和行为规则（按优先级排列，避免冗余）。

## Examples
输入：用户提供 XXX
输出：Agent 返回 XXX

## Guardrails
- 不做什么
- 什么情况下主动询问用户
- 数据不足或权限不够时的处理方式
```

**关键写作原则：**
1. `description` 放触发条件，不放详细说明
2. `Instructions` 写执行逻辑，不写教程
3. 长文档放 `references/`，`SKILL.md` 保持精简
4. `Guardrails` 必须写清边界，防止误触发

---

### 第三步：用 TRACE 框架自检质量

详细评测标准见 `references/trace-framework.md`。

**快速自检清单：**

| 维度 | 检查项 |
|------|--------|
| T - 信任 | 无敏感信息硬编码；核心功能在国内网络可用 |
| R - 可靠性 | 有异常处理；空输入/特殊字符有友好提示 |
| A - 适用性 | 触发条件无歧义；能力边界写清楚 |
| C - 规范性 | 目录结构规范；有真实使用案例 |
| E - 有效性 | 输出可直接使用；比用户自己做有明显增值 |

---

## Examples

**输入：** 用户上传一个写好的 `.md` 技能文件，请求整理成可上传的 Skill 包  
**输出：** Agent 按规范结构创建目录、填写 SKILL.md、打包为合规 `.zip` 并上传

**输入：** "帮我评估这个 Skill 的质量"  
**输出：** Agent 按 TRACE 五维逐项打分，标注不合格项及改进建议

---

## Guardrails

- 本 Skill 仅提供设计规范指导，不执行具体的 Skill 安装或上传操作
- 涉及 Skill 安装/上传请使用 `find-skill` 或 `skill-creator`
- 不为用户编造示例数据或伪造评测结果
- 引用外部文档时，只参考 `references/` 目录中的内容