import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

// Edge 运行时：不做加密校验（放在服务端 layout / API 里做），
// 这里只做「有无会话」的粗粒度守卫 + 透传当前 pathname 给服务端 layout。
const COOKIE_NAME = "tjos_session"

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl
  const hasSession = !!req.cookies.get(COOKIE_NAME)?.value
  const isLogin = pathname === "/login"

  if (!hasSession && !isLogin) {
    return NextResponse.redirect(new URL("/login", req.url))
  }
  if (hasSession && isLogin) {
    return NextResponse.redirect(new URL("/", req.url))
  }

  // 把当前路径塞进请求头，(dashboard)/layout.tsx 据此做权限闸口
  const headers = new Headers(req.headers)
  headers.set("x-pathname", pathname)
  return NextResponse.next({ request: { headers } })
}

export const config = {
  // 排除 api、静态资源、图标；其余路由都走中间件
  matcher: ["/((?!api|_next/static|_next/image|favicon.ico|.*\\.(?:png|svg|ico|jpg|jpeg|webp)).*)"],
}
