import { pbkdf2Sync, randomBytes, timingSafeEqual } from "node:crypto"

// 与天机 backend/lib/admin_session.py 完全一致的格式：pbkdf2$salt$hash
// sha256 / 120000 迭代 / 32 字节派生密钥 / salt 为 16 字节 hex
const ITERATIONS = 120_000
const KEYLEN = 32
const DIGEST = "sha256"

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex")
  const dk = pbkdf2Sync(password, Buffer.from(salt, "hex"), ITERATIONS, KEYLEN, DIGEST).toString("hex")
  return `pbkdf2$${salt}$${dk}`
}

export function verifyPassword(password: string, stored: string | null | undefined): boolean {
  if (!stored) return false
  try {
    const [scheme, salt, expected] = stored.split("$")
    if (scheme !== "pbkdf2" || !salt || !expected) return false
    const dk = pbkdf2Sync(password, Buffer.from(salt, "hex"), ITERATIONS, KEYLEN, DIGEST).toString("hex")
    const a = Buffer.from(dk)
    const b = Buffer.from(expected)
    return a.length === b.length && timingSafeEqual(a, b)
  } catch {
    return false
  }
}
