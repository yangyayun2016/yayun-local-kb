// 可授权的业务模块（key ↔ 导航 href ↔ 标题）。
// 运营账号的 permissions 存的就是这些 key 的数组。
export type ModuleKey =
  | "sales"
  | "ads"
  | "products"
  | "selection"
  | "inventory"
  | "logistics"
  | "purchase"
  | "finance"
  | "agent"
  | "assistant"
  | "tools"

export type ModuleDef = { key: ModuleKey; title: string; href: string }

export const MODULES: ModuleDef[] = [
  { key: "sales", title: "销售中心", href: "/sales" },
  { key: "ads", title: "广告中心", href: "/ads" },
  { key: "products", title: "商品中心", href: "/products" },
  { key: "selection", title: "选品中心", href: "/selection" },
  { key: "inventory", title: "库存货件", href: "/inventory" },
  { key: "logistics", title: "物流中心", href: "/logistics" },
  { key: "purchase", title: "采购中心", href: "/purchase" },
  { key: "finance", title: "财务中心", href: "/finance" },
  { key: "agent", title: "Agent 中心", href: "/agent" },
  { key: "assistant", title: "数据助手", href: "/assistant" },
  { key: "tools", title: "工具箱", href: "/tools" },
]

export const ALL_MODULE_KEYS = MODULES.map((m) => m.key)

// admin/boss 专属路径（运营不可见/不可达）
const ADMIN_BOSS_ONLY = ["/team", "/settings"]

export type AccessUser = { role: string; permissions?: string[] | null }

export function moduleForPath(pathname: string): ModuleDef | undefined {
  return MODULES.find((m) => pathname === m.href || pathname.startsWith(m.href + "/"))
}

// 判断某用户能否访问某路径（服务端权限闸口 + 侧栏过滤共用）
export function canAccess(user: AccessUser, pathname: string): boolean {
  if (user.role === "admin" || user.role === "boss") return true
  // 以下为运营（operator）
  if (pathname === "/") return true // 工作台所有登录用户可见
  if (ADMIN_BOSS_ONLY.some((p) => pathname === p || pathname.startsWith(p + "/"))) return false
  const mod = moduleForPath(pathname)
  if (mod) return (user.permissions || []).includes(mod.key)
  return true // 其它非业务路径默认放行
}

// 仅保留合法模块 key（防止写入越权/无效权限）
export function sanitizePermissions(raw: unknown): string[] {
  if (!Array.isArray(raw)) return []
  return raw.map(String).filter((k) => (ALL_MODULE_KEYS as string[]).includes(k))
}

// 把任意来源（DB JSON 列 / 已解析数组 / null）规整为 string[]
export function normalizePermissions(raw: unknown): string[] {
  if (Array.isArray(raw)) return raw.map(String)
  if (typeof raw === "string") {
    try {
      const parsed = JSON.parse(raw)
      return Array.isArray(parsed) ? parsed.map(String) : []
    } catch {
      return []
    }
  }
  return []
}
