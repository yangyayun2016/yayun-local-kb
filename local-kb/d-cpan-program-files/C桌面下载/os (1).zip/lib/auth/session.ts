import { createHmac, timingSafeEqual } from "node:crypto"
import { cookies } from "next/headers"

// 会话 Cookie：base64url(payload).HMAC-SHA256(secret)，带 exp。
// 复用天机 lib/session.py 的签名思路，密钥为 SESSION_SECRET。
// 独立 Cookie 名 tjos_session，与天机 tianji_session 区分。
export const COOKIE_NAME = "tjos_session"
export const SESSION_TTL = 60 * 60 * 24 * 7 // 7 天

export type SessionPayload = {
  userId: number
  username: string
  role: string
  exp: number
}

function secret(): string {
  return process.env.SESSION_SECRET || "dev-secret-change-me"
}

function sign(payload: string): string {
  return createHmac("sha256", secret()).update(payload).digest("hex")
}

export function encodeSession(userId: number, username: string, role: string): string {
  const payload = JSON.stringify({
    userId,
    username,
    role,
    exp: Math.floor(Date.now() / 1000) + SESSION_TTL,
  })
  const body = Buffer.from(payload, "utf8").toString("base64url")
  return `${body}.${sign(payload)}`
}

export function decodeSession(value: string): SessionPayload | null {
  try {
    const i = value.lastIndexOf(".")
    if (i < 0) return null
    const body = value.slice(0, i)
    const sig = value.slice(i + 1)
    const payload = Buffer.from(body, "base64url").toString("utf8")
    const expected = sign(payload)
    const a = Buffer.from(sig)
    const b = Buffer.from(expected)
    if (a.length !== b.length || !timingSafeEqual(a, b)) return null
    const data = JSON.parse(payload) as SessionPayload
    if (!data.exp || data.exp < Math.floor(Date.now() / 1000)) return null
    return data
  } catch {
    return null
  }
}

// 供 Route Handler / Server Component 读取当前会话（Node 运行时）
export async function getSession(): Promise<SessionPayload | null> {
  const store = await cookies()
  const c = store.get(COOKIE_NAME)
  if (!c?.value) return null
  return decodeSession(c.value)
}

// secure=true（https，如 v0/Vercel）：SameSite=None 才能在跨站 iframe 预览里带上 cookie
// secure=false（本地 http）：SameSite=Lax（Secure cookie 不会走 http）
export function sessionCookieOptions(secure: boolean) {
  return {
    httpOnly: true,
    sameSite: (secure ? "none" : "lax") as "none" | "lax",
    secure,
    path: "/",
    maxAge: SESSION_TTL,
  }
}

// 判断请求是否走 https（v0/Vercel 经反代，看 x-forwarded-proto）
export function isSecureRequest(req: Request): boolean {
  const proto = req.headers.get("x-forwarded-proto")
  if (proto) return proto.split(",")[0].trim() === "https"
  try {
    return new URL(req.url).protocol === "https:"
  } catch {
    return false
  }
}
