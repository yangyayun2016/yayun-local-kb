import { execute, ensureSchema, query } from "@/lib/db"
import { hashPassword } from "@/lib/auth/password"
import { getSession } from "@/lib/auth/session"
import { normalizePermissions } from "@/lib/auth/modules"

export type Role = "admin" | "boss" | "operator"

export type UserRow = {
  id: number
  username: string
  display_name: string | null
  role: Role | null
  parent_id: number | null
  permissions: unknown
  status: string
  password_hash: string | null
  last_login_at: string | null
  created_at: string
}

// 对外暴露的安全用户视图（不含密码哈希）
export type PublicUser = {
  id: number
  username: string
  displayName: string
  role: Role
  parentId: number | null
  permissions: string[]
  status: string
  lastLoginAt: string | null
  createdAt: string
}

export function toPublicUser(u: UserRow): PublicUser {
  return {
    id: u.id,
    username: u.username,
    displayName: u.display_name || u.username,
    role: (u.role || "operator") as Role,
    parentId: u.parent_id,
    permissions: normalizePermissions(u.permissions),
    status: u.status,
    lastLoginAt: u.last_login_at,
    createdAt: u.created_at,
  }
}

export async function findByUsername(username: string): Promise<UserRow | null> {
  const rows = await query<UserRow>("SELECT * FROM users WHERE username = ? LIMIT 1", [username])
  return rows[0] || null
}

export async function findById(id: number): Promise<UserRow | null> {
  const rows = await query<UserRow>("SELECT * FROM users WHERE id = ? LIMIT 1", [id])
  return rows[0] || null
}

// 读取当前登录用户（会话 + DB 实时行）。权限/状态以 DB 为准，改动即时生效。
export async function getCurrentUser(): Promise<UserRow | null> {
  await ensureSchema()
  const session = await getSession()
  if (!session) return null
  const user = await findById(session.userId)
  if (!user || !user.role || user.status === "disabled") return null
  return user
}

export async function touchLogin(id: number): Promise<void> {
  await execute("UPDATE users SET last_login_at = CURRENT_TIMESTAMP WHERE id = ?", [id])
}

export async function createUser(input: {
  username: string
  password: string
  role: Role
  parentId?: number | null
  permissions?: string[] | null
  displayName?: string | null
}): Promise<number> {
  const perms = input.permissions ? JSON.stringify(input.permissions) : null
  const res = await execute(
    `INSERT INTO users (username, password_hash, role, parent_id, permissions, display_name, status)
     VALUES (?, ?, ?, ?, ?, ?, 'active')`,
    [
      input.username,
      hashPassword(input.password),
      input.role,
      input.parentId ?? null,
      perms,
      input.displayName ?? input.username,
    ],
  )
  return res.insertId
}

export async function listByRole(role: Role, parentId?: number): Promise<PublicUser[]> {
  const rows = parentId
    ? await query<UserRow>(
        "SELECT * FROM users WHERE role = ? AND parent_id = ? ORDER BY created_at DESC",
        [role, parentId],
      )
    : await query<UserRow>("SELECT * FROM users WHERE role = ? ORDER BY created_at DESC", [role])
  return rows.map(toPublicUser)
}

export async function updatePermissions(id: number, permissions: string[]): Promise<void> {
  await execute("UPDATE users SET permissions = ? WHERE id = ?", [JSON.stringify(permissions), id])
}

export async function setStatus(id: number, status: "active" | "disabled"): Promise<void> {
  await execute("UPDATE users SET status = ? WHERE id = ?", [status, id])
}

export async function resetPassword(id: number, newPassword: string): Promise<void> {
  await execute("UPDATE users SET password_hash = ? WHERE id = ?", [hashPassword(newPassword), id])
}

export async function usernameExists(username: string): Promise<boolean> {
  const rows = await query<{ id: number }>("SELECT id FROM users WHERE username = ? LIMIT 1", [username])
  return rows.length > 0
}
