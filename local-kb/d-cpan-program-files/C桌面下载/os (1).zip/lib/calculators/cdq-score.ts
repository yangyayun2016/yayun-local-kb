// 亚马逊 CDQ v3 (Composite Data Quality) / LQS 打分引擎
// 算法、权重、扣分点/计分点完全依据《How to improve Amazon CDQ score》文档实现。
// CDQ v3 由 Amazon Selection & Catalog Systems (ASCS) 于 2025-03 推出。

export type Marketplace = "US" | "EU"

// V3 属性链接（含 ASIN）—— 用于在亚马逊后台抓取 reconciledDetailsV3 数据
export const V3_LINK_BASE: Record<Marketplace, string> = {
  US: "https://sellercentral.amazon.com/abis/ajax/reconciledDetailsV3?asin=",
  EU: "https://sellercentral-europe.amazon.com/abis/ajax/reconciledDetailsV3?asin=",
}

export function buildV3Link(marketplace: Marketplace, asin: string): string {
  return V3_LINK_BASE[marketplace] + (asin || "").trim().toUpperCase()
}

/* ============================ 原始数据输入模型 ============================ */

export interface CdqInput {
  asin: string
  marketplace: Marketplace
  productType: string
  // 是否变体家族（orphan = 独立非变体商品，变体维度 N/A 并重新分配权重）
  isVariation: boolean

  /* —— 标题 (Title) —— */
  title: string
  titleAttributesTagged: number // 标题中标注的核心属性数量
  titleStartsWithBrand: boolean

  /* —— 结构化属性 (Structured Attributes) —— */
  top6Total: number // 前 6 RAI 属性应填数（通常 6）
  top6Filled: number // 前 6 已填写
  top6Correct: number // 前 6 已填写且正确
  top10Total: number // 前 10 相关属性应填数（通常 10）
  top10Filled: number // 前 10 已填写
  bandABFilledRatio: number // Band A/B（深度信息组件）填充率 0-1

  /* —— 五点描述 (Bullet Points) —— */
  bulletCount: number
  bulletHasRestrictedWords: boolean

  /* —— 图片 (Image) —— */
  imageCount: number
  imageHasDefect: boolean
  mainImagePx: number // 主图最长边像素
  imageHasZoom: boolean
  iai: number // Imaging Attribute Index 0-1

  /* —— A+ 内容 —— */
  hasAPlus: boolean
  hasPremiumAPlus: boolean

  /* —— 变体 (Variation) —— */
  variationCount: number
  variationThemeConsistent: boolean
  variationHasSevereDefect: boolean // 错误属性值/单位混用/冗余/本地化错误/子项重复

  /* —— 产品类型分类 / 可发现性 (Discoverability) —— */
  hasLeafNode: boolean // 有准确的细分类目叶节点 (Node ID)
  ptClassificationCorrect: boolean
  hasSearchKeywords: boolean
}

/* ============================ 权重与等级 ============================ */

export const DIMENSION_META = [
  { key: "structured", label: "结构化属性质量", en: "Structured Attributes Quality", weight: 30, group: "详情页 Detail page" },
  { key: "title", label: "标题质量", en: "Title Quality", weight: 25, group: "详情页 Detail page" },
  { key: "variation", label: "变体质量", en: "Variation Quality", weight: 20, group: "详情页 Detail page" },
  { key: "image", label: "图片质量", en: "Image Quality", weight: 15, group: "详情页 Detail page" },
  { key: "bullets", label: "描述性摘要(五点)", en: "Descriptive Summary Quality", weight: 5, group: "详情页 Detail page" },
  { key: "aplus", label: "A+ 页面质量", en: "A+ Content Quality", weight: 5, group: "详情页 Detail page" },
  { key: "ptc", label: "产品类型分类", en: "Product Type Classification", weight: 20, group: "可发现性 Discoverability", bonus: true },
] as const

export type DimensionKey = (typeof DIMENSION_META)[number]["key"]

// 标题违禁/受限/促销/敏感词库（依据文档）
export const PROMO_WORDS = ["best seller", "best-seller", "free shipping", "cheapest", "top rated", "#1", "best ", "hot item", "100% quality", "guarantee", "warranty", "free", "gift"]
export const SENSITIVE_WORDS = ["antimicrobial", "antibacterial", "antifungal", "anti-mites", "anti mites", "sanitize", "sanitizes", "disinfect", "disinfects", "sterilize", "sterilizes", "detoxify", "pesticide", "pesticides", "insecticide", "uv sterilize", "prevents bacteria", "resists mildew", "removes mold", "marijuana", "heroin", "drugs"]
export const SPECIAL_CHARS = ["!", "$", "?", "_", "{", "}", "^", "¬", "¦"]

export type CheckStatus = "pass" | "warn" | "fail"

export interface CheckItem {
  label: string
  status: CheckStatus
  detail: string
  // 对该维度得分(0-1)的影响说明
  impact: string
}

export interface DimensionResult {
  key: DimensionKey
  label: string
  en: string
  weight: number // 实际权重（变体可能 N/A → 0，权重重分配）
  baseWeight: number
  applicable: boolean
  score: number // 0-1
  points: number // 实际得分 = score * weight
  grade?: string // 标题专用 A/B/C
  checks: CheckItem[]
  bonus?: boolean
}

export interface DiagnosisItem {
  severity: "critical" | "major" | "minor"
  dimension: string
  problem: string
  suggestion: string
}

export interface TodoItem {
  id: string
  dimension: string
  action: string
  merchantAction: string // 对应商家动作（Merchant Action）
  done: boolean
  priority: "high" | "medium" | "low"
}

export interface CdqResult {
  total: number // 0-120
  baseTotal: number // 不含可发现性加分的 0-100 部分
  grade: GradeKey
  gradeLabel: string
  policyViolation: boolean
  severeDefect: boolean
  dimensions: DimensionResult[]
  diagnoses: DiagnosisItem[]
  todos: TodoItem[]
}

export type GradeKey = "A++" | "A+" | "A" | "B" | "C" | "D" | "U"

export const GRADE_META: Record<GradeKey, { label: string; range: string; color: string }> = {
  "A++": { label: "极高（加分）", range: ">100", color: "#16a34a" },
  "A+": { label: "高质量", range: "90-100", color: "#22c55e" },
  A: { label: "尚可", range: "85-90", color: "#84cc16" },
  B: { label: "低质量 · 无缺陷", range: "70-85", color: "#eab308" },
  C: { label: "低质量 · 非严重缺陷", range: "0-69.99", color: "#f97316" },
  D: { label: "低质量 · 严重缺陷", range: "0", color: "#ef4444" },
  U: { label: "低质量 · 政策违规", range: "N/A", color: "#991b1b" },
}

/* ============================ 标题质量 TQS A/B/C ============================ */

export interface TitleAnalysis {
  length: number
  completeness: number // 0-1
  redundancy: number // 1=无冗余
  pipeScore: number // >0 含分隔符
  specialCharScore: number // 1=无特殊字符
  restrictedScore: number // 1=无受限/促销/敏感词
  startsWithBrand: boolean
  foundSpecial: string[]
  foundPromo: string[]
  foundSensitive: string[]
  repeatedWords: string[]
}

export function analyzeTitle(title: string, attributesTagged: number, startsWithBrand: boolean): TitleAnalysis {
  const t = (title || "").trim()
  const lower = t.toLowerCase()
  const length = t.length

  // 完整性：标注属性数 → 0/2/3+ 映射到 <0.4 / 0.4-0.6 / >=0.6
  const completeness = attributesTagged >= 3 ? 0.6 + Math.min(0.4, (attributesTagged - 3) * 0.1) : attributesTagged === 2 ? 0.45 : attributesTagged * 0.18

  // 冗余：统计重复词（>2 次，排除介词冠词连词）
  const stop = new Set(["the", "a", "an", "and", "or", "for", "in", "on", "with", "of", "to", "by"])
  const words = lower.replace(/[^a-z0-9\s]/g, " ").split(/\s+/).filter((w) => w.length > 1 && !stop.has(w))
  const freq: Record<string, number> = {}
  for (const w of words) freq[w] = (freq[w] || 0) + 1
  const repeatedWords = Object.entries(freq).filter(([, c]) => c > 2).map(([w]) => w)
  const redundancy = repeatedWords.length === 0 ? 1 : repeatedWords.length === 1 ? 0.6 : 0.4

  const pipeScore = /[|]|[-–—]\s|\s[-–—]/.test(t) ? 1 : 0
  const foundSpecial = SPECIAL_CHARS.filter((c) => t.includes(c))
  const specialCharScore = foundSpecial.length === 0 ? 1 : 0
  const foundPromo = PROMO_WORDS.filter((w) => lower.includes(w))
  const foundSensitive = SENSITIVE_WORDS.filter((w) => lower.includes(w))
  const restrictedScore = foundPromo.length === 0 && foundSensitive.length === 0 ? 1 : 0

  return {
    length,
    completeness: Math.min(1, completeness),
    redundancy,
    pipeScore,
    specialCharScore,
    restrictedScore,
    startsWithBrand,
    foundSpecial,
    foundPromo,
    foundSensitive,
    repeatedWords,
  }
}

// 返回 { score, grade }
function scoreTitle(a: TitleAnalysis): { score: number; grade: "A" | "B" | "C" } {
  // C 级（违规, U）
  if (a.completeness < 0.4 || a.redundancy <= 0.6 || a.length > 200 || a.restrictedScore < 1 || a.specialCharScore < 1) {
    return { score: 0, grade: "C" }
  }
  // A 级（100%）
  if (a.completeness >= 0.6 && a.redundancy === 1 && a.length <= 200 && a.pipeScore > 0 && a.specialCharScore === 1 && a.restrictedScore === 1) {
    return { score: 1, grade: "A" }
  }
  // B 级（>=50%）
  return { score: 0.5, grade: "B" }
}

/* ============================ 主评分函数 ============================ */

export function computeCdq(input: CdqInput): CdqResult {
  const dimensions: DimensionResult[] = []
  const diagnoses: DiagnosisItem[] = []
  const todos: TodoItem[] = []
  let policyViolation = false
  let severeDefect = false

  /* —— 1. 结构化属性 (30%) —— */
  {
    const top6CorrectRatio = input.top6Total ? input.top6Correct / input.top6Total : 0
    const top10Completeness = input.top10Total ? input.top10Filled / input.top10Total : 0
    // 评分 = 完整且正确属性的权重总和（前6占 60%，前10其余占 25%，BandA/B 占 15%）
    const score = Math.max(0, Math.min(1, top6CorrectRatio * 0.6 + top10Completeness * 0.25 + input.bandABFilledRatio * 0.15))
    const checks: CheckItem[] = [
      {
        label: "前 6 RAI 属性正确性",
        status: top6CorrectRatio >= 1 ? "pass" : top6CorrectRatio >= 0.6 ? "warn" : "fail",
        detail: `${input.top6Correct}/${input.top6Total} 项正确`,
        impact: "占维度 60%，错误即严重缺陷",
      },
      {
        label: "前 10 相关属性完整性",
        status: top10Completeness >= 0.8 ? "pass" : top10Completeness >= 0.5 ? "warn" : "fail",
        detail: `${input.top10Filled}/${input.top10Total} 已填写 (${(top10Completeness * 100).toFixed(0)}%)`,
        impact: "占维度 25%，<50% 触发严重缺陷",
      },
      {
        label: "Band A/B 深度信息组件",
        status: input.bandABFilledRatio >= 0.8 ? "pass" : input.bandABFilledRatio >= 0.5 ? "warn" : "fail",
        detail: `填充率 ${(input.bandABFilledRatio * 100).toFixed(0)}%`,
        impact: "占维度 15%，构成 Depth Widget",
      },
    ]
    // 严重缺陷判定
    if (input.top6Correct < input.top6Total || top10Completeness < 0.5) {
      severeDefect = true
      diagnoses.push({
        severity: "critical",
        dimension: "结构化属性",
        problem: top10Completeness < 0.5 ? "前 10 相关属性完整性低于 50%（严重缺陷）" : "前 6 RAI 属性存在错误（严重缺陷）",
        suggestion: "分配正确的 Product Type 并补全/修正排名 1-10 的相关属性，正确性优先于完整性。",
      })
      todos.push({ id: "sa-1", dimension: "结构化属性", action: "补全并修正排名 [1..10] 的相关属性", merchantAction: "Assign eligible PT and fill in relevant attributes ranked [1..10]", done: false, priority: "high" })
    }
    if (top10Completeness < 1 && top10Completeness >= 0.5) {
      todos.push({ id: "sa-2", dimension: "结构化属性", action: "补全排名 [5..10] 的缺失属性 (如 maximum_current, item_weight)", merchantAction: "Fill in missing relevant attributes ranked [5..10]", done: false, priority: "medium" })
    }
    dimensions.push({ key: "structured", label: "结构化属性质量", en: "Structured Attributes Quality", weight: 30, baseWeight: 30, applicable: true, score, points: score * 30, checks })
  }

  /* —— 2. 标题 (25%) —— */
  {
    const a = analyzeTitle(input.title, input.titleAttributesTagged, input.titleStartsWithBrand)
    const { score, grade } = scoreTitle(a)
    if (grade === "C") policyViolation = true
    const checks: CheckItem[] = [
      { label: "标题长度 ≤ 200", status: a.length <= 200 ? (a.length >= 75 ? "pass" : "warn") : "fail", detail: `${a.length} 字符（建议 75-200）`, impact: a.length > 200 ? "C级违规→0%" : "" },
      { label: "完整性评分 ≥ 0.6", status: a.completeness >= 0.6 ? "pass" : a.completeness >= 0.4 ? "warn" : "fail", detail: `${a.completeness.toFixed(2)}（标注 ${input.titleAttributesTagged} 个属性）`, impact: "<0.4 触发 C级" },
      { label: "冗余度 = 1（无堆砌）", status: a.redundancy === 1 ? "pass" : "fail", detail: a.repeatedWords.length ? `重复词: ${a.repeatedWords.join(", ")}` : "无重复词", impact: "≤0.6 触发 C级" },
      { label: "分隔符（管套）评分 > 0", status: a.pipeScore > 0 ? "pass" : "warn", detail: a.pipeScore > 0 ? "含 | 或分隔符" : "建议加入分隔符分段", impact: "A级要求 >0" },
      { label: "无特殊字符", status: a.specialCharScore === 1 ? "pass" : "fail", detail: a.foundSpecial.length ? `发现: ${a.foundSpecial.join(" ")}` : "无 !$?_{}^¬¦", impact: a.foundSpecial.length ? "C级违规" : "" },
      { label: "无受限/促销/敏感词", status: a.restrictedScore === 1 ? "pass" : "fail", detail: [...a.foundPromo, ...a.foundSensitive].length ? `发现: ${[...a.foundPromo, ...a.foundSensitive].join(", ")}` : "无违禁词", impact: a.restrictedScore < 1 ? "C级违规" : "" },
      { label: "品牌名开头", status: a.startsWithBrand ? "pass" : "warn", detail: a.startsWithBrand ? "以品牌名开头" : "建议以品牌名开头", impact: "完整性加分项" },
    ]
    if (grade === "C") {
      diagnoses.push({ severity: "critical", dimension: "标题", problem: "标题违反政策（受限词/特殊字符/超长/堆砌），CDQ 等级判为 U", suggestion: "移除违禁词与特殊字符，控制长度 75-200，去除重复堆砌，以品牌名开头并标注 ≥3 个核心属性。" })
      todos.push({ id: "ti-1", dimension: "标题", action: "修正标题政策违规（受限词/特殊字符/长度/堆砌）", merchantAction: "Correct title policy violations", done: false, priority: "high" })
    } else if (grade === "B") {
      diagnoses.push({ severity: "major", dimension: "标题", problem: "标题为 B 级，未达 A 级高质量标准（缺分隔符或属性标注不足）", suggestion: "标注 ≥3 个核心属性、加入分隔符分段、确保以品牌名开头以升至 A 级。" })
      todos.push({ id: "ti-2", dimension: "标题", action: "优化标题至 A 级（属性≥3、分隔符、品牌开头）", merchantAction: "Enhance title to Grade A", done: false, priority: "medium" })
    }
    dimensions.push({ key: "title", label: "标题质量", en: "Title Quality", weight: 25, baseWeight: 25, applicable: true, score, points: score * 25, grade, checks })
  }

  /* —— 3. 变体 (20% / N/A orphan) —— */
  {
    const applicable = input.isVariation
    let score = 0
    const checks: CheckItem[] = []
    if (applicable) {
      const enough = input.variationCount >= 2
      score = input.variationHasSevereDefect ? 0.3 : input.variationThemeConsistent && enough ? 1 : 0.6
      checks.push(
        { label: "变体数量 ≥ 2", status: enough ? "pass" : "fail", detail: `${input.variationCount} 个变体`, impact: "变体家族基本要求" },
        { label: "主题属性一致且正确", status: input.variationThemeConsistent ? "pass" : "fail", detail: input.variationThemeConsistent ? "整个家族一致" : "存在不一致", impact: "占主要权重" },
        { label: "无严重缺陷", status: input.variationHasSevereDefect ? "fail" : "pass", detail: input.variationHasSevereDefect ? "错误值/单位混用/冗余/子项重复" : "无严重缺陷", impact: "严重缺陷→需立即处理" },
      )
      if (input.variationHasSevereDefect) {
        severeDefect = true
        diagnoses.push({ severity: "critical", dimension: "变体", problem: "变体存在严重缺陷（错误属性值/单位混用/冗余/本地化错误/子项重复）", suggestion: "统一变体主题属性，修正错误值与单位，去除冗余与重复子项。" })
        todos.push({ id: "va-1", dimension: "变体", action: "修复变体严重缺陷并统一主题属性", merchantAction: "Fix variation severe defects", done: false, priority: "high" })
      }
    } else {
      checks.push({ label: "Orphan ASIN（独立商品）", status: "pass", detail: "变体维度 N/A，权重重新分配至其他维度", impact: "20% 权重重分配" })
    }
    dimensions.push({ key: "variation", label: "变体质量", en: "Variation Quality", weight: applicable ? 20 : 0, baseWeight: 20, applicable, score, points: applicable ? score * 20 : 0, checks })
  }

  /* —— 4. 图片 (15%) —— */
  {
    const enough = input.imageCount >= 4
    let score: number
    if (enough && !input.imageHasDefect) score = 1.0
    else if (enough && input.imageHasDefect) score = 0.4
    else if (!enough && !input.imageHasDefect) score = 0.6
    else score = 0.0
    const checks: CheckItem[] = [
      { label: "网站图片数量 ≥ 4", status: enough ? "pass" : "fail", detail: `${input.imageCount} 张`, impact: "<4 张大幅降分" },
      { label: "无图片质量缺陷", status: input.imageHasDefect ? "fail" : "pass", detail: input.imageHasDefect ? "存在缺陷 → 0.4" : "无缺陷 → 1.0", impact: "缺陷使分数降至 40%" },
      { label: "主图 ≥ 1000px 且支持缩放", status: input.mainImagePx >= 1000 && input.imageHasZoom ? "pass" : "warn", detail: `主图 ${input.mainImagePx}px，缩放 ${input.imageHasZoom ? "✓" : "✗"}`, impact: "缩放功能要求" },
      { label: "IAI ≥ 0.4", status: input.iai >= 0.4 ? "pass" : "warn", detail: `IAI = ${input.iai.toFixed(2)}（图像属性指数）`, impact: "图片信息完善度" },
    ]
    if (score < 1) {
      diagnoses.push({ severity: input.imageHasDefect ? "major" : "minor", dimension: "图片", problem: input.imageHasDefect ? "存在图片缺陷，图片分被限制在 40%" : input.imageCount < 4 ? "图片数量不足 4 张" : "图片可优化", suggestion: "上传 ≥4 张无缺陷图片，主图 ≥1000px 支持缩放，产品占图比高、有效像素 ≥85%，并补充打标签提升 IAI。" })
      todos.push({ id: "im-1", dimension: "图片", action: "补足 ≥4 张高质量图并修复缺陷（主图≥1000px+缩放）", merchantAction: "Upload ≥4 defect-free images with zoom", done: false, priority: input.imageHasDefect ? "high" : "medium" })
    }
    dimensions.push({ key: "image", label: "图片质量", en: "Image Quality", weight: 15, baseWeight: 15, applicable: true, score, points: score * 15, checks })
  }

  /* —— 5. 五点描述 (5%) —— */
  {
    const score = input.bulletHasRestrictedWords ? Math.min(0.5, input.bulletCount >= 3 ? 0.5 : input.bulletCount >= 1 ? 0.25 : 0) : input.bulletCount >= 3 ? 1 : input.bulletCount >= 1 ? 0.5 : 0
    const checks: CheckItem[] = [
      { label: "五点数量 ≥ 3", status: input.bulletCount >= 3 ? "pass" : input.bulletCount >= 1 ? "warn" : "fail", detail: `${input.bulletCount} 条（≥3→100% · ≥1→50% · 0→0%）`, impact: "遵循 0/1/3 原则" },
      { label: "无违禁/敏感词", status: input.bulletHasRestrictedWords ? "fail" : "pass", detail: input.bulletHasRestrictedWords ? "含违禁词" : "通过关键词检查", impact: "违禁词降分" },
    ]
    if (score < 1) {
      diagnoses.push({ severity: "minor", dimension: "五点描述", problem: input.bulletCount < 3 ? "五点描述少于 3 条" : "五点含违禁词", suggestion: "按 0/1/3 原则撰写 ≥3 条要点：1 个核心功能 + ≥3 个魅力卖点，移除违禁/敏感词。" })
      todos.push({ id: "bp-1", dimension: "五点描述", action: "补足 ≥3 条要点并清理违禁词", merchantAction: "Add ≥3 bullet points, remove restricted words", done: false, priority: "low" })
    }
    dimensions.push({ key: "bullets", label: "描述性摘要(五点)", en: "Descriptive Summary Quality", weight: 5, baseWeight: 5, applicable: true, score, points: score * 5, checks })
  }

  /* —— 6. A+ (5%) —— */
  {
    const score = input.hasAPlus ? 1 : 0
    const checks: CheckItem[] = [
      { label: "拥有 A+ 内容", status: input.hasAPlus ? "pass" : "fail", detail: input.hasAPlus ? "A+ 已应用 → 100%（二元评分）" : "无 A+ → 0%", impact: "二元：有→100% 无→0%" },
      { label: "高级 A+（Premium）", status: input.hasPremiumAPlus ? "pass" : "warn", detail: input.hasPremiumAPlus ? "已使用高级 A+" : "建议升级高级 A+", impact: "2026 将评估 A+ 内容质量" },
    ]
    if (!input.hasAPlus) {
      diagnoses.push({ severity: "major", dimension: "A+", problem: "缺少 A+ 内容（Missing A+）", suggestion: "添加 A+ 内容（富媒体、对比图、增强图），呈现客户反馈的关键信息。" })
      todos.push({ id: "ap-1", dimension: "A+", action: "添加 A+ 内容（缺失 A+）", merchantAction: "Add A+ Content", done: false, priority: "high" })
    }
    dimensions.push({ key: "aplus", label: "A+ 页面质量", en: "A+ Content Quality", weight: 5, baseWeight: 5, applicable: true, score, points: score * 5, checks })
  }

  /* —— 7. 产品类型分类 / 可发现性 (0-20% 加分) —— */
  {
    const score = input.hasLeafNode && input.ptClassificationCorrect ? (input.hasSearchKeywords ? 1 : 0.7) : input.hasLeafNode ? 0.4 : 0
    const checks: CheckItem[] = [
      { label: "细分类目叶节点 (Node ID)", status: input.hasLeafNode ? "pass" : "fail", detail: input.hasLeafNode ? "有准确叶节点" : "缺少叶节点", impact: "可发现性基础" },
      { label: "产品类型分类正确", status: input.ptClassificationCorrect ? "pass" : "fail", detail: input.ptClassificationCorrect ? "PT 分类正确相关" : "PT 分类错误/缺失", impact: "影响搜索与筛选" },
      { label: "包含搜索关键词/类目词", status: input.hasSearchKeywords ? "pass" : "warn", detail: input.hasSearchKeywords ? "含关键词" : "建议补充关键词", impact: "提升 Discoverability" },
    ]
    if (score < 1) {
      diagnoses.push({ severity: "minor", dimension: "可发现性", problem: "产品类型分类/叶节点不完整", suggestion: "分配准确的细分类目叶节点 (Node ID)，确保 PT 分类正确并补充类目关键词。" })
      todos.push({ id: "pt-1", dimension: "可发现性", action: "分配准确叶节点并补充类目关键词", merchantAction: "Assign accurate leaf node + keywords", done: false, priority: "low" })
    }
    dimensions.push({ key: "ptc", label: "产品类型分类", en: "Product Type Classification", weight: 20, baseWeight: 20, applicable: true, score, points: score * 20, checks, bonus: true })
  }

  /* —— 权重重分配（Orphan 时变体 20% 重新分配至详情页其他维度） —— */
  if (!input.isVariation) {
    const detailDims = dimensions.filter((d) => d.key !== "variation" && d.key !== "ptc")
    const totalBase = detailDims.reduce((s, d) => s + d.baseWeight, 0) // 30+25+15+5+5=80
    for (const d of detailDims) {
      const extra = 20 * (d.baseWeight / totalBase)
      d.weight = d.baseWeight + extra
      d.points = d.score * d.weight
    }
  }

  /* —— 汇总 —— */
  const baseDims = dimensions.filter((d) => !d.bonus)
  const baseTotal = baseDims.reduce((s, d) => s + d.points, 0)
  const ptc = dimensions.find((d) => d.key === "ptc")!
  const total = baseTotal + ptc.points

  let grade: GradeKey
  if (policyViolation) grade = "U"
  else if (severeDefect) grade = "D"
  else if (total > 100) grade = "A++"
  else if (total >= 90) grade = "A+"
  else if (total >= 85) grade = "A"
  else if (total >= 70) grade = "B"
  else grade = "C"

  // 诊断按严重度排序
  const sevOrder = { critical: 0, major: 1, minor: 2 }
  diagnoses.sort((a, b) => sevOrder[a.severity] - sevOrder[b.severity])
  const prioOrder = { high: 0, medium: 1, low: 2 }
  todos.sort((a, b) => prioOrder[a.priority] - prioOrder[b.priority])

  return {
    total,
    baseTotal,
    grade,
    gradeLabel: GRADE_META[grade].label,
    policyViolation,
    severeDefect,
    dimensions,
    diagnoses,
    todos,
  }
}

/* ============================ 示例数据 ============================ */

export function sampleInput(): CdqInput {
  return {
    asin: "B0FF3165LL",
    marketplace: "US",
    productType: "HEADPHONES",
    isVariation: true,
    title: "SoundCore Wireless Noise Cancelling Headphones - Over Ear Bluetooth 5.3 Headset with 40H Playtime, Hi-Res Audio, Deep Bass for Travel Work, Black",
    titleAttributesTagged: 4,
    titleStartsWithBrand: true,
    top6Total: 6,
    top6Filled: 6,
    top6Correct: 5,
    top10Total: 10,
    top10Filled: 7,
    bandABFilledRatio: 0.7,
    bulletCount: 5,
    bulletHasRestrictedWords: false,
    imageCount: 10,
    imageHasDefect: false,
    mainImagePx: 1600,
    imageHasZoom: true,
    iai: 0.62,
    hasAPlus: true,
    hasPremiumAPlus: false,
    variationCount: 4,
    variationThemeConsistent: true,
    variationHasSevereDefect: false,
    hasLeafNode: true,
    ptClassificationCorrect: true,
    hasSearchKeywords: false,
  }
}
