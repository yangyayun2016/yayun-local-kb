/**
 * TQS (Title Quality Score) 标题质量诊断引擎
 * 依据 CDQ v3 标题评估体系，按 A / B / C 三级评分，并标注每一个细节。
 *
 * 评估维度（7 项）：
 *  1. 完整性  Completeness     —— 品牌名 + 主关键词 + ≥3 核心属性 + 适用人群/场景/意图/特征 + 无语法错误
 *  2. 准确性  Accuracy        —— 属性与商品一致、无错误拼写、无误导
 *  3. 篇幅    Length          —— 75 字符 + HIGHLIGHT 125 字符，总长 ≤ 200
 *  4. 大小写  Capitalization  —— 首字母大写规范、无全大写堆砌
 *  5. 关键词标注 Keyword Tag  —— 含分隔符（管套 |）分段、关键词分布清晰
 *  6. 冗余度  Redundancy      —— 无关键词堆砌 / 重复
 *  7. 内容限制性 Restriction   —— 无受限 / 促销 / 敏感 / 特殊字符
 *
 * 判级规则（严格按业务定义）：
 *  A 级（CDQ 标题质量评分 = 100%）：
 *    完整性 ≥ 0.6 且 冗余度 = 1 且 长度 ≤ 200 且 管套 > 0 且 特殊字符 = 1 且 限制性 = 1
 *  C 级（违规，CDQ = 0%，CDQv3 等级 = U，评分值 = N/A）：
 *    完整性 < 0.4 或 冗余度 ≤ 0.6 或 长度 > 200 或 受限短语阈值 < 1
 *  B 级（CDQ ≥ 50%）：未违反政策，但至少一个维度未达 A 级高质量标准
 */

export const TITLE_MAX_LENGTH = 200
export const TITLE_CORE_LENGTH = 75 // 核心信息字符
export const TITLE_HIGHLIGHT_LENGTH = 125 // HIGHLIGHT 字符

// 受限 / 促销短语（标题中出现即视为违规）
export const RESTRICTED_PHRASES = [
  "best seller",
  "best-seller",
  "bestseller",
  "top rated",
  "top-rated",
  "free shipping",
  "free ship",
  "sale",
  "discount",
  "% off",
  "percent off",
  "cheap",
  "cheapest",
  "lowest price",
  "best price",
  "hot sale",
  "limited time",
  "clearance",
  "deal",
  "promotion",
  "buy now",
  "new arrival",
  "money back",
  "guarantee",
  "guaranteed",
  "100%",
  "fda approved",
  "eco-friendly",
  "non-toxic",
]

// 敏感词（合规风险）
export const SENSITIVE_WORDS = ["cure", "heal", "treat", "anti-bacterial", "antibacterial", "antiviral", "kill virus", "covid", "medical grade"]

// 不可读 / 特殊字符
export const SPECIAL_CHARS = ["™", "®", "©", "$", "€", "£", "¥", "~", "*", "#", "@", "!", "?", "%", "^", "_", "{", "}", "[", "]", "<", ">", "\\"]

export type DimStatus = "pass" | "warn" | "fail"

export interface TqsCheck {
  label: string // 检测点
  status: DimStatus
  scoreText: string // 该项得分/数值
  note: string // 标注说明（计分点 / 扣分点）
  rule: string // 计分规则
}

export interface TqsDimension {
  key: string
  label: string // 中文维度名
  en: string
  weightHint: string // 在判级中的作用
  score: number // 0-1
  status: DimStatus
  checks: TqsCheck[]
}

export interface TqsResult {
  title: string
  grade: "A" | "B" | "C"
  cdqPercent: number // 100 / 50 / 0
  cdqv3Grade: string // A 级标题 → 正常；C → U
  cdqv3Value: string // C 级 → "N/A"
  gradeLabel: string
  // 关键指标
  length: number
  coreLength: number
  highlightLength: number
  completeness: number
  redundancy: number
  pipeScore: number
  specialCharScore: number
  restrictedScore: number
  capitalizationScore: number
  accuracyScore: number
  startsWithBrand: boolean
  // 细节
  foundRestricted: string[]
  foundSensitive: string[]
  foundSpecial: string[]
  repeatedWords: { word: string; count: number }[]
  allCapsWords: string[]
  dimensions: TqsDimension[]
  violations: string[]
  suggestions: string[]
}

export interface TqsInput {
  title: string
  brand: string
  mainKeyword: string
  attributesTagged: number // 标注的核心属性数量
  hasAudienceOrScene: boolean // 标注了适用人群 / 使用场景 / 意图 / 特征
  grammarOk: boolean // 无语法错误
  attributesAccurate: boolean // 属性与商品一致（准确性）
}

const STOP_WORDS = new Set(["the", "a", "an", "and", "or", "for", "in", "on", "with", "of", "to", "by", "from", "at", "as", "is", "are"])

export function analyzeTqs(input: TqsInput): TqsResult {
  const raw = input.title || ""
  const t = raw.trim()
  const lower = t.toLowerCase()
  const length = t.length
  const coreLength = Math.min(length, TITLE_CORE_LENGTH)
  const highlightLength = Math.max(0, Math.min(length, TITLE_MAX_LENGTH) - TITLE_CORE_LENGTH)

  /* —— 1. 完整性 —— */
  const brand = (input.brand || "").trim().toLowerCase()
  const startsWithBrand = brand.length > 0 && lower.startsWith(brand)
  const hasMainKeyword = (input.mainKeyword || "").trim().length > 0 && lower.includes((input.mainKeyword || "").trim().toLowerCase())
  // 属性数 → 完整性映射：≥3 → ≥0.6，=2 → 0.45，<2 → 线性低分
  let completeness = input.attributesTagged >= 3 ? 0.6 + Math.min(0.3, (input.attributesTagged - 3) * 0.1) : input.attributesTagged === 2 ? 0.45 : input.attributesTagged * 0.18
  // 品牌开头 / 主关键词 / 人群场景 / 语法 微调
  if (startsWithBrand) completeness += 0.04
  if (hasMainKeyword) completeness += 0.04
  if (input.hasAudienceOrScene) completeness += 0.02
  if (!input.grammarOk) completeness -= 0.1
  completeness = Math.max(0, Math.min(1, completeness))

  /* —— 6. 冗余度 —— */
  const words = lower.replace(/[^a-z0-9\s]/g, " ").split(/\s+/).filter((w) => w.length > 1 && !STOP_WORDS.has(w))
  const freq: Record<string, number> = {}
  for (const w of words) freq[w] = (freq[w] || 0) + 1
  const repeatedWords = Object.entries(freq)
    .filter(([, c]) => c > 2)
    .map(([word, count]) => ({ word, count }))
  const redundancy = repeatedWords.length === 0 ? 1 : repeatedWords.length === 1 ? 0.6 : 0.4

  /* —— 5. 关键词标注（管套 / 分隔符） —— */
  const pipeScore = /[|]|[•·]|\s[-–—]\s/.test(t) ? 1 : 0

  /* —— 7. 内容限制性 —— */
  const foundSpecial = SPECIAL_CHARS.filter((c) => t.includes(c))
  const specialCharScore = foundSpecial.length === 0 ? 1 : 0
  const foundRestricted = RESTRICTED_PHRASES.filter((w) => lower.includes(w))
  const foundSensitive = SENSITIVE_WORDS.filter((w) => lower.includes(w))
  const restrictedScore = foundRestricted.length === 0 && foundSensitive.length === 0 ? 1 : 0

  /* —— 4. 大小写规范 —— */
  const tokens = t.split(/\s+/).filter(Boolean)
  const allCapsWords = tokens.filter((w) => /[A-Z]/.test(w) && w.replace(/[^A-Za-z]/g, "").length >= 3 && w === w.toUpperCase())
  const capitalizationScore = allCapsWords.length === 0 ? 1 : allCapsWords.length <= 2 ? 0.6 : 0.3

  /* —— 2. 准确性 —— */
  const accuracyScore = input.attributesAccurate ? (input.grammarOk ? 1 : 0.7) : 0.4

  /* —— 判级 —— */
  let grade: "A" | "B" | "C"
  if (completeness < 0.4 || redundancy <= 0.6 || length > TITLE_MAX_LENGTH || restrictedScore < 1) {
    grade = "C"
  } else if (completeness >= 0.6 && redundancy === 1 && length <= TITLE_MAX_LENGTH && pipeScore > 0 && specialCharScore === 1 && restrictedScore === 1) {
    grade = "A"
  } else {
    grade = "B"
  }
  const cdqPercent = grade === "A" ? 100 : grade === "B" ? 50 : 0

  /* —— 维度明细 —— */
  const stt = (ok: boolean, warn = false): DimStatus => (ok ? "pass" : warn ? "warn" : "fail")

  const dimensions: TqsDimension[] = [
    {
      key: "completeness",
      label: "完整性",
      en: "Completeness",
      weightHint: "A级要求 ≥0.6；<0.4 触发 C级",
      score: completeness,
      status: stt(completeness >= 0.6, completeness >= 0.4),
      checks: [
        { label: "以品牌名开头", status: stt(startsWithBrand), scoreText: startsWithBrand ? "+0.04" : "0", note: startsWithBrand ? `检测到品牌「${input.brand}」` : "标题未以品牌名开头", rule: "标题应以品牌名开头" },
        { label: "包含主关键词", status: stt(hasMainKeyword), scoreText: hasMainKeyword ? "+0.04" : "0", note: hasMainKeyword ? `含主关键词「${input.mainKeyword}」` : "未检测到主关键词", rule: "需包含核心搜索词" },
        { label: "标注 ≥3 个核心属性", status: stt(input.attributesTagged >= 3, input.attributesTagged === 2), scoreText: `${input.attributesTagged} 个`, note: input.attributesTagged >= 3 ? "属性充分" : "属性不足，影响完整性评分", rule: "≥3 属性→≥0.6；=2→0.45；<2→更低" },
        { label: "适用人群/场景/意图/特征", status: stt(input.hasAudienceOrScene), scoreText: input.hasAudienceOrScene ? "+0.02" : "0", note: input.hasAudienceOrScene ? "已标注使用场景" : "缺少人群/场景信息", rule: "标注使用场景提升完整性" },
        { label: "无语法错误", status: stt(input.grammarOk), scoreText: input.grammarOk ? "ok" : "-0.10", note: input.grammarOk ? "语法正确" : "存在语法错误，扣分", rule: "语法错误扣 0.10" },
      ],
    },
    {
      key: "accuracy",
      label: "准确性",
      en: "Accuracy",
      weightHint: "属性需与商品真实信息一致",
      score: accuracyScore,
      status: stt(accuracyScore >= 0.9, accuracyScore >= 0.6),
      checks: [
        { label: "属性与商品一致", status: stt(input.attributesAccurate), scoreText: input.attributesAccurate ? "1.0" : "0.4", note: input.attributesAccurate ? "属性描述准确" : "属性可能与实物不符，存在误导风险", rule: "不一致大幅扣分" },
        { label: "无误导/夸大表述", status: stt(input.grammarOk && input.attributesAccurate), scoreText: accuracyScore.toFixed(2), note: "结合语法与一致性综合评估", rule: "误导表述影响准确性" },
      ],
    },
    {
      key: "length",
      label: "篇幅（长度）",
      en: "Length",
      weightHint: "核心75 + HIGHLIGHT125，总 ≤200；>200 触发 C级",
      score: length <= TITLE_MAX_LENGTH ? (length >= TITLE_CORE_LENGTH ? 1 : length / TITLE_CORE_LENGTH) : 0,
      status: length > TITLE_MAX_LENGTH ? "fail" : length >= TITLE_CORE_LENGTH ? "pass" : "warn",
      checks: [
        { label: "总长度 ≤ 200", status: length <= TITLE_MAX_LENGTH ? "pass" : "fail", scoreText: `${length} / 200`, note: length > TITLE_MAX_LENGTH ? "超长，触发 C级违规" : "长度合规", rule: ">200 → C级 / 0%" },
        { label: "核心信息（前 75 字符）", status: length >= TITLE_CORE_LENGTH ? "pass" : "warn", scoreText: `${coreLength} / 75`, note: length >= TITLE_CORE_LENGTH ? "核心区已填满" : "核心区未填满，建议补充关键信息", rule: "核心 75 字符承载主要卖点" },
        { label: "HIGHLIGHT（76-200 字符）", status: highlightLength > 0 ? "pass" : "warn", scoreText: `${highlightLength} / 125`, note: highlightLength > 0 ? "已使用 HIGHLIGHT 区" : "未使用 HIGHLIGHT 区", rule: "HIGHLIGHT 区可扩展长尾属性" },
      ],
    },
    {
      key: "capitalization",
      label: "大小写规范",
      en: "Capitalization",
      weightHint: "实词首字母大写，避免整词全大写堆砌",
      score: capitalizationScore,
      status: stt(capitalizationScore === 1, capitalizationScore >= 0.6),
      checks: [
        { label: "无全大写堆砌词", status: allCapsWords.length === 0 ? "pass" : allCapsWords.length <= 2 ? "warn" : "fail", scoreText: `${allCapsWords.length} 个`, note: allCapsWords.length ? `全大写: ${allCapsWords.slice(0, 5).join(", ")}` : "无全大写堆砌", rule: "全大写词过多视为不规范" },
      ],
    },
    {
      key: "keyword",
      label: "关键词标注",
      en: "Keyword Tagging",
      weightHint: "A级要求 管套评分 > 0（含分隔符）",
      score: pipeScore,
      status: stt(pipeScore > 0),
      checks: [
        { label: "含管道符/分隔符（| - •）", status: pipeScore > 0 ? "pass" : "fail", scoreText: pipeScore > 0 ? "1" : "0", note: pipeScore > 0 ? "已用分隔符分段" : "缺少分隔符，影响 A级评定", rule: "≥1 个分隔符清晰分隔信息段" },
      ],
    },
    {
      key: "redundancy",
      label: "冗余度",
      en: "Redundancy",
      weightHint: "A级要求 =1（无冗余）；≤0.6 触发 C级",
      score: redundancy,
      status: stt(redundancy === 1, redundancy > 0.6),
      checks: [
        { label: "无关键词堆砌/重复", status: redundancy === 1 ? "pass" : redundancy > 0.6 ? "warn" : "fail", scoreText: redundancy.toFixed(1), note: repeatedWords.length ? `重复词: ${repeatedWords.map((r) => `${r.word}×${r.count}`).join(", ")}` : "无重复堆砌", rule: "同语境 >2 次重复 → ≤0.6 → C级" },
      ],
    },
    {
      key: "restriction",
      label: "内容限制性",
      en: "Restriction",
      weightHint: "A级要求 =1（无受限词与特殊字符）；<1 触发 C级",
      score: restrictedScore === 1 && specialCharScore === 1 ? 1 : restrictedScore < 1 ? 0 : 0.5,
      status: restrictedScore === 1 && specialCharScore === 1 ? "pass" : "fail",
      checks: [
        { label: "无受限/促销短语", status: foundRestricted.length === 0 ? "pass" : "fail", scoreText: foundRestricted.length === 0 ? "1" : "0", note: foundRestricted.length ? `发现: ${foundRestricted.join(", ")}` : "无受限词", rule: "受限短语 → C级违规 / 0%" },
        { label: "无敏感/合规风险词", status: foundSensitive.length === 0 ? "pass" : "fail", scoreText: foundSensitive.length === 0 ? "1" : "0", note: foundSensitive.length ? `发现: ${foundSensitive.join(", ")}` : "无敏感词", rule: "敏感词触发合规风险" },
        { label: "无不可读特殊字符", status: foundSpecial.length === 0 ? "pass" : "fail", scoreText: foundSpecial.length === 0 ? "1" : "0", note: foundSpecial.length ? `发现: ${foundSpecial.join(" ")}` : "无特殊字符", rule: "特殊字符使标题无法升 A级" },
      ],
    },
  ]

  /* —— 违规与建议 —— */
  const violations: string[] = []
  if (length > TITLE_MAX_LENGTH) violations.push(`标题超长（${length} > 200 字符）`)
  if (completeness < 0.4) violations.push(`完整性不足（${completeness.toFixed(2)} < 0.4，属性少于 2 个）`)
  if (redundancy <= 0.6) violations.push(`关键词堆砌（冗余度 ${redundancy.toFixed(1)} ≤ 0.6）`)
  if (foundRestricted.length) violations.push(`含受限/促销短语：${foundRestricted.join(", ")}`)
  if (foundSensitive.length) violations.push(`含敏感词：${foundSensitive.join(", ")}`)

  const suggestions: string[] = []
  if (!startsWithBrand) suggestions.push("以品牌名开头，强化品牌识别。")
  if (!hasMainKeyword) suggestions.push("在前 75 字符内嵌入主关键词。")
  if (input.attributesTagged < 3) suggestions.push("补足至 ≥3 个核心属性（材质/规格/颜色/适用场景等）。")
  if (pipeScore === 0) suggestions.push("使用管道符（|）或分隔符分隔信息段，满足 A级评定。")
  if (redundancy < 1) suggestions.push(`去除重复堆砌词：${repeatedWords.map((r) => r.word).join(", ") || "（精简同义词）"}。`)
  if (foundSpecial.length) suggestions.push(`移除特殊字符：${foundSpecial.join(" ")}。`)
  if (foundRestricted.length || foundSensitive.length) suggestions.push("删除所有受限/促销/敏感词以解除违规状态。")
  if (allCapsWords.length) suggestions.push("调整全大写词为标题大小写（首字母大写）。")
  if (length > TITLE_MAX_LENGTH) suggestions.push("压缩标题至 200 字符以内。")
  if (length < TITLE_CORE_LENGTH) suggestions.push("补充内容填满核心 75 字符区。")
  if (suggestions.length === 0) suggestions.push("标题已达 A 级高质量标准，保持现状。")

  return {
    title: t,
    grade,
    cdqPercent,
    cdqv3Grade: grade === "C" ? "U（违规）" : grade === "A" ? "正常（A级标题）" : "正常",
    cdqv3Value: grade === "C" ? "N/A" : `${cdqPercent}%`,
    gradeLabel: grade === "A" ? "A级 · 高质量标题" : grade === "B" ? "B级 · 待优化" : "C级 · 违规标题",
    length,
    coreLength,
    highlightLength,
    completeness,
    redundancy,
    pipeScore,
    specialCharScore,
    restrictedScore,
    capitalizationScore,
    accuracyScore,
    startsWithBrand,
    foundRestricted,
    foundSensitive,
    foundSpecial,
    repeatedWords,
    allCapsWords,
    dimensions,
    violations,
    suggestions,
  }
}

export const TQS_SAMPLE: TqsInput = {
  title: "SoundCore Wireless Noise Cancelling Headphones | Over-Ear Bluetooth 5.3 Headset, 40H Playtime, Hi-Res Audio, Deep Bass for Travel & Work - Black",
  brand: "SoundCore",
  mainKeyword: "Noise Cancelling Headphones",
  attributesTagged: 5,
  hasAudienceOrScene: true,
  grammarOk: true,
  attributesAccurate: true,
}
