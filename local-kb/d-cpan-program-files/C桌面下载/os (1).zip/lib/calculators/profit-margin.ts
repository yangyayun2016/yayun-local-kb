// 亚马逊利润率计算器 —— 完全复刻《利润率-项目表.xlsx》中四个测算表的公式逻辑
// 表：美国SC毛利测算 / 美国VC毛利测算 / 欧洲SC毛利测算 / 欧洲VC毛利测算

export type FieldType = "number" | "percent" | "select"

export interface FieldDef {
  key: string
  label: string
  type: FieldType
  default: number | string
  group: string
  suffix?: string
  options?: { label: string; value: string }[]
  hint?: string
}

export type ResultFormat = "currency" | "percent" | "number"

export interface ResultRow {
  label: string
  value: number
  format: ResultFormat
  highlight?: boolean
}

export interface RatioRow {
  label: string
  value: number // 0-1 小数
}

export interface CalcResult {
  outputs: ResultRow[]
  ratios: RatioRow[]
}

export interface CalcMode {
  key: string
  label: string
  currency: string // 显示币种符号
  desc: string
  fields: FieldDef[]
  compute: (v: Record<string, number | string>) => CalcResult
}

const num = (v: number | string | undefined, d = 0) => {
  const n = typeof v === "string" ? Number.parseFloat(v) : v
  return Number.isFinite(n as number) ? (n as number) : d
}

/* ============================================================
   模式一：美国 SC 毛利测算
   ============================================================ */
const usSc: CalcMode = {
  key: "us-sc",
  label: "美国 SC",
  currency: "$",
  desc: "Seller Central · 自配送/FBA 毛利测算",
  fields: [
    { key: "price", label: "售价", type: "number", default: 99.99, group: "价格", suffix: "$" },
    { key: "rate", label: "汇率(¥/$)", type: "number", default: 7.1, group: "价格" },
    { key: "purchaseRMB", label: "采购价(¥不含税)", type: "number", default: 120.8, group: "成本", suffix: "¥" },
    { key: "firstLegRMB", label: "头程运费(¥)", type: "number", default: 55, group: "成本", suffix: "¥" },
    { key: "deliveryFee", label: "FBA 配送费", type: "number", default: 13.41, group: "成本", suffix: "$" },
    { key: "commissionRate", label: "抽佣比例", type: "percent", default: 0.15, group: "费率" },
    { key: "adRate", label: "广告费率", type: "percent", default: 0.08, group: "费率" },
    { key: "testRate", label: "送测费率", type: "percent", default: 0.01, group: "费率" },
    { key: "transferRate", label: "仓库调拨费率", type: "percent", default: 0.01, group: "费率" },
    { key: "otherRate", label: "其他费用率", type: "percent", default: 0.02, group: "费率" },
    { key: "returnRate", label: "预估退货率", type: "percent", default: 0.07, group: "费率" },
  ],
  compute: (v) => {
    const price = num(v.price)
    const rate = num(v.rate, 1)
    const purchaseRMB = num(v.purchaseRMB)
    const firstLegRMB = num(v.firstLegRMB)
    const deliveryFee = num(v.deliveryFee)
    const commissionRate = num(v.commissionRate)
    const adRate = num(v.adRate)
    const testRate = num(v.testRate)
    const transferRate = num(v.transferRate)
    const otherRate = num(v.otherRate)
    const returnRate = num(v.returnRate)

    const buyUSD = purchaseRMB / rate // F 进价$
    const firstLegUSD = firstLegRMB / rate // H 头程$
    const costTotal = buyUSD + firstLegUSD // I 成本合计
    const commission = price * commissionRate // K 佣金
    const grossBase = price - costTotal - commission - deliveryFee // M 毛利
    const grossBaseRate = price ? grossBase / price : 0 // N 毛利率
    const transfer = transferRate * price // O 仓库调拨费
    const test = testRate * price // Q 送测
    const ad = adRate * price // R 广告
    const grossNet = price - costTotal - commission - deliveryFee - test - ad // S 净毛利
    const grossNetRate = price ? grossNet / price : 0 // T 净毛利率

    return {
      outputs: [
        { label: "进价($)", value: buyUSD, format: "currency" },
        { label: "头程($)", value: firstLegUSD, format: "currency" },
        { label: "成本合计", value: costTotal, format: "currency" },
        { label: "佣金", value: commission, format: "currency" },
        { label: "广告费", value: ad, format: "currency" },
        { label: "送测费", value: test, format: "currency" },
        { label: "仓库调拨费", value: transfer, format: "currency" },
        { label: "毛利(扣佣配送)", value: grossBase, format: "currency" },
        { label: "毛利率(基础)", value: grossBaseRate, format: "percent" },
        { label: "净毛利", value: grossNet, format: "currency", highlight: true },
        { label: "净毛利率", value: grossNetRate, format: "percent", highlight: true },
      ],
      ratios: [
        { label: "采购占比", value: price ? buyUSD / price : 0 },
        { label: "头程占比", value: price ? firstLegUSD / price : 0 },
        { label: "尾程(配送)占比", value: price ? deliveryFee / price : 0 },
        { label: "佣金占比", value: commissionRate },
        { label: "广告占比", value: adRate },
        { label: "其他费用占比", value: otherRate },
        { label: "预估退货率", value: returnRate },
      ],
    }
  },
}

/* ============================================================
   模式二：美国 VC 毛利测算
   ============================================================ */
const usVc: CalcMode = {
  key: "us-vc",
  label: "美国 VC",
  currency: "$",
  desc: "Vendor Central · PO/DI 毛利与 NET PPM 测算",
  fields: [
    { key: "costPrice", label: "PO 成本价(外币)", type: "number", default: 53.99, group: "价格", suffix: "$" },
    { key: "suggestPrice", label: "亚马逊建议售价(外币)", type: "number", default: 64.99, group: "价格", suffix: "$" },
    { key: "rate", label: "汇率(¥/$)", type: "number", default: 7, group: "价格" },
    { key: "purchaseInclRMB", label: "采购成本(¥含税)", type: "number", default: 136.5, group: "成本", suffix: "¥" },
    { key: "firstLegRMB", label: "头程运费(¥)", type: "number", default: 55, group: "成本", suffix: "¥" },
    { key: "overseaFee", label: "海外仓操作费", type: "number", default: 1.5, group: "成本", suffix: "$" },
    { key: "promoFC", label: "促销费(外币)", type: "number", default: 6.4, group: "费用", suffix: "$" },
    { key: "adRatio", label: "广告占比", type: "percent", default: 0.1, group: "费率" },
    { key: "commissionRatio", label: "佣金占比", type: "percent", default: 0.21, group: "费率" },
    { key: "otherRatio", label: "其他占比", type: "percent", default: 0.01, group: "费率" },
    {
      key: "isBD",
      label: "是否 BD 促销",
      type: "select",
      default: "否",
      group: "费率",
      options: [
        { label: "否(常规)", value: "否" },
        { label: "是(BD 促销)", value: "是" },
      ],
      hint: "影响 NET PPM 公式",
    },
  ],
  compute: (v) => {
    const costPrice = num(v.costPrice)
    const suggestPrice = num(v.suggestPrice)
    const rate = num(v.rate, 1)
    const purchaseInclRMB = num(v.purchaseInclRMB)
    const firstLegRMB = num(v.firstLegRMB)
    const overseaFee = num(v.overseaFee)
    const promoFC = num(v.promoFC)
    const adRatio = num(v.adRatio)
    const commissionRatio = num(v.commissionRatio)
    const otherRatio = num(v.otherRatio)
    const isBD = String(v.isBD) === "是"

    const purchaseExclRMB = purchaseInclRMB / 1.13 // AC 采购¥不含税
    const costRMB = purchaseExclRMB + firstLegRMB // N 成本(RMB)
    const adFC = costPrice * adRatio // X 广告外币
    const otherFC = costPrice * otherRatio // Z 其它外币
    const commissionFC = costPrice * commissionRatio // AA 佣金外币
    const grossFC = costPrice - costRMB / rate - overseaFee - adFC - promoFC - otherFC - commissionFC // I 毛利外币
    const grossRate = costPrice ? grossFC / costPrice : 0 // J 毛利率
    const profitMargin = suggestPrice ? (suggestPrice - costPrice) / suggestPrice : 0 // K Profit Margin %
    const netPpm = isBD
      ? suggestPrice - promoFC
        ? (suggestPrice - costPrice + commissionFC - promoFC) / (suggestPrice - promoFC)
        : 0
      : suggestPrice
        ? (suggestPrice - costPrice + commissionFC) / suggestPrice
        : 0
    const amzGross = suggestPrice - costPrice // M 亚马逊毛利

    return {
      outputs: [
        { label: "采购成本(¥不含税)", value: purchaseExclRMB, format: "number" },
        { label: "成本(RMB)", value: costRMB, format: "number" },
        { label: "广告(外币)", value: adFC, format: "currency" },
        { label: "佣金(外币)", value: commissionFC, format: "currency" },
        { label: "其它(外币)", value: otherFC, format: "currency" },
        { label: "亚马逊毛利", value: amzGross, format: "currency" },
        { label: "Profit Margin", value: profitMargin, format: "percent" },
        { label: "毛利(外币)", value: grossFC, format: "currency", highlight: true },
        { label: "毛利率", value: grossRate, format: "percent", highlight: true },
        { label: "NET PPM", value: netPpm, format: "percent", highlight: true },
      ],
      ratios: [
        { label: "采购占比", value: costPrice && rate ? purchaseExclRMB / (costPrice * rate) : 0 },
        { label: "头程占比", value: costPrice && rate ? firstLegRMB / rate / costPrice : 0 },
        { label: "成本占比", value: costPrice && rate ? costRMB / (costPrice * rate) : 0 },
        { label: "尾程占比", value: costPrice ? overseaFee / costPrice : 0 },
        { label: "佣金占比", value: commissionRatio },
        { label: "广告占比", value: adRatio },
        { label: "促销占比", value: costPrice ? promoFC / costPrice : 0 },
        { label: "其他占比", value: otherRatio },
      ],
    }
  },
}

/* ============================================================
   模式三：欧洲 SC 毛利测算（用户重点示例的字段结构）
   ============================================================ */
const euSc: CalcMode = {
  key: "eu-sc",
  label: "欧洲 SC",
  currency: "€",
  desc: "Seller Central · 含 VAT 利润/定价反推测算",
  fields: [
    { key: "actualPrice", label: "实际定价", type: "number", default: 84.99, group: "价格", suffix: "€" },
    { key: "rate", label: "汇率(¥/€)", type: "number", default: 8, group: "价格" },
    {
      key: "hasVAT",
      label: "有无 VAT",
      type: "select",
      default: "有",
      group: "价格",
      options: [
        { label: "有", value: "有" },
        { label: "无", value: "无" },
      ],
    },
    { key: "purchaseInclRMB", label: "采购价(¥含税)", type: "number", default: 138.5, group: "成本", suffix: "¥" },
    { key: "freightRMB", label: "运费(¥)", type: "number", default: 26, group: "成本", suffix: "¥" },
    { key: "fbaFee", label: "FBA Fee", type: "number", default: 5.69, group: "成本", suffix: "€" },
    { key: "storageFee", label: "FBA 仓储费(€/件)", type: "number", default: 0.61, group: "成本", suffix: "€" },
    { key: "adFee", label: "广告费用(€/件)", type: "number", default: 10, group: "成本", suffix: "€" },
    { key: "commissionRate", label: "佣金比例", type: "percent", default: 0.15, group: "费率" },
    { key: "vat", label: "VAT", type: "percent", default: 0.16, group: "费率" },
    { key: "returnRate", label: "预估退货率", type: "percent", default: 0.05, group: "费率" },
    { key: "otherRate", label: "其他费用率", type: "percent", default: 0.02, group: "费率" },
    { key: "length", label: "长(cm)", type: "number", default: 33.5, group: "尺寸重量" },
    { key: "width", label: "宽(cm)", type: "number", default: 26.5, group: "尺寸重量" },
    { key: "height", label: "高(cm)", type: "number", default: 25, group: "尺寸重量" },
    { key: "realWeight", label: "包装后实重(kg)", type: "number", default: 2.3, group: "尺寸重量" },
    {
      key: "transportMode",
      label: "运输方式",
      type: "select",
      default: "海运",
      group: "尺寸重量",
      options: [
        { label: "海运", value: "海运" },
        { label: "空运", value: "空运" },
        { label: "铁路", value: "铁路" },
        { label: "美森/卡航", value: "美森/卡航" },
      ],
    },
  ],
  compute: (v) => {
    const actualPrice = num(v.actualPrice, 1)
    const rate = num(v.rate, 1)
    const hasVAT = String(v.hasVAT) === "有"
    const purchaseInclRMB = num(v.purchaseInclRMB)
    const freightRMB = num(v.freightRMB)
    const fbaFee = num(v.fbaFee)
    const storageFee = num(v.storageFee)
    const adFee = num(v.adFee)
    const commissionRate = num(v.commissionRate)
    const vat = num(v.vat)
    const returnRate = num(v.returnRate)
    const otherRate = num(v.otherRate)
    const length = num(v.length)
    const width = num(v.width)
    const height = num(v.height)
    const realWeight = num(v.realWeight)

    const purchaseExclRMB = purchaseInclRMB / 1.13 // I 采购价(不含税RMB)
    const adRate = actualPrice ? adFee / actualPrice : 0 // N 广告费率
    const storageRate = actualPrice ? storageFee / actualPrice : 0 // O 仓储费率
    const volWeight = (length * width * height) / 6000 // V 体积重
    const chargeWeight = Math.max(realWeight, volWeight) // W 计费重

    const sumRates = commissionRate + vat + returnRate + adRate + storageRate + otherRate
    const profit = actualPrice - sumRates * actualPrice - fbaFee - purchaseExclRMB / rate - freightRMB / rate // AA 利润
    const profitRate = actualPrice ? profit / actualPrice : 0 // AB 利润率

    const baseNumerator = purchaseExclRMB / rate + fbaFee + freightRMB / rate
    const cost0Denom = hasVAT
      ? 0.99999 - commissionRate - vat - returnRate - adRate
      : 0.99999 - commissionRate - returnRate - adRate
    const suggest20Denom = hasVAT
      ? 0.8 - commissionRate - vat - returnRate - adRate - storageRate - otherRate
      : 0.8 - commissionRate - returnRate - adRate - storageRate - otherRate
    const costPrice0 = cost0Denom > 0 ? baseNumerator / cost0Denom : 0 // F 成本价(0边利)
    const suggestPrice20 = suggest20Denom > 0 ? baseNumerator / suggest20Denom : 0 // G 建议价(20%边利)

    return {
      outputs: [
        { label: "采购价(¥不含税)", value: purchaseExclRMB, format: "number" },
        { label: "广告费率", value: adRate, format: "percent" },
        { label: "仓储费率", value: storageRate, format: "percent" },
        { label: "体积重(kg)", value: volWeight, format: "number" },
        { label: "计费重(kg)", value: chargeWeight, format: "number" },
        { label: "成本价(0 边利)", value: costPrice0, format: "currency", highlight: true },
        { label: "建议价(20% 边利)", value: suggestPrice20, format: "currency", highlight: true },
        { label: "利润", value: profit, format: "currency", highlight: true },
        { label: "利润率", value: profitRate, format: "percent", highlight: true },
      ],
      ratios: [
        { label: "FBA 配送费占比", value: actualPrice ? fbaFee / actualPrice : 0 },
        { label: "采购成本占比", value: actualPrice ? purchaseExclRMB / rate / actualPrice : 0 },
        { label: "头程费用占比", value: actualPrice ? freightRMB / rate / actualPrice : 0 },
        { label: "佣金占比", value: commissionRate },
        { label: "广告占比", value: adRate },
        { label: "其他费用占比", value: otherRate },
        { label: "预估退货率", value: returnRate },
      ],
    }
  },
}

/* ============================================================
   模式四：欧洲 VC 毛利测算
   ============================================================ */
const SITE_FREIGHT: Record<string, number> = {
  UK: 8.95,
  DE: 7.75,
  FR: 14.25,
  IT: 15.25,
  ES: 19.25,
  NL: 16.75,
  PL: 14.05,
  SE: 18.25,
  BE: 14.25,
}

const euVc: CalcMode = {
  key: "eu-vc",
  label: "欧洲 VC",
  currency: "€",
  desc: "Vendor Central · 含税成交价/NET PPM 测算",
  fields: [
    {
      key: "site",
      label: "站点",
      type: "select",
      default: "UK",
      group: "价格",
      options: Object.keys(SITE_FREIGHT).map((k) => ({ label: k, value: k })),
      hint: "决定二程运费",
    },
    { key: "poPrice", label: "PO 售价(外币)", type: "number", default: 48.3, group: "价格", suffix: "€" },
    { key: "suggestPriceIncl", label: "建议售价(含税外币)", type: "number", default: 69.99, group: "价格", suffix: "€" },
    { key: "vatRate", label: "VAT 税率", type: "percent", default: 0.2, group: "价格" },
    { key: "rate", label: "汇率(¥/€)", type: "number", default: 9, group: "价格" },
    { key: "purchaseInclRMB", label: "采购成本(¥含税)", type: "number", default: 138.5, group: "成本", suffix: "¥" },
    { key: "firstLegRMB", label: "头程运费(¥)", type: "number", default: 20, group: "成本", suffix: "¥" },
    { key: "packQty", label: "装箱数", type: "number", default: 4, group: "成本" },
    { key: "adFC", label: "广告费(外币)", type: "number", default: 8, group: "费用", suffix: "€" },
    { key: "promoRate", label: "促销比例", type: "percent", default: 0, group: "费率" },
    { key: "commissionRatio", label: "佣金占比", type: "percent", default: 0.178, group: "费率" },
    { key: "otherRatio", label: "其他占比", type: "percent", default: 0.01, group: "费率" },
  ],
  compute: (v) => {
    const site = String(v.site || "UK")
    const poPrice = num(v.poPrice, 1)
    const suggestPriceIncl = num(v.suggestPriceIncl)
    const vatRate = num(v.vatRate)
    const rate = num(v.rate, 1)
    const purchaseInclRMB = num(v.purchaseInclRMB)
    const firstLegRMB = num(v.firstLegRMB)
    const packQty = num(v.packQty, 1)
    const adFC = num(v.adFC)
    const promoRate = num(v.promoRate)
    const commissionRatio = num(v.commissionRatio)
    const otherRatio = num(v.otherRatio)

    const divisor = 1 + vatRate
    const secondLegFC = packQty ? (SITE_FREIGHT[site] ?? 0) / packQty : 0 // O 二程外币
    const promoFC = suggestPriceIncl * promoRate // Z 促销外币
    const dealIncl = suggestPriceIncl - promoFC // G 成交价含税
    const dealExcl = dealIncl / divisor // H 成交价不含税
    const suggestExcl = suggestPriceIncl / divisor // K 建议售价不含税
    const otherFC = poPrice * otherRatio // AA 其它外币
    const commissionFC = poPrice * commissionRatio // AB 佣金外币
    const purchaseExclRMB = purchaseInclRMB / 1.13 // AD 采购¥不含税
    const costRMB = purchaseExclRMB + firstLegRMB // N 成本(RMB)
    const firstLegFC = firstLegRMB / rate // AE 头程外币
    const grossFC = poPrice - costRMB / rate - commissionFC - adFC - secondLegFC - promoFC - otherFC // I 毛利外币
    const grossRate = poPrice ? grossFC / poPrice : 0 // J 毛利率
    const profitMargin = suggestExcl ? (suggestExcl - poPrice) / suggestExcl : 0 // L Profit Margin %
    const amzGross = suggestExcl - poPrice // M 亚马逊毛利
    const netPpm = suggestExcl - promoFC ? (suggestExcl - poPrice + commissionFC) / (suggestExcl - promoFC) : 0 // AI NET PPM

    return {
      outputs: [
        { label: "二程运费(外币)", value: secondLegFC, format: "currency" },
        { label: "成交价(含税)", value: dealIncl, format: "currency" },
        { label: "成交价(不含税)", value: dealExcl, format: "currency" },
        { label: "建议售价(不含税)", value: suggestExcl, format: "currency" },
        { label: "佣金(外币)", value: commissionFC, format: "currency" },
        { label: "其它(外币)", value: otherFC, format: "currency" },
        { label: "采购成本(¥不含税)", value: purchaseExclRMB, format: "number" },
        { label: "成本(RMB)", value: costRMB, format: "number" },
        { label: "头程(外币)", value: firstLegFC, format: "currency" },
        { label: "亚马逊毛利", value: amzGross, format: "currency" },
        { label: "Profit Margin", value: profitMargin, format: "percent" },
        { label: "毛利(外币)", value: grossFC, format: "currency", highlight: true },
        { label: "毛利率", value: grossRate, format: "percent", highlight: true },
        { label: "NET PPM", value: netPpm, format: "percent", highlight: true },
      ],
      ratios: [
        { label: "采购占比", value: poPrice && rate ? purchaseExclRMB / (poPrice * rate) : 0 },
        { label: "头程占比", value: poPrice ? firstLegFC / poPrice : 0 },
        { label: "成本占比", value: poPrice && rate ? costRMB / (poPrice * rate) : 0 },
        { label: "尾程占比", value: poPrice ? secondLegFC / poPrice : 0 },
        { label: "佣金占比", value: commissionRatio },
        { label: "广告占比", value: poPrice ? adFC / poPrice : 0 },
        { label: "前台广告占比", value: dealExcl ? adFC / dealExcl : 0 },
        { label: "促销占比", value: poPrice ? promoFC / poPrice : 0 },
        { label: "其他占比", value: otherRatio },
      ],
    }
  },
}

export const calcModes: CalcMode[] = [usSc, usVc, euSc, euVc]

export function defaultsForMode(mode: CalcMode): Record<string, number | string> {
  const out: Record<string, number | string> = {}
  for (const f of mode.fields) out[f.key] = f.default
  return out
}

export function formatValue(value: number, format: ResultFormat, currency: string): string {
  if (!Number.isFinite(value)) return "—"
  if (format === "percent") return `${(value * 100).toFixed(2)}%`
  if (format === "currency") return `${currency}${value.toFixed(2)}`
  return value.toFixed(2)
}
