// 搜索词分析（Amazon Search Terms）数据

export const stCampaignTypes = ["全部", "SP", "SB", "SD"] as const
export type StCampaignType = (typeof stCampaignTypes)[number]

export const stMatchTypes = ["全部", "精准匹配", "广泛匹配", "词组匹配"] as const
export type StMatchType = (typeof stMatchTypes)[number]

export interface SearchTermRow {
  term: string // 客户搜索词
  matchType: Exclude<StMatchType, "全部"> // 匹配类型
  campaignType: Exclude<StCampaignType, "全部"> // 投放类型 SP/SB/SD
  campaignCount: number // 投放次数：多少个广告活动在投放该词
  campaigns: string[] // 关联广告活动名
  impressions: number // 曝光量
  clicks: number // 点击
  ctr: string // CTR
  cpc: string // CPC
  spend: string // 花费
  adSales: string // 广告销售额
  acos: string // ACOS
  roas: string // ROAS
  adOrders: number // 广告订单
  cvr: string // CVR
  cpa: string // CPA
  aov: string // 广告笔单价
  // 机会标记：转化好值得拓词 / 高花费无转化需否定
  opportunity: "拓词" | "提价" | "观察" | "止损"
}

export const searchTermRows: SearchTermRow[] = [
  {
    term: "wireless noise cancelling headphones",
    matchType: "广泛匹配",
    campaignType: "SP",
    campaignCount: 4,
    campaigns: ["SP-自动-01", "SP-手动-精准", "SP-手动-广泛", "SB-品牌-头部"],
    impressions: 28640,
    clicks: 612,
    ctr: "2.14%",
    cpc: "$1.86",
    spend: "$1,138.32",
    adSales: "$5,420.00",
    acos: "21.0%",
    roas: "4.76",
    adOrders: 58,
    cvr: "9.48%",
    cpa: "$19.63",
    aov: "$93.45",
    opportunity: "拓词",
  },
  {
    term: "noise cancelling earbuds bluetooth",
    matchType: "词组匹配",
    campaignType: "SP",
    campaignCount: 3,
    campaigns: ["SP-自动-01", "SP-手动-广泛", "SD-再营销"],
    impressions: 19450,
    clicks: 438,
    ctr: "2.25%",
    cpc: "$1.72",
    spend: "$753.36",
    adSales: "$3,180.00",
    acos: "23.7%",
    roas: "4.22",
    adOrders: 34,
    cvr: "7.76%",
    cpa: "$22.16",
    aov: "$93.53",
    opportunity: "拓词",
  },
  {
    term: "over ear headphones for running",
    matchType: "广泛匹配",
    campaignType: "SP",
    campaignCount: 2,
    campaigns: ["SP-自动-01", "SP-手动-广泛"],
    impressions: 15280,
    clicks: 296,
    ctr: "1.94%",
    cpc: "$2.05",
    spend: "$606.80",
    adSales: "$1,120.00",
    acos: "54.2%",
    roas: "1.85",
    adOrders: 12,
    cvr: "4.05%",
    cpa: "$50.57",
    aov: "$93.33",
    opportunity: "观察",
  },
  {
    term: "best headphones under 100",
    matchType: "广泛匹配",
    campaignType: "SB",
    campaignCount: 5,
    campaigns: ["SB-品牌-头部", "SP-自动-01", "SP-手动-广泛", "SP-手动-词组", "SD-再营销"],
    impressions: 41200,
    clicks: 724,
    ctr: "1.76%",
    cpc: "$1.58",
    spend: "$1,143.92",
    adSales: "$3,960.00",
    acos: "28.9%",
    roas: "3.46",
    adOrders: 41,
    cvr: "5.66%",
    cpa: "$27.90",
    aov: "$96.59",
    opportunity: "提价",
  },
  {
    term: "cheap bluetooth headset",
    matchType: "广泛匹配",
    campaignType: "SP",
    campaignCount: 2,
    campaigns: ["SP-自动-01", "SP-手动-广泛"],
    impressions: 22380,
    clicks: 510,
    ctr: "2.28%",
    cpc: "$1.41",
    spend: "$719.10",
    adSales: "$210.00",
    acos: "342.4%",
    roas: "0.29",
    adOrders: 2,
    cvr: "0.39%",
    cpa: "$359.55",
    aov: "$105.00",
    opportunity: "止损",
  },
  {
    term: "headphone stand wood",
    matchType: "广泛匹配",
    campaignType: "SP",
    campaignCount: 1,
    campaigns: ["SP-自动-01"],
    impressions: 8640,
    clicks: 182,
    ctr: "2.11%",
    cpc: "$1.33",
    spend: "$242.06",
    adSales: "$0.00",
    acos: "-",
    roas: "0.00",
    adOrders: 0,
    cvr: "0.00%",
    cpa: "-",
    aov: "-",
    opportunity: "止损",
  },
  {
    term: "kids headphones volume limited",
    matchType: "精准匹配",
    campaignType: "SP",
    campaignCount: 3,
    campaigns: ["SP-手动-精准", "SP-自动-01", "SB-品牌-头部"],
    impressions: 12960,
    clicks: 268,
    ctr: "2.07%",
    cpc: "$1.79",
    spend: "$479.72",
    adSales: "$2,260.00",
    acos: "21.2%",
    roas: "4.71",
    adOrders: 24,
    cvr: "8.96%",
    cpa: "$19.99",
    aov: "$94.17",
    opportunity: "拓词",
  },
  {
    term: "studio monitor headphones",
    matchType: "词组匹配",
    campaignType: "SP",
    campaignCount: 2,
    campaigns: ["SP-手动-词组", "SP-自动-01"],
    impressions: 10120,
    clicks: 214,
    ctr: "2.11%",
    cpc: "$1.95",
    spend: "$417.30",
    adSales: "$1,480.00",
    acos: "28.2%",
    roas: "3.55",
    adOrders: 16,
    cvr: "7.48%",
    cpa: "$26.08",
    aov: "$92.50",
    opportunity: "提价",
  },
]

export const searchTermSummary = {
  termCount: 549,
  totalClicks: 3254,
  totalSpend: "$5,499.58",
  totalAdSales: "$17,630.00",
  avgAcos: "31.2%",
  dataDate: "2026-06-11",
}

export const opportunityMeta: Record<
  SearchTermRow["opportunity"],
  { label: string; tone: "up" | "amber" | "down" | "brand" }
> = {
  拓词: { label: "建议拓词", tone: "up" },
  提价: { label: "建议提价", tone: "brand" },
  观察: { label: "持续观察", tone: "amber" },
  止损: { label: "建议否定", tone: "down" },
}
