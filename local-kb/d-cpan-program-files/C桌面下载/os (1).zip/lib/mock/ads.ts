// 每日广告诊断单
export type DiagnosisRow = {
  metric: string
  yesterday: string
  vs7: number
  avg7: string
  vs30: number
  avg30: string
  /** 趋势是否健康 */
  healthy: boolean
  /** 部分指标越低越好（花费/ACOS/TACOS） */
  lowerIsBetter?: boolean
}

export const diagnosisRows: DiagnosisRow[] = [
  { metric: "广告花费", yesterday: "$2,392", vs7: 10.4, avg7: "$2,168", vs30: -21.6, avg30: "$3,052", healthy: true, lowerIsBetter: true },
  { metric: "TACOS", yesterday: "12%", vs7: -2.4, avg7: "12.3%", vs30: -5.5, avg30: "12.7%", healthy: true, lowerIsBetter: true },
  { metric: "ACOS", yesterday: "31.6%", vs7: 2.6, avg7: "30.8%", vs30: 7.1, avg30: "29.5%", healthy: true, lowerIsBetter: true },
  { metric: "广告出单", yesterday: "46单", vs7: 0.9, avg7: "46单", vs30: -80.5, avg30: "236单", healthy: true },
  { metric: "预算打满", yesterday: "0次", vs7: -100, avg7: "14.7次", vs30: -100, avg30: "28.5次", healthy: true, lowerIsBetter: true },
]

// 店铺广告明细
export type ShopAdRow = {
  shop: string
  spend: string
  sales: string
  acos: string
  tacos: string
  orders: number
  adRatio: string
  impressions: string
  clicks: string
  ctr: string
  cpc: string
  cvr: string
  budgetHit: number
  status: "正常" | "预警" | "异常"
}

export const shopAdRows: ShopAdRow[] = [
  {
    shop: "星辰**(北美)-US",
    spend: "$13,778",
    sales: "$47,568",
    acos: "29.0%",
    tacos: "11.8%",
    orders: 292,
    adRatio: "40.8%",
    impressions: "32.1万",
    clicks: "6,469",
    ctr: "2.01%",
    cpc: "$2.13",
    cvr: "4.5%",
    budgetHit: 0,
    status: "正常",
  },
  {
    shop: "晨光**(欧洲)-DE",
    spend: "$6,204",
    sales: "$21,330",
    acos: "29.1%",
    tacos: "13.2%",
    orders: 138,
    adRatio: "38.5%",
    impressions: "18.6万",
    clicks: "3,021",
    ctr: "1.62%",
    cpc: "$2.05",
    cvr: "4.6%",
    budgetHit: 2,
    status: "预警",
  },
  {
    shop: "远帆**(日本)-JP",
    spend: "$3,910",
    sales: "$9,860",
    acos: "39.7%",
    tacos: "16.4%",
    orders: 71,
    adRatio: "44.2%",
    impressions: "9.8万",
    clicks: "1,544",
    ctr: "1.58%",
    cpc: "$2.53",
    cvr: "4.6%",
    budgetHit: 5,
    status: "异常",
  },
]

export const adTabs = [
  "看板",
  "广告诊断",
  "处理清单",
  "健康诊断",
  "关键词机会",
  "ASIN 视图",
  "自动规则",
  "规则设置",
  "待投放（增益）",
  "否定（止损）",
  "词根聚合",
  "异常问题",
] as const

export const adSummary = {
  shopCount: 1,
  totalSpend: "$13,777.95",
  dataDate: "2026-06-11",
  diagnosisDate: "2026-06-10",
}

export interface SkuAdRow {
  sku: string
  asin: string
  image: string
  shop: string
  spend: string
  sales: string
  acos: string
  tacos: string
  orders: number
  adRatio: string
  impressions: string
  clicks: string
  ctr: string
  cpc: string
  cvr: string
  budgetHit: number
  status: "正常" | "预警" | "异常"
}

export const skuAdRows: SkuAdRow[] = [
  {
    sku: "SKU-KJ-01",
    asin: "B0GDC7BWK",
    image: "无线降噪耳机",
    shop: "星辰**(北美)-US",
    spend: "$5,142",
    sales: "$19,860",
    acos: "25.9%",
    tacos: "10.2%",
    orders: 121,
    adRatio: "38.4%",
    impressions: "13.6万",
    clicks: "2,714",
    ctr: "2.00%",
    cpc: "$1.89",
    cvr: "4.5%",
    budgetHit: 0,
    status: "正常",
  },
  {
    sku: "SKU-HW-07",
    asin: "B0RBZU7QX",
    image: "运动蓝牙耳机",
    shop: "星辰**(北美)-US",
    spend: "$3,908",
    sales: "$14,120",
    acos: "27.7%",
    tacos: "12.1%",
    orders: 88,
    adRatio: "41.0%",
    impressions: "9.8万",
    clicks: "1,902",
    ctr: "1.94%",
    cpc: "$2.05",
    cvr: "4.6%",
    budgetHit: 1,
    status: "预警",
  },
  {
    sku: "SKU-XJ-12",
    asin: "B0TKM3PLZ",
    image: "头戴式耳机 Pro",
    shop: "晨光**(欧洲)-DE",
    spend: "$2,861",
    sales: "$8,540",
    acos: "33.5%",
    tacos: "14.8%",
    orders: 54,
    adRatio: "43.6%",
    impressions: "6.2万",
    clicks: "1,128",
    ctr: "1.82%",
    cpc: "$2.54",
    cvr: "4.8%",
    budgetHit: 3,
    status: "预警",
  },
  {
    sku: "SKU-EJ-09",
    asin: "B0VPQ2NWA",
    image: "儿童护耳耳机",
    shop: "远帆**(日本)-JP",
    spend: "$1,866",
    sales: "$4,710",
    acos: "39.6%",
    tacos: "16.9%",
    orders: 29,
    adRatio: "45.1%",
    impressions: "3.7万",
    clicks: "725",
    ctr: "1.96%",
    cpc: "$2.57",
    cvr: "4.0%",
    budgetHit: 5,
    status: "异常",
  },
]

export const skuAdSummary = {
  skuCount: skuAdRows.length,
  totalSpend: "$13,777.95",
  dataDate: "2026-06-11",
}
