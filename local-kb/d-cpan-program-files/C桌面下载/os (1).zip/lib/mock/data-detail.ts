// 数据明细 - 每日广告诊断单（细化板块一）

// ① 时间筛选维度
export const dateRangeOptions = [
  "今天",
  "昨天",
  "最近7天",
  "最近7天（排除最近2天）",
  "本周",
  "上周",
  "最近14天",
  "最近30天",
  "本月",
  "上个月",
  "最近60天",
  "最近12个月",
  "年初至今",
  "生命周期",
  "选定时间段",
] as const

export type DateRangeOption = (typeof dateRangeOptions)[number]

// 对比方式
export const compareModes = ["同比", "环比"] as const
export type CompareMode = (typeof compareModes)[number]

// 聚合维度
export const granularityOptions = ["按日", "按周", "按月"] as const
export type Granularity = (typeof granularityOptions)[number]

// ② 诊断指标行
export interface DiagnosisDetailRow {
  metric: string
  /** 指标分组：用于视觉分区 */
  group: "花费销售" | "订单结构" | "流量效率" | "运营健康"
  current: string
  vs7: number
  avg7: string
  vs30: number
  avg30: string
  healthy: boolean
  /** 越低越好（花费/ACOS/TACOS/CPC/CPA/打满） */
  lowerIsBetter?: boolean
  /** 占比/状态类行，不显示涨跌箭头 */
  noDelta?: boolean
}

export const diagnosisDetailRows: DiagnosisDetailRow[] = [
  // —— 花费 & 销售 ——
  { metric: "广告花费", group: "花费销售", current: "$2,392", vs7: 10.4, avg7: "$2,168", vs30: -21.6, avg30: "$3,052", healthy: true, lowerIsBetter: true },
  { metric: "广告销售额", group: "花费销售", current: "$7,570", vs7: 8.2, avg7: "$6,994", vs30: -15.3, avg30: "$8,938", healthy: true },
  { metric: "总销售额", group: "花费销售", current: "$19,930", vs7: 5.1, avg7: "$18,960", vs30: -8.4, avg30: "$21,758", healthy: true },
  { metric: "ACOS", group: "花费销售", current: "31.6%", vs7: 2.6, avg7: "30.8%", vs30: 7.1, avg30: "29.5%", healthy: false, lowerIsBetter: true },
  { metric: "TACOS（广告花费占比）", group: "花费销售", current: "12.0%", vs7: -2.4, avg7: "12.3%", vs30: -5.5, avg30: "12.7%", healthy: true, lowerIsBetter: true },

  // —— 订单结构 ——
  { metric: "总订单", group: "订单结构", current: "173 单", vs7: 4.2, avg7: "166 单", vs30: -6.1, avg30: "184 单", healthy: true },
  { metric: "自然订单", group: "订单结构", current: "127 单", vs7: 6.1, avg7: "120 单", vs30: 3.2, avg30: "123 单", healthy: true },
  { metric: "广告订单", group: "订单结构", current: "46 单", vs7: -2.1, avg7: "47 单", vs30: -22.0, avg30: "59 单", healthy: true },
  { metric: "广告出单", group: "订单结构", current: "46 单", vs7: 0.9, avg7: "46 单", vs30: -80.5, avg30: "236 单", healthy: true },
  { metric: "广告占比", group: "订单结构", current: "26.6%", vs7: -3.0, avg7: "27.4%", vs30: -8.0, avg30: "28.9%", healthy: true, lowerIsBetter: true },
  { metric: "自然 VS 广告订单占比", group: "订单结构", current: "73.4% : 26.6%", vs7: 0, avg7: "72.6% : 27.4%", vs30: 0, avg30: "71.1% : 28.9%", healthy: true, noDelta: true },
  { metric: "自然 VS 广告流量占比", group: "订单结构", current: "68.2% : 31.8%", vs7: 0, avg7: "67.0% : 33.0%", vs30: 0, avg30: "65.4% : 34.6%", healthy: true, noDelta: true },

  // —— 流量效率 ——
  { metric: "CTR", group: "流量效率", current: "2.01%", vs7: 1.5, avg7: "1.98%", vs30: 4.7, avg30: "1.92%", healthy: true },
  { metric: "CPC", group: "流量效率", current: "$2.13", vs7: 3.4, avg7: "$2.06", vs30: -1.4, avg30: "$2.16", healthy: true, lowerIsBetter: true },
  { metric: "CPA", group: "流量效率", current: "$52.0", vs7: 5.2, avg7: "$49.4", vs30: 12.0, avg30: "$46.4", healthy: false, lowerIsBetter: true },
  { metric: "CVR", group: "流量效率", current: "4.5%", vs7: -1.2, avg7: "4.56%", vs30: 2.3, avg30: "4.40%", healthy: true },

  // —— 运营健康 ——
  { metric: "打满次数", group: "运营健康", current: "0 次", vs7: -100, avg7: "14.7 次", vs30: -100, avg30: "28.5 次", healthy: true, lowerIsBetter: true },
]

// 板块顶部上下文
export const detailContext = {
  shop: "星辰**(北美)-US",
  date: "2026-06-10",
  health: "正常" as "正常" | "预警" | "异常",
}

export const metricGroups = ["花费销售", "订单结构", "流量效率", "运营健康"] as const

/* ---------------- 细化板块二：店铺详细分析 ---------------- */

// 时间快捷选项
export const quickRanges = ["近3天", "近7天", "近30天"] as const
export type QuickRange = (typeof quickRanges)[number]

export interface StoreDetailRow {
  shop: string
  spend: string // 广告花费
  adSales: string // 广告销售额
  totalSales: string // 总销售额
  acos: string // ACOS
  tacos: string // TACOS（广告花费占比）
  totalOrders: number // 总订单
  adOrders: number // 广告出单
  adRatio: string // 广告占比
  orderSplit: string // 自然-广告订单占比
  trafficSplit: string // 自然-广告流量占比
  ctr: string // CTR
  cpc: string // CPC
  cvr: string // CVR
  budgetHit: number // 打满次数
  health: number // 健康度（0-100）
  margin: string // 毛利率
  refundRate: string // 退款率
  status: "正常" | "预警" | "异常" // 健康状态
}

export const storeDetailRows: StoreDetailRow[] = [
  {
    shop: "星辰**(北美)-US",
    spend: "$13,778",
    adSales: "$47,568",
    totalSales: "$116,800",
    acos: "29.0%",
    tacos: "11.8%",
    totalOrders: 716,
    adOrders: 292,
    adRatio: "40.8%",
    orderSplit: "59.2% : 40.8%",
    trafficSplit: "63.5% : 36.5%",
    ctr: "2.01%",
    cpc: "$2.13",
    cvr: "4.5%",
    budgetHit: 0,
    health: 92,
    margin: "24.6%",
    refundRate: "2.1%",
    status: "正常",
  },
  {
    shop: "晨光**(欧洲)-DE",
    spend: "$6,204",
    adSales: "$21,330",
    totalSales: "$47,000",
    acos: "29.1%",
    tacos: "13.2%",
    totalOrders: 358,
    adOrders: 138,
    adRatio: "38.5%",
    orderSplit: "61.5% : 38.5%",
    trafficSplit: "60.2% : 39.8%",
    ctr: "1.62%",
    cpc: "$2.05",
    cvr: "4.6%",
    budgetHit: 2,
    health: 74,
    margin: "21.3%",
    refundRate: "3.4%",
    status: "预警",
  },
  {
    shop: "远帆**(日本)-JP",
    spend: "$3,910",
    adSales: "$9,860",
    totalSales: "$22,300",
    acos: "39.7%",
    tacos: "16.4%",
    totalOrders: 184,
    adOrders: 71,
    adRatio: "44.2%",
    orderSplit: "55.8% : 44.2%",
    trafficSplit: "53.1% : 46.9%",
    ctr: "1.58%",
    cpc: "$2.53",
    cvr: "4.6%",
    budgetHit: 5,
    health: 48,
    margin: "16.8%",
    refundRate: "5.9%",
    status: "异常",
  },
]

export const storeDetailSummary = {
  shopCount: 3,
  totalSpend: "$23,892.00",
  dataDate: "2026-06-11",
}

/* ---------------- 细化板块三：ASIN 产品详细分析 ---------------- */

export interface AsinDetailRow {
  asin: string
  title: string
  sku: string
  shop: string
  spend: string // 广告花费
  adSales: string // 广告销售额
  totalSales: string // 总销售额
  acos: string // ACOS
  tacos: string // TACOS（广告花费占比）
  totalOrders: number // 总订单
  naturalOrders: number // 自然订单
  adOrders: number // 广告订单
  adSpend: string // 广告花费（美金）
  adRatio: string // 广告占比
  orderSplit: string // 自然VS广告订单占比
  trafficSplit: string // 自然VS广告流量占比
  ctr: string // CTR
  cpc: string // CPC
  cpa: string // CPA
  cvr: string // CVR
  budgetHit: number // 打满次数
  health: number // 健康度（0-100）
  refundRate: string // 退货率
  margin: string // 毛利率
  status: "正常" | "预警" | "异常" // 健康状态
}

export const asinDetailRows: AsinDetailRow[] = [
  {
    asin: "B0GDC7BWK",
    title: "无线降噪耳机",
    sku: "SKU-KJ-01",
    shop: "星辰**(北美)-US",
    spend: "$5,142",
    adSales: "$19,860",
    totalSales: "$51,700",
    acos: "25.9%",
    tacos: "10.2%",
    totalOrders: 315,
    naturalOrders: 194,
    adOrders: 121,
    adSpend: "$5,142",
    adRatio: "38.4%",
    orderSplit: "61.6% : 38.4%",
    trafficSplit: "64.2% : 35.8%",
    ctr: "2.00%",
    cpc: "$1.89",
    cpa: "$42.5",
    cvr: "4.5%",
    budgetHit: 0,
    health: 91,
    refundRate: "1.9%",
    margin: "25.4%",
    status: "正常",
  },
  {
    asin: "B0RBZU7QX",
    title: "运动蓝牙耳机",
    sku: "SKU-HW-07",
    shop: "星辰**(北美)-US",
    spend: "$3,908",
    adSales: "$14,120",
    totalSales: "$34,440",
    acos: "27.7%",
    tacos: "12.1%",
    totalOrders: 215,
    naturalOrders: 127,
    adOrders: 88,
    adSpend: "$3,908",
    adRatio: "41.0%",
    orderSplit: "59.0% : 41.0%",
    trafficSplit: "58.5% : 41.5%",
    ctr: "1.94%",
    cpc: "$2.05",
    cpa: "$44.4",
    cvr: "4.6%",
    budgetHit: 1,
    health: 73,
    refundRate: "3.2%",
    margin: "21.8%",
    status: "预警",
  },
  {
    asin: "B0TKM3PLZ",
    title: "头戴式耳机 Pro",
    sku: "SKU-XJ-12",
    shop: "晨光**(欧洲)-DE",
    spend: "$2,861",
    adSales: "$8,540",
    totalSales: "$19,600",
    acos: "33.5%",
    tacos: "14.8%",
    totalOrders: 124,
    naturalOrders: 70,
    adOrders: 54,
    adSpend: "$2,861",
    adRatio: "43.6%",
    orderSplit: "56.4% : 43.6%",
    trafficSplit: "54.9% : 45.1%",
    ctr: "1.82%",
    cpc: "$2.54",
    cpa: "$53.0",
    cvr: "4.8%",
    budgetHit: 3,
    health: 61,
    refundRate: "4.6%",
    margin: "18.5%",
    status: "预警",
  },
  {
    asin: "B0VPQ2NWA",
    title: "儿童护耳耳机",
    sku: "SKU-EJ-09",
    shop: "远帆**(日本)-JP",
    spend: "$1,866",
    adSales: "$4,710",
    totalSales: "$10,440",
    acos: "39.6%",
    tacos: "16.9%",
    totalOrders: 64,
    naturalOrders: 35,
    adOrders: 29,
    adSpend: "$1,866",
    adRatio: "45.1%",
    orderSplit: "54.9% : 45.1%",
    trafficSplit: "51.3% : 48.7%",
    ctr: "1.96%",
    cpc: "$2.57",
    cpa: "$64.3",
    cvr: "4.0%",
    budgetHit: 5,
    health: 45,
    refundRate: "6.4%",
    margin: "15.2%",
    status: "异常",
  },
]

export const asinDetailSummary = {
  asinCount: asinDetailRows.length,
  totalSpend: "$13,777.95",
  dataDate: "2026-06-11",
}
