export type Kpi = {
  label: string
  today: string
  yesterday: string
  delta: number
  lowerIsBetter?: boolean
  icon: "bag" | "dollar" | "order" | "ad"
}

export const kpis: Kpi[] = [
  { label: "销量", today: "202", yesterday: "113", delta: 78.76, icon: "bag" },
  { label: "销售额 ($)", today: "13,757", yesterday: "7,806", delta: 76.23, icon: "dollar" },
  { label: "订单数", today: "189", yesterday: "104", delta: 81.73, icon: "order" },
  { label: "广告花费 ($)", today: "2,392", yesterday: "2,168", delta: 10.33, lowerIsBetter: true, icon: "ad" },
]

// 业绩走势：今日 vs 昨日，按小时
export const trendData = [
  { time: "00:00", today: 4, yesterday: 2 },
  { time: "02:00", today: 12, yesterday: 8 },
  { time: "04:00", today: 28, yesterday: 18 },
  { time: "06:00", today: 46, yesterday: 30 },
  { time: "08:00", today: 78, yesterday: 44 },
  { time: "10:00", today: 102, yesterday: 58 },
  { time: "12:00", today: 134, yesterday: 71 },
  { time: "14:00", today: 158, yesterday: 86 },
  { time: "16:00", today: 176, yesterday: 95 },
  { time: "18:00", today: 190, yesterday: 104 },
  { time: "20:00", today: 198, yesterday: 110 },
  { time: "22:00", today: 202, yesterday: 113 },
]

export const trendCompare = [
  { label: "今日", value: "202", delta: null },
  { label: "上周同天", value: "31", delta: 551.61 },
  { label: "去年同天", value: "115", delta: 75.65 },
]

export type Todo = {
  title: string
  count: number
  type: "warn" | "info" | "danger"
}

export const todos: Todo[] = [
  { title: "待处理广告诊断", count: 8, type: "warn" },
  { title: "库存预警 SKU", count: 5, type: "danger" },
  { title: "待回复客评", count: 12, type: "info" },
  { title: "待审核采购单", count: 3, type: "info" },
]

export type AiInsight = {
  title: string
  desc: string
  tag: string
}

export const aiInsights: AiInsight[] = [
  {
    tag: "广告优化",
    title: "建议下调「无线充电器」自动广告竞价 12%",
    desc: "近 7 天该广告 ACOS 升至 39.7%，高于店铺均值 10 个百分点，预计可节省花费 $420/周。",
  },
  {
    tag: "库存补货",
    title: "「便携榨汁杯」预计 14 天后断货",
    desc: "结合近 30 天动销与在途库存，建议立即补货 600 件以避免 Listing 降权。",
  },
  {
    tag: "选品机会",
    title: "发现 1 个高潜力蓝海类目",
    desc: "「宠物智能饮水机」搜索量环比 +38%，竞品集中度低，建议进入测款。",
  },
]
