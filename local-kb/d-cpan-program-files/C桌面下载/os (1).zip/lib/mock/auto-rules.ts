export type RuleStatus = "启用" | "暂停"
export type RuleResult = "成功" | "未运行" | "失败"

export interface AutoRule {
  id: string
  campaign: string
  tag: string
  status: RuleStatus
  type: string
  target: string
  frequency: string
  lastResult: RuleResult
  lastNext: string
  dateRange: string
  owner: string
  createdAt: string
}

export const autoRules: AutoRule[] = [
  {
    id: "r1",
    campaign: "海王-BOXX-01 · SP targets",
    tag: "dayly",
    status: "启用",
    type: "目标规则",
    target: "关键词",
    frequency: "每日",
    lastResult: "成功",
    lastNext: "昨天 | 明天",
    dateRange: "06/01 ~ 12/31",
    owner: "Ops",
    createdAt: "2026-06-12",
  },
  {
    id: "r2",
    campaign: "销量词低竞价-BOXX-01 · campaigns",
    tag: "weekly",
    status: "暂停",
    type: "广告活动规则",
    target: "广告活动",
    frequency: "每周",
    lastResult: "未运行",
    lastNext: "- | 下周",
    dateRange: "06/01 ~ 12/31",
    owner: "Ops",
    createdAt: "2026-06-12",
  },
  {
    id: "r3",
    campaign: "套装asin定位-BOXX-01 · campaigns",
    tag: "weekly",
    status: "暂停",
    type: "广告活动规则",
    target: "广告活动",
    frequency: "每周",
    lastResult: "未运行",
    lastNext: "- | 下周",
    dateRange: "06/01 ~ 12/31",
    owner: "Ops",
    createdAt: "2026-06-12",
  },
  {
    id: "r4",
    campaign: "第二层级-低竞价-BOXX-01 · SP targets",
    tag: "dayly",
    status: "启用",
    type: "目标规则",
    target: "关键词",
    frequency: "每日",
    lastResult: "成功",
    lastNext: "昨天 | 明天",
    dateRange: "06/01 ~ 12/31",
    owner: "Ops",
    createdAt: "2026-06-12",
  },
  {
    id: "r5",
    campaign: "顶首页-搜索首位-BOXX-01 · placement",
    tag: "dayly",
    status: "启用",
    type: "广告位规则",
    target: "广告活动",
    frequency: "每日",
    lastResult: "失败",
    lastNext: "今天 | 明天",
    dateRange: "06/01 ~ 12/31",
    owner: "Ops",
    createdAt: "2026-05-28",
  },
  {
    id: "r6",
    campaign: "K07-重开-BOXX-01 · budget",
    tag: "monthly",
    status: "暂停",
    type: "预算规则",
    target: "广告活动",
    frequency: "每月",
    lastResult: "未运行",
    lastNext: "- | 下月",
    dateRange: "06/01 ~ 12/31",
    owner: "Ops",
    createdAt: "2026-05-20",
  },
]

export const ruleFilters = [
  { label: "规则状态", placeholder: "全选" },
  { label: "店铺", placeholder: "全选" },
  { label: "频率 (按照日/周/月维度)", placeholder: "全选" },
  { label: "应用级别", placeholder: "全选" },
  { label: "广告活动", placeholder: "全选" },
] as const
