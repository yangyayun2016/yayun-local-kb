// 待投放（增益）—— 建议加入投放的高效搜索词
export interface GainItem {
  id: string
  keyword: string
  asin: string
  matchType: "精准" | "短语" | "广泛"
  suggestedBid: number
  clicks: number
  orders: number
  acos: number
  cvr: number
  source?: "规则设置"
}

export const gainItems: GainItem[] = [
  { id: "g1", keyword: "noise cancelling earbuds", asin: "B0GK****CG", matchType: "精准", suggestedBid: 0.92, clicks: 9, orders: 3, acos: 22.1, cvr: 33.3 },
  { id: "g2", keyword: "sport earbuds waterproof", asin: "B0F6****44", matchType: "精准", suggestedBid: 0.85, clicks: 7, orders: 2, acos: 18.5, cvr: 28.6 },
  { id: "g3", keyword: "tws earbuds bluetooth 5.3", asin: "B0DZ****KH", matchType: "短语", suggestedBid: 0.78, clicks: 12, orders: 4, acos: 16.9, cvr: 33.3 },
  { id: "g4", keyword: "earbuds with mic", asin: "B0GV****71", matchType: "广泛", suggestedBid: 0.66, clicks: 6, orders: 2, acos: 24.0, cvr: 33.3 },
  { id: "g5", keyword: "wireless earbuds for running", asin: "B0GK****CG", matchType: "精准", suggestedBid: 0.88, clicks: 8, orders: 2, acos: 21.3, cvr: 25.0 },
]

// 否定（止损）—— 建议否定的无转化高消耗词
export interface StopItem {
  id: string
  keyword: string
  asin: string
  negType: "精准否定" | "短语否定"
  clicks: number
  spend: number
  days: number
  source?: "规则设置"
}

export const stopItems: StopItem[] = [
  { id: "s1", keyword: "wireless earbuds case", asin: "B0GK****CG", negType: "精准否定", clicks: 28, spend: 41.2, days: 7 },
  { id: "s2", keyword: "cheap bluetooth headset", asin: "B0GR****LG", negType: "短语否定", clicks: 19, spend: 26.1, days: 5 },
  { id: "s3", keyword: "kids headphone pink", asin: "B0GV****71", negType: "精准否定", clicks: 16, spend: 31.5, days: 6 },
  { id: "s4", keyword: "over ear headphone", asin: "B0DP****NQ", negType: "短语否定", clicks: 22, spend: 38.0, days: 8 },
  { id: "s5", keyword: "earbuds replacement tips", asin: "B0GJ****DH", negType: "精准否定", clicks: 14, spend: 22.4, days: 5 },
]

// 词根聚合
export interface RootItem {
  root: string
  keywordCount: number
  clicks: number
  spend: number
  orders: number
  sales: number
  acos: number
  trend: "up" | "down" | "flat"
}

export const rootItems: RootItem[] = [
  { root: "earbuds", keywordCount: 42, clicks: 1280, spend: 1640.5, orders: 96, sales: 6210.0, acos: 26.4, trend: "up" },
  { root: "wireless", keywordCount: 31, clicks: 980, spend: 1320.0, orders: 64, sales: 4180.0, acos: 31.6, trend: "flat" },
  { root: "bluetooth", keywordCount: 28, clicks: 760, spend: 1010.2, orders: 41, sales: 2660.0, acos: 38.0, trend: "down" },
  { root: "noise cancelling", keywordCount: 18, clicks: 540, spend: 612.4, orders: 38, sales: 2470.0, acos: 24.8, trend: "up" },
  { root: "sport", keywordCount: 15, clicks: 410, spend: 480.0, orders: 28, sales: 1820.0, acos: 26.4, trend: "up" },
  { root: "case", keywordCount: 12, clicks: 320, spend: 460.0, orders: 6, sales: 390.0, acos: 117.9, trend: "down" },
]

// 异常问题
export type AnomalySeverity = "高" | "中" | "低"
export interface AnomalyItem {
  id: string
  title: string
  asin: string
  severity: AnomalySeverity
  metric: string
  detail: string
  detectedAt: string
  status: "未处理" | "已处理"
}

export const anomalyItems: AnomalyItem[] = [
  { id: "a1", title: "ACOS 单日飙升超 50%", asin: "B0GK****CG", severity: "高", metric: "ACOS 33.0% → 52.2%", detail: "CVR 下滑叠加花费未压缩，导致 ACOS 飙升，建议立即排查高花费低转化词。", detectedAt: "2026-06-28 09:12", status: "未处理" },
  { id: "a2", title: "广告花费异常归零", asin: "B0GR****LG", severity: "高", metric: "日花费 $0", detail: "预算耗尽或竞价过低导致广告停止曝光，建议检查预算与出价。", detectedAt: "2026-06-28 07:40", status: "未处理" },
  { id: "a3", title: "点击量骤降", asin: "B0F6****44", severity: "中", metric: "点击 -64%", detail: "排名下滑或竞品抢位，建议检查关键词排名与广告位占有率。", detectedAt: "2026-06-27 22:05", status: "未处理" },
  { id: "a4", title: "CPC 持续走高", asin: "B0DP****NQ", severity: "中", metric: "CPC $0.62 → $0.94", detail: "竞价环境恶化，建议评估关键词竞争度与出价策略。", detectedAt: "2026-06-27 18:30", status: "已处理" },
  { id: "a5", title: "转化率低于类目均值", asin: "B0GJ****DH", severity: "低", metric: "CVR 2.2% (类目 5%)", detail: "Listing 转化能力偏弱，建议优化主图与五点描述。", detectedAt: "2026-06-27 14:10", status: "未处理" },
]
