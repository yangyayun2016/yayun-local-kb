export type DiagnosisType = "问题" | "机会"
export type DiagnosisSeverity = "极高" | "高" | "中" | "低"

/** 状态标签语气：红色警示 / 橙色提醒 / 绿色机会 */
export type TagTone = "danger" | "warning" | "success" | "muted"

export interface DiagnosisCard {
  id: string
  type: DiagnosisType
  shop: string
  asin: string
  owner: string
  /** 诊断结论标签，如「ACOS 飙升」「花费无产出」 */
  statusTag: string
  statusTone: TagTone
  severity: DiagnosisSeverity
  /** 指标说明行 */
  metric: string
  /** 指标行内的红色高亮片段（可选），如「损耗: $70」 */
  metricHighlight?: string
  /** AI 建议摘要（点击展开显示） */
  aiAdvice: string
}

export const severityTone: Record<DiagnosisSeverity, TagTone> = {
  极高: "danger",
  高: "warning",
  中: "warning",
  低: "success",
}

export const toneClass: Record<TagTone, string> = {
  danger: "text-down",
  warning: "text-[#fa8c16]",
  success: "text-up",
  muted: "text-muted-foreground",
}

export const toneBadge: Record<TagTone, string> = {
  danger: "bg-down/10 text-down",
  warning: "bg-[#fa8c16]/10 text-[#fa8c16]",
  success: "bg-up/10 text-up",
  muted: "bg-muted text-muted-foreground",
}

export const diagnosisCards: DiagnosisCard[] = [
  {
    id: "d1",
    type: "问题",
    shop: "星辰**(北美)-US",
    asin: "B0GK****CG",
    owner: "周**",
    statusTag: "ACOS 飙升",
    statusTone: "danger",
    severity: "极高",
    metric: "ACOS 33.0% → 52.2%（↑58%）",
    aiAdvice:
      "近期 CVR 从 5% 跌至 2.5%，广告花费未同步收紧，导致 ACOS 飙升至 52.2%，远超盈亏平衡线。建议复核高花费低转化词，将日预算降至当前 50% 或暂停高 ACOS 活动。",
  },
  {
    id: "d2",
    type: "问题",
    shop: "星辰**(北美)-US",
    asin: "B0GR****LG",
    owner: "郑**",
    statusTag: "花费无产出",
    statusTone: "danger",
    severity: "极高",
    metric: "连续 5 天有花费，0 订单，累计花费",
    metricHighlight: "$26.1",
    aiAdvice:
      "该 ASIN 连续 5 天有广告花费但 0 出单，累计烧钱 $26.1。建议立即暂停无转化关键词，检查 Listing 转化要素（主图、价格、评分）是否存在问题。",
  },
  {
    id: "d3",
    type: "问题",
    shop: "星辰**(北美)-US",
    asin: "B0GK****CG",
    owner: "周**",
    statusTag: "广告亏损被自然流量掩盖",
    statusTone: "warning",
    severity: "中",
    metric: "ACOS 59.2%，盈亏平衡 21.5%，广告亏损约 $70 ·",
    metricHighlight: "损耗: $70",
    aiAdvice:
      "广告加权 ACOS 59.2% 远超盈亏平衡 21.5%，造成广告亏损约 $70。自然流量订单较多掩盖了广告亏损事实。建议提供近 14 天搜索词报告，精准否定低效词。",
  },
  {
    id: "d4",
    type: "机会",
    shop: "星辰**(北美)-US",
    asin: "B0FG****44",
    owner: "周**",
    statusTag: "ACOS 攀升",
    statusTone: "success",
    severity: "低",
    metric: "ACOS 18.7% → 29.8%（↑60%）",
    aiAdvice:
      "ACOS 小幅攀升但仍在可控区间，整体处于健康水平。建议持续观察出价与转化趋势，必要时小幅微调出价即可。",
  },
  {
    id: "d5",
    type: "机会",
    shop: "星辰**(北美)-US",
    asin: "B0GV****71",
    owner: "刘**",
    statusTag: "ACOS 攀升",
    statusTone: "success",
    severity: "低",
    metric: "ACOS 8.2% → 13.1%（↑59%）",
    aiAdvice: "ACOS 基数低，攀升幅度可接受，转化效率良好。可适当加大优质关键词预算抢占更多曝光。",
  },
  {
    id: "d6",
    type: "问题",
    shop: "星辰**(北美)-US",
    asin: "B0DP****NQ",
    owner: "周**",
    statusTag: "ACOS 攀升",
    statusTone: "warning",
    severity: "低",
    metric: "ACOS 13.3% → 22.3%（↑68%）",
    aiAdvice: "ACOS 涨幅较大需关注，建议核对近期是否新增高花费词，及时调整出价控制成本。",
  },
  {
    id: "d7",
    type: "问题",
    shop: "星辰**(北美)-US",
    asin: "B0DZ****KH",
    owner: "刘**",
    statusTag: "ACOS 攀升",
    statusTone: "warning",
    severity: "低",
    metric: "ACOS 11.5% → 19.2%（↑67%）",
    aiAdvice: "ACOS 持续上行，建议复核搜索词报告，对低转化词进行否定或降价处理。",
  },
  {
    id: "d8",
    type: "问题",
    shop: "星辰**(北美)-US",
    asin: "B0GJ****DH",
    owner: "刘**",
    statusTag: "ACOS 攀升",
    statusTone: "warning",
    severity: "低",
    metric: "ACOS 14.1% → 21.8%（↑55%）",
    aiAdvice: "ACOS 稳步攀升，需观察是否进入旺季竞价加剧阶段，建议保持预算并优化出价结构。",
  },
]
