export type AsinKpi = {
  label: string
  value: string
  delta: number
  accent: string
}

/** 店铺 / SKU 选项 */
export const shopOptions = [
  "星辰大海-美国-US",
  "星辰大海-德国-DE",
  "海王优选-美国-US",
  "云图电子-日本-JP",
] as const

export const skuOptions = ["SKU-KJ-01", "SKU-KJ-02", "SKU-HW-07", "SKU-YT-12"] as const

/** 顶部时间范围胶囊 */
export const timeRanges = [
  "昨天",
  "最近7天",
  "最近7天（排除最近2天）",
  "上周",
  "本周",
  "最近14天",
  "最近30天",
  "上个月",
  "本月",
  "今年",
  "最近60天",
  "最近12个月",
] as const

export type TimeRange = (typeof timeRanges)[number]

/** 不同时间范围对累积型指标的缩放（时间越长累计越大） */
const rangeScale: Record<TimeRange, number> = {
  昨天: 0.04,
  最近7天: 0.25,
  "最近7天（排除最近2天）": 0.18,
  上周: 0.24,
  本周: 0.2,
  最近14天: 0.5,
  最近30天: 1,
  上个月: 1,
  本月: 0.7,
  今年: 6,
  最近60天: 2,
  最近12个月: 12,
}

/** 稳定字符串哈希，保证 SSR/CSR 一致 */
function hash(s: string): number {
  let h = 0
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0
  return h
}

/** 店铺 + SKU 决定的店铺质量系数 0.70 ~ 1.39 */
function shopFactor(shop: string, sku: string): number {
  return 0.7 + (hash(shop + "|" + sku) % 70) / 100
}

/** 时间范围决定的相位偏移，使折线形态随时间范围变化 */
function rangeShift(range: TimeRange): number {
  return timeRanges.indexOf(range)
}

/* ---------- 数值格式化（欧洲式逗号小数） ---------- */
function fmtK(n: number): string {
  return (n / 1000).toFixed(1).replace(".", ",") + "K"
}
function fmtInt(n: number): string {
  return Math.round(n).toLocaleString("en-US")
}
function fmtEur(n: number): string {
  return "€" + n.toFixed(1).replace(".", ",")
}
function fmtPct(n: number): string {
  return n.toFixed(2).replace(".", ",") + "%"
}

/** 根据店铺 / SKU / 时间范围生成 5 个 KPI */
export function buildKpis(shop: string, sku: string, range: TimeRange): AsinKpi[] {
  const f = shopFactor(shop, sku)
  const r = rangeScale[range] ?? 1
  const imp = 114300 * f * r
  const clk = 1203 * f * r
  const spend = 179.3 * f * r
  const sales = 934.1 * f * r
  // ACOS 为比率型：店铺质量越高越低，不随时间线性增长
  const acos = 14 + (1.39 - f) * 14
  const d = (base: number) => Math.round(base * (0.5 + f) * 10) / 10
  return [
    { label: "曝光量", value: fmtK(imp), delta: d(143.7), accent: "#faad14" },
    { label: "点击量", value: fmtInt(clk), delta: d(144.6), accent: "#52c41a" },
    { label: "花费", value: fmtEur(spend), delta: d(146.4), accent: "#13c2c2" },
    { label: "销售额", value: fmtEur(sales), delta: d(76.1), accent: "#1677ff" },
    { label: "ACOS", value: fmtPct(acos), delta: d(39.9), accent: "#eb2f96" },
  ]
}

/** 多指标折线图的一行数据 */
export type SeriesPoint = {
  date: string
  a: number
  b: number
  c: number
}

const chartDates = [
  "周六,05/30",
  "周一,06/01",
  "周三,06/03",
  "周五,06/05",
  "周日,06/07",
  "周二,06/09",
  "周四,06/11",
  "周六,06/13",
  "周一,06/15",
  "周三,06/17",
  "周五,06/19",
  "周日,06/21",
  "周二,06/23",
]
// 固定的伪随机相位，保证 SSR/CSR 一致
const phaseA = [0.1, 0.5, 0.3, 0.8, 0.45, 0.95, 0.6, 0.2, 0.7, 0.4, 0.85, 0.55, 0.65]
const phaseB = [0.6, 0.3, 0.7, 0.4, 0.9, 0.5, 0.35, 0.8, 0.25, 0.75, 0.45, 0.6, 0.5]
const phaseC = [0.2, 0.7, 0.55, 0.85, 0.3, 0.6, 0.95, 0.4, 0.65, 0.5, 0.2, 0.8, 0.45]

/** 生成三条折线：base/amp 受店铺系数缩放，相位受时间范围偏移 */
function buildSeries(
  base: [number, number, number],
  amp: [number, number, number],
  f: number,
  shift: number,
): SeriesPoint[] {
  const n = chartDates.length
  return chartDates.map((date, i) => {
    const j = (i + shift) % n
    return {
      date,
      a: Math.round((base[0] * f + amp[0] * f * (phaseA[j] - 0.5) * 2) * 10) / 10,
      b: Math.round((base[1] * f + amp[1] * f * (phaseB[j] - 0.5) * 2) * 10) / 10,
      c: Math.round((base[2] * f + amp[2] * f * (phaseC[j] - 0.5) * 2) * 10) / 10,
    }
  })
}

export type ChartPanel = {
  id: string
  title: string
  subtitle?: string
  note?: string
  series: SeriesPoint[]
  legend: { key: "a" | "b" | "c"; label: string; color: string }[]
  modeTabs: ("SP" | "SB")[]
}

/** 面板元信息（结构固定，series 运行时生成） */
type PanelMeta = Omit<ChartPanel, "series"> & {
  base: [number, number, number]
  amp: [number, number, number]
}

const panelMeta: PanelMeta[] = [
  {
    id: "perf",
    title: "绩效",
    base: [4200, 4400, 4000],
    amp: [1400, 1100, 1500],
    legend: [
      { key: "a", label: "销售额", color: "#722ed1" },
      { key: "b", label: "花费", color: "#fa8c16" },
      { key: "c", label: "ACOS", color: "#13c2c2" },
    ],
    modeTabs: [],
  },
  {
    id: "efficiency",
    title: "效率",
    base: [4300, 3800, 4100],
    amp: [1300, 1500, 1400],
    legend: [
      { key: "a", label: "点击成本(CPC)", color: "#fa8c16" },
      { key: "b", label: "单次点击转化(CPA)", color: "#722ed1" },
      { key: "c", label: "转化率(CVR)", color: "#13c2c2" },
    ],
    modeTabs: [],
  },
  {
    id: "placement",
    title: "广告位绩效",
    note: "搜索顶部(TOS)、搜索结果其余位置(ROS)、商品页面(PP)",
    base: [4200, 4400, 4000],
    amp: [1400, 1100, 1500],
    legend: [
      { key: "a", label: "TOS", color: "#722ed1" },
      { key: "b", label: "ROS", color: "#fa8c16" },
      { key: "c", label: "PP", color: "#13c2c2" },
    ],
    modeTabs: ["SP", "SB"],
  },
  {
    id: "profit",
    title: "绩效",
    subtitle: "(盈利指标)",
    note: "ROAS 是 ACoS 的倒数，TACoS，产品毛利率 GPM",
    base: [4200, 4400, 4000],
    amp: [1400, 1100, 1500],
    legend: [
      { key: "a", label: "ROAS", color: "#722ed1" },
      { key: "b", label: "TACoS", color: "#fa8c16" },
      { key: "c", label: "GPM", color: "#13c2c2" },
    ],
    modeTabs: ["SP", "SB"],
  },
  {
    id: "peak",
    title: "广告出单高峰统计",
    note: "销量(小时级)、转化率(小时级)、广告花费(小时级)",
    base: [4200, 4400, 4000],
    amp: [1400, 1100, 1500],
    legend: [
      { key: "a", label: "Orders", color: "#722ed1" },
      { key: "b", label: "CVR", color: "#fa8c16" },
      { key: "c", label: "Hourly Ad Spend", color: "#13c2c2" },
    ],
    modeTabs: ["SP", "SB"],
  },
  {
    id: "ecpm",
    title: "绩效",
    subtitle: "(模拟亚马逊 eCPM 算法)",
    note: "ASIN 整体点击率 整体转化率 自然流量拟合 eCPM",
    base: [4200, 4400, 4000],
    amp: [1400, 1100, 1500],
    legend: [
      { key: "a", label: "CTR", color: "#722ed1" },
      { key: "b", label: "CVR", color: "#fa8c16" },
      { key: "c", label: "eCPM", color: "#13c2c2" },
    ],
    modeTabs: ["SP", "SB"],
  },
]

/** 根据店铺 / SKU / 时间范围生成 6 个图表面板 */
export function buildChartPanels(shop: string, sku: string, range: TimeRange): ChartPanel[] {
  const f = shopFactor(shop, sku)
  const shift = rangeShift(range)
  return panelMeta.map(({ base, amp, ...rest }) => ({
    ...rest,
    series: buildSeries(base, amp, f, shift),
  }))
}

/** SIF 坑位快照 Tab */
export const sifTabs = ["自然位", "SP-常规", "SP-推荐专栏", "SB/SBV"] as const

/** SIF 小时级排名数据（排名越小越靠前，1 为最优） */
export type RankPoint = { time: string; rank: number }

const baseSifRank: RankPoint[] = [
  { time: "06-27 08:00", rank: 3 },
  { time: "06-27 09:00", rank: 3 },
  { time: "06-27 09:30", rank: 24 },
  { time: "06-27 10:00", rank: 24 },
  { time: "06-27 10:30", rank: 3 },
  { time: "06-27 11:00", rank: 3 },
  { time: "06-27 11:30", rank: 4 },
  { time: "06-27 12:00", rank: 4 },
  { time: "06-27 12:30", rank: 3 },
  { time: "06-27 13:00", rank: 3 },
  { time: "06-27 13:30", rank: 24 },
  { time: "06-27 14:00", rank: 24 },
  { time: "06-27 14:30", rank: 4 },
  { time: "06-27 15:00", rank: 4 },
  { time: "06-27 16:00", rank: 4 },
  { time: "06-27 17:00", rank: 4 },
  { time: "06-27 18:00", rank: 4 },
  { time: "06-27 19:00", rank: 2 },
  { time: "06-27 20:00", rank: 2 },
  { time: "06-27 21:00", rank: 2 },
  { time: "06-27 22:00", rank: 2 },
  { time: "06-27 23:00", rank: 2 },
  { time: "06-28 00:00", rank: 2 },
  { time: "06-28 01:00", rank: 2 },
  { time: "06-28 02:00", rank: 2 },
  { time: "06-28 03:00", rank: 1 },
  { time: "06-28 04:00", rank: 1 },
  { time: "06-28 05:00", rank: 1 },
  { time: "06-28 06:00", rank: 1 },
]

/** 根据 SKU + 广告位 Tab 生成排名走势（围绕基线小幅扰动，限定 1~25） */
export function buildSifRank(sku: string, tab: string): RankPoint[] {
  return baseSifRank.map((p, i) => {
    const delta = (hash(sku + tab + i) % 5) - 2
    return { time: p.time, rank: Math.max(1, Math.min(25, p.rank + delta)) }
  })
}

/** 由 SKU 推导出 SIF 当前展示的 ASIN 标签 */
export function skuToAsin(sku: string): string {
  const h = hash(sku).toString(36).toUpperCase().slice(0, 5)
  return "B0" + h
}

/* ===================== 时间线（多指标 + 更改记录） ===================== */

/** 时间线指标定义：axis 决定挂左轴(数值)还是右轴(更改记录次数) */
export type TimelineMetric = {
  key: string
  label: string
  /** 选中时的颜色 */
  color: string
  /** 数值格式化方式 */
  fmt: "int" | "eur" | "pct" | "ratio"
}

export const timelineMetrics: TimelineMetric[] = [
  { key: "impressions", label: "曝光量", color: "#faad14", fmt: "int" },
  { key: "topIS", label: "搜索结果首页顶部IS", color: "#1677ff", fmt: "pct" },
  { key: "clicks", label: "点击量", color: "#13c2c2", fmt: "int" },
  { key: "ctr", label: "CTR", color: "#722ed1", fmt: "pct" },
  { key: "cvr", label: "CVR", color: "#eb2f96", fmt: "pct" },
  { key: "cpc", label: "CPC", color: "#fa8c16", fmt: "eur" },
  { key: "orders", label: "广告总订单量", color: "#52c41a", fmt: "int" },
  { key: "cpa", label: "CPA", color: "#f5222d", fmt: "eur" },
  { key: "spend", label: "广告花费", color: "#2f54eb", fmt: "eur" },
  { key: "sales", label: "广告总销售额", color: "#13a8a8", fmt: "eur" },
  { key: "acos", label: "ACoS", color: "#c41d7f", fmt: "pct" },
  { key: "roas", label: "ROAS", color: "#531dab", fmt: "ratio" },
  { key: "indirectRatio", label: "间接成交订单比", color: "#fa541c", fmt: "pct" },
  { key: "units", label: "广告总销量", color: "#1890ff", fmt: "int" },
  { key: "vcpm", label: "VCPM", color: "#389e0d", fmt: "eur" },
]

/** 更改记录的颜色（图例与标记统一使用） */
export const CHANGE_COLOR = "#722ed1"

/** 时间线每天一行：包含全部指标值 + 当天更改记录次数 */
export type TimelinePoint = {
  date: string
  impressions: number
  topIS: number
  clicks: number
  ctr: number
  cvr: number
  cpc: number
  orders: number
  cpa: number
  spend: number
  sales: number
  acos: number
  roas: number
  indirectRatio: number
  units: number
  vcpm: number
  change: number | null
}

/** 单条更改明细 */
export type ChangeItem = {
  category: "广告日志" | "运营日志" | "更改记录"
  action: string
  time: string
  detail: string
}

export type ChangeRecord = {
  date: string
  count: number
  items: ChangeItem[]
}

/** 生成 05-30 ~ 06-28 的日期标签 */
function buildTimelineDates(): string[] {
  const dates: string[] = []
  // 05-30、05-31
  dates.push("05-30", "05-31")
  for (let d = 1; d <= 28; d++) {
    dates.push("06-" + String(d).padStart(2, "0"))
  }
  return dates
}

const timelineDates = buildTimelineDates()

/** 各日更改记录次数（与设计稿一致的关键点，其余为 0） */
const changeCounts: Record<string, number> = {
  "05-31": 9,
  "06-04": 14,
  "06-06": 1,
  "06-07": 1,
  "06-09": 3,
  "06-12": 16,
  "06-14": 11,
  "06-15": 3,
  "06-17": 2,
  "06-26": 6,
}

const changeActionPool: { category: ChangeItem["category"]; action: string; detail: string }[] = [
  { category: "广告日志", action: "调整竞价", detail: "关键词 wireless earbuds 竞价 $1.20 → $1.45" },
  { category: "广告日志", action: "新增否定词", detail: "否定精准：cheap headphone" },
  { category: "广告日志", action: "修改预算", detail: "广告活动「SP-自动-01」日预算 $50 → $80" },
  { category: "广告日志", action: "暂停广告组", detail: "广告组「ASIN 定位-02」已暂停" },
  { category: "运营日志", action: "修改售价", detail: "售价 €139,99 → €129,99" },
  { category: "运营日志", action: "设置 Coupon", detail: "新增 15% Coupon" },
  { category: "运营日志", action: "更新主图", detail: "替换主图为 A+ 新版本" },
  { category: "运营日志", action: "补货入仓", detail: "FBA 补货 500 件已签收" },
  { category: "更改记录", action: "Listing 变更", detail: "标题关键词优化" },
  { category: "更改记录", action: "类目变更", detail: "后台搜索类目调整" },
]

/** 根据 SKU 生成某天的更改明细列表 */
function buildChangeItems(sku: string, date: string, count: number): ChangeItem[] {
  const items: ChangeItem[] = []
  for (let i = 0; i < count; i++) {
    const pick = changeActionPool[hash(sku + date + i) % changeActionPool.length]
    const hh = String(8 + (hash(date + i) % 12)).padStart(2, "0")
    const mm = String(hash(sku + i) % 60).padStart(2, "0")
    items.push({
      category: pick.category,
      action: pick.action,
      detail: pick.detail,
      time: `${date} ${hh}:${mm}`,
    })
  }
  return items
}

/** 时间线主数据：受店铺 / SKU 系数影响，保证 SSR/CSR 一致 */
export function buildTimeline(
  shop: string,
  sku: string,
): { points: TimelinePoint[]; changes: ChangeRecord[] } {
  const f = shopFactor(shop, sku)
  const points: TimelinePoint[] = timelineDates.map((date, i) => {
    const wave = (seed: number) => (hash(sku + date + seed) % 100) / 100
    const clicks = Math.round((90 + wave(1) * 130) * f)
    const ctr = Math.round((0.4 + wave(2) * 0.5) * 100) / 100
    const impressions = Math.round(clicks / (ctr / 100))
    const cvr = Math.round((3 + wave(3) * 4) * 100) / 100
    const orders = Math.max(1, Math.round((clicks * cvr) / 100))
    const cpc = Math.round((0.8 + wave(4) * 1.6) * 100) / 100
    const spend = Math.round(clicks * cpc * 100) / 100
    const cpa = Math.round((spend / orders) * 100) / 100
    const sales = Math.round(orders * (28 + wave(5) * 20) * 100) / 100
    const acos = Math.round((spend / sales) * 10000) / 100
    const roas = Math.round((sales / spend) * 100) / 100
    const change = changeCounts[date] ?? 0
    return {
      date,
      impressions,
      topIS: Math.round((10 + wave(6) * 35) * 100) / 100,
      clicks,
      ctr,
      cvr,
      cpc,
      orders,
      cpa,
      spend,
      sales,
      acos,
      roas,
      indirectRatio: Math.round((5 + wave(7) * 20) * 100) / 100,
      units: orders + (hash(sku + date) % 4),
      vcpm: Math.round((3 + wave(8) * 6) * 100) / 100,
      change: change > 0 ? change : null,
    }
  })

  const changes: ChangeRecord[] = Object.entries(changeCounts).map(([date, count]) => ({
    date,
    count,
    items: buildChangeItems(sku, date, count),
  }))

  return { points, changes }
}

/* ===================== 24 小时指标趋势 ===================== */

/** 24 小时趋势可选指标定义 */
export type HourlyMetric = {
  key: string
  label: string
  color: string
  /** 是否虚线（如 CPC） */
  dashed?: boolean
  /** 是否填充面积（如销售额） */
  area?: boolean
  fmt: "int" | "eur" | "pct" | "ratio"
}

export const hourlyMetrics: HourlyMetric[] = [
  { key: "sales", label: "销售额", color: "#0f766e", area: true, fmt: "eur" },
  { key: "orders", label: "每小时出单", color: "#2563eb", fmt: "int" },
  { key: "cvr", label: "每小时转化率", color: "#db2777", fmt: "pct" },
  { key: "cpc", label: "CPC", color: "#7c3aed", dashed: true, fmt: "eur" },
  { key: "ctr", label: "CTR", color: "#f59e0b", fmt: "pct" },
  { key: "acos", label: "ACOS", color: "#dc2626", fmt: "pct" },
  { key: "roas", label: "ROAS", color: "#0891b2", fmt: "ratio" },
]

/** 24 小时中每小时的原始指标值 + 各指标相对自身峰值的百分比 */
export type HourlyPoint = {
  hour: string // "00:00"
  range: string // "00:59"
  sales: number
  orders: number
  cvr: number
  cpc: number
  ctr: number
  acos: number
  roas: number
  /** 各指标相对峰值（0-100），键名为 `${metric}Pct` */
  [k: `${string}Pct`]: number
}

/** 销量在一天内的形态：凌晨低、上午爬升、午间峰值、傍晚回落 */
const salesShape = [
  0.09, 0.08, 0.1, 0.21, 0.42, 0.53, 0.7, 0.84, 0.88, 0.97, 0.97, 0.96, 1.0, 0.9, 0.8, 0.76, 0.87,
  0.78, 0.75, 0.56, 0.41, 0.3, 0.17, 0.07,
]
/** CPC 形态：早间竞争高、午后逐步走低 */
const cpcShape = [
  0.88, 0.94, 0.97, 0.95, 0.97, 0.96, 0.97, 0.97, 1.0, 0.99, 0.98, 0.96, 0.95, 0.94, 0.94, 0.93,
  0.93, 0.92, 0.9, 0.88, 0.86, 0.84, 0.83, 0.77,
]

/** 生成 24 小时指标趋势（受店铺/SKU 影响，SSR/CSR 一致） */
export function buildHourlyTrend(shop: string, sku: string): {
  points: HourlyPoint[]
  peaks: Record<string, { hour: string; value: number }>
} {
  const f = shopFactor(shop, sku)
  const raw: Omit<HourlyPoint, `${string}Pct`>[] = Array.from({ length: 24 }, (_, h) => {
    const hh = String(h).padStart(2, "0")
    const wave = (seed: number) => 0.85 + ((hash(sku + h + seed) % 30) / 100) // 0.85~1.15 抖动
    const s = salesShape[h] * wave(1)
    const orders = Math.max(0, Math.round(s * 40 * f))
    const clicks = Math.max(1, Math.round(s * 320 * f * wave(2)))
    const impressions = Math.round(clicks / (0.006 + (hash(sku + h) % 5) / 1000))
    const cvr = orders > 0 ? Math.round(((orders / clicks) * 100) * 100) / 100 : 0
    const ctr = Math.round(((clicks / impressions) * 100) * 100) / 100
    const cpc = Math.round(cpcShape[h] * (0.9 + wave(3) * 0.4) * 100) / 100
    const spend = Math.round(clicks * cpc * 100) / 100
    const sales = Math.round(orders * (28 + (hash(sku + h + 7) % 18)) * 100) / 100
    const acos = sales > 0 ? Math.round((spend / sales) * 10000) / 100 : 0
    const roas = spend > 0 ? Math.round((sales / spend) * 100) / 100 : 0
    return { hour: `${hh}:00`, range: `${hh}:59`, sales, orders, cvr, cpc, ctr, acos, roas }
  })

  // 计算各指标峰值，得到相对峰值百分比
  const metricKeys = ["sales", "orders", "cvr", "cpc", "ctr", "acos", "roas"] as const
  const peaks: Record<string, { hour: string; value: number }> = {}
  for (const key of metricKeys) {
    let max = 0
    let peakHour = "00:00"
    for (const p of raw) {
      const v = p[key] as number
      if (v > max) {
        max = v
        peakHour = p.hour
      }
    }
    peaks[key] = { hour: peakHour, value: max }
  }

  const points: HourlyPoint[] = raw.map((p) => {
    const out: HourlyPoint = { ...p } as HourlyPoint
    for (const key of metricKeys) {
      const max = peaks[key].value || 1
      out[`${key}Pct`] = Math.round(((p[key] as number) / max) * 1000) / 10
    }
    return out
  })

  return { points, peaks }
}
