export const ruleSettingsTabs = ["数据明细", "可视化图表", "词根聚合", "建议操作", "待投放"] as const

export interface RuleConfig {
  // 目标值
  targetAcos: number
  targetAov: number
  targetCvr: number
  acosUp: number
  acosDown: number
  cvrUp: number
  cvrDown: number
  targetMargin: number
  categoryCvr: number
  // 目标毛利率板块
  marginGoal: number // 目标毛利率
  marginBeforeAd: number // 广告前毛利率
  marginAfterAd: number // 广告后毛利率
  // 目标转化率板块
  cvrCategoryAvg: number // 类目平均转化率
  cvrGoal: number // 目标转化率
  cvrAd: number // 广告转化率
  // ① 否定词候选规则
  negClicks: number
  negSpend: number
  // ② 加词候选规则
  addClicks: number
  addAcos: number
  addCvr: number
  addOrders: number
  // ③ 出价调整规则
  bidClicks: number
  bidUp1: number // 低于目标ACOS的 X%（提15%）
  bidUp2: number // （提20%）
  bidDown1: number // 超过目标ACOS的 X%（降10%）
  bidDown2: number // （降20%）
  bidDown3: number // （降30%）
  // ④ 重点关注规则
  focusClicks: number
  focusCvr: number
  focusGroupClicks: number
  focusAcos: number
}

export const defaultRuleConfig: RuleConfig = {
  targetAcos: 30,
  targetAov: 30,
  targetCvr: 3,
  acosUp: 21,
  acosDown: 39,
  cvrUp: 21,
  cvrDown: 39,
  targetMargin: 25,
  categoryCvr: 5,
  marginGoal: 20,
  marginBeforeAd: 25,
  marginAfterAd: 20,
  cvrCategoryAvg: 5,
  cvrGoal: 8,
  cvrAd: 6,
  negClicks: 13,
  negSpend: 25,
  addClicks: 4,
  addAcos: 30,
  addCvr: 12,
  addOrders: 1,
  bidClicks: 6,
  bidUp1: 70,
  bidUp2: 50,
  bidDown1: 130,
  bidDown2: 160,
  bidDown3: 190,
  focusClicks: 40,
  focusCvr: 5,
  focusGroupClicks: 10,
  focusAcos: 40,
}

export interface SuggestionItem {
  keyword: string
  asin: string
  clicks: number
  spend: number
  orders: number
  acos: number
  cvr: number
  reason: string
}

export const suggestionPool: Record<string, SuggestionItem[]> = {
  否定词候选: [
    { keyword: "bluetooth speaker mini", asin: "B0GK****CG", clicks: 31, spend: 44.6, orders: 0, acos: 0, cvr: 0, reason: "无转化高消耗词，建议添加否定" },
    { keyword: "headphone stand wood", asin: "B0GR****LG", clicks: 21, spend: 28.3, orders: 0, acos: 0, cvr: 0, reason: "连续5天花费0订单" },
    { keyword: "earphone cleaning kit", asin: "B0GV****71", clicks: 17, spend: 33.0, orders: 0, acos: 0, cvr: 0, reason: "花费超阈值无销售" },
  ],
  加词候选: [
    { keyword: "anc earbuds for travel", asin: "B0GK****CG", clicks: 9, spend: 12.4, orders: 3, acos: 22.1, cvr: 33.3, reason: "高转化词，建议加入精准投放" },
    { keyword: "gym earbuds sweatproof", asin: "B0F6****44", clicks: 7, spend: 9.8, orders: 2, acos: 18.5, cvr: 28.6, reason: "效率优秀，建议提价拓量" },
  ],
  出价调整: [
    { keyword: "bluetooth earbuds", asin: "B0GK****CG", clicks: 42, spend: 58.3, orders: 6, acos: 25.3, cvr: 14.3, reason: "低于目标ACOS，建议提价15%" },
    { keyword: "earbuds for iphone", asin: "B0DP****NQ", clicks: 31, spend: 74.0, orders: 2, acos: 51.2, cvr: 6.5, reason: "超过目标ACOS 160%，建议降价20%" },
    { keyword: "tws earbuds", asin: "B0DZ****KH", clicks: 25, spend: 38.6, orders: 4, acos: 16.9, cvr: 16.0, reason: "全表最高效，建议提价20%" },
  ],
  重点关注: [
    { keyword: "wireless headphone", asin: "B0GJ****DH", clicks: 45, spend: 88.0, orders: 1, acos: 64.5, cvr: 2.2, reason: "高点击低转化，重点排查" },
  ],
}
