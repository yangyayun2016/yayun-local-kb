// ASIN 日常跟踪表数据与维度分组配置

export interface ColumnDef {
  key: string
  label: string
  /** 文本左对齐，默认数值右对齐 */
  text?: boolean
  /** 总转化率列特殊渲染为条形 */
  bar?: boolean
}

export interface ColumnGroup {
  id: string
  label: string
  /** 锁定分组不可关闭（基础信息） */
  locked?: boolean
  /** 默认是否展示 */
  defaultOn: boolean
  columns: ColumnDef[]
}

export const columnGroups: ColumnGroup[] = [
  {
    id: "base",
    label: "基础信息",
    locked: true,
    defaultOn: true,
    columns: [
      { key: "date", label: "时间", text: true },
      { key: "weekday", label: "星期", text: true },
      { key: "work", label: "工作内容/运营动作", text: true },
    ],
  },
  {
    id: "price",
    label: "价格 & 毛利",
    defaultOn: true,
    columns: [
      { key: "price", label: "售价" },
      { key: "fbaPrice", label: "FBA价" },
      { key: "strikeDiscount", label: "划线价折扣" },
      { key: "coupon", label: "Coupon" },
      { key: "minDealPrice", label: "最低成交价" },
      { key: "scMargin", label: "SC最低成交价毛利率" },
      { key: "vcMargin", label: "VC采购价毛利率" },
    ],
  },
  {
    id: "traffic",
    label: "流量 & 转化",
    defaultOn: true,
    columns: [
      { key: "visitMobile", label: "移动端访问" },
      { key: "visitPc", label: "PC端访问" },
      { key: "visitTotal", label: "总访问" },
      { key: "cvrTotal", label: "总转化率", bar: true },
    ],
  },
  {
    id: "orders",
    label: "订单",
    defaultOn: true,
    columns: [
      { key: "naturalOrderActual", label: "实际自然订单" },
      { key: "naturalOrder", label: "自然订单" },
      { key: "totalOrders", label: "总订单量" },
      { key: "scOrders", label: "SC总订单" },
      { key: "reviewOrders", label: "测评出单" },
      { key: "reviewTotalOrders", label: "测评总出单" },
      { key: "reviewRate", label: "测评完成率" },
      { key: "vine", label: "Vine数量" },
      { key: "salesUsd", label: "销售额$" },
    ],
  },
  {
    id: "ranking",
    label: "排名 & Listing",
    defaultOn: false,
    columns: [
      { key: "abaRank", label: "核心词ABA排名" },
      { key: "naturalRank", label: "自然排名" },
      { key: "adRank", label: "广告排位" },
      { key: "indexCount", label: "关键词收录数" },
      { key: "bigRank", label: "大类排名" },
      { key: "smallRank", label: "小类排名" },
      { key: "reviews", label: "评论数" },
      { key: "rating", label: "评分" },
      { key: "qa", label: "QA数" },
    ],
  },
  {
    id: "ad",
    label: "广告数据",
    defaultOn: false,
    columns: [
      { key: "adImpr", label: "广告曝光" },
      { key: "adClicks", label: "点击" },
      { key: "adCtr", label: "点击率" },
      { key: "adOrders", label: "广告订单" },
      { key: "adCpc", label: "CPC" },
      { key: "adAcos", label: "ACOS" },
      { key: "adCvr", label: "广告转化" },
      { key: "adOrderShare", label: "广告订单占比" },
      { key: "adSpend", label: "广告花费$" },
      { key: "adCpa", label: "CPA" },
      { key: "adTacos", label: "TACOS" },
      { key: "adCpm", label: "CPM" },
      { key: "adSales", label: "广告销售额" },
    ],
  },
  {
    id: "margin",
    label: "毛利数据",
    defaultOn: false,
    columns: [
      { key: "refundRate", label: "退款率" },
      { key: "adMarginP1", label: "广告订单毛利P1$" },
      { key: "naturalMarginP1", label: "自然订单毛利P1$" },
      { key: "totalMarginP1", label: "总订单毛利P1$" },
      { key: "totalMarginRate", label: "总订单毛利率P1" },
      { key: "domesticCost", label: "国内总成本$" },
      { key: "payback", label: "回款金额" },
      { key: "reviewLoss", label: "测评亏损" },
    ],
  },
  {
    id: "offsite",
    label: "站外 & 流量占比",
    defaultOn: false,
    columns: [
      { key: "offsiteDeals", label: "站外deals" },
      { key: "offsiteMargin", label: "站外毛利$" },
      { key: "offsiteOrders", label: "站外出单" },
      { key: "offsitePrice", label: "站外售价" },
      { key: "offsiteDiscount", label: "站外折扣" },
      { key: "adTrafficShare", label: "广告流量占比" },
      { key: "naturalTrafficShare", label: "自然流量占比" },
      { key: "naturalCvr", label: "自然转化" },
      { key: "realNaturalCvr", label: "实际自然转化率" },
    ],
  },
  {
    id: "competitor",
    label: "对标竞品",
    defaultOn: false,
    columns: [
      { key: "catAvgCvr", label: "类目平均转化率" },
      { key: "comp1Cvr", label: "竞品1转化率" },
      { key: "comp2Cvr", label: "竞品2转化率" },
      { key: "simEcpm", label: "模拟eCPM" },
    ],
  },
]

export type TrackingRow = Record<string, string | number>

// 工作内容来源于跟踪表（5/17 起逐日记录）
const schedule: { date: string; weekday: string; work: string; fba: number; strike: number }[] = [
  { date: "5月17日", weekday: "星期六", work: "准备", fba: 139.99, strike: 30 },
  { date: "5月18日", weekday: "星期日", work: "链接上架", fba: 139.99, strike: 30 },
  { date: "5月19日", weekday: "星期一", work: "确定主图文案", fba: 139.99, strike: 30 },
  { date: "5月20日", weekday: "星期二", work: "确定A+图文案", fba: 139.99, strike: 30 },
  { date: "5月21日", weekday: "星期三", work: "红人视频", fba: 139.99, strike: 30 },
  { date: "5月22日", weekday: "星期四", work: "QA20对上架，动画-注", fba: 139.99, strike: 30 },
  { date: "5月23日", weekday: "星期五", work: "QA20对上架，动画-注", fba: 97.99, strike: 30 },
  { date: "5月24日", weekday: "星期六", work: "绿标回评 2个", fba: 97.99, strike: 30 },
  { date: "5月25日", weekday: "星期日", work: "做划线价", fba: 97.99, strike: 30 },
  { date: "5月26日", weekday: "星期一", work: "欧洲小站点A+优化 链接", fba: 97.99, strike: 20 },
  { date: "5月27日", weekday: "星期二", work: "动画，外模视频到位", fba: 139.99, strike: 20 },
  { date: "5月28日", weekday: "星期三", work: "做划线价", fba: 139.99, strike: 20 },
  { date: "5月29日", weekday: "星期四", work: "2个测评下单 139.95", fba: 139.95, strike: 20 },
  { date: "5月30日", weekday: "星期五", work: "2个测评下单 139.95", fba: 139.95, strike: 20 },
  { date: "5月31日", weekday: "星期六", work: "2个测评下单 139.95", fba: 139.95, strike: 20 },
  { date: "6月1日", weekday: "星期日", work: "2个测评下单 139.95", fba: 139.95, strike: 20 },
  { date: "6月2日", weekday: "星期一", work: "收集关键词 广告准备", fba: 139.95, strike: 20 },
  { date: "6月3日", weekday: "星期二", work: "优惠券设置15% 开始", fba: 97.97, strike: 20 },
  { date: "6月4日", weekday: "星期三", work: "开始做广告", fba: 97.97, strike: 20 },
]

// 基于天数确定性生成，访问量随上架推进逐步爬升
function buildRow(i: number, s: (typeof schedule)[number]): TrackingRow {
  const ramp = Math.max(0, i - 2) // 前几天准备期访问为 0
  const visitMobile = ramp === 0 ? 0 : Math.round(1 + ramp * 0.9 + ((i * 7) % 6))
  const visitPc = ramp === 0 ? 0 : Math.round(3 + ramp * 1.4 + ((i * 13) % 9))
  const visitTotal = visitMobile + visitPc
  const totalOrders = ramp === 0 ? 0 : Math.max(0, Math.round(visitTotal * (0.05 + ((i * 3) % 9) / 100)))
  const cvr = visitTotal === 0 ? 0 : Math.round((totalOrders / visitTotal) * 100)
  const reviewOrders = i >= 12 && i <= 16 ? 2 : 0
  const naturalOrder = Math.max(0, totalOrders - reviewOrders)
  const adOrders = i >= 18 ? Math.round(totalOrders * 0.4) : 0
  const naturalOrderActual = Math.max(0, naturalOrder - adOrders)
  const price = 139.99
  const salesUsd = (totalOrders * 95.19).toFixed(2)
  const adSpend = i >= 18 ? (12 + ramp * 0.6).toFixed(2) : "0.00"
  const adClicks = i >= 18 ? Math.round(visitTotal * 0.5) : 0
  const adImpr = i >= 18 ? adClicks * 120 : 0

  return {
    date: s.date,
    weekday: s.weekday,
    work: s.work,
    // 价格&毛利
    price: `$${price}`,
    fbaPrice: `$${s.fba}`,
    strikeDiscount: `${s.strike}%`,
    coupon: "15%",
    minDealPrice: s.strike === 30 ? "83.29" : "95.19",
    scMargin: "8%",
    vcMargin: "0.06",
    // 流量&转化
    visitMobile,
    visitPc,
    visitTotal,
    cvrTotal: cvr,
    // 订单
    naturalOrderActual,
    naturalOrder,
    totalOrders,
    scOrders: totalOrders,
    reviewOrders,
    reviewTotalOrders: reviewOrders,
    reviewRate: reviewOrders ? "100%" : "0%",
    vine: 0,
    salesUsd: `$${salesUsd}`,
    // 排名&Listing
    abaRank: ramp === 0 ? "-" : `${20000 - ramp * 600}`,
    naturalRank: ramp === 0 ? "-" : `${300 - ramp * 8}`,
    adRank: i >= 18 ? `${40 - ramp}` : "-",
    indexCount: `${Math.min(120, ramp * 6)}`,
    bigRank: ramp === 0 ? "-" : `${50000 - ramp * 1200}`,
    smallRank: ramp === 0 ? "-" : `${1800 - ramp * 40}`,
    reviews: `${Math.min(30, Math.floor(ramp / 2))}`,
    rating: ramp >= 4 ? "4.6" : ramp >= 1 ? "4.3" : "-",
    qa: `${Math.min(20, ramp)}`,
    // 广告数据
    adImpr,
    adClicks,
    adCtr: adImpr ? `${((adClicks / adImpr) * 100).toFixed(2)}%` : "-",
    adOrders,
    adCpc: adClicks ? `$${(Number(adSpend) / adClicks).toFixed(2)}` : "-",
    adAcos: adOrders ? `${(Number(adSpend) / (adOrders * 95.19) * 100).toFixed(1)}%` : "-",
    adCvr: adClicks ? `${((adOrders / adClicks) * 100).toFixed(1)}%` : "-",
    adOrderShare: totalOrders ? `${((adOrders / totalOrders) * 100).toFixed(0)}%` : "0%",
    adSpend: `$${adSpend}`,
    adCpa: adOrders ? `$${(Number(adSpend) / adOrders).toFixed(2)}` : "-",
    adTacos: Number(salesUsd) ? `${(Number(adSpend) / Number(salesUsd) * 100).toFixed(1)}%` : "-",
    adCpm: adImpr ? `$${(Number(adSpend) / adImpr * 1000).toFixed(2)}` : "-",
    adSales: adOrders ? `$${(adOrders * 95.19).toFixed(2)}` : "$0.00",
    // 毛利数据
    refundRate: ramp === 0 ? "0%" : `${((i * 3) % 5) + 1}%`,
    adMarginP1: adOrders ? `$${(adOrders * 12).toFixed(2)}` : "$0.00",
    naturalMarginP1: `$${(naturalOrder * 22).toFixed(2)}`,
    totalMarginP1: `$${(totalOrders * 20).toFixed(2)}`,
    totalMarginRate: totalOrders ? "21%" : "0%",
    domesticCost: `$${(totalOrders * 38).toFixed(2)}`,
    payback: `$${(Number(salesUsd) * 0.85).toFixed(2)}`,
    reviewLoss: reviewOrders ? `$${(reviewOrders * 95.19).toFixed(2)}` : "$0.00",
    // 站外&流量占比
    offsiteDeals: "-",
    offsiteMargin: "$0.00",
    offsiteOrders: 0,
    offsitePrice: "-",
    offsiteDiscount: "-",
    adTrafficShare: i >= 18 ? "36%" : "0%",
    naturalTrafficShare: i >= 18 ? "64%" : "100%",
    naturalCvr: visitTotal ? `${cvr}%` : "0%",
    realNaturalCvr: visitTotal ? `${Math.max(0, cvr - 2)}%` : "0%",
    // 对标竞品
    catAvgCvr: "8%",
    comp1Cvr: "9.2%",
    comp2Cvr: "7.4%",
    simEcpm: i >= 18 ? `$${(8 + ramp * 0.3).toFixed(2)}` : "-",
  }
}

export const trackingRows: TrackingRow[] = schedule.map((s, i) => buildRow(i, s))

export const trackingSummary = {
  asin: "B0GDC7BWK",
  product: "无线降噪耳机",
  dayCount: trackingRows.length,
  dataDate: "2026-06-11",
}
