export type ActionSeverity = "极高" | "高" | "中" | "低"
export type ActionStatus = "待处理" | "执行中" | "已忽略" | "已采纳"

export interface ActionStep {
  /** 编号说明文字（含内嵌的蓝色高亮短语） */
  text: string
  /** 右侧高亮链接/操作文案 */
  highlight?: string
  /** 高亮颜色：蓝色链接 or 红色警示 */
  highlightTone?: "brand" | "danger"
}

export interface ActionItem {
  id: string
  asin: string
  shop: string
  owner: string
  date: string
  /** 卡片标题（问题诊断结论） */
  title: string
  /** 标题严重度标签 */
  severity: ActionSeverity
  /** 标题旁补充小标签，如「广告亏损被自然流量掩盖 中」 */
  subtitle?: string
  /** ACOS 指标变化行 */
  metricLine: string
  /** 右侧黄色徽标，如「当前7天均值 55.7% · 仍偏高」 */
  metricBadge: string
  /** 黄色灯泡说明段落 */
  insight: string
  /** 编号操作动作 */
  steps: ActionStep[]
  /** 历史参考文字 */
  history?: string
  status: ActionStatus
}

export const actionStatusTabs: { label: string; value: ActionStatus | "全部" }[] = [
  { label: "全部", value: "全部" },
  { label: "待处理", value: "待处理" },
  { label: "执行中", value: "执行中" },
  { label: "已忽略", value: "已忽略" },
]

export const actionItems: ActionItem[] = [
  {
    id: "act-1",
    asin: "B0GK****CG",
    shop: "星辰**(北美)-US",
    owner: "陈**",
    date: "2026-06-11",
    title: "ACOS 飙升",
    severity: "极高",
    metricLine: "ACOS 33.0% → 52.2%（↑58%）",
    metricBadge: "当前7天均值 55.7% · 仍偏高",
    insight:
      "近期 CVR 从 5% 跌至 2.5%（↓50%），广告花费未能同步收紧，导致 ACOS 从 28.1% 飙升至 55.4%（↑48%），远超盈亏平衡 ACOS 22.3%，且产品毛利率为负（-36.5%），广告加剧亏损。",
    steps: [
      {
        text: "建议人工复核：核对缺少广告活动及搜索词报告，无法定位高花费低转化投放，需补充近 7 天 / 30 天的广告活动花费、订单、ACOS 及搜索词点击转化数据。",
        highlight: "获取广告活动报告与搜索词报告",
        highlightTone: "brand",
      },
      {
        text: "复核前先将该 ASIN 所有广告活动日预算总额降低约 50%，或直接暂停高 ACOS 活动，以控制烧钱速度。",
        highlight: "总日预算降至当前 50%",
        highlightTone: "brand",
      },
    ],
    history:
      "2026-06-02 recovered：近期 ACOS 从 24.62% 飙升至 38.95%，远超盈亏平衡 ACOS 20.11%；主要原因是广告花费集中在高花费低转化词上，且整体转化率从 5 月约 5% 降至 6 月初 0%，同时毛利率为负（-30.6%），导致广告亏损严重。",
    status: "待处理",
  },
  {
    id: "act-2",
    asin: "B0GK****CG",
    shop: "星辰**(北美)-US",
    owner: "陈**",
    date: "2026-06-11",
    title: "广告亏损被自然流量掩盖",
    severity: "中",
    subtitle: "ACOS 提升（高）",
    metricLine: "ACOS 59.2%，盈亏平衡 21.5%，广告亏损约 $70",
    metricBadge: "当前7日均值 55.7% · 仍偏高",
    insight:
      "ASIN B0GK****CG 广告加权 ACOS 为 59.16%，远超盈亏平衡 ACOS 21.49%，造成广告亏损 $69.84。由于自然流量订单较多，整体 TACOS 可能较低，掩盖了广告亏损的事实。近期 CVR 波动下降，部分高花费关键词可能转化不佳。",
    steps: [
      {
        text: "建议人工复核：缺少搜索词报告和广告活动层级数据，无法定位具体低效关键词 / 广告活动。需提供近 14 天搜索词报告（含花费、点击、订单、CVR），以及各广告活动的 ACOS、出价和预算设置。",
        highlight: "通过人工分析可精准降低亏损词出价或否定，预计使加权 ACOS 回归至盈亏平衡线附近",
        highlightTone: "brand",
      },
    ],
    status: "待处理",
  },
]

export const severityColor: Record<ActionSeverity, string> = {
  极高: "bg-down/10 text-down",
  高: "bg-amber-100 text-amber-700",
  中: "bg-amber-100 text-amber-700",
  低: "bg-muted text-muted-foreground",
}

/** 状态徽标样式 */
export const statusBadge: Record<ActionStatus, string> = {
  待处理: "bg-amber-100 text-amber-700",
  执行中: "bg-brand/10 text-brand",
  已采纳: "bg-up/10 text-up",
  已忽略: "bg-muted text-muted-foreground",
}
