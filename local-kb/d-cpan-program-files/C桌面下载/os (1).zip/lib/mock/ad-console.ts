/* ===================== 广告看板（管理控制台） ===================== */

function hash(s: string): number {
  let h = 0
  for (let i = 0; i < s.length; i++) {
    h = (h << 5) - h + s.charCodeAt(i)
    h |= 0
  }
  return Math.abs(h)
}

/** 实体 Tab 定义，部分带 new 标记 */
export type ConsoleTab = {
  key: string
  label: string
  isNew?: boolean
}

export const consoleTabs: ConsoleTab[] = [
  { key: "placement", label: "广告位", isNew: true },
  { key: "campaign", label: "广告活动" },
  { key: "adgroup", label: "广告组" },
  { key: "ad", label: "广告", isNew: true },
  { key: "product", label: "投放产品" },
  { key: "searchterm", label: "搜索词" },
  { key: "asin", label: "ASIN" },
  { key: "negative", label: "否定投放" },
  { key: "pending", label: "待投放" },
]

/** 筛选下拉项 */
export const consoleFilters: { key: string; label: string; options: string[] }[] = [
  { key: "shop", label: "店铺", options: ["全部店铺", "星辰**(北美)-US", "晨光**(欧洲)-DE", "远帆**(日本)-JP"] },
  { key: "tag", label: "标签", options: ["全部标签", "核心款", "新品", "清仓"] },
  { key: "portfolio", label: "广告组合", options: ["全部组合", "品牌词组合", "大词组合", "防御组合"] },
  { key: "delivery", label: "投放组合", options: ["全部投放", "SP 自动", "SP 手动", "SB 视频", "SD 展示"] },
]

/** 操作工具栏按钮 */
export const consoleActions: string[] = [
  "批量操作",
  "竞价调整",
  "预算规则",
  "历史记录",
  "定向策略",
  "广告组设置",
  "广告活动设置",
]

/** 列定义 */
export type ConsoleColumn = {
  key: string
  label: string
  align?: "left" | "right"
  kind?: "text" | "int" | "eur" | "pct" | "ratio" | "status" | "match"
  primary?: boolean
}

export type ConsoleRow = Record<string, string | number>

type TabConfig = {
  columns: ConsoleColumn[]
  build: (shop: string, sku: string) => ConsoleRow[]
}

const STATUS = ["投放中", "已暂停", "预算受限", "已存档"] as const
const MATCH = ["精准匹配", "广泛匹配", "词组匹配"] as const

/** 通用指标生成 */
function metrics(seed: string, scale = 1) {
  const w = (n: number) => (hash(seed + n) % 100) / 100
  const impressions = Math.round((4000 + w(1) * 26000) * scale)
  const ctr = Math.round((0.4 + w(2) * 0.7) * 100) / 100
  const clicks = Math.max(1, Math.round((impressions * ctr) / 100))
  const cpc = Math.round((0.7 + w(3) * 1.8) * 100) / 100
  const spend = Math.round(clicks * cpc * 100) / 100
  const cvr = Math.round((3 + w(4) * 5) * 100) / 100
  const orders = Math.max(0, Math.round((clicks * cvr) / 100))
  const sales = Math.round(orders * (26 + w(5) * 22) * 100) / 100
  const acos = sales > 0 ? Math.round((spend / sales) * 10000) / 100 : 0
  const roas = spend > 0 ? Math.round((sales / spend) * 100) / 100 : 0
  return { impressions, ctr, clicks, cpc, spend, cvr, orders, sales, acos, roas }
}

function asinTag(seed: string): string {
  return "B0" + hash(seed).toString(36).toUpperCase().slice(0, 6)
}

const tabConfigs: Record<string, TabConfig> = {
  placement: {
    columns: [
      { key: "name", label: "广告位", primary: true },
      { key: "campaign", label: "所属广告活动" },
      { key: "impressions", label: "曝光量", align: "right", kind: "int" },
      { key: "clicks", label: "点击量", align: "right", kind: "int" },
      { key: "ctr", label: "CTR", align: "right", kind: "pct" },
      { key: "bidAdjust", label: "竞价调整", align: "right", kind: "pct" },
      { key: "spend", label: "广告花费", align: "right", kind: "eur" },
      { key: "orders", label: "订单", align: "right", kind: "int" },
      { key: "acos", label: "ACoS", align: "right", kind: "pct" },
    ],
    build: (shop, sku) =>
      ["搜索结果首页顶部", "商品页面", "搜索结果其余位置"].map((name, i) => {
        const m = metrics(shop + sku + "pl" + i, [1.4, 0.9, 0.7][i])
        return {
          name,
          campaign: "SP-自动-0" + (1 + (i % 3)),
          impressions: m.impressions,
          clicks: m.clicks,
          ctr: m.ctr,
          bidAdjust: [50, 20, 0][i],
          spend: m.spend,
          orders: m.orders,
          acos: m.acos,
        }
      }),
  },
  campaign: {
    columns: [
      { key: "name", label: "广告活动", primary: true },
      { key: "type", label: "类型" },
      { key: "status", label: "状态", kind: "status" },
      { key: "budget", label: "日预算", align: "right", kind: "eur" },
      { key: "spend", label: "广告花费", align: "right", kind: "eur" },
      { key: "sales", label: "广告销售额", align: "right", kind: "eur" },
      { key: "orders", label: "订单", align: "right", kind: "int" },
      { key: "acos", label: "ACoS", align: "right", kind: "pct" },
      { key: "roas", label: "ROAS", align: "right", kind: "ratio" },
    ],
    build: (shop, sku) =>
      ["SP-自动-01", "SP-手动-大词", "SB-视频-品牌", "SD-展示-再营销", "SP-手动-防御"].map((name, i) => {
        const m = metrics(shop + sku + "cp" + i, 1 + (i % 3) * 0.4)
        return {
          name,
          type: ["SP", "SP", "SB", "SD", "SP"][i],
          status: STATUS[hash(name) % 3],
          budget: [80, 120, 60, 40, 50][i],
          spend: m.spend,
          sales: m.sales,
          orders: m.orders,
          acos: m.acos,
          roas: m.roas,
        }
      }),
  },
  adgroup: {
    columns: [
      { key: "name", label: "广告组", primary: true },
      { key: "campaign", label: "所属广告活动" },
      { key: "status", label: "状态", kind: "status" },
      { key: "defaultBid", label: "默认竞价", align: "right", kind: "eur" },
      { key: "spend", label: "广告花费", align: "right", kind: "eur" },
      { key: "orders", label: "订单", align: "right", kind: "int" },
      { key: "acos", label: "ACoS", align: "right", kind: "pct" },
    ],
    build: (shop, sku) =>
      ["核心词-精准", "拓展词-广泛", "ASIN 定位", "类目定位"].map((name, i) => {
        const m = metrics(shop + sku + "ag" + i, 1 - i * 0.15)
        return {
          name,
          campaign: ["SP-手动-大词", "SP-自动-01", "SD-展示-再营销", "SP-手动-防御"][i],
          status: STATUS[hash(name + i) % 3],
          defaultBid: Math.round((0.8 + (hash(name) % 80) / 100) * 100) / 100,
          spend: m.spend,
          orders: m.orders,
          acos: m.acos,
        }
      }),
  },
  ad: {
    columns: [
      { key: "sku", label: "SKU", primary: true },
      { key: "asin", label: "ASIN" },
      { key: "status", label: "状态", kind: "status" },
      { key: "impressions", label: "曝光量", align: "right", kind: "int" },
      { key: "clicks", label: "点击量", align: "right", kind: "int" },
      { key: "spend", label: "广告花费", align: "right", kind: "eur" },
      { key: "orders", label: "订单", align: "right", kind: "int" },
      { key: "acos", label: "ACoS", align: "right", kind: "pct" },
    ],
    build: (shop, sku) =>
      [sku, sku + "-A", sku + "-B"].map((s, i) => {
        const m = metrics(shop + s + "ad", 1 - i * 0.2)
        return {
          sku: s,
          asin: asinTag(s),
          status: STATUS[hash(s) % 3],
          impressions: m.impressions,
          clicks: m.clicks,
          spend: m.spend,
          orders: m.orders,
          acos: m.acos,
        }
      }),
  },
  product: {
    columns: [
      { key: "asin", label: "投放 ASIN", primary: true },
      { key: "match", label: "匹配类型", kind: "match" },
      { key: "bid", label: "竞价", align: "right", kind: "eur" },
      { key: "impressions", label: "曝光量", align: "right", kind: "int" },
      { key: "clicks", label: "点击量", align: "right", kind: "int" },
      { key: "spend", label: "广告花费", align: "right", kind: "eur" },
      { key: "orders", label: "订单", align: "right", kind: "int" },
      { key: "acos", label: "ACoS", align: "right", kind: "pct" },
    ],
    build: (shop, sku) =>
      Array.from({ length: 6 }).map((_, i) => {
        const s = sku + "p" + i
        const m = metrics(shop + s, 0.8 + (i % 3) * 0.3)
        return {
          asin: asinTag(s),
          match: MATCH[hash(s) % MATCH.length],
          bid: Math.round((0.6 + (hash(s) % 90) / 100) * 100) / 100,
          impressions: m.impressions,
          clicks: m.clicks,
          spend: m.spend,
          orders: m.orders,
          acos: m.acos,
        }
      }),
  },
  searchterm: {
    columns: [
      { key: "term", label: "客户搜索词", primary: true },
      { key: "match", label: "匹配类型", kind: "match" },
      { key: "clicks", label: "点击量", align: "right", kind: "int" },
      { key: "cpc", label: "CPC", align: "right", kind: "eur" },
      { key: "spend", label: "广告花费", align: "right", kind: "eur" },
      { key: "orders", label: "订单", align: "right", kind: "int" },
      { key: "acos", label: "ACoS", align: "right", kind: "pct" },
    ],
    build: (shop, sku) =>
      ["wireless earbuds", "bluetooth headphones", "noise cancelling", "sport earbuds", "kids headphone", "headset for pc"].map(
        (term, i) => {
          const m = metrics(shop + sku + term, 0.7 + (i % 3) * 0.3)
          return {
            term,
            match: MATCH[hash(term) % MATCH.length],
            clicks: m.clicks,
            cpc: m.cpc,
            spend: m.spend,
            orders: m.orders,
            acos: m.acos,
          }
        },
      ),
  },
  asin: {
    columns: [
      { key: "asin", label: "ASIN", primary: true },
      { key: "title", label: "标题" },
      { key: "impressions", label: "曝光量", align: "right", kind: "int" },
      { key: "clicks", label: "点击量", align: "right", kind: "int" },
      { key: "spend", label: "广告花费", align: "right", kind: "eur" },
      { key: "sales", label: "广告销售额", align: "right", kind: "eur" },
      { key: "acos", label: "ACoS", align: "right", kind: "pct" },
    ],
    build: (shop, sku) =>
      ["无线降噪耳机", "运动蓝牙耳机", "头戴式耳机 Pro", "儿童护耳耳机"].map((title, i) => {
        const s = sku + "as" + i
        const m = metrics(shop + s, 1 - i * 0.18)
        return {
          asin: asinTag(s),
          title,
          impressions: m.impressions,
          clicks: m.clicks,
          spend: m.spend,
          sales: m.sales,
          acos: m.acos,
        }
      }),
  },
  negative: {
    columns: [
      { key: "term", label: "否定词", primary: true },
      { key: "level", label: "否定层级" },
      { key: "match", label: "匹配方式", kind: "match" },
      { key: "campaign", label: "所属广告活动" },
      { key: "addedAt", label: "添加时间", align: "right" },
    ],
    build: (shop, sku) =>
      ["cheap headphone", "free earbuds", "refurbished", "case only", "broken"].map((term, i) => ({
        term,
        level: ["广告活动", "广告组"][i % 2],
        match: i % 2 === 0 ? "精准匹配" : "词组匹配",
        campaign: ["SP-自动-01", "SP-手动-大词"][i % 2],
        addedAt: "06-" + String(10 + i).padStart(2, "0"),
      })),
  },
  pending: {
    columns: [
      { key: "term", label: "待投放词", primary: true },
      { key: "source", label: "来源" },
      { key: "match", label: "建议匹配", kind: "match" },
      { key: "suggestBid", label: "建议竞价", align: "right", kind: "eur" },
      { key: "estClicks", label: "预估点击", align: "right", kind: "int" },
      { key: "status", label: "状态", kind: "status" },
    ],
    build: (shop, sku) =>
      ["premium earbuds", "long battery headset", "gaming headphone", "travel earbuds"].map((term, i) => {
        const m = metrics(shop + sku + term + "pd", 0.6)
        return {
          term,
          source: ["搜索词报告", "竞品分析", "关键词机会"][i % 3],
          match: MATCH[hash(term) % MATCH.length],
          suggestBid: Math.round((0.8 + (hash(term) % 70) / 100) * 100) / 100,
          estClicks: m.clicks,
          status: "待确认",
        }
      }),
  },
}

export function getConsoleColumns(tab: string): ConsoleColumn[] {
  return tabConfigs[tab]?.columns ?? []
}

export function buildConsoleRows(tab: string, shop: string, sku: string): ConsoleRow[] {
  return tabConfigs[tab]?.build(shop, sku) ?? []
}

/** 各 Tab 行数（用于 Tab 上的计数角标） */
export function consoleTabCount(tab: string, shop: string, sku: string): number {
  return buildConsoleRows(tab, shop, sku).length
}

/** 格式化单元格 */
export function fmtConsole(v: string | number, kind?: string): string {
  if (v == null || v === "") return "-"
  switch (kind) {
    case "eur":
      return "€" + Number(v).toFixed(2).replace(".", ",")
    case "pct":
      return Number(v).toFixed(2).replace(".", ",") + "%"
    case "ratio":
      return Number(v).toFixed(2).replace(".", ",")
    case "int":
      return Number(v).toLocaleString("en-US")
    default:
      return String(v)
  }
}
