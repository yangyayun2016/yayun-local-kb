// 广告健康诊断 — 13 步分析流程
export const analysisSteps = [
  "拉取 ASIN 基础信息与 Listing 状态",
  "采集近 30 天广告活动数据",
  "汇总曝光 / 点击 / 转化漏斗",
  "计算 ACOS / TACOS / ROAS 指标",
  "识别高耗低产关键词",
  "检测否定关键词覆盖情况",
  "分析竞价策略与建议出价",
  "评估广告位表现（顶部 / 商品页 / 其余）",
  "扫描预算打满与断量风险",
  "比对竞品广告投放强度",
  "评估自然排名与广告联动",
  "生成优化动作清单",
  "汇总诊断报告并评分",
] as const

export type ReportStatus = "已完成" | "分析中" | "失败"

export type HealthReport = {
  id: string
  asin: string
  shop: string
  owner: string
  time: string
  status: ReportStatus
  /** 健康总分 0-100 */
  score: number
  /** 核心问题数 */
  issues: number
  summary: string
  /** 优化建议 */
  actions: { title: string; level: "高" | "中" | "低"; desc: string }[]
  metrics: { label: string; value: string; healthy: boolean }[]
}

export const healthReports: HealthReport[] = [
  {
    id: "rpt-001",
    asin: "B0XX****01",
    shop: "星辰**(北美)-US",
    owner: "陈**",
    time: "2026-06-12 16:29",
    status: "已完成",
    score: 82,
    issues: 3,
    summary:
      "整体广告健康度良好，ACOS 控制在目标线内，但存在 3 个高耗低产关键词及 1 个广告组预算打满风险，建议优化出价结构。",
    actions: [
      { title: "降低高耗关键词出价", level: "高", desc: "关键词「wireless earbuds」近 7 天 ACOS 达 58%，建议下调竞价 20%。" },
      { title: "补充否定关键词", level: "中", desc: "检测到 12 个无效搜索词消耗预算，建议加入否定列表。" },
      { title: "提升商品页广告位预算", level: "低", desc: "商品页广告位转化率 6.2%，高于平均，可适度加预算。" },
    ],
    metrics: [
      { label: "ACOS", value: "29.0%", healthy: true },
      { label: "TACOS", value: "11.8%", healthy: true },
      { label: "CTR", value: "2.01%", healthy: true },
      { label: "CVR", value: "4.5%", healthy: true },
      { label: "预算打满", value: "0 次", healthy: true },
      { label: "无效搜索词", value: "12 个", healthy: false },
    ],
  },
  {
    id: "rpt-002",
    asin: "B0DG****5R",
    shop: "星辰**(北美)-US",
    owner: "林**",
    time: "2026-06-04 06:05",
    status: "已完成",
    score: 68,
    issues: 5,
    summary:
      "广告 ACOS 偏高且存在多次预算打满，自然排名与广告联动不足，建议重构广告活动结构并增加预算冗余。",
    actions: [
      { title: "重构广告活动结构", level: "高", desc: "建议拆分自动 / 手动广告活动，单独管理精准与广泛匹配。" },
      { title: "增加预算冗余", level: "高", desc: "近 30 天预算打满 5 次，存在断量风险，建议提升日预算 30%。" },
      { title: "优化广告位策略", level: "中", desc: "顶部搜索结果广告位 ACOS 偏高，建议下调溢价比例。" },
    ],
    metrics: [
      { label: "ACOS", value: "39.7%", healthy: false },
      { label: "TACOS", value: "16.4%", healthy: false },
      { label: "CTR", value: "1.58%", healthy: true },
      { label: "CVR", value: "4.6%", healthy: true },
      { label: "预算打满", value: "5 次", healthy: false },
      { label: "无效搜索词", value: "23 个", healthy: false },
    ],
  },
]

export const pushChannels = [
  { key: "feishu", label: "飞书" },
  { key: "dingtalk", label: "钉钉" },
  { key: "wechat", label: "企业微信" },
] as const
