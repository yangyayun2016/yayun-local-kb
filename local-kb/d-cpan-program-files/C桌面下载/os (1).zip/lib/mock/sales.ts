export const salesKpis = [
  { label: "销售额 ($)", value: "47,568", delta: 18.4 },
  { label: "销量", value: "1,024", delta: 12.7 },
  { label: "订单数", value: "936", delta: 9.2 },
  { label: "客单价 ($)", value: "50.82", delta: 6.1 },
  { label: "退款率", value: "2.3%", delta: -0.4, lowerIsBetter: true },
  { label: "毛利率", value: "34.6%", delta: 2.1 },
]

// 近 14 天销售额
export const salesTrend = [
  { date: "06-01", sales: 2980, orders: 61 },
  { date: "06-02", sales: 3120, orders: 64 },
  { date: "06-03", sales: 2760, orders: 57 },
  { date: "06-04", sales: 3460, orders: 71 },
  { date: "06-05", sales: 3890, orders: 80 },
  { date: "06-06", sales: 3540, orders: 73 },
  { date: "06-07", sales: 4120, orders: 85 },
  { date: "06-08", sales: 3980, orders: 82 },
  { date: "06-09", sales: 3650, orders: 75 },
  { date: "06-10", sales: 4380, orders: 90 },
  { date: "06-11", sales: 4760, orders: 98 },
  { date: "06-12", sales: 4210, orders: 86 },
  { date: "06-13", sales: 4520, orders: 93 },
  { date: "06-14", sales: 4880, orders: 100 },
]

// 店铺销售占比
export const shopShare = [
  { name: "星辰(北美)-US", value: 47568, color: "#1677ff" },
  { name: "晨光(欧洲)-DE", value: 21330, color: "#52c41a" },
  { name: "远帆(日本)-JP", value: 9860, color: "#faad14" },
  { name: "其他", value: 4200, color: "#cbd5e1" },
]

export type AsinRow = {
  asin: string
  name: string
  shop: string
  sales: string
  qty: number
  orders: number
  price: string
  margin: string
  status: "在售" | "断货预警" | "已停售"
}

export const asinRows: AsinRow[] = [
  { asin: "B0CX1234AA", name: "便携无线榨汁杯 380ml", shop: "星辰-US", sales: "$12,480", qty: 312, orders: 298, price: "$39.99", margin: "38.2%", status: "在售" },
  { asin: "B0CX5678BB", name: "桌面无线充电器 15W", shop: "星辰-US", sales: "$9,860", qty: 246, orders: 240, price: "$40.10", margin: "31.5%", status: "在售" },
  { asin: "B0CX9012CC", name: "宠物智能饮水机 2.5L", shop: "晨光-DE", sales: "$8,420", qty: 168, orders: 165, price: "$50.12", margin: "42.0%", status: "断货预警" },
  { asin: "B0CX3456DD", name: "折叠蓝牙键盘", shop: "晨光-DE", sales: "$6,210", qty: 134, orders: 130, price: "$46.34", margin: "29.8%", status: "在售" },
  { asin: "B0CX7890EE", name: "便携咖啡研磨机", shop: "远帆-JP", sales: "$5,180", qty: 98, orders: 95, price: "$52.86", margin: "35.4%", status: "在售" },
  { asin: "B0CX2468FF", name: "智能体脂秤", shop: "远帆-JP", sales: "$3,420", qty: 76, orders: 74, price: "$45.00", margin: "27.6%", status: "已停售" },
]
