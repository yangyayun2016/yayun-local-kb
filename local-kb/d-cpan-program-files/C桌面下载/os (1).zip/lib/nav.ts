import {
  LayoutGrid,
  TrendingUp,
  Megaphone,
  Package,
  Search,
  Warehouse,
  Truck,
  ShoppingCart,
  Wallet,
  Users,
  Bot,
  MessageSquareText,
  Wrench,
  Settings,
  type LucideIcon,
} from "lucide-react"

export type NavItem = {
  title: string
  href: string
  icon: LucideIcon
  badge?: string
}

export const navItems: NavItem[] = [
  { title: "工作台", href: "/", icon: LayoutGrid },
  { title: "销售中心", href: "/sales", icon: TrendingUp },
  { title: "广告中心", href: "/ads", icon: Megaphone },
  { title: "商品中心", href: "/products", icon: Package },
  { title: "选品中心", href: "/selection", icon: Search },
  { title: "库存货件", href: "/inventory", icon: Warehouse },
  { title: "物流中心", href: "/logistics", icon: Truck },
  { title: "采购中心", href: "/purchase", icon: ShoppingCart },
  { title: "财务中心", href: "/finance", icon: Wallet },
  { title: "团队管理", href: "/team", icon: Users },
  { title: "Agent 中心", href: "/agent", icon: Bot, badge: "AI" },
  { title: "数据助手", href: "/assistant", icon: MessageSquareText },
  { title: "工具箱", href: "/tools", icon: Wrench },
  { title: "系统设置", href: "/settings", icon: Settings },
]

export function findNav(pathname: string): NavItem | undefined {
  if (pathname === "/") return navItems[0]
  return navItems.find((i) => i.href !== "/" && pathname.startsWith(i.href))
}
