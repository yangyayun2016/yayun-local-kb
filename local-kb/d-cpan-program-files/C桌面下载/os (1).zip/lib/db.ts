import mysql from "mysql2/promise"
import { hashPassword } from "@/lib/auth/password"

// 连接天机同一个腾讯云 MySQL（tianji 库）。共享 users 表，仅新增列。
let pool: mysql.Pool | null = null

export function getPool(): mysql.Pool {
  if (!pool) {
    pool = mysql.createPool({
      host: process.env.MYSQL_HOST,
      port: Number(process.env.MYSQL_PORT || 3306),
      user: process.env.MYSQL_USER,
      password: process.env.MYSQL_PASSWORD,
      database: process.env.MYSQL_DATABASE,
      waitForConnections: true,
      connectionLimit: 5,
      charset: "utf8mb4",
      timezone: "+08:00",
    })
  }
  return pool
}

export async function query<T = any>(sql: string, params: any[] = []): Promise<T[]> {
  const [rows] = await getPool().execute(sql, params)
  return rows as T[]
}

export async function execute(sql: string, params: any[] = []): Promise<mysql.ResultSetHeader> {
  const [res] = await getPool().execute(sql, params)
  return res as mysql.ResultSetHeader
}

// ── Schema：幂等，首次请求惰性执行一次 ──────────────────────────────
let schemaReady: Promise<void> | null = null

export function ensureSchema(): Promise<void> {
  if (!schemaReady) {
    schemaReady = doEnsureSchema().catch((e) => {
      schemaReady = null // 失败后允许下次请求重试
      throw e
    })
  }
  return schemaReady
}

async function doEnsureSchema(): Promise<void> {
  const pool = getPool()

  // 防御：共享库里天机已有 users 表；若不存在（独立部署）则建最小可用表
  await pool.query(`CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login_at TIMESTAMP NULL
  ) DEFAULT CHARSET=utf8mb4`)

  // TIANJIOS 三级角色所需的新增列（加法、幂等；MySQL8 无 IF NOT EXISTS，重复列错误吞掉）
  const migrations = [
    "ALTER TABLE users ADD COLUMN role VARCHAR(20) DEFAULT NULL",
    "ALTER TABLE users ADD COLUMN parent_id INT DEFAULT NULL",
    "ALTER TABLE users ADD COLUMN permissions JSON DEFAULT NULL",
    "ALTER TABLE users ADD COLUMN status VARCHAR(20) NOT NULL DEFAULT 'active'",
    "ALTER TABLE users ADD COLUMN display_name VARCHAR(100) DEFAULT NULL",
    // 天机老库可能尚未加 password_hash（无密码登录时期），这里兜底
    "ALTER TABLE users ADD COLUMN password_hash VARCHAR(255) DEFAULT NULL",
  ]
  for (const m of migrations) {
    try {
      await pool.query(m)
    } catch {
      /* 列已存在，忽略 */
    }
  }

  await seedSuperAdmin()
}

async function seedSuperAdmin(): Promise<void> {
  const username = (process.env.SUPER_ADMIN_USERNAME || "admin").trim()
  const password = process.env.SUPER_ADMIN_PASSWORD || "admin123456"

  const rows = await query<{ id: number; role: string | null; password_hash: string | null }>(
    "SELECT id, role, password_hash FROM users WHERE username = ? LIMIT 1",
    [username],
  )

  if (rows.length === 0) {
    await execute(
      "INSERT INTO users (username, password_hash, role, status, display_name) VALUES (?, ?, 'admin', 'active', ?)",
      [username, hashPassword(password), "超级管理员"],
    )
    return
  }

  // 已存在（可能是天机侧用户）：提升为 admin，且若从未设密码则补设为引导密码
  const u = rows[0]
  const sets: string[] = []
  const args: any[] = []
  if (u.role !== "admin") {
    sets.push("role = 'admin'")
  }
  if (!u.password_hash) {
    sets.push("password_hash = ?")
    args.push(hashPassword(password))
  }
  if (sets.length) {
    args.push(u.id)
    await execute(`UPDATE users SET ${sets.join(", ")} WHERE id = ?`, args)
  }
}
