"use client"

import { useCallback, useEffect, useState } from "react"
import { Users, Plus, RotateCcw, Ban, CheckCircle2, ShieldCheck } from "lucide-react"
import { PageHeader } from "@/components/ui/page-header"
import { Button } from "@/components/ui/button"
import { useSession } from "@/components/providers/session-provider"
import { MODULES } from "@/lib/auth/modules"

type Member = {
  id: number
  username: string
  displayName: string
  status: string
  lastLoginAt: string | null
  permissions: string[]
}

export default function TeamPage() {
  const user = useSession()
  if (user.role === "admin") return <BossManager />
  if (user.role === "boss") return <OperatorManager />
  return (
    <div>
      <PageHeader title="团队管理" description="当前角色无团队管理权限" />
    </div>
  )
}

// ── 超级管理员：管理老板账号 ──────────────────────────────────────────
function BossManager() {
  const { list, loading, err, reload } = useMembers("/api/admin/users", "bosses")
  const [form, setForm] = useState({ username: "", displayName: "", password: "" })
  const [busy, setBusy] = useState(false)
  const [formErr, setFormErr] = useState("")

  async function create() {
    setFormErr("")
    if (!form.username || !form.password) return setFormErr("用户名和初始密码必填")
    setBusy(true)
    const res = await fetch("/api/admin/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    })
    setBusy(false)
    const data = await res.json().catch(() => ({}))
    if (!res.ok) return setFormErr(data?.error || "创建失败")
    setForm({ username: "", displayName: "", password: "" })
    reload()
  }

  return (
    <div>
      <PageHeader title="团队管理" description="超级管理员 · 分配与管理老板账号" />

      <Section title="新建老板账号" icon={ShieldCheck}>
        <div className="flex flex-wrap items-end gap-3">
          <Field label="用户名" value={form.username} onChange={(v) => setForm({ ...form, username: v })} />
          <Field label="显示名（可选）" value={form.displayName} onChange={(v) => setForm({ ...form, displayName: v })} />
          <Field label="初始密码" type="password" value={form.password} onChange={(v) => setForm({ ...form, password: v })} />
          <Button onClick={create} disabled={busy} className="bg-brand text-white hover:bg-brand/90">
            <Plus className="h-4 w-4" /> {busy ? "创建中…" : "创建老板"}
          </Button>
        </div>
        {formErr && <p className="mt-2 text-sm text-destructive">{formErr}</p>}
      </Section>

      <MemberTable
        title="老板账号列表"
        list={list}
        loading={loading}
        err={err}
        showPermissions={false}
        onReload={reload}
        patchBase="/api/admin/users"
      />
    </div>
  )
}

// ── 老板：管理运营账号 + 模块权限 ─────────────────────────────────────
function OperatorManager() {
  const { list, loading, err, reload } = useMembers("/api/team/members", "operators")
  const [form, setForm] = useState<{ username: string; displayName: string; password: string; permissions: string[] }>({
    username: "",
    displayName: "",
    password: "",
    permissions: [],
  })
  const [busy, setBusy] = useState(false)
  const [formErr, setFormErr] = useState("")

  function togglePerm(key: string) {
    setForm((f) => ({
      ...f,
      permissions: f.permissions.includes(key)
        ? f.permissions.filter((k) => k !== key)
        : [...f.permissions, key],
    }))
  }

  async function create() {
    setFormErr("")
    if (!form.username || !form.password) return setFormErr("用户名和初始密码必填")
    setBusy(true)
    const res = await fetch("/api/team/members", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    })
    setBusy(false)
    const data = await res.json().catch(() => ({}))
    if (!res.ok) return setFormErr(data?.error || "创建失败")
    setForm({ username: "", displayName: "", password: "", permissions: [] })
    reload()
  }

  return (
    <div>
      <PageHeader title="团队管理" description="老板 · 创建运营账号并分配模块权限" />

      <Section title="新建运营账号" icon={Users}>
        <div className="flex flex-wrap items-end gap-3">
          <Field label="用户名" value={form.username} onChange={(v) => setForm({ ...form, username: v })} />
          <Field label="显示名（可选）" value={form.displayName} onChange={(v) => setForm({ ...form, displayName: v })} />
          <Field label="初始密码" type="password" value={form.password} onChange={(v) => setForm({ ...form, password: v })} />
        </div>
        <p className="mb-2 mt-4 text-sm font-medium text-foreground">授权可访问模块</p>
        <PermissionPicker selected={form.permissions} onToggle={togglePerm} />
        <div className="mt-4">
          <Button onClick={create} disabled={busy} className="bg-brand text-white hover:bg-brand/90">
            <Plus className="h-4 w-4" /> {busy ? "创建中…" : "创建运营"}
          </Button>
        </div>
        {formErr && <p className="mt-2 text-sm text-destructive">{formErr}</p>}
      </Section>

      <MemberTable
        title="运营账号列表"
        list={list}
        loading={loading}
        err={err}
        showPermissions
        onReload={reload}
        patchBase="/api/team/members"
      />
    </div>
  )
}

// ── 通用列表 + 操作 ───────────────────────────────────────────────────
function MemberTable({
  title,
  list,
  loading,
  err,
  showPermissions,
  onReload,
  patchBase,
}: {
  title: string
  list: Member[]
  loading: boolean
  err: string
  showPermissions: boolean
  onReload: () => void
  patchBase: string
}) {
  const [editing, setEditing] = useState<Member | null>(null)

  async function patch(id: number, body: any) {
    const res = await fetch(`${patchBase}/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    })
    if (!res.ok) {
      const data = await res.json().catch(() => ({}))
      alert(data?.error || "操作失败")
      return
    }
    onReload()
  }

  async function resetPwd(m: Member) {
    const pwd = window.prompt(`为「${m.displayName}」设置新密码（至少 6 位）`)
    if (!pwd) return
    if (pwd.length < 6) return alert("密码至少 6 位")
    await patch(m.id, { password: pwd })
    alert("密码已重置")
  }

  return (
    <div className="mt-5 rounded-lg border border-border bg-card">
      <div className="border-b border-border px-4 py-3 text-sm font-medium text-foreground">{title}</div>
      {err && <p className="px-4 py-3 text-sm text-destructive">{err}</p>}
      {loading ? (
        <p className="px-4 py-6 text-sm text-muted-foreground">加载中…</p>
      ) : list.length === 0 ? (
        <p className="px-4 py-6 text-sm text-muted-foreground">暂无账号</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-left text-xs text-muted-foreground">
                <th className="px-4 py-2 font-medium">用户名</th>
                <th className="px-4 py-2 font-medium">显示名</th>
                {showPermissions && <th className="px-4 py-2 font-medium">授权模块</th>}
                <th className="px-4 py-2 font-medium">状态</th>
                <th className="px-4 py-2 font-medium">最近登录</th>
                <th className="px-4 py-2 font-medium">操作</th>
              </tr>
            </thead>
            <tbody>
              {list.map((m) => (
                <tr key={m.id} className="border-b border-border/60 last:border-0">
                  <td className="px-4 py-2.5 font-medium text-foreground">{m.username}</td>
                  <td className="px-4 py-2.5 text-foreground/80">{m.displayName}</td>
                  {showPermissions && (
                    <td className="px-4 py-2.5">
                      <div className="flex flex-wrap gap-1">
                        {m.permissions.length === 0 ? (
                          <span className="text-xs text-muted-foreground">无</span>
                        ) : (
                          m.permissions.map((k) => (
                            <span key={k} className="rounded bg-muted px-1.5 py-0.5 text-[11px] text-foreground/70">
                              {MODULES.find((x) => x.key === k)?.title || k}
                            </span>
                          ))
                        )}
                      </div>
                    </td>
                  )}
                  <td className="px-4 py-2.5">
                    {m.status === "disabled" ? (
                      <span className="rounded bg-destructive/10 px-1.5 py-0.5 text-[11px] text-destructive">已禁用</span>
                    ) : (
                      <span className="rounded bg-emerald-500/10 px-1.5 py-0.5 text-[11px] text-emerald-600">正常</span>
                    )}
                  </td>
                  <td className="px-4 py-2.5 text-xs text-muted-foreground">{m.lastLoginAt || "从未"}</td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center gap-1">
                      {showPermissions && (
                        <Button size="xs" variant="outline" onClick={() => setEditing(m)}>
                          权限
                        </Button>
                      )}
                      <Button size="xs" variant="outline" onClick={() => resetPwd(m)}>
                        <RotateCcw className="h-3 w-3" /> 重置密码
                      </Button>
                      {m.status === "disabled" ? (
                        <Button size="xs" variant="outline" onClick={() => patch(m.id, { status: "active" })}>
                          <CheckCircle2 className="h-3 w-3" /> 启用
                        </Button>
                      ) : (
                        <Button size="xs" variant="destructive" onClick={() => patch(m.id, { status: "disabled" })}>
                          <Ban className="h-3 w-3" /> 禁用
                        </Button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {editing && (
        <PermissionModal
          member={editing}
          onClose={() => setEditing(null)}
          onSave={async (perms) => {
            await patch(editing.id, { permissions: perms })
            setEditing(null)
          }}
        />
      )}
    </div>
  )
}

function PermissionModal({
  member,
  onClose,
  onSave,
}: {
  member: Member
  onClose: () => void
  onSave: (perms: string[]) => void
}) {
  const [selected, setSelected] = useState<string[]>(member.permissions)
  function toggle(key: string) {
    setSelected((s) => (s.includes(key) ? s.filter((k) => k !== key) : [...s, key]))
  }
  return (
    <div className="fixed inset-0 z-30 flex items-center justify-center bg-black/30 p-4" onClick={onClose}>
      <div className="w-full max-w-md rounded-lg border border-border bg-card p-5 shadow-xl" onClick={(e) => e.stopPropagation()}>
        <h3 className="mb-1 text-base font-semibold text-foreground">编辑权限 · {member.displayName}</h3>
        <p className="mb-4 text-sm text-muted-foreground">勾选该运营可访问的模块</p>
        <PermissionPicker selected={selected} onToggle={toggle} />
        <div className="mt-5 flex justify-end gap-2">
          <Button variant="outline" onClick={onClose}>
            取消
          </Button>
          <Button className="bg-brand text-white hover:bg-brand/90" onClick={() => onSave(selected)}>
            保存
          </Button>
        </div>
      </div>
    </div>
  )
}

function PermissionPicker({ selected, onToggle }: { selected: string[]; onToggle: (k: string) => void }) {
  return (
    <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
      {MODULES.map((m) => {
        const on = selected.includes(m.key)
        return (
          <button
            key={m.key}
            type="button"
            onClick={() => onToggle(m.key)}
            className={
              "flex items-center gap-2 rounded-md border px-3 py-2 text-sm transition-colors " +
              (on ? "border-brand bg-brand/10 text-brand" : "border-border text-foreground/70 hover:bg-muted")
            }
          >
            <span className={"h-3.5 w-3.5 shrink-0 rounded-sm border " + (on ? "border-brand bg-brand" : "border-muted-foreground/40")} />
            {m.title}
          </button>
        )
      })}
    </div>
  )
}

function Section({ title, icon: Icon, children }: { title: string; icon: any; children: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-border bg-card p-4">
      <div className="mb-3 flex items-center gap-2 text-sm font-medium text-foreground">
        <Icon className="h-4 w-4 text-brand" /> {title}
      </div>
      {children}
    </div>
  )
}

function Field({
  label,
  value,
  onChange,
  type = "text",
}: {
  label: string
  value: string
  onChange: (v: string) => void
  type?: string
}) {
  return (
    <div>
      <label className="mb-1 block text-xs text-muted-foreground">{label}</label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-9 w-44 rounded-md border border-border bg-page px-3 text-sm text-foreground outline-none focus:border-brand focus:bg-card"
      />
    </div>
  )
}

// 拉取成员列表的通用 hook
function useMembers(url: string, key: string) {
  const [list, setList] = useState<Member[]>([])
  const [loading, setLoading] = useState(true)
  const [err, setErr] = useState("")

  const reload = useCallback(async () => {
    setLoading(true)
    setErr("")
    try {
      const res = await fetch(url)
      const data = await res.json().catch(() => ({}))
      if (!res.ok) {
        setErr(data?.error || "加载失败")
        setList([])
      } else {
        setList((data?.[key] as Member[]) || [])
      }
    } catch {
      setErr("网络错误")
    } finally {
      setLoading(false)
    }
  }, [url, key])

  useEffect(() => {
    reload()
  }, [reload])

  return { list, loading, err, reload }
}
