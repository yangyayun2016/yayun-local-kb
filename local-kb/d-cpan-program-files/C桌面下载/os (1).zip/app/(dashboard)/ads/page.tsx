import { AdsCenter } from "@/components/ads/ads-center"

export default function AdsPage() {
  return <AdsCenter />
}
