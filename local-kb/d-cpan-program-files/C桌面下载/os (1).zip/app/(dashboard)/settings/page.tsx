import { Store, Bell, Bot, ShieldCheck, Plug, Check } from "lucide-react"
import { PageHeader } from "@/components/ui/page-header"

const shops = [
  { name: "星辰**(北美)-US", site: "Amazon US", status: "已授权", date: "2026-05-01" },
  { name: "晨光**(欧洲)-DE", site: "Amazon DE", status: "已授权", date: "2026-05-12" },
  { name: "远帆**(日本)-JP", site: "Amazon JP", status: "授权过期", date: "2026-06-20" },
]

const toggles = [
  { label: "广告异常每日推送", desc: "ACOS / 花费异常时通过站内信与邮件提醒", on: true },
  { label: "库存断货预警", desc: "预计可售天数低于阈值时提醒补货", on: true },
  { label: "差评实时提醒", desc: "收到 3 星及以下评价时即时推送", on: false },
  { label: "AI 决策建议日报", desc: "每日 09:00 推送天机引擎经营建议", on: true },
]

export default function SettingsPage() {
  return (
    <div>
      <PageHeader title="系统设置" description="账户、店铺授权、通知与 AI 引擎配置" />

      {/* 店铺授权 */}
      <section className="rounded-lg border border-border bg-card shadow-sm">
        <div className="flex items-center gap-2 border-b border-border px-4 py-3">
          <Store className="h-4 w-4 text-brand" />
          <h3 className="text-sm font-semibold text-foreground">店铺授权</h3>
          <button className="ml-auto rounded-md bg-brand px-3 py-1.5 text-xs font-medium text-white hover:bg-brand/90">
            + 授权新店铺
          </button>
        </div>
        <ul className="divide-y divide-border">
          {shops.map((s) => (
            <li key={s.name} className="flex items-center justify-between px-4 py-3">
              <div className="flex items-center gap-3">
                <span className="flex h-9 w-9 items-center justify-center rounded-md bg-brand/10 text-brand">
                  <Plug className="h-4 w-4" />
                </span>
                <div>
                  <p className="text-sm font-medium text-foreground">{s.name}</p>
                  <p className="text-xs text-muted-foreground">{s.site} · 授权日期 {s.date}</p>
                </div>
              </div>
              <span
                className={
                  s.status === "已授权"
                    ? "inline-flex items-center gap-1 rounded bg-up/10 px-2 py-0.5 text-xs font-medium text-up"
                    : "inline-flex items-center gap-1 rounded bg-down/10 px-2 py-0.5 text-xs font-medium text-down"
                }
              >
                {s.status === "已授权" && <Check className="h-3 w-3" />}
                {s.status}
              </span>
            </li>
          ))}
        </ul>
      </section>

      <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-2">
        {/* 通知设置 */}
        <section className="rounded-lg border border-border bg-card shadow-sm">
          <div className="flex items-center gap-2 border-b border-border px-4 py-3">
            <Bell className="h-4 w-4 text-brand" />
            <h3 className="text-sm font-semibold text-foreground">通知设置</h3>
          </div>
          <ul className="divide-y divide-border">
            {toggles.map((t) => (
              <li key={t.label} className="flex items-center justify-between gap-4 px-4 py-3">
                <div>
                  <p className="text-sm font-medium text-foreground">{t.label}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">{t.desc}</p>
                </div>
                <span
                  className={
                    "relative h-5 w-9 shrink-0 rounded-full transition-colors " +
                    (t.on ? "bg-brand" : "bg-border")
                  }
                >
                  <span
                    className={
                      "absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all " +
                      (t.on ? "left-[18px]" : "left-0.5")
                    }
                  />
                </span>
              </li>
            ))}
          </ul>
        </section>

        {/* AI 引擎配置 */}
        <section className="rounded-lg border border-border bg-card shadow-sm">
          <div className="flex items-center gap-2 border-b border-border px-4 py-3">
            <Bot className="h-4 w-4 text-brand" />
            <h3 className="text-sm font-semibold text-foreground">天机 AI 引擎配置</h3>
          </div>
          <div className="space-y-4 p-4">
            <div>
              <label className="text-sm font-medium text-foreground">决策模型</label>
              <select className="mt-1.5 h-9 w-full rounded-md border border-border bg-page px-3 text-sm text-foreground outline-none focus:border-brand">
                <option>天机决策大模型 v2（推荐）</option>
                <option>标准分析模型</option>
                <option>快速响应模型</option>
              </select>
            </div>
            <div>
              <label className="text-sm font-medium text-foreground">建议激进程度</label>
              <select className="mt-1.5 h-9 w-full rounded-md border border-border bg-page px-3 text-sm text-foreground outline-none focus:border-brand">
                <option>稳健</option>
                <option>均衡</option>
                <option>激进</option>
              </select>
            </div>
            <div className="flex items-start gap-2 rounded-md bg-brand/5 p-3">
              <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-brand" />
              <p className="text-xs leading-relaxed text-muted-foreground">
                所有 AI 决策建议仅作辅助参考，关键操作（调价、补货、广告投放）默认需人工确认后执行。
              </p>
            </div>
            <button className="w-full rounded-md bg-brand py-2 text-sm font-medium text-white hover:bg-brand/90">
              保存配置
            </button>
          </div>
        </section>
      </div>
    </div>
  )
}
