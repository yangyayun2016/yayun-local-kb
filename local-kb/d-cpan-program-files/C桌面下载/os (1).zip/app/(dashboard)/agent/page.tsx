import { Bot } from "lucide-react"
import { PlaceholderPage } from "@/components/layout/placeholder-page"

export default function AgentPage() {
  return (
    <PlaceholderPage
      title="Agent 中心"
      icon={Bot}
      modules={["广告优化 Agent", "补货决策 Agent", "选品分析 Agent", "客服自动回复 Agent", "Agent 编排", "运行记录"]}
    />
  )
}
