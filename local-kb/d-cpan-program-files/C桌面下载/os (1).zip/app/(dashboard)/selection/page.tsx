import { Search } from "lucide-react"
import { PlaceholderPage } from "@/components/layout/placeholder-page"

export default function SelectionPage() {
  return (
    <PlaceholderPage
      title="选品中心"
      icon={Search}
      modules={["蓝海类目挖掘", "竞品监控", "市场趋势分析", "AI 选品推荐", "关键词调研", "选品库"]}
    />
  )
}
