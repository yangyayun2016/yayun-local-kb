import { PageHeader } from "@/components/ui/page-header"
import { KpiCards } from "@/components/workbench/kpi-cards"
import { TrendChart } from "@/components/workbench/trend-chart"
import { TodoPanel, AiInsightPanel } from "@/components/workbench/side-panels"

export default function WorkbenchPage() {
  return (
    <div>
      <PageHeader
        title="工作台"
        description="欢迎回来，飞** · 今日经营概览（数据截至 2026-06-11）"
      />

      <KpiCards />

      <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <TrendChart />
        </div>
        <TodoPanel />
      </div>

      <div className="mt-4">
        <AiInsightPanel />
      </div>
    </div>
  )
}
