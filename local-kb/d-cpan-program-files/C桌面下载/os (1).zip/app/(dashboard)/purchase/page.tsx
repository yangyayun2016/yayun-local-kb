import { ShoppingCart } from "lucide-react"
import { PlaceholderPage } from "@/components/layout/placeholder-page"

export default function PurchasePage() {
  return (
    <PlaceholderPage
      title="采购中心"
      icon={ShoppingCart}
      modules={["采购单管理", "供应商管理", "采购计划", "到货验收", "采购对账", "成本核算"]}
    />
  )
}
