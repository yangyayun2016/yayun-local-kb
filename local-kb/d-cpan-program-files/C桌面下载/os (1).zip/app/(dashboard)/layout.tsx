import type { ReactNode } from "react"
import { redirect } from "next/navigation"
import { headers } from "next/headers"
import { AppShell } from "@/components/layout/app-shell"
import { SessionProvider } from "@/components/providers/session-provider"
import { getCurrentUser, toPublicUser } from "@/lib/auth/users"
import { canAccess } from "@/lib/auth/modules"

// 依赖会话/权限，纯运行时渲染，禁止构建期预渲染（否则会去连库）
export const dynamic = "force-dynamic"

export default async function DashboardLayout({ children }: { children: ReactNode }) {
  const user = await getCurrentUser()
  if (!user) redirect("/login")

  const publicUser = toPublicUser(user)

  // 服务端权限闸口：按当前路径 + DB 实时权限判定，越权重定向回工作台
  const pathname = (await headers()).get("x-pathname") || "/"
  if (!canAccess({ role: publicUser.role, permissions: publicUser.permissions }, pathname)) {
    redirect("/")
  }

  return (
    <SessionProvider user={publicUser}>
      <AppShell>{children}</AppShell>
    </SessionProvider>
  )
}
