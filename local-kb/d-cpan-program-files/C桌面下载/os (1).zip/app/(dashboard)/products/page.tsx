import { Package } from "lucide-react"
import { PlaceholderPage } from "@/components/layout/placeholder-page"

export default function ProductsPage() {
  return (
    <PlaceholderPage
      title="商品中心"
      icon={Package}
      modules={["商品列表", "Listing 管理", "多平台刊登", "A+ 页面", "评价管理", "商品分组"]}
    />
  )
}
