import { Truck } from "lucide-react"
import { PlaceholderPage } from "@/components/layout/placeholder-page"

export default function LogisticsPage() {
  return (
    <PlaceholderPage
      title="物流中心"
      icon={Truck}
      modules={["头程物流", "物流商管理", "运费核算", "在途追踪", "清关管理", "物流时效分析"]}
    />
  )
}
