import { PageHeader } from "@/components/ui/page-header"
import { ProfitCalculator } from "@/components/tools/profit-calculator"
import { LqsScore } from "@/components/tools/lqs-score"
import { TqsScore } from "@/components/tools/tqs-score"

export default function ToolsPage() {
  return (
    <div className="space-y-8">
      <PageHeader title="工具箱" description="亚马逊运营常用工具集合" />

      <section>
        <div className="mb-3">
          <h2 className="text-base font-semibold text-foreground">亚马逊利润率计算器</h2>
          <p className="text-sm text-muted-foreground">
            支持美国 SC、美国 VC、欧洲 SC、欧洲 VC 四种模式，完全复刻利润率项目表的测算逻辑
          </p>
        </div>
        <ProfitCalculator />
      </section>

      <section>
        <div className="mb-3">
          <h2 className="text-base font-semibold text-foreground">LQS 打分（CDQ v3 综合数据质量）</h2>
          <p className="text-sm text-muted-foreground">
            依据亚马逊官方 CDQ v3 算法，对 listing 7 大维度综合打分：抓取前台数据与后台 V3 属性数据，自动诊断扣分点并生成优化 TODOLIST
          </p>
        </div>
        <LqsScore />
      </section>

      <section>
        <div className="mb-3">
          <h2 className="text-base font-semibold text-foreground">TQS 标题质量诊断（A / B / C 评分）</h2>
          <p className="text-sm text-muted-foreground">
            采用 TQS（Title Quality Score）逻辑，对标题完整性、准确性、篇幅、大小写、关键词标注、冗余度、内容限制性逐项诊断打分
          </p>
        </div>
        <TqsScore />
      </section>
    </div>
  )
}
