import { Wallet } from "lucide-react"
import { PlaceholderPage } from "@/components/layout/placeholder-page"

export default function FinancePage() {
  return (
    <PlaceholderPage
      title="财务中心"
      icon={Wallet}
      modules={["利润报表", "费用明细", "回款管理", "成本分摊", "汇率管理", "财务对账"]}
    />
  )
}
