import { MessageSquareText } from "lucide-react"
import { PlaceholderPage } from "@/components/layout/placeholder-page"

export default function AssistantPage() {
  return (
    <PlaceholderPage
      title="数据助手"
      icon={MessageSquareText}
      modules={["自然语言问数", "智能报表生成", "经营诊断", "异常预警", "对话式分析", "数据看板订阅"]}
    />
  )
}
