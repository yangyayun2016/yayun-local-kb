import { Warehouse } from "lucide-react"
import { PlaceholderPage } from "@/components/layout/placeholder-page"

export default function InventoryPage() {
  return (
    <PlaceholderPage
      title="库存货件"
      icon={Warehouse}
      modules={["FBA 库存", "海外仓库存", "补货计划", "库存预警", "货件管理", "库龄分析"]}
    />
  )
}
