"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"

export default function LoginPage() {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError("")
    setLoading(true)
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) {
        setError(data?.error || "登录失败")
        setLoading(false)
        return
      }
      // 硬跳转：确保带上刚下发的 cookie 重新走中间件（iframe 预览下比 router.replace 更稳）
      window.location.href = "/"
    } catch {
      setError("网络错误，请稍后重试")
      setLoading(false)
    }
  }

  return (
    <div className="w-full max-w-sm rounded-xl border border-border bg-card p-8 shadow-sm">
      <div className="mb-6 flex items-center gap-2">
        <div className="flex h-8 w-8 items-center justify-center rounded-md bg-brand text-sm font-bold text-white">
          天
        </div>
        <span className="text-lg font-semibold tracking-tight text-foreground">
          天机 <span className="text-brand">OS</span>
        </span>
      </div>
      <h1 className="mb-1 text-xl font-semibold text-foreground">登录</h1>
      <p className="mb-6 text-sm text-muted-foreground">请输入账号密码进入 天机 OS 平台</p>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="mb-1.5 block text-sm font-medium text-foreground">用户名</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            autoComplete="username"
            className="h-10 w-full rounded-md border border-border bg-page px-3 text-sm text-foreground outline-none focus:border-brand focus:bg-card"
            placeholder="请输入用户名"
          />
        </div>
        <div>
          <label className="mb-1.5 block text-sm font-medium text-foreground">密码</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="current-password"
            className="h-10 w-full rounded-md border border-border bg-page px-3 text-sm text-foreground outline-none focus:border-brand focus:bg-card"
            placeholder="请输入密码"
          />
        </div>

        {error && (
          <p className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">{error}</p>
        )}

        <Button type="submit" disabled={loading} size="lg" className="w-full bg-brand text-white [a]:hover:bg-brand/90 hover:bg-brand/90">
          {loading ? "登录中…" : "登录"}
        </Button>
      </form>

      <p className="mt-6 text-center text-xs text-muted-foreground">
        账号由管理员或老板分配，如需开通请联系管理员
      </p>
    </div>
  )
}
