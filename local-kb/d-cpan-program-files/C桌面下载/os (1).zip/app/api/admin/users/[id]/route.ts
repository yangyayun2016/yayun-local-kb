import { NextResponse } from "next/server"
import { findById, getCurrentUser, resetPassword, setStatus } from "@/lib/auth/users"

// 仅超级管理员：改老板 status / 重置老板密码
export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "未登录" }, { status: 401 })
  if (me.role !== "admin") return NextResponse.json({ error: "无权限" }, { status: 403 })

  const { id } = await ctx.params
  const targetId = Number(id)
  const target = await findById(targetId)
  if (!target || target.role !== "boss") {
    return NextResponse.json({ error: "目标老板账号不存在" }, { status: 404 })
  }

  let body: any
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: "请求格式错误" }, { status: 400 })
  }

  if (typeof body?.status === "string") {
    const status = body.status === "disabled" ? "disabled" : "active"
    await setStatus(targetId, status)
  }
  if (typeof body?.password === "string" && body.password) {
    if (body.password.length < 6) {
      return NextResponse.json({ error: "新密码至少 6 位" }, { status: 400 })
    }
    await resetPassword(targetId, body.password)
  }

  return NextResponse.json({ ok: true })
}
