import { NextResponse } from "next/server"
import { createUser, getCurrentUser, listByRole, usernameExists } from "@/lib/auth/users"

// 仅超级管理员：管理「老板」账号
export async function GET() {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "未登录" }, { status: 401 })
  if (me.role !== "admin") return NextResponse.json({ error: "无权限" }, { status: 403 })
  const bosses = await listByRole("boss")
  return NextResponse.json({ bosses })
}

export async function POST(req: Request) {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "未登录" }, { status: 401 })
  if (me.role !== "admin") return NextResponse.json({ error: "无权限" }, { status: 403 })

  let body: any
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: "请求格式错误" }, { status: 400 })
  }
  const username = String(body?.username || "").trim()
  const password = String(body?.password || "")
  const displayName = String(body?.displayName || "").trim() || null

  if (!username || !password) {
    return NextResponse.json({ error: "用户名和初始密码必填" }, { status: 400 })
  }
  if (password.length < 6) {
    return NextResponse.json({ error: "初始密码至少 6 位" }, { status: 400 })
  }
  if (await usernameExists(username)) {
    return NextResponse.json({ error: "用户名已存在" }, { status: 409 })
  }

  const id = await createUser({
    username,
    password,
    role: "boss",
    parentId: me.id,
    displayName,
  })
  return NextResponse.json({ ok: true, id })
}
