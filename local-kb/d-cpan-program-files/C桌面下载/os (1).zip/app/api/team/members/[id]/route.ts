import { NextResponse } from "next/server"
import {
  findById,
  getCurrentUser,
  resetPassword,
  setStatus,
  updatePermissions,
} from "@/lib/auth/users"
import { sanitizePermissions } from "@/lib/auth/modules"

// 仅老板：改自己名下运营的权限 / status / 重置密码
export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "未登录" }, { status: 401 })
  if (me.role !== "boss") return NextResponse.json({ error: "无权限" }, { status: 403 })

  const { id } = await ctx.params
  const targetId = Number(id)
  const target = await findById(targetId)
  // 层级校验：只能改自己名下的运营
  if (!target || target.role !== "operator" || target.parent_id !== me.id) {
    return NextResponse.json({ error: "目标运营账号不存在或无权操作" }, { status: 404 })
  }

  let body: any
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: "请求格式错误" }, { status: 400 })
  }

  if (Array.isArray(body?.permissions)) {
    await updatePermissions(targetId, sanitizePermissions(body.permissions))
  }
  if (typeof body?.status === "string") {
    await setStatus(targetId, body.status === "disabled" ? "disabled" : "active")
  }
  if (typeof body?.password === "string" && body.password) {
    if (body.password.length < 6) {
      return NextResponse.json({ error: "新密码至少 6 位" }, { status: 400 })
    }
    await resetPassword(targetId, body.password)
  }

  return NextResponse.json({ ok: true })
}
