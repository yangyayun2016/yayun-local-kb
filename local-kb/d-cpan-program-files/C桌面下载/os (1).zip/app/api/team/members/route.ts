import { NextResponse } from "next/server"
import { createUser, getCurrentUser, listByRole, usernameExists } from "@/lib/auth/users"
import { sanitizePermissions } from "@/lib/auth/modules"

// 仅老板：管理自己名下的「运营」账号
export async function GET() {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "未登录" }, { status: 401 })
  if (me.role !== "boss") return NextResponse.json({ error: "无权限" }, { status: 403 })
  const operators = await listByRole("operator", me.id)
  return NextResponse.json({ operators })
}

export async function POST(req: Request) {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "未登录" }, { status: 401 })
  if (me.role !== "boss") return NextResponse.json({ error: "无权限" }, { status: 403 })

  let body: any
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: "请求格式错误" }, { status: 400 })
  }
  const username = String(body?.username || "").trim()
  const password = String(body?.password || "")
  const displayName = String(body?.displayName || "").trim() || null
  const permissions = sanitizePermissions(body?.permissions)

  if (!username || !password) {
    return NextResponse.json({ error: "用户名和初始密码必填" }, { status: 400 })
  }
  if (password.length < 6) {
    return NextResponse.json({ error: "初始密码至少 6 位" }, { status: 400 })
  }
  if (await usernameExists(username)) {
    return NextResponse.json({ error: "用户名已存在" }, { status: 409 })
  }

  const id = await createUser({
    username,
    password,
    role: "operator",
    parentId: me.id,
    permissions,
    displayName,
  })
  return NextResponse.json({ ok: true, id })
}
