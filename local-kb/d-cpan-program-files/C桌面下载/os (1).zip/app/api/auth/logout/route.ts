import { NextResponse } from "next/server"
import { COOKIE_NAME, isSecureRequest } from "@/lib/auth/session"

export async function POST(req: Request) {
  const secure = isSecureRequest(req)
  const res = NextResponse.json({ ok: true })
  res.cookies.set(COOKIE_NAME, "", {
    httpOnly: true,
    sameSite: secure ? "none" : "lax",
    secure,
    path: "/",
    maxAge: 0,
  })
  return res
}
