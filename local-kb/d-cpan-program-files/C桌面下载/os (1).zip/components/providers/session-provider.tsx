"use client"

import { createContext, useContext, type ReactNode } from "react"
import type { PublicUser } from "@/lib/auth/users"

const SessionContext = createContext<PublicUser | null>(null)

export function SessionProvider({ user, children }: { user: PublicUser; children: ReactNode }) {
  return <SessionContext.Provider value={user}>{children}</SessionContext.Provider>
}

// 当前登录用户（在 (dashboard) 布局内一定非空）
export function useSession(): PublicUser {
  const user = useContext(SessionContext)
  if (!user) {
    throw new Error("useSession 必须在 SessionProvider 内使用")
  }
  return user
}
