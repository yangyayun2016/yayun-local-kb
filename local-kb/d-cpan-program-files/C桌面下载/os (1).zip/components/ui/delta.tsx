import { ArrowDown, ArrowUp } from "lucide-react"
import { cn } from "@/lib/utils"

type DeltaProps = {
  value: number // percentage, e.g. 551.61 or -2.4
  className?: string
  /** when true, a lower value is good (e.g. ACOS / 花费) so colors invert */
  lowerIsBetter?: boolean
}

export function Delta({ value, className, lowerIsBetter = false }: DeltaProps) {
  const isUp = value >= 0
  const good = lowerIsBetter ? !isUp : isUp
  return (
    <span
      className={cn(
        "inline-flex items-center gap-0.5 text-xs font-medium tabular-nums",
        good ? "text-up" : "text-down",
        className,
      )}
    >
      {isUp ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />}
      {Math.abs(value).toFixed(2)}%
    </span>
  )
}
