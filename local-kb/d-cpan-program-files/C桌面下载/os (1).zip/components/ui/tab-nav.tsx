"use client"

import { cn } from "@/lib/utils"

export function TabNav({
  tabs,
  active,
  onChange,
}: {
  tabs: readonly string[]
  active: string
  onChange: (t: string) => void
}) {
  return (
    <div className="no-scrollbar flex items-center gap-6 overflow-x-auto border-b border-border">
      {tabs.map((tab) => {
        const isActive = tab === active
        return (
          <button
            key={tab}
            onClick={() => onChange(tab)}
            className={cn(
              "relative -mb-px shrink-0 whitespace-nowrap border-b-2 px-0.5 pb-3 text-sm transition-colors",
              isActive
                ? "border-brand font-medium text-brand"
                : "border-transparent text-muted-foreground hover:text-foreground",
            )}
          >
            {tab}
          </button>
        )
      })}
    </div>
  )
}
