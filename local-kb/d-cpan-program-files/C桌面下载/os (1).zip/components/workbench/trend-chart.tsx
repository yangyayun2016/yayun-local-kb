"use client"

import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"
import { trendData, trendCompare } from "@/lib/mock/workbench"
import { Delta } from "@/components/ui/delta"

export function TrendChart() {
  return (
    <div className="rounded-lg border border-border bg-card p-4 shadow-sm">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-foreground">业绩走势</h3>
        <div className="flex items-center gap-4 text-xs text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full" style={{ background: "#1677ff" }} />
            今日
          </span>
          <span className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full" style={{ background: "#91caff" }} />
            昨日
          </span>
        </div>
      </div>

      <div className="mt-4 h-56">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={trendData} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
            <defs>
              <linearGradient id="todayFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#1677ff" stopOpacity={0.18} />
                <stop offset="100%" stopColor="#1677ff" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#eef0f3" vertical={false} />
            <XAxis
              dataKey="time"
              tick={{ fontSize: 11, fill: "#94a3b8" }}
              axisLine={false}
              tickLine={false}
              interval={1}
            />
            <YAxis tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false} width={40} />
            <Tooltip
              contentStyle={{
                borderRadius: 8,
                border: "1px solid #e5e7eb",
                fontSize: 12,
                boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
              }}
              labelStyle={{ color: "#64748b" }}
              formatter={(value: number, name: string) => [value, name === "today" ? "今日" : "昨日"]}
            />
            <Area
              type="monotone"
              dataKey="yesterday"
              stroke="#91caff"
              strokeWidth={2}
              fill="none"
              dot={false}
            />
            <Area
              type="monotone"
              dataKey="today"
              stroke="#1677ff"
              strokeWidth={2.5}
              fill="url(#todayFill)"
              dot={false}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* compare */}
      <div className="mt-3 grid grid-cols-3 gap-3 border-t border-border pt-3">
        {trendCompare.map((c) => (
          <div key={c.label} className="text-center">
            <p className="text-xs text-muted-foreground">{c.label}</p>
            <p className="mt-1 text-lg font-semibold tabular-nums text-foreground">{c.value}</p>
            {c.delta !== null && <Delta value={c.delta} className="mt-0.5 justify-center" />}
          </div>
        ))}
      </div>
    </div>
  )
}
