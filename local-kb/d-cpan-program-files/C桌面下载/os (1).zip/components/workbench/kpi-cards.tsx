import { ShoppingBag, DollarSign, Package, Megaphone, type LucideIcon } from "lucide-react"
import { kpis } from "@/lib/mock/workbench"
import { Delta } from "@/components/ui/delta"

const iconMap: Record<string, LucideIcon> = {
  bag: ShoppingBag,
  dollar: DollarSign,
  order: Package,
  ad: Megaphone,
}

export function KpiCards() {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {kpis.map((kpi) => {
        const Icon = iconMap[kpi.icon]
        return (
          <div key={kpi.label} className="rounded-lg border border-border bg-card p-4 shadow-sm">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">{kpi.label}</span>
              <span className="flex h-8 w-8 items-center justify-center rounded-md bg-brand/10 text-brand">
                <Icon className="h-4 w-4" />
              </span>
            </div>
            <div className="mt-3 flex items-end gap-2">
              <span className="text-2xl font-semibold tabular-nums text-foreground">{kpi.today}</span>
              <Delta value={kpi.delta} lowerIsBetter={kpi.lowerIsBetter} className="mb-1" />
            </div>
            <p className="mt-1 text-xs text-muted-foreground">
              昨日 <span className="tabular-nums">{kpi.yesterday}</span>
            </p>
          </div>
        )
      })}
    </div>
  )
}
