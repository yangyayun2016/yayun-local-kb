import { Bot, ChevronRight, Sparkles } from "lucide-react"
import { todos, aiInsights } from "@/lib/mock/workbench"
import { cn } from "@/lib/utils"

const todoStyle: Record<string, string> = {
  warn: "bg-[#faad14]/10 text-[#d48806]",
  danger: "bg-down/10 text-down",
  info: "bg-brand/10 text-brand",
}

export function TodoPanel() {
  return (
    <div className="rounded-lg border border-border bg-card p-4 shadow-sm">
      <h3 className="text-sm font-semibold text-foreground">待办事项</h3>
      <ul className="mt-3 space-y-2">
        {todos.map((t) => (
          <li
            key={t.title}
            className="flex cursor-pointer items-center justify-between rounded-md px-2 py-2 hover:bg-muted"
          >
            <div className="flex items-center gap-2.5">
              <span className={cn("flex h-7 w-9 items-center justify-center rounded text-sm font-semibold tabular-nums", todoStyle[t.type])}>
                {t.count}
              </span>
              <span className="text-sm text-foreground">{t.title}</span>
            </div>
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
          </li>
        ))}
      </ul>
    </div>
  )
}

export function AiInsightPanel() {
  return (
    <div className="rounded-lg border border-border bg-card p-4 shadow-sm">
      <div className="flex items-center gap-2">
        <span className="flex h-6 w-6 items-center justify-center rounded-md bg-brand text-white">
          <Bot className="h-3.5 w-3.5" />
        </span>
        <h3 className="text-sm font-semibold text-foreground">AI 智能决策建议</h3>
        <span className="ml-auto inline-flex items-center gap-1 text-xs text-brand">
          <Sparkles className="h-3 w-3" />
          天机引擎
        </span>
      </div>
      <ul className="mt-3 space-y-3">
        {aiInsights.map((i) => (
          <li key={i.title} className="rounded-md border border-border p-3 hover:border-brand/40">
            <span className="inline-block rounded bg-brand/10 px-1.5 py-0.5 text-[11px] font-medium text-brand">
              {i.tag}
            </span>
            <p className="mt-1.5 text-sm font-medium leading-snug text-foreground">{i.title}</p>
            <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{i.desc}</p>
          </li>
        ))}
      </ul>
    </div>
  )
}
