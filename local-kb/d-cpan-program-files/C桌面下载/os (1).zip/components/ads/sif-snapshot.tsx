"use client"

import { useEffect, useMemo, useState } from "react"
import {
  Brush,
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"
import { Calendar, Search, X, Download } from "lucide-react"
import { cn } from "@/lib/utils"
import { sifTabs, buildSifRank, skuToAsin } from "@/lib/mock/asin-view"

export function SifSnapshot({ sku }: { sku: string }) {
  const [tab, setTab] = useState<(typeof sifTabs)[number]>("SP-常规")
  const rankData = useMemo(() => buildSifRank(sku, tab), [sku, tab])
  const asin = useMemo(() => skuToAsin(sku), [sku])

  // 缩放窗口：默认聚焦最近时段，向左拖动可查看更长时间
  const lastIndex = rankData.length - 1
  const defaultStart = Math.max(0, lastIndex - 11)
  const [brushRange, setBrushRange] = useState<[number, number]>([defaultStart, lastIndex])

  // 切换 SKU / 广告位后重置缩放窗口
  useEffect(() => {
    setBrushRange([Math.max(0, rankData.length - 12), rankData.length - 1])
  }, [sku, tab, rankData.length])

  return (
    <div className="rounded-lg border border-border bg-card p-5 shadow-sm">
      <h3 className="text-sm font-semibold text-foreground">SIF 坑位快照</h3>

      {/* 位置 Tab */}
      <div className="mt-3 flex gap-1 border-b border-border">
        {sifTabs.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={cn(
              "relative px-4 pb-2.5 text-sm font-medium transition-colors",
              tab === t ? "text-up" : "text-muted-foreground hover:text-foreground",
            )}
          >
            {t}
            {tab === t && <span className="absolute inset-x-0 -bottom-px h-0.5 rounded-full bg-up" />}
          </button>
        ))}
      </div>

      {/* 筛选行 */}
      <div className="mt-4 flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-1 rounded-md border border-border px-2 py-1.5">
          <span className="inline-flex items-center gap-1 rounded-full bg-up/10 px-2 py-0.5 text-xs font-medium text-up">
            {asin}
            <X className="h-3 w-3 cursor-pointer" />
          </span>
          <span className="rounded bg-muted px-1 text-xs text-muted-foreground">+1</span>
          <span className="ml-1 text-xs text-muted-foreground">筛选 ASIN，最多支持 10 个</span>
          <Search className="ml-1 h-3.5 w-3.5 text-muted-foreground" />
        </div>

        <div className="flex items-center gap-1.5 rounded-md border border-border px-2.5 py-1.5 text-xs text-foreground">
          <span className="text-muted-foreground">筛选时间</span>
          <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
          2026-06-28
        </div>

        <button className="rounded-md border border-border px-3 py-1.5 text-xs font-medium text-foreground hover:border-brand/40">
          查看前 12 小时
        </button>
        <button className="rounded-md border border-border px-3 py-1.5 text-xs font-medium text-muted-foreground hover:text-foreground">
          查看后 12 小时
        </button>
        <button className="inline-flex items-center gap-1.5 rounded-md border border-border px-3 py-1.5 text-xs font-medium text-foreground hover:border-brand/40">
          <Download className="h-3.5 w-3.5 text-muted-foreground" />
          下载数据
        </button>
      </div>

      {/* 排名折线图 */}
      <div className="mt-5">
        <p className="mb-2 text-center text-xs text-muted-foreground">
          <span className="mr-1 inline-block h-2 w-2 rounded-full bg-brand align-middle" />
          {asin} · {tab} · 排名走势（数值越小越靠前）
        </p>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={rankData} margin={{ top: 8, right: 16, left: -8, bottom: 4 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#eef0f3" vertical={false} />
              <XAxis
                dataKey="time"
                tick={{ fontSize: 10, fill: "#94a3b8" }}
                axisLine={false}
                tickLine={false}
                interval={3}
              />
              <YAxis
                reversed
                domain={[1, 25]}
                ticks={[1, 5, 10, 15, 20, 25]}
                tick={{ fontSize: 10, fill: "#94a3b8" }}
                axisLine={false}
                tickLine={false}
                width={32}
                label={{ value: "排名", position: "insideTopLeft", fontSize: 11, fill: "#94a3b8", offset: -2 }}
              />
              <Tooltip
                contentStyle={{
                  borderRadius: 8,
                  border: "1px solid #e5e7eb",
                  fontSize: 12,
                  boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
                }}
                labelStyle={{ color: "#64748b" }}
                formatter={(value: number) => [`第 ${value} 名`, "排名"]}
              />
              <Line
                type="stepAfter"
                dataKey="rank"
                stroke="#1677ff"
                strokeWidth={2}
                dot={{ r: 2.5, fill: "#1677ff" }}
                activeDot={{ r: 4 }}
              />
              <Brush
                dataKey="time"
                height={26}
                travellerWidth={10}
                stroke="#1677ff"
                fill="#1677ff14"
                tickFormatter={() => ""}
                startIndex={brushRange[0]}
                endIndex={brushRange[1]}
                onChange={(range) => {
                  if (range && typeof range.startIndex === "number" && typeof range.endIndex === "number") {
                    setBrushRange([range.startIndex, range.endIndex])
                  }
                }}
              >
                <LineChart>
                  <Line type="stepAfter" dataKey="rank" stroke="#1677ff" strokeWidth={1} dot={false} />
                </LineChart>
              </Brush>
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  )
}
