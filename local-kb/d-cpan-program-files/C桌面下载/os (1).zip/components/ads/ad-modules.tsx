"use client"

import { useState } from "react"
import { TrendingUp, TrendingDown, Minus, Copy, Download, Check, Ban, Sparkles } from "lucide-react"
import {
  rootItems,
  anomalyItems,
  type AnomalyItem,
} from "@/lib/mock/ad-modules"
import { useAdStore } from "./ad-store"
import { cn } from "@/lib/utils"

/* ----------------------------- 通用工具栏 ----------------------------- */
function Toolbar({
  title,
  desc,
  count,
  fromRule = 0,
}: {
  title: string
  desc: string
  count: number
  fromRule?: number
}) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-3">
      <div>
        <h3 className="text-sm font-semibold text-foreground">{title}</h3>
        <p className="mt-0.5 text-xs text-muted-foreground">{desc}</p>
      </div>
      <div className="flex items-center gap-2">
        {fromRule > 0 && (
          <span className="inline-flex items-center gap-1 rounded-md bg-brand/10 px-2.5 py-1 text-xs font-medium text-brand">
            <Sparkles className="h-3 w-3" />
            来自规则 {fromRule}
          </span>
        )}
        <span className="rounded-md bg-muted px-2.5 py-1 text-xs text-muted-foreground">
          共 <span className="font-semibold text-foreground">{count}</span> 条
        </span>
        <button className="inline-flex items-center gap-1.5 rounded-md bg-up px-3 py-1.5 text-sm font-medium text-white hover:bg-up/90">
          <Copy className="h-3.5 w-3.5" />
          复制
        </button>
        <button className="inline-flex items-center gap-1.5 rounded-md bg-brand px-3 py-1.5 text-sm font-medium text-white hover:bg-brand/90">
          <Download className="h-3.5 w-3.5" />
          导出
        </button>
      </div>
    </div>
  )
}

/* ----------------------------- 待投放（增益） ----------------------------- */
export function GainList() {
  const { gain, appliedGain, toggleGainApplied } = useAdStore()
  const fromRule = gain.filter((g) => g.source === "规则设置").length
  return (
    <div className="rounded-lg border border-border bg-card p-4 shadow-sm">
      <Toolbar
        title="待投放（增益）"
        desc="基于规则筛选的高转化搜索词，建议加入投放以放大销量"
        count={gain.length}
        fromRule={fromRule}
      />
      <div className="mt-3 overflow-x-auto rounded-md border border-border">
        <table className="w-full min-w-[880px] text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/40 text-left text-xs text-muted-foreground">
              <th className="px-4 py-2.5 font-medium">搜索词</th>
              <th className="px-4 py-2.5 font-medium">来源 ASIN</th>
              <th className="px-4 py-2.5 font-medium">建议匹配</th>
              <th className="px-4 py-2.5 font-medium">建议出价($)</th>
              <th className="px-4 py-2.5 font-medium">点击</th>
              <th className="px-4 py-2.5 font-medium">订单</th>
              <th className="px-4 py-2.5 font-medium">ACOS</th>
              <th className="px-4 py-2.5 font-medium">CVR</th>
              <th className="px-4 py-2.5 font-medium">操作</th>
            </tr>
          </thead>
          <tbody>
            {gain.map((it) => (
              <tr
                key={it.id}
                className={cn(
                  "border-b border-border last:border-0 hover:bg-muted/30",
                  it.source === "规则设置" && "bg-brand/5",
                )}
              >
                <td className="px-4 py-2.5 font-medium text-foreground">
                  <span className="inline-flex items-center gap-1.5">
                    {it.keyword}
                    {it.source === "规则设置" && (
                      <span className="inline-flex items-center gap-0.5 rounded bg-brand/10 px-1.5 py-0.5 text-[10px] font-medium text-brand">
                        <Sparkles className="h-2.5 w-2.5" />
                        规则
                      </span>
                    )}
                  </span>
                </td>
                <td className="px-4 py-2.5 text-muted-foreground">{it.asin}</td>
                <td className="px-4 py-2.5">
                  <span className="rounded bg-brand/10 px-2 py-0.5 text-xs font-medium text-brand">{it.matchType}</span>
                </td>
                <td className="px-4 py-2.5 text-foreground">{it.suggestedBid.toFixed(2)}</td>
                <td className="px-4 py-2.5 text-foreground">{it.clicks}</td>
                <td className="px-4 py-2.5 text-foreground">{it.orders}</td>
                <td className="px-4 py-2.5 font-medium text-up">{it.acos}%</td>
                <td className="px-4 py-2.5 text-foreground">{it.cvr}%</td>
                <td className="px-4 py-2.5">
                  <button
                    onClick={() => toggleGainApplied(it.keyword)}
                    className={cn(
                      "inline-flex items-center gap-1 rounded-md px-2.5 py-1 text-xs font-medium transition-colors",
                      appliedGain.has(it.keyword.toLowerCase())
                        ? "bg-up/10 text-up"
                        : "bg-brand text-white hover:bg-brand/90",
                    )}
                  >
                    {appliedGain.has(it.keyword.toLowerCase()) ? <Check className="h-3 w-3" /> : null}
                    {appliedGain.has(it.keyword.toLowerCase()) ? "已加入" : "加入投放"}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

/* ----------------------------- 否定（止损） ----------------------------- */
export function StopList() {
  const { stop, appliedStop, toggleStopApplied } = useAdStore()
  const fromRule = stop.filter((s) => s.source === "规则设置").length
  return (
    <div className="rounded-lg border border-border bg-card p-4 shadow-sm">
      <Toolbar
        title="否定（止损）"
        desc="无转化高消耗搜索词，建议否定以止损降耗"
        count={stop.length}
        fromRule={fromRule}
      />
      <div className="mt-3 overflow-x-auto rounded-md border border-border">
        <table className="w-full min-w-[800px] text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/40 text-left text-xs text-muted-foreground">
              <th className="px-4 py-2.5 font-medium">搜索词</th>
              <th className="px-4 py-2.5 font-medium">ASIN</th>
              <th className="px-4 py-2.5 font-medium">建议否定方式</th>
              <th className="px-4 py-2.5 font-medium">点击</th>
              <th className="px-4 py-2.5 font-medium">花费($)</th>
              <th className="px-4 py-2.5 font-medium">无转化天数</th>
              <th className="px-4 py-2.5 font-medium">操作</th>
            </tr>
          </thead>
          <tbody>
            {stop.map((it) => (
              <tr
                key={it.id}
                className={cn(
                  "border-b border-border last:border-0 hover:bg-muted/30",
                  it.source === "规则设置" && "bg-down/5",
                )}
              >
                <td className="px-4 py-2.5 font-medium text-foreground">
                  <span className="inline-flex items-center gap-1.5">
                    {it.keyword}
                    {it.source === "规则设置" && (
                      <span className="inline-flex items-center gap-0.5 rounded bg-down/10 px-1.5 py-0.5 text-[10px] font-medium text-down">
                        <Sparkles className="h-2.5 w-2.5" />
                        规则
                      </span>
                    )}
                  </span>
                </td>
                <td className="px-4 py-2.5 text-muted-foreground">{it.asin}</td>
                <td className="px-4 py-2.5">
                  <span className="rounded bg-down/10 px-2 py-0.5 text-xs font-medium text-down">{it.negType}</span>
                </td>
                <td className="px-4 py-2.5 text-foreground">{it.clicks}</td>
                <td className="px-4 py-2.5 font-medium text-down">{it.spend.toFixed(1)}</td>
                <td className="px-4 py-2.5 text-foreground">{it.days > 0 ? `${it.days} 天` : "新增"}</td>
                <td className="px-4 py-2.5">
                  <button
                    onClick={() => toggleStopApplied(it.keyword)}
                    className={cn(
                      "inline-flex items-center gap-1 rounded-md px-2.5 py-1 text-xs font-medium transition-colors",
                      appliedStop.has(it.keyword.toLowerCase())
                        ? "bg-muted text-muted-foreground"
                        : "bg-down text-white hover:bg-down/90",
                    )}
                  >
                    {appliedStop.has(it.keyword.toLowerCase()) ? <Check className="h-3 w-3" /> : <Ban className="h-3 w-3" />}
                    {appliedStop.has(it.keyword.toLowerCase()) ? "已否定" : "否定"}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

/* ----------------------------- 词根聚合 ----------------------------- */
const trendIcon = { up: TrendingUp, down: TrendingDown, flat: Minus }
const trendColor = { up: "text-up", down: "text-down", flat: "text-muted-foreground" }

export function RootAggregation() {
  return (
    <div className="rounded-lg border border-border bg-card p-4 shadow-sm">
      <Toolbar title="词根聚合" desc="将搜索词按词根聚合，洞察各词根的整体效率与趋势" count={rootItems.length} />
      <div className="mt-3 overflow-x-auto rounded-md border border-border">
        <table className="w-full min-w-[820px] text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/40 text-left text-xs text-muted-foreground">
              <th className="px-4 py-2.5 font-medium">词根</th>
              <th className="px-4 py-2.5 font-medium">关键词数</th>
              <th className="px-4 py-2.5 font-medium">点击</th>
              <th className="px-4 py-2.5 font-medium">花费($)</th>
              <th className="px-4 py-2.5 font-medium">订单</th>
              <th className="px-4 py-2.5 font-medium">销售额($)</th>
              <th className="px-4 py-2.5 font-medium">ACOS</th>
              <th className="px-4 py-2.5 font-medium">趋势</th>
            </tr>
          </thead>
          <tbody>
            {rootItems.map((it) => {
              const Icon = trendIcon[it.trend]
              return (
                <tr key={it.root} className="border-b border-border last:border-0 hover:bg-muted/30">
                  <td className="px-4 py-2.5 font-medium text-foreground">{it.root}</td>
                  <td className="px-4 py-2.5 text-foreground">{it.keywordCount}</td>
                  <td className="px-4 py-2.5 text-foreground">{it.clicks.toLocaleString()}</td>
                  <td className="px-4 py-2.5 text-foreground">{it.spend.toLocaleString()}</td>
                  <td className="px-4 py-2.5 text-foreground">{it.orders}</td>
                  <td className="px-4 py-2.5 text-foreground">{it.sales.toLocaleString()}</td>
                  <td className={cn("px-4 py-2.5 font-medium", it.acos > 50 ? "text-down" : it.acos > 35 ? "text-amber-600" : "text-up")}>
                    {it.acos}%
                  </td>
                  <td className="px-4 py-2.5">
                    <Icon className={cn("h-4 w-4", trendColor[it.trend])} />
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}

/* ----------------------------- 异常问题 ----------------------------- */
const sevColor: Record<AnomalyItem["severity"], string> = {
  高: "bg-down/10 text-down",
  中: "bg-amber-100 text-amber-700",
  低: "bg-muted text-muted-foreground",
}

export function AnomalyList() {
  const [items, setItems] = useState(anomalyItems)
  const unresolved = items.filter((i) => i.status === "未处理").length

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <span className="rounded-md bg-down/10 px-2.5 py-1 text-xs font-medium text-down">
          未处理 {unresolved}
        </span>
        <span className="rounded-md bg-muted px-2.5 py-1 text-xs text-muted-foreground">
          共 {items.length} 条异常
        </span>
      </div>
      {items.map((it) => (
        <div
          key={it.id}
          className={cn(
            "rounded-lg border bg-card p-4 shadow-sm",
            it.status === "已处理" ? "border-border opacity-60" : "border-l-4 border-l-down border-border",
          )}
        >
          <div className="flex flex-wrap items-center gap-2">
            <span className={cn("rounded-md px-2 py-0.5 text-xs font-medium", sevColor[it.severity])}>
              {it.severity}
            </span>
            <span className="text-sm font-semibold text-foreground">{it.title}</span>
            <span className="text-xs text-muted-foreground">{it.asin}</span>
            <span className="rounded bg-muted px-1.5 py-0.5 text-xs font-medium text-foreground">{it.metric}</span>
            <span className="ml-auto text-xs text-muted-foreground">{it.detectedAt}</span>
          </div>
          <p className="mt-2 text-sm text-muted-foreground">{it.detail}</p>
          <div className="mt-3 flex justify-end">
            <button
              onClick={() =>
                setItems((prev) =>
                  prev.map((x) =>
                    x.id === it.id ? { ...x, status: x.status === "未处理" ? "已处理" : "未处理" } : x,
                  ),
                )
              }
              className={cn(
                "inline-flex items-center gap-1 rounded-md px-3 py-1.5 text-xs font-medium transition-colors",
                it.status === "未处理"
                  ? "bg-brand text-white hover:bg-brand/90"
                  : "border border-border bg-background text-foreground hover:bg-muted",
              )}
            >
              {it.status === "未处理" ? "标记已处理" : "恢复未处理"}
            </button>
          </div>
        </div>
      ))}
    </div>
  )
}
