"use client"

import { useEffect, useState } from "react"
import { createPortal } from "react-dom"
import { X, Send, Check, CircleAlert, CircleCheck, ChevronDown } from "lucide-react"
import { pushChannels, type HealthReport } from "@/lib/mock/health"
import { FullReport } from "./full-report"

const levelStyle: Record<string, string> = {
  高: "bg-down/10 text-down",
  中: "bg-amber-500/10 text-amber-600",
  低: "bg-up/10 text-up",
}

function SummaryView({ report }: { report: HealthReport }) {
  const scoreColor = report.score >= 80 ? "text-up" : report.score >= 60 ? "text-amber-600" : "text-down"
  return (
    <>
      {/* 评分 + 摘要 */}
      <div className="flex items-start gap-4 rounded-lg border border-border bg-page/60 p-4">
        <div className="flex flex-col items-center justify-center rounded-lg bg-card px-5 py-3 shadow-sm">
          <span className={`text-3xl font-bold leading-none ${scoreColor}`}>{report.score}</span>
          <span className="mt-1 text-xs text-muted-foreground">健康评分</span>
        </div>
        <div className="flex-1">
          <div className="mb-1 flex items-center gap-2">
            <span className="text-sm font-medium text-foreground">诊断摘要</span>
            <span className="rounded bg-down/10 px-1.5 py-0.5 text-xs text-down">{report.issues} 个核心问题</span>
          </div>
          <p className="text-sm leading-relaxed text-muted-foreground">{report.summary}</p>
        </div>
      </div>

      {/* 核心指标 */}
      <h3 className="mb-2 mt-5 text-sm font-medium text-foreground">核心指标</h3>
      <div className="grid grid-cols-3 gap-3">
        {report.metrics.map((m) => (
          <div key={m.label} className="rounded-lg border border-border bg-card p-3">
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground">{m.label}</span>
              {m.healthy ? (
                <CircleCheck className="h-3.5 w-3.5 text-up" />
              ) : (
                <CircleAlert className="h-3.5 w-3.5 text-down" />
              )}
            </div>
            <p className="mt-1 text-lg font-semibold text-foreground">{m.value}</p>
          </div>
        ))}
      </div>

      {/* 优化建议 */}
      <h3 className="mb-2 mt-5 text-sm font-medium text-foreground">优化建议</h3>
      <div className="space-y-2">
        {report.actions.map((a, i) => (
          <div key={i} className="flex gap-3 rounded-lg border border-border bg-card p-3">
            <span
              className={`mt-0.5 inline-flex h-5 shrink-0 items-center rounded px-1.5 text-xs font-medium ${levelStyle[a.level]}`}
            >
              {a.level}优先
            </span>
            <div>
              <p className="text-sm font-medium text-foreground">{a.title}</p>
              <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">{a.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </>
  )
}

export function ReportModal({
  report,
  onClose,
}: {
  report: HealthReport
  onClose: () => void
}) {
  const [mounted, setMounted] = useState(false)
  const [pushOpen, setPushOpen] = useState(false)
  const [pushedTo, setPushedTo] = useState<string | null>(null)
  const [view, setView] = useState<"完整报告" | "诊断摘要">("完整报告")

  useEffect(() => {
    setMounted(true)
    document.body.style.overflow = "hidden"
    return () => {
      document.body.style.overflow = ""
    }
  }, [])

  if (!mounted) return null

  return createPortal(
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} aria-hidden />
      <div className="relative z-10 flex max-h-[90vh] w-full max-w-4xl flex-col overflow-hidden rounded-xl bg-card shadow-xl">
        {/* 头部 */}
        <div className="flex items-center justify-between border-b border-border px-5 py-4">
          <div>
            <h2 className="text-base font-semibold text-foreground">{report.asin} 广告健康诊断报告</h2>
            <p className="mt-0.5 text-xs text-muted-foreground">
              {report.shop} · {report.owner} · 生成时间：{report.time}
            </p>
          </div>
          <button
            onClick={onClose}
            className="rounded-md p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground"
            aria-label="关闭"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* 视图切换 */}
        <div className="flex border-b border-border px-5 pt-3">
          {(["完整报告", "诊断摘要"] as const).map((v) => (
            <button
              key={v}
              onClick={() => setView(v)}
              className={`relative mr-6 pb-2.5 text-sm font-medium transition-colors ${
                view === v ? "text-brand" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {v}
              {view === v && <span className="absolute inset-x-0 -bottom-px h-0.5 rounded-full bg-brand" />}
            </button>
          ))}
        </div>

        {/* 内容 */}
        <div className="flex-1 overflow-y-auto px-5 py-4">
          {view === "完整报告" ? (
            <FullReport asin={report.asin} shop={report.shop} time={report.time} />
          ) : (
            <SummaryView report={report} />
          )}
        </div>

        {/* 底部操作 */}
        <div className="flex items-center justify-between border-t border-border px-5 py-3">
          <span className="text-xs text-muted-foreground">
            {pushedTo ? `已推送至${pushedTo}对应运营` : "可将报告推送给相应运营"}
          </span>
          <div className="relative">
            <button
              onClick={() => setPushOpen((v) => !v)}
              className="inline-flex items-center gap-1.5 rounded-md bg-brand px-3 py-2 text-sm font-medium text-white hover:bg-brand/90"
            >
              <Send className="h-4 w-4" />
              推送给运营
              <ChevronDown className="h-3.5 w-3.5" />
            </button>
            {pushOpen && (
              <div className="absolute bottom-full right-0 mb-1 w-36 overflow-hidden rounded-md border border-border bg-card py-1 shadow-lg">
                {pushChannels.map((c) => (
                  <button
                    key={c.key}
                    onClick={() => {
                      setPushedTo(c.label)
                      setPushOpen(false)
                    }}
                    className="flex w-full items-center justify-between px-3 py-2 text-sm text-foreground hover:bg-muted"
                  >
                    {c.label}
                    {pushedTo === c.label && <Check className="h-4 w-4 text-up" />}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>,
    document.body,
  )
}
