"use client"

import { useState } from "react"
import { Calendar, ChevronDown, ArrowRight, Lightbulb } from "lucide-react"
import { cn } from "@/lib/utils"
import {
  diagnosisCards,
  toneClass,
  toneBadge,
  severityTone,
  type DiagnosisCard,
  type DiagnosisType,
} from "@/lib/mock/diagnosis"

const ranges = ["近7天", "近14天", "近30天"] as const
const filters = ["全部店铺", "全部团队", "全部负责人"] as const

export function AdDiagnosis() {
  const [range, setRange] = useState<(typeof ranges)[number]>("近7天")
  const [typeFilter, setTypeFilter] = useState<DiagnosisType | "全部">("全部")

  const problemCount = diagnosisCards.filter((c) => c.type === "问题").length
  const chanceCount = diagnosisCards.filter((c) => c.type === "机会").length

  const visible = diagnosisCards.filter((c) => typeFilter === "全部" || c.type === typeFilter)

  return (
    <div className="space-y-4">
      {/* 时间筛选行 */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex rounded-md border border-border p-0.5">
          {ranges.map((r) => (
            <button
              key={r}
              onClick={() => setRange(r)}
              className={cn(
                "rounded px-3 py-1 text-xs transition-colors",
                range === r ? "bg-brand text-white" : "text-muted-foreground hover:text-foreground",
              )}
            >
              {r}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-1.5 rounded-md border border-border px-2.5 py-1.5 text-xs text-muted-foreground">
          <Calendar className="h-3.5 w-3.5" />
          年/月/日
          <span className="text-border">~</span>
          年/月/日
        </div>
        <button className="rounded-md bg-brand px-4 py-1.5 text-xs font-medium text-white hover:bg-brand/90">
          查询
        </button>
      </div>

      {/* 下拉筛选行 */}
      <div className="flex flex-wrap items-center gap-2">
        {filters.map((f) => (
          <button
            key={f}
            className="inline-flex items-center gap-2 rounded-md border border-border bg-background px-3 py-1.5 text-xs text-foreground hover:border-brand/40"
          >
            {f}
            <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
          </button>
        ))}
      </div>

      {/* 问题 / 机会 胶囊 */}
      <div className="flex flex-wrap items-center gap-3">
        <button
          onClick={() => setTypeFilter(typeFilter === "问题" ? "全部" : "问题")}
          className={cn(
            "inline-flex items-center gap-2 rounded-full border px-3 py-1 text-xs font-medium transition-colors",
            typeFilter === "问题"
              ? "border-down bg-down/5 text-down"
              : "border-border text-foreground hover:border-down/40",
          )}
        >
          <span className="h-2 w-2 rounded-full bg-down" />
          问题 ASIN
          <span className="flex h-4 min-w-4 items-center justify-center rounded-full bg-down px-1 text-[10px] text-white">
            {problemCount}
          </span>
        </button>
        <button
          onClick={() => setTypeFilter(typeFilter === "机会" ? "全部" : "机会")}
          className={cn(
            "inline-flex items-center gap-2 rounded-full border px-3 py-1 text-xs font-medium transition-colors",
            typeFilter === "机会"
              ? "border-up bg-up/5 text-up"
              : "border-border text-foreground hover:border-up/40",
          )}
        >
          <span className="h-2 w-2 rounded-full bg-up" />
          机会 ASIN
          <span className="flex h-4 min-w-4 items-center justify-center rounded-full bg-up px-1 text-[10px] text-white">
            {chanceCount}
          </span>
        </button>
      </div>

      {/* 卡片网格 */}
      <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
        {visible.map((card) => (
          <DiagnosisCardItem key={card.id} card={card} />
        ))}
      </div>
    </div>
  )
}

function DiagnosisCardItem({ card }: { card: DiagnosisCard }) {
  const [open, setOpen] = useState(false)
  const isProblem = card.type === "问题"

  return (
    <div
      className={cn(
        "rounded-lg border border-l-4 border-border bg-card p-4 shadow-sm transition-shadow hover:shadow-md",
        isProblem ? "border-l-down" : "border-l-up",
      )}
    >
      {/* 头部信息行 */}
      <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-sm">
        <span className="text-muted-foreground">{card.shop}</span>
        <span className="font-semibold text-foreground">{card.asin}</span>
        <span className={cn("font-medium", toneClass[card.statusTone])}>{card.statusTag}</span>
        <span
          className={cn(
            "rounded px-1.5 py-0.5 text-xs font-medium",
            toneBadge[severityTone[card.severity]],
          )}
        >
          {card.severity}
        </span>
        <span className="ml-auto text-xs text-muted-foreground">{card.owner}</span>
      </div>

      {/* 指标行 */}
      <p className="mt-2 text-sm text-foreground/80">
        {card.metric}
        {card.metricHighlight && <span className="ml-1 font-medium text-down">{card.metricHighlight}</span>}
      </p>

      {/* AI 建议按钮 */}
      <button
        onClick={() => setOpen((v) => !v)}
        className="mt-3 inline-flex items-center gap-1.5 rounded-md bg-brand px-3 py-1.5 text-xs font-medium text-white hover:bg-brand/90"
      >
        AI 建议
        <ArrowRight className={cn("h-3.5 w-3.5 transition-transform", open && "rotate-90")} />
      </button>

      {/* AI 建议展开面板 */}
      {open && (
        <div className="mt-3 flex gap-2 rounded-md bg-amber-50 p-3 text-xs leading-relaxed text-amber-900">
          <Lightbulb className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-500" />
          <p>{card.aiAdvice}</p>
        </div>
      )}
    </div>
  )
}
