"use client"

import { useMemo, useState } from "react"
import { Search, Calendar, RefreshCw, Megaphone, Info } from "lucide-react"
import {
  searchTermRows,
  searchTermSummary,
  stCampaignTypes,
  stMatchTypes,
  opportunityMeta,
  type StCampaignType,
  type StMatchType,
} from "@/lib/mock/search-terms"
import { compareModes, granularityOptions, type CompareMode, type Granularity } from "@/lib/mock/data-detail"
import { DateRangeDropdown, Segmented } from "./time-filter"
import { cn } from "@/lib/utils"

export function SearchTermAnalysis() {
  const [campaignType, setCampaignType] = useState<StCampaignType>("全部")
  const [matchType, setMatchType] = useState<StMatchType>("全部")
  const [range, setRange] = useState("最近30天")
  const [compare, setCompare] = useState<CompareMode>("环比")
  const [granularity, setGranularity] = useState<Granularity>("按日")
  const [keyword, setKeyword] = useState("")
  const [syncing, setSyncing] = useState(false)

  function handleSync() {
    setSyncing(true)
    setTimeout(() => setSyncing(false), 900)
  }

  const rows = useMemo(() => {
    return searchTermRows.filter((r) => {
      if (campaignType !== "全部" && r.campaignType !== campaignType) return false
      if (matchType !== "全部" && r.matchType !== matchType) return false
      if (keyword.trim() && !r.term.toLowerCase().includes(keyword.trim().toLowerCase())) return false
      return true
    })
  }, [campaignType, matchType, keyword])

  const cols = [
    { label: "曝光量", get: (r: (typeof rows)[number]) => r.impressions.toLocaleString() },
    { label: "点击", get: (r: (typeof rows)[number]) => r.clicks.toLocaleString() },
    { label: "CTR", get: (r: (typeof rows)[number]) => r.ctr },
    { label: "CPC", get: (r: (typeof rows)[number]) => r.cpc },
    { label: "花费", get: (r: (typeof rows)[number]) => r.spend },
    { label: "广告销售额", get: (r: (typeof rows)[number]) => r.adSales },
    { label: "ROAS", get: (r: (typeof rows)[number]) => r.roas },
    { label: "广告订单", get: (r: (typeof rows)[number]) => r.adOrders },
    { label: "CVR", get: (r: (typeof rows)[number]) => r.cvr },
    { label: "CPA", get: (r: (typeof rows)[number]) => r.cpa },
    { label: "广告笔单价", get: (r: (typeof rows)[number]) => r.aov },
  ]

  return (
    <div className="rounded-lg border border-border bg-card shadow-sm">
      {/* 标题栏 */}
      <div className="flex items-center gap-2 border-b border-border px-4 py-3">
        <Search className="h-4 w-4 text-brand" />
        <h3 className="text-sm font-semibold text-foreground">搜索词分析</h3>
        <span className="text-xs text-muted-foreground">汇总客户搜索词在 SP / SB / SD 广告中的表现，定位值得优化出单的词</span>
      </div>

      {/* 筛选行 */}
      <div className="flex flex-wrap items-center gap-3 border-b border-border bg-muted/20 px-4 py-3">
        <FilterLabel text="投放类型">
          <Segmented options={stCampaignTypes} value={campaignType} onChange={(v) => setCampaignType(v as StCampaignType)} />
        </FilterLabel>
        <FilterLabel text="匹配类型">
          <Segmented options={stMatchTypes} value={matchType} onChange={(v) => setMatchType(v as StMatchType)} />
        </FilterLabel>

        <DateRangeDropdown value={range as never} onChange={(v) => setRange(v)} />
        <Segmented options={compareModes} value={compare} onChange={(v) => setCompare(v as CompareMode)} />
        <Segmented options={granularityOptions} value={granularity} onChange={(v) => setGranularity(v as Granularity)} />

        <div className="inline-flex items-center gap-2 rounded-md border border-border bg-card px-3 py-1.5 text-sm text-muted-foreground">
          <Calendar className="h-3.5 w-3.5" />
          <span>年/月/日</span>
          <span>~</span>
          <span>年/月/日</span>
        </div>

        <button
          onClick={handleSync}
          className="inline-flex items-center gap-1.5 rounded-md bg-brand px-3 py-1.5 text-sm font-medium text-white transition-colors hover:bg-brand/90"
        >
          <RefreshCw className={cn("h-3.5 w-3.5", syncing && "animate-spin")} />
          同步
        </button>

        <div className="relative ml-auto">
          <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
          <input
            value={keyword}
            onChange={(e) => setKeyword(e.target.value)}
            placeholder="搜索客户搜索词"
            className="w-56 rounded-md border border-border bg-card py-1.5 pl-8 pr-3 text-sm text-foreground outline-none placeholder:text-muted-foreground focus:border-brand"
          />
        </div>
      </div>

      {/* 汇总 */}
      <div className="flex flex-wrap items-center gap-x-6 gap-y-1 border-b border-border bg-card px-4 py-2.5 text-xs text-muted-foreground">
        <span>
          搜索词 <span className="font-semibold text-foreground">{searchTermSummary.termCount}</span>
        </span>
        <span>
          点击 <span className="font-semibold text-foreground">{searchTermSummary.totalClicks.toLocaleString()}</span>
        </span>
        <span>
          花费 <span className="font-semibold text-foreground">{searchTermSummary.totalSpend}</span>
        </span>
        <span>
          广告销售额 <span className="font-semibold text-foreground">{searchTermSummary.totalAdSales}</span>
        </span>
        <span>
          平均 ACOS <span className="font-semibold text-brand">{searchTermSummary.avgAcos}</span>
        </span>
        <span className="ml-auto">数据截至 {searchTermSummary.dataDate}</span>
      </div>

      {/* 表格 */}
      <div className="overflow-x-auto">
        <table className="w-full min-w-[1700px] text-sm">
          <thead>
            <tr className="text-left text-xs text-muted-foreground">
              <th className="sticky left-0 z-10 whitespace-nowrap bg-card px-4 py-2.5 font-medium">客户搜索词</th>
              <th className="whitespace-nowrap px-4 py-2.5 font-medium">匹配类型</th>
              <th className="whitespace-nowrap px-4 py-2.5 font-medium">
                <span className="inline-flex items-center gap-1">
                  投放次数
                  <Info className="h-3 w-3 text-muted-foreground/60" />
                </span>
              </th>
              <th className="whitespace-nowrap px-4 py-2.5 font-medium">投放类型</th>
              {cols.map((c) => (
                <th key={c.label} className="whitespace-nowrap px-4 py-2.5 font-medium">
                  {c.label}
                </th>
              ))}
              <th className="whitespace-nowrap px-4 py-2.5 font-medium">ACOS</th>
              <th className="whitespace-nowrap px-4 py-2.5 font-medium">优化建议</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => {
              const meta = opportunityMeta[r.opportunity]
              return (
                <tr key={r.term} className="border-t border-border hover:bg-muted/20">
                  <td className="sticky left-0 z-10 whitespace-nowrap bg-card px-4 py-3 font-medium text-foreground">
                    {r.term}
                  </td>
                  <td className="whitespace-nowrap px-4 py-3">
                    <MatchTag type={r.matchType} />
                  </td>
                  <td className="px-4 py-3">
                    <CampaignCount count={r.campaignCount} campaigns={r.campaigns} />
                  </td>
                  <td className="whitespace-nowrap px-4 py-3 text-foreground">{r.campaignType}</td>
                  {cols.map((c) => (
                    <td key={c.label} className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground">
                      {c.get(r)}
                    </td>
                  ))}
                  <td className="whitespace-nowrap px-4 py-3 tabular-nums font-medium text-brand">{r.acos}</td>
                  <td className="whitespace-nowrap px-4 py-3">
                    <span
                      className={cn(
                        "inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium",
                        meta.tone === "up" && "bg-up/10 text-up",
                        meta.tone === "down" && "bg-down/10 text-down",
                        meta.tone === "amber" && "bg-amber-500/10 text-amber-600",
                        meta.tone === "brand" && "bg-brand/10 text-brand",
                      )}
                    >
                      {meta.label}
                    </span>
                  </td>
                </tr>
              )
            })}
            {rows.length === 0 && (
              <tr>
                <td colSpan={cols.length + 6} className="px-4 py-12 text-center text-sm text-muted-foreground">
                  没有符合当前筛选条件的搜索词
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}

function FilterLabel({ text, children }: { text: string; children: React.ReactNode }) {
  return (
    <div className="inline-flex items-center gap-2">
      <span className="text-sm text-muted-foreground">{text}</span>
      {children}
    </div>
  )
}

function MatchTag({ type }: { type: "精准匹配" | "广泛匹配" | "词组匹配" }) {
  const tone =
    type === "精准匹配" ? "bg-up/10 text-up" : type === "词组匹配" ? "bg-brand/10 text-brand" : "bg-amber-500/10 text-amber-600"
  return <span className={cn("inline-flex items-center rounded px-2 py-0.5 text-xs font-medium", tone)}>{type}</span>
}

function CampaignCount({ count, campaigns }: { count: number; campaigns: string[] }) {
  const [open, setOpen] = useState(false)
  return (
    <div className="relative inline-block" onMouseEnter={() => setOpen(true)} onMouseLeave={() => setOpen(false)}>
      <span className="inline-flex items-center gap-1.5 rounded-md border border-border bg-muted/40 px-2 py-0.5 text-xs font-medium text-foreground">
        <Megaphone className="h-3 w-3 text-brand" />
        {count} 个活动
      </span>
      {open && (
        <div className="absolute left-0 top-full z-20 mt-1 w-52 rounded-md border border-border bg-card p-2 shadow-lg">
          <p className="mb-1 text-xs font-medium text-muted-foreground">投放该搜索词的广告活动</p>
          <ul className="space-y-0.5">
            {campaigns.map((c) => (
              <li key={c} className="truncate text-xs text-foreground">
                · {c}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  )
}
