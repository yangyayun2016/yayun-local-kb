"use client"

import { useState } from "react"
import {
  Settings,
  Target,
  Ban,
  Plus,
  Gauge,
  Eye,
  Play,
  Copy,
  Download,
  ChevronUp,
  Send,
  Check,
} from "lucide-react"
import {
  ruleSettingsTabs,
  defaultRuleConfig,
  suggestionPool,
  type RuleConfig,
  type SuggestionItem,
} from "@/lib/mock/rule-settings"
import { useAdStore } from "./ad-store"
import { DataDetail } from "./data-detail"
import { cn } from "@/lib/utils"

type SuggestionKey = keyof typeof suggestionPool

export function RuleSettings() {
  const [innerTab, setInnerTab] = useState<string>("建议操作")
  const [cfg, setCfg] = useState<RuleConfig>(defaultRuleConfig)
  const [collapsed, setCollapsed] = useState(false)
  const [generated, setGenerated] = useState<Record<SuggestionKey, SuggestionItem[]> | null>(null)
  const [activeResult, setActiveResult] = useState<SuggestionKey>("否定词候选")

  function set<K extends keyof RuleConfig>(key: K, value: number) {
    setCfg((prev) => ({ ...prev, [key]: value }))
  }

  function generate() {
    setGenerated(suggestionPool)
    setActiveResult("否定词候选")
  }

  return (
    <div className="space-y-4">
      {/* 内部 Tab 条 */}
      <div className="inline-flex flex-wrap items-center gap-1 rounded-lg bg-muted/60 p-1">
        {ruleSettingsTabs.map((t) => (
          <button
            key={t}
            onClick={() => setInnerTab(t)}
            className={cn(
              "rounded-md px-4 py-1.5 text-sm font-medium transition-colors",
              innerTab === t ? "bg-card text-brand shadow-sm" : "text-muted-foreground hover:text-foreground",
            )}
          >
            {t}
          </button>
        ))}
      </div>

      {innerTab === "数据明细" ? (
        <DataDetail />
      ) : innerTab !== "建议操作" ? (
        <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-border bg-card py-20 text-center shadow-sm">
          <p className="text-base font-medium text-foreground">{innerTab}</p>
          <p className="mt-1 text-sm text-muted-foreground">请在「建议操作」中配置规则后生成结果</p>
        </div>
      ) : (
        <>
          {/* 规则配置面板 */}
          <div className="rounded-lg border border-border bg-card p-5 shadow-sm">
            <div className="mb-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Settings className="h-4 w-4 text-brand" />
                <h3 className="text-sm font-semibold text-foreground">规则配置</h3>
                <span className="text-xs text-muted-foreground">（基于当前左侧筛选数据）</span>
                <span className="ml-3 text-xs font-medium text-down">目标毛利率 = {cfg.targetMargin}%</span>
              </div>
              <button
                onClick={() => setCollapsed((c) => !c)}
                className="rounded p-1 text-muted-foreground hover:bg-muted"
                aria-label="折叠"
              >
                <ChevronUp className={cn("h-4 w-4 transition-transform", collapsed && "rotate-180")} />
              </button>
            </div>

            {!collapsed && (
              <div className="space-y-4">
                {/* 目标值行 */}
                <div className="rounded-lg border border-border bg-muted/20 p-4">
                  <div className="mb-3 flex items-center gap-2">
                    <Target className="h-4 w-4 text-down" />
                    <span className="text-sm font-medium text-foreground">目标 ACOS</span>
                  </div>
                  <div className="flex flex-wrap items-center gap-x-6 gap-y-3">
                    <Field label="目标ACOS" value={cfg.targetAcos} onChange={(v) => set("targetAcos", v)} suffix="%" />
                    <Badge>目标: {cfg.targetAcos}%</Badge>
                    <Threshold up={cfg.acosUp} down={cfg.acosDown} />

                    <span className="ml-2 text-sm font-medium text-down">目标客单价</span>
                    <Field value={cfg.targetAov} onChange={(v) => set("targetAov", v)} suffix="$" />
                    <Badge>目标: {cfg.targetAov}</Badge>

                    <span className="ml-2 text-sm font-medium text-down">目标CVR</span>
                    <Field value={cfg.targetCvr} onChange={(v) => set("targetCvr", v)} suffix="%" />
                    <Badge>目标: {cfg.targetCvr}%</Badge>
                    <Threshold up={cfg.cvrUp} down={cfg.cvrDown} />
                  </div>
                </div>

                {/* 目标毛利率行 */}
                <div className="rounded-lg border border-border bg-muted/20 p-4">
                  <div className="mb-3 flex items-center gap-2">
                    <Target className="h-4 w-4 text-up" />
                    <span className="text-sm font-medium text-foreground">目标毛利率</span>
                    <span className="text-xs text-muted-foreground">（手动设定）</span>
                  </div>
                  <div className="flex flex-wrap items-center gap-x-6 gap-y-3">
                    <Field label="目标毛利率" value={cfg.marginGoal} onChange={(v) => set("marginGoal", v)} suffix="%" />
                    <Badge>目标: {cfg.marginGoal}%</Badge>

                    <span className="ml-2 text-sm font-medium text-up">广告前毛利率</span>
                    <Field value={cfg.marginBeforeAd} onChange={(v) => set("marginBeforeAd", v)} suffix="%" />
                    <Badge>{cfg.marginBeforeAd}%</Badge>

                    <span className="ml-2 text-sm font-medium text-up">广告后毛利率</span>
                    <Field value={cfg.marginAfterAd} onChange={(v) => set("marginAfterAd", v)} suffix="%" />
                    <Badge>{cfg.marginAfterAd}%</Badge>
                  </div>
                </div>

                {/* 目标转化率行 */}
                <div className="rounded-lg border border-border bg-muted/20 p-4">
                  <div className="mb-3 flex items-center gap-2">
                    <Target className="h-4 w-4 text-up" />
                    <span className="text-sm font-medium text-foreground">目标转化率</span>
                    <span className="text-xs text-muted-foreground">（手动设定）</span>
                  </div>
                  <div className="flex flex-wrap items-center gap-x-6 gap-y-3">
                    <Field label="类目平均转化率" value={cfg.cvrCategoryAvg} onChange={(v) => set("cvrCategoryAvg", v)} suffix="%" />
                    <Badge>{cfg.cvrCategoryAvg}%</Badge>

                    <span className="ml-2 text-sm font-medium text-up">目标转化率</span>
                    <Field value={cfg.cvrGoal} onChange={(v) => set("cvrGoal", v)} suffix="%" />
                    <Badge>目标: {cfg.cvrGoal}%</Badge>

                    <span className="ml-2 text-sm font-medium text-up">广告转化率</span>
                    <Field value={cfg.cvrAd} onChange={(v) => set("cvrAd", v)} suffix="%" />
                    <Badge>{cfg.cvrAd}%</Badge>
                  </div>
                </div>

                {/* 4 张规则卡 */}
                <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
                  {/* ① 否定词候选规则 */}
                  <RuleCard
                    index="①"
                    icon={Ban}
                    iconBg="bg-down/10 text-down"
                    title="否定词候选规则"
                    note={`类目平均转化率 = ${cfg.categoryCvr}%`}
                  >
                    <div className="flex flex-wrap items-center gap-2 text-sm text-foreground">
                      <span>无订单/无销售 且 点击 ≥</span>
                      <Field value={cfg.negClicks} onChange={(v) => set("negClicks", v)} compact />
                      <span>或 花费 ≥ $</span>
                      <Field value={cfg.negSpend} onChange={(v) => set("negSpend", v)} compact />
                    </div>
                  </RuleCard>

                  {/* ② 加词候选规则 */}
                  <RuleCard index="②" icon={Plus} iconBg="bg-up/10 text-up" title="加词候选规则">
                    <div className="flex flex-wrap items-center gap-2 text-sm text-foreground">
                      <span>有订单 且 点击 ≥</span>
                      <Field value={cfg.addClicks} onChange={(v) => set("addClicks", v)} compact />
                      <span>且 ACOS ≤</span>
                      <Field value={cfg.addAcos} onChange={(v) => set("addAcos", v)} compact suffix="%" />
                      <span>且 CVR ≥</span>
                      <Field value={cfg.addCvr} onChange={(v) => set("addCvr", v)} compact suffix="%" />
                      <span>或 订单 ≥</span>
                      <Field value={cfg.addOrders} onChange={(v) => set("addOrders", v)} compact />
                    </div>
                  </RuleCard>

                  {/* ③ 出价调整规则 */}
                  <RuleCard
                    index="③"
                    icon={Gauge}
                    iconBg="bg-brand/10 text-brand"
                    title="出价调整规则"
                    note="广告出单临界值：15个点击出一单，目标CPC，广告预算 15*CPC，即 CPA"
                  >
                    <div className="space-y-2.5 text-sm text-foreground">
                      <div className="flex flex-wrap items-center gap-2">
                        <span>有订单 且 点击 ≥</span>
                        <Field value={cfg.bidClicks} onChange={(v) => set("bidClicks", v)} compact />
                      </div>
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-muted-foreground">提价区间系数: 低于目标ACOS的</span>
                        <Field value={cfg.bidUp1} onChange={(v) => set("bidUp1", v)} compact suffix="%" />
                        <span className="text-up">(提15%)</span>
                        <Field value={cfg.bidUp2} onChange={(v) => set("bidUp2", v)} compact suffix="%" />
                        <span className="text-up">(提20%)</span>
                      </div>
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-muted-foreground">降价区间系数: 超过目标ACOS的</span>
                        <Field value={cfg.bidDown1} onChange={(v) => set("bidDown1", v)} compact suffix="%" />
                        <span className="text-down">(降10%)</span>
                        <Field value={cfg.bidDown2} onChange={(v) => set("bidDown2", v)} compact suffix="%" />
                        <span className="text-down">(降20%)</span>
                        <Field value={cfg.bidDown3} onChange={(v) => set("bidDown3", v)} compact suffix="%" />
                        <span className="text-down">(降30%)</span>
                      </div>
                    </div>
                  </RuleCard>

                  {/* ④ 重点关注规则 */}
                  <RuleCard index="④" icon={Eye} iconBg="bg-purple-100 text-purple-600" title="重点关注规则">
                    <div className="space-y-2 text-sm text-foreground">
                      <div className="flex flex-wrap items-center gap-2">
                        <span>点击 ≥</span>
                        <Field value={cfg.focusClicks} onChange={(v) => set("focusClicks", v)} compact />
                        <span>且 CVR ≤</span>
                        <Field value={cfg.focusCvr} onChange={(v) => set("focusCvr", v)} compact suffix="%" />
                      </div>
                      <p className="text-xs text-muted-foreground">或</p>
                      <div className="flex flex-wrap items-center gap-2">
                        <span>单广告组点击 ≥</span>
                        <Field value={cfg.focusGroupClicks} onChange={(v) => set("focusGroupClicks", v)} compact />
                        <span>且无成交</span>
                      </div>
                      <p className="text-xs text-muted-foreground">或</p>
                      <div className="flex flex-wrap items-center gap-2">
                        <span>ACOS ≥</span>
                        <Field value={cfg.focusAcos} onChange={(v) => set("focusAcos", v)} compact suffix="%" />
                      </div>
                    </div>
                  </RuleCard>
                </div>

                {/* 生成按钮 */}
                <div className="flex justify-center pt-1">
                  <button
                    onClick={generate}
                    className="inline-flex items-center gap-2 rounded-lg bg-brand px-8 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-brand/90"
                  >
                    <Play className="h-4 w-4 fill-current" />
                    生成建议操作
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* 结果区 */}
          {generated && <ResultPanel data={generated} active={activeResult} onSelect={setActiveResult} />}
        </>
      )}
    </div>
  )
}

function Field({
  label,
  value,
  onChange,
  suffix,
  compact,
}: {
  label?: string
  value: number
  onChange: (v: number) => void
  suffix?: string
  compact?: boolean
}) {
  return (
    <span className="inline-flex items-center gap-1.5">
      {label && <span className="text-sm text-foreground">{label}</span>}
      <span className="inline-flex items-center rounded-md border border-border bg-background">
        <input
          type="number"
          value={value}
          onChange={(e) => onChange(Number(e.target.value))}
          className={cn(
            "rounded-md bg-transparent px-2 py-1 text-sm text-foreground outline-none focus:ring-1 focus:ring-brand",
            compact ? "w-14" : "w-16",
          )}
        />
      </span>
      {suffix && <span className="text-sm text-muted-foreground">{suffix}</span>}
    </span>
  )
}

function Badge({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center rounded-md bg-brand px-2.5 py-1 text-xs font-medium text-white">
      {children}
    </span>
  )
}

function Threshold({ up, down }: { up: number; down: number }) {
  return (
    <span className="text-xs text-muted-foreground">
      上调阈值: <span className="font-medium text-up">{up}%</span>
      <span className="mx-1.5 text-border">|</span>
      下调阈值: <span className="font-medium text-down">{down}%</span>
    </span>
  )
}

function RuleCard({
  index,
  icon: Icon,
  iconBg,
  title,
  note,
  children,
}: {
  index: string
  icon: typeof Ban
  iconBg: string
  title: string
  note?: string
  children: React.ReactNode
}) {
  return (
    <div className="rounded-lg border border-border bg-background p-4">
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <span className={cn("flex h-5 w-5 items-center justify-center rounded-full text-xs font-bold", iconBg)}>
          {index}
        </span>
        <Icon className="h-4 w-4 text-muted-foreground" />
        <span className="text-sm font-medium text-foreground">{title}</span>
        {note && <span className="text-xs font-medium text-down">{note}</span>}
      </div>
      {children}
    </div>
  )
}

function ResultPanel({
  data,
  active,
  onSelect,
}: {
  data: Record<SuggestionKey, SuggestionItem[]>
  active: SuggestionKey
  onSelect: (k: SuggestionKey) => void
}) {
  const { pushGain, pushStop, appliedGain, appliedStop } = useAdStore()
  const [pushedKey, setPushedKey] = useState<SuggestionKey | null>(null)
  const [pushMsg, setPushMsg] = useState("")

  const tabs: { key: SuggestionKey; icon: typeof Ban; color: string }[] = [
    { key: "否定词候选", icon: Ban, color: "bg-brand text-white" },
    { key: "加词候选", icon: Plus, color: "bg-up/10 text-up" },
    { key: "出价调整", icon: Gauge, color: "bg-amber-100 text-amber-700" },
    { key: "重点关注", icon: Eye, color: "bg-purple-100 text-purple-600" },
  ]
  const items = data[active]

  // 回写：目标模块执行后，结果区对应候选词显示已执行状态
  const appliedSet = active === "否定词候选" ? appliedStop : active === "加词候选" ? appliedGain : null
  const appliedLabel = active === "否定词候选" ? "已否定" : "已加入投放"
  const appliedCount = appliedSet ? items.filter((it) => appliedSet.has(it.keyword.toLowerCase())).length : 0

  // 联动目标：否定词候选 → 否定（止损）；加词候选 → 待投放（增益）
  const pushTarget =
    active === "否定词候选" ? "否定（止损）" : active === "加词候选" ? "待投放（增益）" : null

  function handlePush() {
    if (active === "否定词候选") {
      const n = pushStop(data["否定词候选"])
      setPushMsg(n > 0 ? `已推送 ${n} 个否定词到「否定（止损）」` : "所有否定词已存在于「否定（止损）」")
    } else if (active === "加词候选") {
      const n = pushGain(data["加词候选"])
      setPushMsg(n > 0 ? `已推送 ${n} 个加词到「待投放（增益）」` : "所有加词已存在于「待投放（增益）」")
    }
    setPushedKey(active)
  }

  return (
    <div className="rounded-lg border border-border bg-card p-4 shadow-sm">
      {/* 统计胶囊 */}
      <div className="flex flex-wrap items-center gap-2">
        {tabs.map((t) => {
          const isActive = t.key === active
          return (
            <button
              key={t.key}
              onClick={() => onSelect(t.key)}
              className={cn(
                "inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-colors",
                isActive ? "bg-brand text-white" : "border border-border bg-background text-foreground hover:bg-muted",
              )}
            >
              <t.icon className="h-3.5 w-3.5" />
              {t.key}
              <span
                className={cn(
                  "ml-0.5 inline-flex h-4 min-w-4 items-center justify-center rounded-full px-1 text-xs",
                  isActive ? "bg-white/20 text-white" : "bg-muted text-muted-foreground",
                )}
              >
                {data[t.key].length}
              </span>
            </button>
          )
        })}
        {appliedSet && appliedCount > 0 && (
          <span className="inline-flex items-center gap-1 rounded-md bg-up/10 px-2.5 py-1 text-xs font-medium text-up">
            <Check className="h-3 w-3" />
            {appliedLabel} {appliedCount}/{items.length}
          </span>
        )}
        <div className="ml-auto flex items-center gap-2">
          {pushTarget && items.length > 0 && (
            <button
              onClick={handlePush}
              className={cn(
                "inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-colors",
                pushedKey === active
                  ? "bg-up/10 text-up"
                  : active === "否定词候选"
                    ? "bg-down text-white hover:bg-down/90"
                    : "bg-up text-white hover:bg-up/90",
              )}
            >
              {pushedKey === active ? <Check className="h-3.5 w-3.5" /> : <Send className="h-3.5 w-3.5" />}
              {pushedKey === active ? "已推送" : `推送到「${pushTarget}」`}
            </button>
          )}
          <button className="inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-3 py-1.5 text-sm font-medium text-foreground hover:bg-muted">
            <Copy className="h-3.5 w-3.5" />
            复制搜索词
          </button>
          <button className="inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-3 py-1.5 text-sm font-medium text-foreground hover:bg-muted">
            <Download className="h-3.5 w-3.5" />
            导出
          </button>
        </div>
      </div>

      {/* 提示 / 推送反馈 */}
      {pushedKey === active && pushMsg ? (
        <p className="mt-3 inline-flex items-center gap-1.5 text-xs font-medium text-up">
          <Check className="h-3.5 w-3.5" />
          {pushMsg}
        </p>
      ) : (
        <p className="mt-3 inline-flex items-center gap-1.5 text-xs text-down">
          <Ban className="h-3.5 w-3.5" />
          {items[0]?.reason ?? "暂无符合规则的搜索词"}
        </p>
      )}

      {/* 结果表 */}
      <div className="mt-3 overflow-x-auto rounded-md border border-border">
        <table className="w-full min-w-[760px] text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/40 text-left text-xs text-muted-foreground">
              <th className="px-4 py-2.5 font-medium">搜索词</th>
              <th className="px-4 py-2.5 font-medium">ASIN</th>
              <th className="px-4 py-2.5 font-medium">点击</th>
              <th className="px-4 py-2.5 font-medium">花费($)</th>
              <th className="px-4 py-2.5 font-medium">订单</th>
              <th className="px-4 py-2.5 font-medium">ACOS</th>
              <th className="px-4 py-2.5 font-medium">CVR</th>
              <th className="px-4 py-2.5 font-medium">判断</th>
              {appliedSet && <th className="px-4 py-2.5 font-medium">执行状态</th>}
            </tr>
          </thead>
          <tbody>
            {items.map((it) => {
              const isApplied = appliedSet?.has(it.keyword.toLowerCase()) ?? false
              return (
                <tr key={it.keyword} className="border-b border-border last:border-0 hover:bg-muted/30">
                  <td className="px-4 py-2.5 font-medium text-foreground">{it.keyword}</td>
                  <td className="px-4 py-2.5 text-muted-foreground">{it.asin}</td>
                  <td className="px-4 py-2.5 text-foreground">{it.clicks}</td>
                  <td className="px-4 py-2.5 text-foreground">{it.spend.toFixed(1)}</td>
                  <td className="px-4 py-2.5 text-foreground">{it.orders}</td>
                  <td className={cn("px-4 py-2.5 font-medium", it.acos > 40 ? "text-down" : it.acos > 0 ? "text-up" : "text-muted-foreground")}>
                    {it.acos > 0 ? `${it.acos}%` : "-"}
                  </td>
                  <td className="px-4 py-2.5 text-foreground">{it.cvr > 0 ? `${it.cvr}%` : "-"}</td>
                  <td className="px-4 py-2.5 text-xs text-muted-foreground">{it.reason}</td>
                  {appliedSet && (
                    <td className="px-4 py-2.5">
                      {isApplied ? (
                        <span className="inline-flex items-center gap-1 rounded bg-up/10 px-2 py-0.5 text-xs font-medium text-up">
                          <Check className="h-3 w-3" />
                          {appliedLabel}
                        </span>
                      ) : (
                        <span className="text-xs text-muted-foreground">待执行</span>
                      )}
                    </td>
                  )}
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}
