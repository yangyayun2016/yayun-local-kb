"use client"

import { useState } from "react"
import {
  ChevronDown,
  Plus,
  Filter,
  Search,
  Layers,
  Upload,
  KeyRound,
  Bot,
  Ban,
  Gauge,
  Wallet,
  LayoutGrid,
  Eye,
  Inbox,
} from "lucide-react"
import { autoRules, ruleFilters, type AutoRule } from "@/lib/mock/auto-rules"
import { cn } from "@/lib/utils"

const resultColor: Record<AutoRule["lastResult"], string> = {
  成功: "text-up",
  未运行: "text-muted-foreground",
  失败: "text-down",
}

const candidateModules = [
  { key: "否定词候选", icon: Ban, count: 0, color: "bg-brand text-white", activeIcon: "text-white" },
  { key: "加词候选", icon: Plus, count: 0, color: "bg-background text-foreground", activeIcon: "text-up" },
  { key: "出价调整", icon: Gauge, count: 0, color: "bg-background text-foreground", activeIcon: "text-amber-600" },
  { key: "预算调整", icon: Wallet, count: 0, color: "bg-background text-foreground", activeIcon: "text-emerald-600" },
  { key: "广告位 TOS/ROS/PP 调整", icon: LayoutGrid, count: 0, color: "bg-background text-foreground", activeIcon: "text-brand" },
  { key: "重点关注", icon: Eye, count: 0, color: "bg-background text-foreground", activeIcon: "text-purple-600" },
] as const

export function AutoRules() {
  const [rules, setRules] = useState(autoRules)
  const [activeModule, setActiveModule] = useState<string>(candidateModules[0].key)
  const current = candidateModules.find((m) => m.key === activeModule) ?? candidateModules[0]

  function toggleStatus(id: string) {
    setRules((prev) =>
      prev.map((r) =>
        r.id === id ? { ...r, status: r.status === "启用" ? "暂停" : "启用" } : r,
      ),
    )
  }

  return (
    <div className="space-y-4">
      {/* 筛选区 */}
      <div className="rounded-lg border border-border bg-card p-4 shadow-sm">
        <div className="grid grid-cols-1 gap-4 md:grid-cols-3 lg:grid-cols-5">
          {ruleFilters.map((f) => (
            <div key={f.label} className="min-w-0">
              <label className="mb-1.5 block truncate text-xs text-muted-foreground">{f.label}</label>
              <button className="flex w-full items-center justify-between rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground">
                <span>{f.placeholder}</span>
                <ChevronDown className="h-4 w-4 text-muted-foreground" />
              </button>
            </div>
          ))}
        </div>
        <div className="mt-4 flex flex-wrap items-end gap-4">
          <div className="min-w-48">
            <label className="mb-1.5 block text-xs text-muted-foreground">排序</label>
            <button className="flex w-full items-center justify-between rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground">
              <span>全选</span>
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            </button>
          </div>
          <button className="inline-flex items-center gap-1.5 rounded-md bg-brand px-6 py-2 text-sm font-medium text-white hover:bg-brand/90">
            <Search className="h-4 w-4" />
            搜索
          </button>
          <span className="inline-flex items-center gap-1.5 pb-2 text-xs text-muted-foreground">
            <Bot className="h-3.5 w-3.5 text-brand" />
            AI 会记录和监控每一个动作
          </span>
        </div>
      </div>

      {/* 操作按钮组 */}
      <div className="flex flex-wrap items-center justify-end gap-2">
        <ToolButton icon={Filter}>筛选项</ToolButton>
        <ToolButton icon={Layers}>方案</ToolButton>
        <ToolButton icon={Search}>搜索</ToolButton>
        <button className="inline-flex items-center gap-1.5 rounded-md bg-brand px-3 py-2 text-sm font-medium text-white hover:bg-brand/90">
          <Plus className="h-4 w-4" />
          创建自动规则
        </button>
        <ToolButton icon={Layers}>批量操作</ToolButton>
        <ToolButton icon={Upload}>Import Shared Rule</ToolButton>
        <ToolButton icon={KeyRound}>共享通行码列表</ToolButton>
      </div>

      {/* 规则表格 */}
      <div className="overflow-x-auto rounded-lg border border-border bg-card shadow-sm">
        <table className="w-full min-w-[1100px] text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/40 text-left text-xs text-muted-foreground">
              <th className="px-4 py-3 font-medium">广告活动名称</th>
              <th className="px-4 py-3 font-medium">状态</th>
              <th className="px-4 py-3 font-medium">规则类型</th>
              <th className="px-4 py-3 font-medium">应用对象</th>
              <th className="px-4 py-3 font-medium">频率</th>
              <th className="px-4 py-3 font-medium">上次执行结果</th>
              <th className="px-4 py-3 font-medium">上次 | 下次执行</th>
              <th className="px-4 py-3 font-medium">开始 | 结束日期</th>
              <th className="px-4 py-3 font-medium">拥有者</th>
              <th className="px-4 py-3 font-medium">创建时间(PST)</th>
            </tr>
          </thead>
          <tbody>
            {rules.map((r) => (
              <tr key={r.id} className="border-b border-border last:border-0 hover:bg-muted/30">
                <td className="px-4 py-3">
                  <span className="font-medium text-foreground">{r.campaign}</span>
                  <span className="ml-2 rounded bg-muted px-1.5 py-0.5 text-xs text-muted-foreground">{r.tag}</span>
                </td>
                <td className="px-4 py-3">
                  <button
                    onClick={() => toggleStatus(r.id)}
                    className={cn(
                      "rounded-md px-2 py-0.5 text-xs font-medium transition-colors",
                      r.status === "启用"
                        ? "bg-up/10 text-up hover:bg-up/20"
                        : "bg-amber-100 text-amber-700 hover:bg-amber-200",
                    )}
                  >
                    {r.status}
                  </button>
                </td>
                <td className="px-4 py-3 text-foreground">{r.type}</td>
                <td className="px-4 py-3 text-foreground">{r.target}</td>
                <td className="px-4 py-3 text-foreground">{r.frequency}</td>
                <td className={cn("px-4 py-3 font-medium", resultColor[r.lastResult])}>{r.lastResult}</td>
                <td className="px-4 py-3 text-muted-foreground">{r.lastNext}</td>
                <td className="px-4 py-3 text-muted-foreground">{r.dateRange}</td>
                <td className="px-4 py-3 text-foreground">{r.owner}</td>
                <td className="px-4 py-3 text-muted-foreground">{r.createdAt}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* 候选结果模块 */}
      <div className="rounded-lg border border-border bg-card p-4 shadow-sm">
        <div className="flex flex-wrap items-center gap-2.5">
          {candidateModules.map((m) => {
            const isActive = m.key === activeModule
            return (
              <button
                key={m.key}
                onClick={() => setActiveModule(m.key)}
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-full border px-3.5 py-1.5 text-sm font-medium transition-colors",
                  isActive
                    ? "border-brand bg-brand text-white shadow-sm"
                    : "border-border bg-background text-foreground hover:bg-muted",
                )}
              >
                <m.icon className={cn("h-4 w-4", isActive ? "text-white" : m.activeIcon)} />
                {m.key}
                <span
                  className={cn(
                    "ml-1 inline-flex h-5 min-w-5 items-center justify-center rounded-full px-1.5 text-xs font-semibold",
                    isActive ? "bg-white/20 text-white" : "bg-muted text-muted-foreground",
                  )}
                >
                  {m.count}
                </span>
              </button>
            )
          })}
        </div>

        {/* 当前模块内容区 */}
        <div className="mt-4 flex flex-col items-center justify-center rounded-md border border-dashed border-border bg-muted/20 py-10 text-center">
          <Inbox className="h-8 w-8 text-muted-foreground/50" />
          <p className="mt-2 text-sm font-medium text-foreground">{current.key}</p>
          <p className="mt-1 text-xs text-muted-foreground">暂无候选项，规则执行后将在此展示符合条件的结果</p>
        </div>
      </div>
    </div>
  )
}

function ToolButton({ icon: Icon, children }: { icon: typeof Filter; children: React.ReactNode }) {
  return (
    <button className="inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-3 py-2 text-sm font-medium text-foreground hover:bg-muted">
      <Icon className="h-4 w-4 text-muted-foreground" />
      {children}
    </button>
  )
}
