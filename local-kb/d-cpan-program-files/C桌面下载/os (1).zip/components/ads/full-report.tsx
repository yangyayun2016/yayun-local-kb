import { ArrowDown } from "lucide-react"
import {
  productInfo,
  layer1Table,
  monthlyTable,
  campaignTable,
  keywordTable,
  placementTable,
  budgetTable,
  bsrTable,
  causalChain,
  timelineTable,
  stopKeywordTable,
  expandBudgetTable,
  raiseBidTable,
  newWordTable,
  abaHighTable,
  abaLongTailTable,
  externalTable,
  type Cell,
  type ReportTable as TableData,
  type Callout as CalloutData,
} from "@/lib/mock/report-detail"

const toneClass: Record<string, string> = {
  red: "text-down font-medium",
  green: "text-up font-medium",
  orange: "text-amber-600 font-medium",
  muted: "text-muted-foreground",
  bold: "font-semibold text-foreground",
}

function renderCell(cell: Cell) {
  if (typeof cell === "string") return cell
  return <span className={cell.tone ? toneClass[cell.tone] : ""}>{cell.text}</span>
}

/* 章节大标题：蓝色左边框 + 浅蓝底 */
function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <h3 className="mt-7 mb-3 flex items-center gap-2 rounded-md border-l-4 border-brand bg-brand/5 px-3 py-2 text-sm font-semibold text-foreground">
      {children}
    </h3>
  )
}

/* 小标题 */
function SubTitle({ children }: { children: React.ReactNode }) {
  return <h4 className="mb-2 mt-4 text-sm font-medium text-brand">{children}</h4>
}

const calloutStyle: Record<CalloutData["tone"], string> = {
  red: "border-down/30 bg-down/5",
  orange: "border-amber-500/30 bg-amber-500/5",
  yellow: "border-amber-400/40 bg-amber-100/40",
  green: "border-up/30 bg-up/5",
  blue: "border-brand/30 bg-brand/5",
}

function Callout({ tone, title, lines }: CalloutData) {
  return (
    <div className={`my-3 rounded-lg border px-4 py-3 ${calloutStyle[tone]}`}>
      {title && <p className="mb-1.5 text-sm font-semibold text-foreground">{title}</p>}
      <ul className="space-y-1">
        {lines.map((l, i) => (
          <li key={i} className="text-xs leading-relaxed text-muted-foreground">
            {l}
          </li>
        ))}
      </ul>
    </div>
  )
}

function Table({ data }: { data: TableData }) {
  return (
    <div className="overflow-x-auto rounded-lg border border-border">
      <table className="w-full border-collapse text-xs">
        <thead>
          <tr className="bg-muted/60 text-muted-foreground">
            {data.headers.map((h) => (
              <th key={h} className="whitespace-nowrap px-3 py-2 text-left font-medium">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.rows.map((row, ri) => {
            const alert = data.alertRows?.includes(ri)
            const muted = data.mutedRows?.includes(ri)
            return (
              <tr
                key={ri}
                className={`border-t border-border ${
                  alert ? "bg-down/5" : muted ? "bg-muted/30 text-muted-foreground" : ""
                }`}
              >
                {row.map((cell, ci) => (
                  <td key={ci} className={`whitespace-nowrap px-3 py-2 ${ci === 0 ? "font-medium text-foreground" : "text-foreground/80"}`}>
                    {renderCell(cell)}
                  </td>
                ))}
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}

/* 因果链 */
function CausalChain() {
  return (
    <div className="my-3 rounded-lg border border-border bg-page/50 p-4">
      <div className="flex flex-col items-start gap-1">
        {causalChain.map((step, i) => (
          <div key={i} className="flex flex-col items-start">
            <span className="text-xs leading-relaxed text-foreground/80">{step}</span>
            {i < causalChain.length - 1 && <ArrowDown className="my-0.5 h-3.5 w-3.5 text-muted-foreground" />}
          </div>
        ))}
      </div>
      <p className="mt-3 border-t border-border pt-3 text-xs font-medium text-down">
        广告流量断崖 → 自然排名因销量不足持续下滑 → BSR 恶化
      </p>
    </div>
  )
}

function ActionRow({ tag, children }: { tag: string; children: React.ReactNode }) {
  return (
    <p className="mb-2 mt-3 text-xs leading-relaxed text-foreground/90">
      <span className="mr-1.5 font-semibold text-foreground">{tag}</span>
      {children}
    </p>
  )
}

export function FullReport({ asin, shop, time }: { asin: string; shop: string; time: string }) {
  return (
    <div className="text-sm">
      {/* 报告抬头 */}
      <div className="rounded-lg border border-border bg-card p-4">
        <h2 className="text-base font-bold text-foreground">{asin} 广告分析报告（完整版）</h2>
        <div className="mt-3 rounded-lg border border-amber-500/30 bg-amber-500/5 px-4 py-3 text-xs leading-relaxed text-muted-foreground">
          <p>
            <span className="font-medium text-foreground">分析日期：</span>2026-05-10
          </p>
          <p className="mt-1">
            <span className="font-medium text-foreground">数据来源：</span>天机 OS 数据库（领星同步）+ 卖家精灵 + SIF MCP + Amazon BA 搜索词绩效
          </p>
          <p className="mt-1">
            <span className="font-medium text-foreground">覆盖：</span>月度销售广告数据、Campaign 操作日志、关键词层级表现、广告位拆解、关键词需求时机、流量异常诊断
          </p>
        </div>
        <p className="mt-3 text-xs leading-relaxed text-muted-foreground">
          脱敏说明：本报告所有 ASIN（B0XX/BOYY/B0ZZ 系列）、品牌名（品牌 A/B）、产品描述、英文关键词（K01-K18）、类目（Category X）均为脱敏占位符；数量级保留真实规模，便于演示分析方法论。
        </p>
      </div>

      {/* 一、产品基础信息 */}
      <SectionTitle>一、产品基础信息</SectionTitle>
      <div className="overflow-hidden rounded-lg border border-border">
        <table className="w-full border-collapse text-xs">
          <thead>
            <tr className="bg-muted/60 text-muted-foreground">
              <th className="w-40 px-3 py-2 text-left font-medium">字段</th>
              <th className="px-3 py-2 text-left font-medium">数据</th>
            </tr>
          </thead>
          <tbody>
            {productInfo.map((r) => (
              <tr key={r.field} className="border-t border-border">
                <td className="px-3 py-2 font-medium text-foreground">{r.field}</td>
                <td className="px-3 py-2 text-foreground/80">{r.value}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* 二、第一层：基本面 */}
      <SectionTitle>二、第一层：基本面</SectionTitle>
      <SubTitle>2.1 评分 / 评论</SubTitle>
      <Table data={layer1Table} />
      <SubTitle>2.2 价格与竞争力</SubTitle>
      <ul className="ml-4 list-disc space-y-1 text-xs leading-relaxed text-muted-foreground">
        <li>上市初期 $24.99，约 2026 年 3 月调整至 $25.99</li>
        <li>涨价后 3-4 月销量反而是历史最好阶段，说明定价合理、有提价空间</li>
      </ul>
      <SubTitle>2.3 库存状态</SubTitle>
      <ul className="ml-4 list-disc space-y-1 text-xs leading-relaxed text-muted-foreground">
        <li>数据库未见断货记录，4 月日均出单稳定，判断库存正常</li>
        <li>5 月销量骤降原因另有其他，不是断货（见第五节）</li>
      </ul>

      {/* 三、月度销售、广告 & 毛利综合表现 */}
      <SectionTitle>三、月度销售、广告 & 毛利综合表现</SectionTitle>
      <Callout
        tone="yellow"
        lines={[
          "数据来源：lx_ad_asin_daily + lx_profit_asin_daily",
          "毛利润字段说明：gross_profit 已扣除平台佣金、FBA 费、仓储费、广告费、商品成本，是真实广告后净利润，数据可信。",
        ]}
      />
      <SubTitle>3.0 盈亏分析框架</SubTitle>
      <div className="mb-3 rounded-lg border border-border bg-page/50 p-3 text-xs leading-relaxed text-foreground/80">
        <p>毛利率（广告后）= gross_profit / 总销售额</p>
        <p>广告前毛利率（盈亏平衡 ACOS）=（gross_profit + 广告费）/ 总销售额</p>
        <p>ACOS &lt; 广告前毛利率 = 广告盈利；ACOS &gt; 广告前毛利率 = 广告亏损</p>
        <p className="mt-1 text-muted-foreground">该产品广告前毛利率历史范围：约 19%–29%（月均约 24%）</p>
      </div>
      <SubTitle>3.1 月度广告 + 毛利综合数据</SubTitle>
      <Table data={monthlyTable} />
      <Callout
        tone="red"
        title="关键结论：该产品盈亏平衡 ACOS 约为 31%（基于 2026 年 4 月完整成本数据推算）"
        lines={[
          "· 当前 5 月 ACOS = 37.7%，每投一块钱广告在亏钱",
          "· 历史最优期（2025 年 7-10 月）ACOS 16~21%，有 10 个百分点的安全余量",
          "· 优先任务：把「K01」（0 购买）和「K02」（0 购买）停投，释放预算投向高效词",
        ]}
      />

      {/* 四、第二层：投放现状分析 */}
      <SectionTitle>四、第二层：投放现状分析</SectionTitle>
      <SubTitle>4.1 Campaign 结构总览（共 12 个 SP）</SubTitle>
      <Table data={campaignTable} />
      <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
        结构判断：以 SP 手动精准词为主，没有 SB / SD，广告类型单一，全靠 SP 搜索结果位，没有详情页定投补充，广告结构不稳定。
      </p>
      <SubTitle>4.2 关键词层级表现（近 3 月，花费 &gt; 0）</SubTitle>
      <Table data={keywordTable} />
      <Callout
        tone="orange"
        title="关键词层核心发现"
        lines={[
          "1. 最高效词几乎没有预算：K04（ACOS 11%）、K09（7.3%）、K10（8.8%）花费合计不到 $32",
          "2. 最大词 K07（月搜 201K）近 3 月只花了 $6、0 订单，完全没有被认真投放",
          "3. K05（ACOS 49.6%）是当前最大亏损词，需要立即降价或暂停",
        ]}
      />
      <SubTitle>4.3 广告位表现</SubTitle>
      <p className="mb-2 text-xs leading-relaxed text-muted-foreground">
        分析原则：不能只看汇总广告位 ACOS，必须下钻到 Campaign 级别，因为同一广告位在不同 Campaign 下表现可能截然不同。
      </p>
      <Table data={placementTable} />
      <Callout
        tone="green"
        title="广告位层核心结论"
        lines={[
          "1. 搜索首位本身不是问题——「海王」ACOS 仅 25.3%，是特定 Campaign 的词选错了",
          "2. 「顶首页」只需关闭搜索首位的出价倍增系数，不应整个 Campaign 停掉",
          "3. 「K07-重开」才是真正要暂停的 Campaign——三个广告位全面亏损（38~51%）",
          "4. 「销量词低竞价」是最高效 Campaign——应优先扩大预算",
        ]}
      />
      <SubTitle>4.4 预算分配——打满情况</SubTitle>
      <Callout tone="red" lines={["这是当前最核心的结构问题。"]} />
      <Table data={budgetTable} />

      {/* 五、竞品对标分析 */}
      <SectionTitle>五、竞品对标分析</SectionTitle>
      <SubTitle>5.2 竞品 BSR 横向对比（诊断 5 月下滑根因）</SubTitle>
      <Callout
        tone="orange"
        lines={[
          "分析原则：业绩下滑时，第一步先看竞品是否同步下滑。同步下滑＝市场整体现象；只有我们下滑＝内部问题；我们下滑幅度更大＝混合原因。",
        ]}
      />
      <Table data={bsrTable} />
      <Callout
        tone="red"
        lines={["诊断结论：混合原因——市场整体回落 + 我们广告断投加速下滑（市场跌 1.5 倍，我们跌 4 倍）"]}
      />

      {/* 六、5月排名下滑根因诊断 */}
      <SectionTitle>六、5 月排名下滑根因诊断</SectionTitle>
      <Callout tone="blue" lines={["根因：不是产品问题，是旺季到来时广告预算 / 出价没有跟上。"]} />
      <SubTitle>因果链还原</SubTitle>
      <CausalChain />
      <SubTitle>时间线对照</SubTitle>
      <Table data={timelineTable} />

      {/* 七、可立即执行的动作 */}
      <SectionTitle>七、可立即执行的动作</SectionTitle>
      <div className="mb-1 inline-flex rounded bg-down/10 px-2 py-1 text-xs font-semibold text-down">优先级 1：今日解决（止损）</div>
      <ActionRow tag="动作 1：">立即停投「K01」和「K02」——这是当前最大的出血口，$147/3 月打水漂：</ActionRow>
      <Table data={stopKeywordTable} />
      <ActionRow tag="动作 2：">扩大高效 Campaign 预算</ActionRow>
      <Table data={expandBudgetTable} />
      <ActionRow tag="动作 3：">
        「K07-重开」评估暂停——吃掉 88% 曝光，但三个广告位 ACOS 全部在 38–51%，建议暂停重建。
      </ActionRow>

      <div className="mb-1 mt-5 inline-flex rounded bg-amber-500/10 px-2 py-1 text-xs font-semibold text-amber-600">优先级 2：本周处理</div>
      <ActionRow tag="动作 4：">
        修正「顶首页」Campaign——不是停，是调位置。将「搜索结果顶部」的出价倍增系数降至 0%。
      </ActionRow>
      <ActionRow tag="动作 5：">加大真正高效词出价</ActionRow>
      <Table data={raiseBidTable} />
      <ActionRow tag="动作 6：">停掉其余小额无转化词（K05 降至 $0.15 或暂停，K06/K08 暂停）</ActionRow>

      <div className="mb-1 mt-5 inline-flex rounded bg-up/10 px-2 py-1 text-xs font-semibold text-up">优先级 3：中期布局</div>
      <ActionRow tag="动作 7：">
        「K07」大词——旺季真正峰值是 7 月，距今还有 12 周。现在是「布局自然排名」窗口。
      </ActionRow>
      <ActionRow tag="动作 8：">新词测试（BA 高转化长尾词）</ActionRow>
      <Table data={newWordTable} />
      <ActionRow tag="动作 9：">
        加速评论积累——65 条评论在本品类偏弱，建议开启 Request a Review 自动发送，目标 3 个月内到 150 条。
      </ActionRow>

      {/* 八、ABA 搜索词绩效报告分析 */}
      <SectionTitle>八、ABA 搜索词绩效报告分析</SectionTitle>
      <Callout
        tone="yellow"
        lines={[
          "数据来源：amazon.ba.query.performance.rows，周期：2026-05-02（周报）",
          "点击占比 / 购买占比 → 该 ASIN 在此词下的点击 / 购买份额",
        ]}
      />
      <SubTitle>8.1 高量级词（月搜索量 &gt; 5,000）表现</SubTitle>
      <Table data={abaHighTable} />
      <Callout
        tone="red"
        title="关键发现：广告投向与真实转化严重错位"
        lines={[
          "花费最多的词，购买转化为零：K01（$88）+ K02（$59）= $147，占近 3 月总广告花费的 42%，但 BA 购买份额为零。不是竞价问题，是词本身就转化不了这个产品。",
          "购买占比最高的词，广告几乎没有覆盖：K10 购买占比 80%，但近 3 月仅投了 $2。",
        ]}
      />
      <SubTitle>8.2 值得挖掘的长尾高转化词</SubTitle>
      <Table data={abaLongTailTable} />

      {/* 九、外部视角机会 */}
      <SectionTitle>九、外部视角机会（词的空白）</SectionTitle>
      <Table data={externalTable} />
    </div>
  )
}
