"use client"

import { useEffect, useMemo, useState } from "react"
import {
  Bar,
  CartesianGrid,
  ComposedChart,
  Brush,
  Line,
  ResponsiveContainer,
  Scatter,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"
import { X } from "lucide-react"
import { cn } from "@/lib/utils"
import {
  buildTimeline,
  timelineMetrics,
  CHANGE_COLOR,
  type ChangeRecord,
} from "@/lib/mock/asin-view"

/** 数值格式化 */
function fmtVal(v: number, fmt: string): string {
  if (v == null || Number.isNaN(v)) return "-"
  switch (fmt) {
    case "eur":
      return "€" + v.toFixed(2).replace(".", ",")
    case "pct":
      return v.toFixed(2).replace(".", ",") + "%"
    case "ratio":
      return v.toFixed(2).replace(".", ",")
    default:
      return Math.round(v).toLocaleString("en-US")
  }
}

/** 更改记录散点的自定义标记：紫色圆圈 + 次数，可点击 */
function ChangeDot(props: any) {
  const { cx, cy, payload, onPick } = props
  if (cx == null || cy == null || !payload?.change) return null
  const label = String(payload.change)
  const r = 11
  return (
    <g
      transform={`translate(${cx},${cy})`}
      style={{ cursor: "pointer" }}
      onClick={() => onPick?.(payload.date)}
    >
      <circle r={r} fill="#fff" stroke={CHANGE_COLOR} strokeWidth={1.5} />
      <text
        textAnchor="middle"
        dominantBaseline="central"
        fontSize={11}
        fontWeight={600}
        fill={CHANGE_COLOR}
      >
        {label}
      </text>
    </g>
  )
}

export function Timeline({ shop, sku }: { shop: string; sku: string }) {
  const { points, changes } = useMemo(() => buildTimeline(shop, sku), [shop, sku])

  // 默认选中：点击量
  const [selected, setSelected] = useState<Set<string>>(new Set(["clicks"]))
  // 是否显示更改记录标记（默认显示）
  const [showChanges, setShowChanges] = useState(true)
  // 当前展开查看的更改记录
  const [activeDate, setActiveDate] = useState<string | null>(null)
  // 缩放窗口
  const lastIndex = points.length - 1
  const [brushRange, setBrushRange] = useState<[number, number]>([0, lastIndex])

  useEffect(() => {
    setBrushRange([0, points.length - 1])
    setActiveDate(null)
  }, [shop, sku, points.length])

  function toggleMetric(key: string) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(key)) next.delete(key)
      else next.add(key)
      return next
    })
  }

  const activeRecord: ChangeRecord | undefined = useMemo(
    () => changes.find((c) => c.date === activeDate),
    [changes, activeDate],
  )

  // 散点数据只保留有更改记录的天
  const scatterData = useMemo(() => points.filter((p) => p.change), [points])

  const selectedMetrics = timelineMetrics.filter((m) => selected.has(m.key))

  return (
    <div className="rounded-lg border border-border bg-card p-5 shadow-sm">
      <h3 className="text-sm font-semibold text-foreground">时间线</h3>

      {/* 指标图例（可切换） */}
      <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2">
        {timelineMetrics.map((m) => {
          const on = selected.has(m.key)
          return (
            <button
              key={m.key}
              onClick={() => toggleMetric(m.key)}
              className="inline-flex items-center gap-1.5 text-xs transition-colors"
            >
              <span
                className="inline-block h-0.5 w-4 rounded-full"
                style={{ background: on ? m.color : "#d9d9d9" }}
              />
              <span
                className={cn("font-medium", on ? "" : "text-muted-foreground")}
                style={on ? { color: m.color } : undefined}
              >
                {m.label}
              </span>
            </button>
          )
        })}
        {/* 更改记录开关 */}
        <button
          onClick={() => setShowChanges((s) => !s)}
          className="inline-flex items-center gap-1.5 text-xs transition-colors"
        >
          <span
            className="inline-block h-0.5 w-4 rounded-full"
            style={{ background: showChanges ? CHANGE_COLOR : "#d9d9d9" }}
          />
          <span
            className={cn("font-medium", showChanges ? "" : "text-muted-foreground")}
            style={showChanges ? { color: CHANGE_COLOR } : undefined}
          >
            更改记录
          </span>
        </button>
      </div>

      {/* 图表 */}
      <div className="mt-4 h-96">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={points} margin={{ top: 20, right: 8, left: -4, bottom: 4 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#eef0f3" vertical={false} />
            <XAxis
              dataKey="date"
              tick={{ fontSize: 10, fill: "#94a3b8" }}
              axisLine={false}
              tickLine={false}
              interval={0}
              minTickGap={4}
            />
            {/* 左轴：数值 */}
            <YAxis
              yAxisId="left"
              tick={{ fontSize: 10, fill: "#94a3b8" }}
              axisLine={false}
              tickLine={false}
              width={44}
            />
            {/* 右轴：更改记录次数 */}
            <YAxis
              yAxisId="right"
              orientation="right"
              allowDecimals={false}
              tick={{ fontSize: 10, fill: "#94a3b8" }}
              axisLine={false}
              tickLine={false}
              width={28}
            />
            <Tooltip
              contentStyle={{
                borderRadius: 8,
                border: "1px solid #e5e7eb",
                fontSize: 12,
                boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
              }}
              labelStyle={{ color: "#64748b" }}
              formatter={(value: number, name: string) => {
                if (name === "更改记录") return [`${value} 次`, name]
                const meta = timelineMetrics.find((m) => m.label === name)
                return [fmtVal(value, meta?.fmt ?? "int"), name]
              }}
            />

            {/* 选中的数值指标折线（左轴） */}
            {selectedMetrics.map((m) => (
              <Line
                key={m.key}
                yAxisId="left"
                type="monotone"
                dataKey={m.key}
                name={m.label}
                stroke={m.color}
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 4 }}
                isAnimationActive={false}
              />
            ))}

            {/* 占位柱（透明）保证右轴存在并参与缩放 */}
            <Bar yAxisId="right" dataKey="change" fill="transparent" name="更改记录" />

            {/* 更改记录散点标记（右轴，可点击） */}
            {showChanges && (
              <Scatter
                yAxisId="right"
                data={scatterData}
                dataKey="change"
                name="更改记录"
                shape={<ChangeDot onPick={setActiveDate} />}
                isAnimationActive={false}
              />
            )}

            {/* 缩放：拖动可查看更长时间 */}
            <Brush
              dataKey="date"
              height={24}
              travellerWidth={10}
              stroke="#13c2c2"
              fill="#13c2c214"
              startIndex={brushRange[0]}
              endIndex={brushRange[1]}
              onChange={(range) => {
                if (range && typeof range.startIndex === "number" && typeof range.endIndex === "number") {
                  setBrushRange([range.startIndex, range.endIndex])
                }
              }}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      {/* 更改记录明细：点击标记后展开 */}
      {activeRecord && (
        <div className="mt-4 rounded-lg border border-border bg-background p-4">
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium text-foreground">
              <span style={{ color: CHANGE_COLOR }}>{activeRecord.date}</span> 共 {activeRecord.count} 条更改记录
            </p>
            <button
              onClick={() => setActiveDate(null)}
              className="rounded p-1 text-muted-foreground hover:bg-muted hover:text-foreground"
              aria-label="关闭明细"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
          <ul className="mt-3 divide-y divide-border">
            {activeRecord.items.map((item, i) => (
              <li key={i} className="flex items-start gap-3 py-2.5">
                <span
                  className={cn(
                    "mt-0.5 shrink-0 rounded px-2 py-0.5 text-xs font-medium",
                    item.category === "广告日志"
                      ? "bg-brand/10 text-brand"
                      : item.category === "运营日志"
                        ? "bg-up/10 text-up"
                        : "bg-[#722ed1]/10 text-[#722ed1]",
                  )}
                >
                  {item.category}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-foreground">{item.action}</p>
                  <p className="truncate text-xs text-muted-foreground">{item.detail}</p>
                </div>
                <span className="shrink-0 text-xs tabular-nums text-muted-foreground">{item.time}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  )
}
