"use client"

import { useMemo, useState } from "react"
import {
  Area,
  CartesianGrid,
  ComposedChart,
  Line,
  ReferenceDot,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"
import { cn } from "@/lib/utils"
import { buildHourlyTrend, hourlyMetrics, type HourlyMetric } from "@/lib/mock/asin-view"

/** 原始值格式化 */
function fmtVal(v: number, fmt: string): string {
  if (v == null || Number.isNaN(v)) return "-"
  switch (fmt) {
    case "eur":
      return "€" + v.toFixed(2)
    case "pct":
      return v.toFixed(2) + "%"
    case "ratio":
      return v.toFixed(2)
    default:
      return Math.round(v).toLocaleString("en-US")
  }
}

/** X 轴双行刻度：整点 + 区间 */
function HourTick(props: any) {
  const { x, y, payload } = props
  const range = `${payload.value.slice(0, 2)}:59`
  return (
    <g transform={`translate(${x},${y})`}>
      <text textAnchor="middle" fontSize={10} fill="#475569" dy={12}>
        {payload.value}
      </text>
      <text textAnchor="middle" fontSize={9} fill="#cbd5e1" dy={26}>
        {range}
      </text>
    </g>
  )
}

export function HourlyTrend({ shop, sku }: { shop: string; sku: string }) {
  const { points, peaks } = useMemo(() => buildHourlyTrend(shop, sku), [shop, sku])

  // 默认选中：销售额 + CPC（与设计稿一致）
  const [selected, setSelected] = useState<Set<string>>(new Set(["sales", "cpc"]))

  function toggleMetric(key: string) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(key)) {
        // 至少保留一个指标
        if (next.size > 1) next.delete(key)
      } else {
        next.add(key)
      }
      return next
    })
  }

  const selectedMetrics = hourlyMetrics.filter((m) => selected.has(m.key))

  return (
    <div className="rounded-lg border border-border bg-card p-5 shadow-sm">
      {/* 标题 + 图例 */}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="text-sm font-semibold text-foreground">24 小时指标趋势</h3>
          <p className="mt-1 text-xs text-muted-foreground">
            横轴逐小时展示；多指标按各自峰值对齐。CTR / CVR / CPC / ACOS / ROAS
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
          {hourlyMetrics.map((m) => {
            const on = selected.has(m.key)
            return (
              <button
                key={m.key}
                onClick={() => toggleMetric(m.key)}
                className="inline-flex items-center gap-1.5 text-xs transition-colors"
                aria-pressed={on}
              >
                <span
                  className={cn("inline-block h-0.5 w-5 rounded-full", m.dashed && "opacity-90")}
                  style={{
                    background: on
                      ? m.dashed
                        ? `repeating-linear-gradient(90deg, ${m.color} 0 4px, transparent 4px 7px)`
                        : m.color
                      : "#d9d9d9",
                  }}
                />
                <span
                  className={cn("font-medium", on ? "" : "text-muted-foreground")}
                  style={on ? { color: m.color } : undefined}
                >
                  {m.label}
                </span>
              </button>
            )
          })}
        </div>
      </div>

      {/* 图表 */}
      <div className="mt-5 h-[420px]">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={points} margin={{ top: 28, right: 16, left: 8, bottom: 16 }}>
            <defs>
              {selectedMetrics
                .filter((m) => m.area)
                .map((m) => (
                  <linearGradient key={m.key} id={`grad-${m.key}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={m.color} stopOpacity={0.18} />
                    <stop offset="100%" stopColor={m.color} stopOpacity={0.01} />
                  </linearGradient>
                ))}
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#eef0f3" />
            <XAxis
              dataKey="hour"
              tick={<HourTick />}
              axisLine={{ stroke: "#e2e8f0" }}
              tickLine={false}
              interval={0}
              height={44}
            />
            <YAxis
              domain={[0, 100]}
              ticks={[0, 25, 50, 75, 100]}
              tickFormatter={(v) => `${v}%`}
              tick={{ fontSize: 10, fill: "#94a3b8" }}
              axisLine={false}
              tickLine={false}
              width={44}
              label={{
                value: "相对峰值",
                position: "top",
                offset: 14,
                fontSize: 11,
                fill: "#64748b",
              }}
            />
            <Tooltip
              contentStyle={{
                borderRadius: 8,
                border: "1px solid #e5e7eb",
                fontSize: 12,
                boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
              }}
              labelFormatter={(label) => `${label} - ${String(label).slice(0, 2)}:59`}
              formatter={(value: number, _name: string, item: any) => {
                const key: string = item?.dataKey?.replace("Pct", "")
                const meta = hourlyMetrics.find((m) => m.key === key)
                const point = points.find((p) => p[`${key}Pct`] === value)
                const rawVal = point ? (point[key as keyof typeof point] as number) : undefined
                const rawStr = rawVal != null ? ` (${fmtVal(rawVal, meta?.fmt ?? "int")})` : ""
                return [`${value}%${rawStr}`, meta?.label ?? key]
              }}
            />

            {/* 面积型指标（如销售额）：先画面积再叠折线 */}
            {selectedMetrics
              .filter((m) => m.area)
              .map((m) => (
                <Area
                  key={`area-${m.key}`}
                  type="monotone"
                  dataKey={`${m.key}Pct`}
                  name={m.label}
                  stroke={m.color}
                  strokeWidth={2.5}
                  fill={`url(#grad-${m.key})`}
                  dot={{ r: 3, fill: "#fff", stroke: m.color, strokeWidth: 1.5 }}
                  activeDot={{ r: 5 }}
                  isAnimationActive={false}
                />
              ))}

            {/* 折线型指标 */}
            {selectedMetrics
              .filter((m) => !m.area)
              .map((m) => (
                <Line
                  key={`line-${m.key}`}
                  type="monotone"
                  dataKey={`${m.key}Pct`}
                  name={m.label}
                  stroke={m.color}
                  strokeWidth={2}
                  strokeDasharray={m.dashed ? "6 4" : undefined}
                  dot={{ r: 3, fill: "#fff", stroke: m.color, strokeWidth: 1.5 }}
                  activeDot={{ r: 5 }}
                  isAnimationActive={false}
                />
              ))}

            {/* 峰值标注：每个选中指标在其峰值小时显示一个气泡 */}
            {selectedMetrics.map((m) => {
              const peak = peaks[m.key]
              if (!peak) return null
              return (
                <ReferenceDot
                  key={`peak-${m.key}`}
                  x={peak.hour}
                  y={100}
                  r={5}
                  yAxisId={0}
                  fill="#fff"
                  stroke={m.color}
                  strokeWidth={2}
                  label={{
                    value: `${m.label}峰值 ${peak.hour}`,
                    position: "top",
                    fontSize: 11,
                    fill: m.color,
                    offset: 8,
                  }}
                  isFront
                />
              )
            })}
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
