"use client"

import { useEffect, useRef, useState, type ReactNode } from "react"
import { Calendar, ChevronDown, Check } from "lucide-react"
import { dateRangeOptions, type DateRangeOption } from "@/lib/mock/data-detail"
import { cn } from "@/lib/utils"

export function DateRangeDropdown({
  value,
  onChange,
}: {
  value: DateRangeOption
  onChange: (v: DateRangeOption) => void
}) {
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    function onClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener("mousedown", onClick)
    return () => document.removeEventListener("mousedown", onClick)
  }, [])

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen((o) => !o)}
        className="inline-flex items-center gap-1.5 rounded-md border border-border bg-card px-3 py-1.5 text-sm font-medium text-foreground transition-colors hover:bg-muted"
      >
        <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
        {value}
        <ChevronDown className={cn("h-3.5 w-3.5 text-muted-foreground transition-transform", open && "rotate-180")} />
      </button>
      {open && (
        <div className="absolute left-0 top-full z-20 mt-1 max-h-72 w-56 overflow-y-auto rounded-md border border-border bg-card p-1 shadow-lg">
          {dateRangeOptions.map((opt) => (
            <button
              key={opt}
              onClick={() => {
                onChange(opt)
                setOpen(false)
              }}
              className={cn(
                "flex w-full items-center justify-between rounded px-2.5 py-1.5 text-left text-sm transition-colors hover:bg-muted",
                opt === value ? "font-medium text-brand" : "text-foreground",
              )}
            >
              {opt}
              {opt === value && <Check className="h-3.5 w-3.5 text-brand" />}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

export function Segmented({
  options,
  value,
  onChange,
  icon,
}: {
  options: readonly string[]
  value: string
  onChange: (v: string) => void
  icon?: ReactNode
}) {
  return (
    <div className="inline-flex items-center gap-1 rounded-md border border-border bg-card p-0.5">
      {icon && <span className="pl-1.5 text-muted-foreground">{icon}</span>}
      {options.map((opt) => (
        <button
          key={opt}
          onClick={() => onChange(opt)}
          className={cn(
            "rounded px-2.5 py-1 text-sm font-medium transition-colors",
            opt === value ? "bg-brand text-white" : "text-muted-foreground hover:text-foreground",
          )}
        >
          {opt}
        </button>
      ))}
    </div>
  )
}
