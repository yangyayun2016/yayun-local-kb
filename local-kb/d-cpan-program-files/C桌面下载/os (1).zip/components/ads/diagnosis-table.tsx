import { Check } from "lucide-react"
import { diagnosisRows, adSummary } from "@/lib/mock/ads"
import { Delta } from "@/components/ui/delta"

export function DiagnosisTable() {
  return (
    <div className="rounded-lg border border-border bg-card shadow-sm">
      <div className="flex items-center justify-between border-b border-border px-4 py-3">
        <h3 className="text-sm font-semibold text-foreground">每日广告诊断单</h3>
        <p className="text-xs text-muted-foreground">
          昨日数据 {adSummary.diagnosisDate}，对比近 7 天和近 30 天均值
        </p>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[760px] text-sm">
          <thead>
            <tr className="text-left text-xs text-muted-foreground">
              <th className="px-4 py-2.5 font-medium">指标</th>
              <th className="px-4 py-2.5 text-right font-medium">昨天</th>
              <th className="px-4 py-2.5 text-right font-medium">vs 7天均值</th>
              <th className="px-4 py-2.5 text-right font-medium">7天均值</th>
              <th className="px-4 py-2.5 text-right font-medium">vs 30天均值</th>
              <th className="px-4 py-2.5 text-right font-medium">30天均值</th>
              <th className="px-4 py-2.5 text-center font-medium">趋势</th>
            </tr>
          </thead>
          <tbody>
            {diagnosisRows.map((row) => (
              <tr key={row.metric} className="border-t border-border">
                <td className="px-4 py-3 text-foreground">{row.metric}</td>
                <td className="px-4 py-3 text-right text-base font-semibold tabular-nums text-foreground">
                  {row.yesterday}
                </td>
                <td className="px-4 py-3 text-right">
                  <Delta value={row.vs7} lowerIsBetter={row.lowerIsBetter} className="justify-end" />
                </td>
                <td className="px-4 py-3 text-right tabular-nums text-foreground/80">{row.avg7}</td>
                <td className="px-4 py-3 text-right">
                  <Delta value={row.vs30} lowerIsBetter={row.lowerIsBetter} className="justify-end" />
                </td>
                <td className="px-4 py-3 text-right tabular-nums text-foreground/80">{row.avg30}</td>
                <td className="px-4 py-3">
                  <div className="flex justify-center">
                    <span className="flex h-5 w-5 items-center justify-center rounded bg-up/15 text-up">
                      <Check className="h-3.5 w-3.5" />
                    </span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
