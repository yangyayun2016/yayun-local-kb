"use client"

import { useState } from "react"
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"
import { ChevronDown, List, Download, BarChart3 } from "lucide-react"
import { cn } from "@/lib/utils"
import type { ChartPanel } from "@/lib/mock/asin-view"

const granularities = ["日", "周", "月"] as const

export function ChartPanelCard({ panel }: { panel: ChartPanel }) {
  const [view, setView] = useState<"绩效" | "概览">("绩效")
  const [gran, setGran] = useState<(typeof granularities)[number]>("日")
  const [mode, setMode] = useState<"SP" | "SB" | null>(panel.modeTabs[0] ?? null)

  return (
    <div className="rounded-lg border border-border bg-card p-4 shadow-sm">
      {/* 头部工具栏 */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex items-baseline gap-1">
          <h3 className="text-sm font-semibold text-foreground">{panel.title}</h3>
          {panel.subtitle && (
            <span className="text-xs text-muted-foreground">{panel.subtitle}</span>
          )}
        </div>

        {/* 绩效 / 概览 切换 */}
        <div className="flex rounded-md border border-border p-0.5">
          {(["绩效", "概览"] as const).map((v) => (
            <button
              key={v}
              onClick={() => setView(v)}
              className={cn(
                "rounded px-2 py-0.5 text-xs transition-colors",
                view === v ? "bg-brand text-white" : "text-muted-foreground hover:text-foreground",
              )}
            >
              {v}
            </button>
          ))}
        </div>

        <div className="ml-auto flex items-center gap-1.5">
          {/* 指标数下拉 */}
          <button className="inline-flex items-center gap-1 rounded-md border border-border px-2 py-1 text-xs text-foreground hover:border-brand/40">
            3 指标
            <ChevronDown className="h-3 w-3 text-muted-foreground" />
          </button>

          {/* SP/SB 切换 */}
          {panel.modeTabs.map((m) => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={cn(
                "rounded-md border px-2 py-1 text-xs transition-colors",
                mode === m
                  ? "border-brand bg-brand/5 text-brand"
                  : "border-border text-muted-foreground hover:text-foreground",
              )}
            >
              {m}
            </button>
          ))}

          {/* 日/周/月 切换（仅前两个面板有） */}
          {panel.modeTabs.length === 0 && (
            <div className="flex rounded-md border border-border p-0.5">
              {granularities.map((g) => (
                <button
                  key={g}
                  onClick={() => setGran(g)}
                  className={cn(
                    "rounded px-2 py-0.5 text-xs transition-colors",
                    gran === g ? "bg-brand/10 text-brand" : "text-muted-foreground hover:text-foreground",
                  )}
                >
                  {g}
                </button>
              ))}
            </div>
          )}

          <button className="rounded border border-border p-1 text-brand" aria-label="图表视图">
            <BarChart3 className="h-3.5 w-3.5" />
          </button>
          <button className="rounded border border-border p-1 text-muted-foreground hover:text-foreground" aria-label="列表视图">
            <List className="h-3.5 w-3.5" />
          </button>
          <button className="rounded border border-border p-1 text-muted-foreground hover:text-foreground" aria-label="下载">
            <Download className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* 图表 */}
      <div className="mt-4 h-64">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={panel.series} margin={{ top: 8, right: 12, left: -8, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#eef0f3" vertical={false} />
            <XAxis
              dataKey="date"
              tick={{ fontSize: 10, fill: "#94a3b8" }}
              axisLine={false}
              tickLine={false}
              interval={1}
            />
            <YAxis
              tick={{ fontSize: 10, fill: "#94a3b8" }}
              axisLine={false}
              tickLine={false}
              width={48}
            />
            <Tooltip
              contentStyle={{
                borderRadius: 8,
                border: "1px solid #e5e7eb",
                fontSize: 12,
                boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
              }}
              labelStyle={{ color: "#64748b" }}
              formatter={(value: number, _name: string, item) => {
                const leg = panel.legend.find((l) => l.key === (item as { dataKey: string }).dataKey)
                return [value, leg?.label ?? ""]
              }}
            />
            {panel.legend.map((l) => (
              <Line
                key={l.key}
                type="monotone"
                dataKey={l.key}
                stroke={l.color}
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 4 }}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* 图例 */}
      <div className="mt-2 flex flex-wrap items-center justify-center gap-4 text-xs">
        {panel.legend.map((l) => (
          <span key={l.key} className="flex items-center gap-1.5 text-muted-foreground">
            <span className="h-0.5 w-4 rounded-full" style={{ background: l.color }} />
            {l.label}
          </span>
        ))}
      </div>

      {/* 说明 */}
      {panel.note && (
        <p className="mt-2 text-center text-xs text-muted-foreground">{panel.note}</p>
      )}
    </div>
  )
}
