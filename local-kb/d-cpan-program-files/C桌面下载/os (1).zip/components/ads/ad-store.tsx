"use client"

import { createContext, useCallback, useContext, useMemo, useState } from "react"
import {
  gainItems as seedGain,
  stopItems as seedStop,
  type GainItem,
  type StopItem,
} from "@/lib/mock/ad-modules"
import type { SuggestionItem } from "@/lib/mock/rule-settings"

interface AdStore {
  gain: GainItem[]
  stop: StopItem[]
  /** 把规则设置生成的「加词候选」推送到待投放，返回新增数量 */
  pushGain: (items: SuggestionItem[]) => number
  /** 把规则设置生成的「否定词候选」推送到否定，返回新增数量 */
  pushStop: (items: SuggestionItem[]) => number
  /** 已执行「加入投放」的关键词（小写） */
  appliedGain: Set<string>
  /** 已执行「否定」的关键词（小写） */
  appliedStop: Set<string>
  /** 切换某关键词的「加入投放」执行状态 */
  toggleGainApplied: (keyword: string) => void
  /** 切换某关键词的「否定」执行状态 */
  toggleStopApplied: (keyword: string) => void
}

const AdStoreContext = createContext<AdStore | null>(null)

export function AdStoreProvider({ children }: { children: React.ReactNode }) {
  const [gain, setGain] = useState<GainItem[]>(seedGain)
  const [stop, setStop] = useState<StopItem[]>(seedStop)

  const pushGain = useCallback((items: SuggestionItem[]) => {
    let added = 0
    setGain((prev) => {
      const existing = new Set(prev.map((g) => g.keyword.toLowerCase()))
      const next = [...prev]
      for (const it of items) {
        if (existing.has(it.keyword.toLowerCase())) continue
        existing.add(it.keyword.toLowerCase())
        added++
        next.unshift({
          id: `rs-g-${it.keyword}`,
          keyword: it.keyword,
          asin: it.asin,
          matchType: "精准",
          // 建议出价：以类目出单临界（15 点击/单）粗略折算
          suggestedBid: Math.max(0.3, Number((it.spend / Math.max(it.clicks, 1)).toFixed(2))),
          clicks: it.clicks,
          orders: it.orders,
          acos: it.acos,
          cvr: it.cvr,
          source: "规则设置",
        })
      }
      return next
    })
    return added
  }, [])

  const pushStop = useCallback((items: SuggestionItem[]) => {
    let added = 0
    setStop((prev) => {
      const existing = new Set(prev.map((s) => s.keyword.toLowerCase()))
      const next = [...prev]
      for (const it of items) {
        if (existing.has(it.keyword.toLowerCase())) continue
        existing.add(it.keyword.toLowerCase())
        added++
        next.unshift({
          id: `rs-s-${it.keyword}`,
          keyword: it.keyword,
          asin: it.asin,
          negType: "精准否定",
          clicks: it.clicks,
          spend: it.spend,
          days: 0,
          source: "规则设置",
        })
      }
      return next
    })
    return added
  }, [])

  const [appliedGain, setAppliedGain] = useState<Set<string>>(new Set())
  const [appliedStop, setAppliedStop] = useState<Set<string>>(new Set())

  const toggleGainApplied = useCallback((keyword: string) => {
    const key = keyword.toLowerCase()
    setAppliedGain((prev) => {
      const next = new Set(prev)
      next.has(key) ? next.delete(key) : next.add(key)
      return next
    })
  }, [])

  const toggleStopApplied = useCallback((keyword: string) => {
    const key = keyword.toLowerCase()
    setAppliedStop((prev) => {
      const next = new Set(prev)
      next.has(key) ? next.delete(key) : next.add(key)
      return next
    })
  }, [])

  const value = useMemo(
    () => ({
      gain,
      stop,
      pushGain,
      pushStop,
      appliedGain,
      appliedStop,
      toggleGainApplied,
      toggleStopApplied,
    }),
    [gain, stop, pushGain, pushStop, appliedGain, appliedStop, toggleGainApplied, toggleStopApplied],
  )

  return <AdStoreContext.Provider value={value}>{children}</AdStoreContext.Provider>
}

export function useAdStore() {
  const ctx = useContext(AdStoreContext)
  if (!ctx) throw new Error("useAdStore must be used within AdStoreProvider")
  return ctx
}
