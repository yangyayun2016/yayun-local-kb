"use client"

import { useState } from "react"
import { Check, Calendar, RefreshCw, CalendarDays, Box } from "lucide-react"
import { DateRangeDropdown, Segmented } from "./time-filter"
import {
  dateRangeOptions,
  compareModes,
  granularityOptions,
  diagnosisDetailRows,
  detailContext,
  metricGroups,
  quickRanges,
  storeDetailRows,
  storeDetailSummary,
  asinDetailRows,
  asinDetailSummary,
  type DateRangeOption,
  type CompareMode,
  type Granularity,
  type QuickRange,
} from "@/lib/mock/data-detail"
import { Delta } from "@/components/ui/delta"
import { cn } from "@/lib/utils"

export function DataDetail() {
  return (
    <div className="space-y-4">
      <DailyDiagnosisPanel />

      <StoreDetailPanel />

      <AsinDetailPanel />
    </div>
  )
}

/* ---------------- 板块一：每日广告诊断单 ---------------- */

function DailyDiagnosisPanel() {
  const [range, setRange] = useState<DateRangeOption>("昨天")
  const [compare, setCompare] = useState<CompareMode>("环比")
  const [granularity, setGranularity] = useState<Granularity>("按日")
  const [syncing, setSyncing] = useState(false)

  function handleSync() {
    setSyncing(true)
    setTimeout(() => setSyncing(false), 900)
  }

  const healthColor =
    detailContext.health === "正常"
      ? "bg-up/10 text-up"
      : detailContext.health === "预警"
        ? "bg-amber-100 text-amber-700"
        : "bg-down/10 text-down"

  return (
    <div className="rounded-lg border border-border bg-card shadow-sm">
      {/* 标题栏 */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border px-4 py-3">
        <div className="flex items-center gap-2">
          <h3 className="text-sm font-semibold text-foreground">每日广告诊断单</h3>
          <span className={cn("rounded-full px-2 py-0.5 text-xs font-medium", healthColor)}>
            健康状态 · {detailContext.health}
          </span>
        </div>
        <p className="text-xs text-muted-foreground">
          {detailContext.shop} · {range} {compare} · 数据日期 {detailContext.date}
        </p>
      </div>

      {/* ① 筛选维度 */}
      <div className="flex flex-wrap items-center gap-2 border-b border-border bg-muted/20 px-4 py-3">
        <DateRangeDropdown value={range} onChange={setRange} />

        <Segmented
          icon={<RefreshCw className="h-3.5 w-3.5" />}
          options={compareModes as readonly string[]}
          value={compare}
          onChange={(v) => setCompare(v as CompareMode)}
        />

        <Segmented
          icon={<CalendarDays className="h-3.5 w-3.5" />}
          options={granularityOptions as readonly string[]}
          value={granularity}
          onChange={(v) => setGranularity(v as Granularity)}
        />

        <button
          onClick={handleSync}
          className="ml-auto inline-flex items-center gap-1.5 rounded-md bg-brand px-3 py-1.5 text-sm font-medium text-white transition-colors hover:bg-brand/90"
        >
          <RefreshCw className={cn("h-3.5 w-3.5", syncing && "animate-spin")} />
          {syncing ? "同步中…" : "同步"}
        </button>
      </div>

      {/* ② 指标表 */}
      <div className="overflow-x-auto">
        <table className="w-full min-w-[860px] text-sm">
          <thead>
            <tr className="text-left text-xs text-muted-foreground">
              <th className="px-4 py-2.5 font-medium">指标</th>
              <th className="px-4 py-2.5 text-right font-medium">{range}</th>
              <th className="px-4 py-2.5 text-right font-medium">vs 7天均值</th>
              <th className="px-4 py-2.5 text-right font-medium">7天均值</th>
              <th className="px-4 py-2.5 text-right font-medium">vs 30天均值</th>
              <th className="px-4 py-2.5 text-right font-medium">30天均值</th>
              <th className="px-4 py-2.5 text-center font-medium">趋势</th>
            </tr>
          </thead>
          <tbody>
            {metricGroups.map((group) => {
              const rows = diagnosisDetailRows.filter((r) => r.group === group)
              if (rows.length === 0) return null
              return (
                <GroupBlock key={group} group={group} rows={rows} />
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}

function GroupBlock({
  group,
  rows,
}: {
  group: string
  rows: typeof diagnosisDetailRows
}) {
  return (
    <>
      <tr className="bg-muted/30">
        <td colSpan={7} className="px-4 py-1.5 text-xs font-semibold text-muted-foreground">
          {group}
        </td>
      </tr>
      {rows.map((row) => (
        <tr key={row.metric} className="border-t border-border hover:bg-muted/20">
          <td className="px-4 py-3 text-foreground">{row.metric}</td>
          <td className="px-4 py-3 text-right text-base font-semibold tabular-nums text-foreground">
            {row.current}
          </td>
          <td className="px-4 py-3 text-right">
            {row.noDelta ? (
              <span className="text-xs text-muted-foreground">—</span>
            ) : (
              <Delta value={row.vs7} lowerIsBetter={row.lowerIsBetter} className="justify-end" />
            )}
          </td>
          <td className="px-4 py-3 text-right tabular-nums text-foreground/80">{row.avg7}</td>
          <td className="px-4 py-3 text-right">
            {row.noDelta ? (
              <span className="text-xs text-muted-foreground">—</span>
            ) : (
              <Delta value={row.vs30} lowerIsBetter={row.lowerIsBetter} className="justify-end" />
            )}
          </td>
          <td className="px-4 py-3 text-right tabular-nums text-foreground/80">{row.avg30}</td>
          <td className="px-4 py-3">
            <div className="flex justify-center">
              <span
                className={cn(
                  "flex h-5 w-5 items-center justify-center rounded",
                  row.healthy ? "bg-up/15 text-up" : "bg-down/15 text-down",
                )}
              >
                <Check className="h-3.5 w-3.5" />
              </span>
            </div>
          </td>
        </tr>
      ))}
    </>
  )
}

/* ---------------- 板块二：店铺详细分析 ---------------- */

function StoreDetailPanel() {
  const [quick, setQuick] = useState<QuickRange>("近7天")

  const columns: { key: keyof (typeof storeDetailRows)[number] | "_"; label: string; sticky?: boolean }[] = [
    { key: "shop", label: "店铺", sticky: true },
    { key: "spend", label: "广告花费" },
    { key: "adSales", label: "广告销售额" },
    { key: "totalSales", label: "总销售额" },
    { key: "acos", label: "ACOS" },
    { key: "tacos", label: "TACOS" },
    { key: "totalOrders", label: "总订单" },
    { key: "adOrders", label: "广告出单" },
    { key: "adRatio", label: "广告占比" },
    { key: "orderSplit", label: "自然/广告订单" },
    { key: "trafficSplit", label: "自然/广告流量" },
    { key: "ctr", label: "CTR" },
    { key: "cpc", label: "CPC" },
    { key: "cvr", label: "CVR" },
    { key: "budgetHit", label: "打满次数" },
    { key: "health", label: "健康度" },
    { key: "margin", label: "毛利率" },
    { key: "refundRate", label: "退款率" },
    { key: "status", label: "健康状态" },
  ]

  return (
    <div className="rounded-lg border border-border bg-card shadow-sm">
      {/* 标题栏 */}
      <div className="border-b border-border px-4 py-3">
        <h3 className="text-sm font-semibold text-foreground">店铺详细分析</h3>
      </div>

      {/* 筛选行 */}
      <div className="flex flex-wrap items-center gap-3 border-b border-border bg-muted/20 px-4 py-3">
        <div className="inline-flex items-center gap-1 rounded-md border border-border bg-card p-0.5">
          {quickRanges.map((opt) => (
            <button
              key={opt}
              onClick={() => setQuick(opt)}
              className={cn(
                "rounded px-2.5 py-1 text-sm font-medium transition-colors",
                opt === quick ? "bg-brand text-white" : "text-muted-foreground hover:text-foreground",
              )}
            >
              {opt}
            </button>
          ))}
        </div>

        <div className="inline-flex items-center gap-2 rounded-md border border-border bg-card px-3 py-1.5 text-sm text-muted-foreground">
          <Calendar className="h-3.5 w-3.5" />
          <span>年/月/日</span>
          <span>~</span>
          <span>年/月/日</span>
        </div>

        <button className="rounded-md bg-brand px-4 py-1.5 text-sm font-medium text-white transition-colors hover:bg-brand/90">
          查询
        </button>

        <p className="ml-auto text-xs text-muted-foreground">
          {storeDetailSummary.shopCount} 家店铺 · 合计广告花费{" "}
          <span className="font-semibold text-foreground">{storeDetailSummary.totalSpend}</span> · 数据截至{" "}
          {storeDetailSummary.dataDate}
        </p>
      </div>

      {/* 表格 */}
      <div className="overflow-x-auto">
        <table className="w-full min-w-[1500px] text-sm">
          <thead>
            <tr className="text-left text-xs text-muted-foreground">
              {columns.map((c) => (
                <th
                  key={c.key as string}
                  className={cn(
                    "whitespace-nowrap px-4 py-2.5 font-medium",
                    c.sticky && "sticky left-0 z-10 bg-card",
                  )}
                >
                  {c.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {storeDetailRows.map((row) => (
              <tr key={row.shop} className="border-t border-border hover:bg-muted/20">
                <td className="sticky left-0 z-10 whitespace-nowrap bg-card px-4 py-3 font-medium text-brand">
                  {row.shop}
                </td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground">{row.spend}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground">{row.adSales}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground">{row.totalSales}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums font-medium text-brand">{row.acos}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground">{row.tacos}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground">{row.totalOrders}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground">{row.adOrders}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground">{row.adRatio}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground/80">{row.orderSplit}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground/80">{row.trafficSplit}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground">{row.ctr}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground">{row.cpc}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground">{row.cvr}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground">{row.budgetHit}</td>
                <td className="px-4 py-3">
                  <HealthScore value={row.health} />
                </td>
                <td className={cn("whitespace-nowrap px-4 py-3 tabular-nums font-medium", marginColor(row.margin))}>
                  {row.margin}
                </td>
                <td className={cn("whitespace-nowrap px-4 py-3 tabular-nums font-medium", refundColor(row.refundRate))}>
                  {row.refundRate}
                </td>
                <td className="whitespace-nowrap px-4 py-3">
                  <StatusDot status={row.status} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

function HealthScore({ value }: { value: number }) {
  const color = value >= 80 ? "bg-up" : value >= 60 ? "bg-amber-500" : "bg-down"
  const text = value >= 80 ? "text-up" : value >= 60 ? "text-amber-600" : "text-down"
  return (
    <div className="flex w-28 items-center gap-2">
      <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-muted">
        <div className={cn("h-full rounded-full", color)} style={{ width: `${value}%` }} />
      </div>
      <span className={cn("text-xs font-semibold tabular-nums", text)}>{value}</span>
    </div>
  )
}

function StatusDot({ status }: { status: "正常" | "预警" | "异常" }) {
  const map = {
    正常: { dot: "bg-up", text: "text-up" },
    预警: { dot: "bg-amber-500", text: "text-amber-600" },
    异常: { dot: "bg-down", text: "text-down" },
  }[status]
  return (
    <span className={cn("inline-flex items-center gap-1.5 text-xs font-medium", map.text)}>
      <span className={cn("h-1.5 w-1.5 rounded-full", map.dot)} />
      {status}
    </span>
  )
}

function marginColor(v: string) {
  const n = Number.parseFloat(v)
  if (n >= 24) return "text-up"
  if (n >= 20) return "text-amber-600"
  return "text-down"
}

function refundColor(v: string) {
  const n = Number.parseFloat(v)
  if (n <= 3) return "text-up"
  if (n <= 5) return "text-amber-600"
  return "text-down"
}

/* ---------------- 板块三：ASIN 产品详细分析 ---------------- */

function AsinDetailPanel() {
  const [range, setRange] = useState<DateRangeOption>("最近7天")
  const [compare, setCompare] = useState<CompareMode>("环比")
  const [granularity, setGranularity] = useState<Granularity>("按日")
  const [syncing, setSyncing] = useState(false)

  function handleSync() {
    setSyncing(true)
    setTimeout(() => setSyncing(false), 900)
  }

  const numCols: { key: keyof AsinDetailRow; label: string }[] = [
    { key: "spend", label: "广告花费" },
    { key: "adSales", label: "广告销售额" },
    { key: "totalSales", label: "总销售额" },
    { key: "acos", label: "ACOS" },
    { key: "tacos", label: "TACOS" },
    { key: "totalOrders", label: "总订单" },
    { key: "naturalOrders", label: "自然订单" },
    { key: "adOrders", label: "广告订单" },
    { key: "adSpend", label: "广告花费($)" },
    { key: "adRatio", label: "广告占比" },
    { key: "orderSplit", label: "自然/广告订单" },
    { key: "trafficSplit", label: "自然/广告流量" },
    { key: "ctr", label: "CTR" },
    { key: "cpc", label: "CPC" },
    { key: "cpa", label: "CPA" },
    { key: "cvr", label: "CVR" },
    { key: "budgetHit", label: "打满次数" },
  ]

  return (
    <div className="rounded-lg border border-border bg-card shadow-sm">
      {/* 标题栏 */}
      <div className="flex items-center gap-2 border-b border-border px-4 py-3">
        <Box className="h-4 w-4 text-brand" />
        <h3 className="text-sm font-semibold text-foreground">ASIN 产品详细分析</h3>
        <span className="text-xs text-muted-foreground">按 ASIN 维度透视广告与运营表现</span>
      </div>

      {/* 筛选行 */}
      <div className="flex flex-wrap items-center gap-3 border-b border-border bg-muted/20 px-4 py-3">
        <DateRangeDropdown value={range} onChange={setRange} />
        <Segmented options={compareModes} value={compare} onChange={(v) => setCompare(v as CompareMode)} />
        <Segmented options={granularityOptions} value={granularity} onChange={(v) => setGranularity(v as Granularity)} />

        <div className="inline-flex items-center gap-2 rounded-md border border-border bg-card px-3 py-1.5 text-sm text-muted-foreground">
          <Calendar className="h-3.5 w-3.5" />
          <span>年/月/日</span>
          <span>~</span>
          <span>年/月/日</span>
        </div>

        <button
          onClick={handleSync}
          className="inline-flex items-center gap-1.5 rounded-md bg-brand px-3 py-1.5 text-sm font-medium text-white transition-colors hover:bg-brand/90"
        >
          <RefreshCw className={cn("h-3.5 w-3.5", syncing && "animate-spin")} />
          同步
        </button>

        <p className="ml-auto text-xs text-muted-foreground">
          {asinDetailSummary.asinCount} �� ASIN · 合计广告花费{" "}
          <span className="font-semibold text-foreground">{asinDetailSummary.totalSpend}</span> · 数据截至{" "}
          {asinDetailSummary.dataDate}
        </p>
      </div>

      {/* 表格 */}
      <div className="overflow-x-auto">
        <table className="w-full min-w-[1800px] text-sm">
          <thead>
            <tr className="text-left text-xs text-muted-foreground">
              <th className="sticky left-0 z-10 whitespace-nowrap bg-card px-4 py-2.5 font-medium">SKU / ASIN</th>
              <th className="whitespace-nowrap px-4 py-2.5 font-medium">店铺</th>
              {numCols.map((c) => (
                <th key={c.key} className="whitespace-nowrap px-4 py-2.5 font-medium">
                  {c.label}
                </th>
              ))}
              <th className="whitespace-nowrap px-4 py-2.5 font-medium">健康度</th>
              <th className="whitespace-nowrap px-4 py-2.5 font-medium">退货率</th>
              <th className="whitespace-nowrap px-4 py-2.5 font-medium">毛利率</th>
              <th className="whitespace-nowrap px-4 py-2.5 font-medium">健康状态</th>
            </tr>
          </thead>
          <tbody>
            {asinDetailRows.map((row) => (
              <tr key={row.asin} className="border-t border-border hover:bg-muted/20">
                <td className="sticky left-0 z-10 whitespace-nowrap bg-card px-4 py-3">
                  <div className="font-medium text-brand">{row.sku}</div>
                  <div className="text-xs text-muted-foreground">
                    {row.asin} · {row.title}
                  </div>
                </td>
                <td className="whitespace-nowrap px-4 py-3 text-foreground">{row.shop}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground">{row.spend}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground">{row.adSales}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground">{row.totalSales}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums font-medium text-brand">{row.acos}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground">{row.tacos}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground">{row.totalOrders}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground">{row.naturalOrders}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground">{row.adOrders}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground">{row.adSpend}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground">{row.adRatio}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground/80">{row.orderSplit}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground/80">{row.trafficSplit}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground">{row.ctr}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground">{row.cpc}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground">{row.cpa}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground">{row.cvr}</td>
                <td className="whitespace-nowrap px-4 py-3 tabular-nums text-foreground">{row.budgetHit}</td>
                <td className="px-4 py-3">
                  <HealthScore value={row.health} />
                </td>
                <td className={cn("whitespace-nowrap px-4 py-3 tabular-nums font-medium", refundColor(row.refundRate))}>
                  {row.refundRate}
                </td>
                <td className={cn("whitespace-nowrap px-4 py-3 tabular-nums font-medium", marginColor(row.margin))}>
                  {row.margin}
                </td>
                <td className="whitespace-nowrap px-4 py-3">
                  <StatusDot status={row.status} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

/* ---------------- 复用控件 ---------------- */


