"use client"

import { useMemo, useState } from "react"
import { ChevronDown, Plus, Calendar, Check } from "lucide-react"
import { cn } from "@/lib/utils"
import { Delta } from "@/components/ui/delta"
import {
  buildKpis,
  buildChartPanels,
  shopOptions,
  skuOptions,
  timeRanges,
  type TimeRange,
} from "@/lib/mock/asin-view"
import { ChartPanelCard } from "./chart-panel"
import { SifSnapshot } from "./sif-snapshot"
import { Timeline } from "./timeline"
import { AdConsole } from "./ad-console"
import { HourlyTrend } from "./hourly-trend"

/** 轻量下拉选择器 */
function Select({
  value,
  options,
  onChange,
}: {
  value: string
  options: readonly string[]
  onChange: (v: string) => void
}) {
  const [open, setOpen] = useState(false)
  return (
    <div className="relative">
      <button
        onClick={() => setOpen((o) => !o)}
        className="inline-flex items-center gap-2 rounded-md border border-border bg-background px-3 py-1.5 text-xs font-medium text-foreground hover:border-brand/40"
      >
        {value}
        <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute left-0 top-full z-20 mt-1 min-w-[180px] rounded-md border border-border bg-popover py-1 shadow-lg">
            {options.map((opt) => (
              <button
                key={opt}
                onClick={() => {
                  onChange(opt)
                  setOpen(false)
                }}
                className={cn(
                  "flex w-full items-center justify-between px-3 py-1.5 text-left text-xs hover:bg-muted",
                  opt === value ? "font-medium text-brand" : "text-foreground",
                )}
              >
                {opt}
                {opt === value && <Check className="h-3.5 w-3.5" />}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  )
}

export function AsinView() {
  const [shop, setShop] = useState<string>(shopOptions[0])
  const [sku, setSku] = useState<string>(skuOptions[0])
  const [range, setRange] = useState<TimeRange>("最近30天")

  // 选择变化时联动重新计算所有数据
  const kpis = useMemo(() => buildKpis(shop, sku, range), [shop, sku, range])
  const panels = useMemo(() => buildChartPanels(shop, sku, range), [shop, sku, range])

  return (
    <div className="space-y-4">
      {/* 顶部：店铺 / SKU 选择 + 日期范围 */}
      <div className="flex flex-wrap items-center gap-2">
        <Select value={shop} options={shopOptions} onChange={setShop} />
        <Select value={sku} options={skuOptions} onChange={setSku} />
        <span className="rounded-md bg-brand/10 px-2 py-1 text-xs font-medium text-brand">已选 5/5</span>

        <div className="ml-auto flex flex-wrap items-center gap-2">
          <button className="inline-flex items-center gap-2 rounded-md border border-border bg-background px-3 py-1.5 text-xs text-foreground hover:border-brand/40">
            All Profiles
            <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
          </button>
          <button className="inline-flex items-center gap-2 rounded-md border border-border bg-background px-3 py-1.5 text-xs text-foreground hover:border-brand/40">
            {'广告活动标签 "或"'}
            <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
          </button>
          <div className="inline-flex items-center gap-1.5 rounded-md border border-border px-2.5 py-1.5 text-xs text-foreground">
            <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
            05/30/2026 ~ 06/28/2026
          </div>
        </div>
      </div>

      {/* 时间范围胶囊 */}
      <div className="flex flex-wrap gap-1.5">
        {timeRanges.map((r) => (
          <button
            key={r}
            onClick={() => setRange(r)}
            className={cn(
              "rounded-md px-3 py-1.5 text-xs transition-colors",
              range === r
                ? "bg-brand text-white"
                : "border border-border bg-background text-muted-foreground hover:text-foreground",
            )}
          >
            {r}
          </button>
        ))}
      </div>

      {/* KPI 卡片 + 添加卡片 */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
        {kpis.map((kpi) => (
          <div
            key={kpi.label}
            className="overflow-hidden rounded-lg border border-border bg-card shadow-sm"
          >
            <div className="h-1" style={{ background: kpi.accent }} />
            <div className="p-4">
              <p className="text-xs text-muted-foreground">{kpi.label}</p>
              <p className="mt-1.5 text-xl font-semibold tabular-nums text-foreground">{kpi.value}</p>
              <Delta value={kpi.delta} className="mt-1" />
            </div>
          </div>
        ))}
        {/* 添加卡片 */}
        <button className="flex min-h-[104px] items-center justify-center rounded-lg border border-dashed border-border bg-card text-muted-foreground transition-colors hover:border-brand/50 hover:text-brand">
          <Plus className="h-6 w-6" />
        </button>
      </div>

      {/* 6 图表网格 */}
      <div className="grid grid-cols-1 gap-3 xl:grid-cols-2">
        {panels.map((panel) => (
          <ChartPanelCard key={panel.id} panel={panel} />
        ))}
      </div>

      {/* SIF 坑位快照 */}
      <SifSnapshot sku={sku} />

      {/* 时间线 */}
      <Timeline shop={shop} sku={sku} />

      {/* 广告看板 */}
      <AdConsole shop={shop} sku={sku} />

      {/* 24 小时指标趋势 */}
      <HourlyTrend shop={shop} sku={sku} />
    </div>
  )
}
