"use client"

import { useMemo, useState } from "react"
import { Search, ChevronDown, Check } from "lucide-react"
import { cn } from "@/lib/utils"
import {
  consoleTabs,
  consoleFilters,
  consoleActions,
  getConsoleColumns,
  buildConsoleRows,
  fmtConsole,
  type ConsoleRow,
} from "@/lib/mock/ad-console"

/** 状态彩色标签 */
function StatusBadge({ value }: { value: string }) {
  const map: Record<string, string> = {
    投放中: "bg-up/10 text-up",
    已暂停: "bg-muted text-muted-foreground",
    预算受限: "bg-amber-500/10 text-amber-600",
    已存档: "bg-muted text-muted-foreground",
    待确认: "bg-brand/10 text-brand",
  }
  return (
    <span className={cn("inline-flex items-center gap-1 rounded px-2 py-0.5 text-xs font-medium", map[value] ?? "bg-muted text-muted-foreground")}>
      {(value === "投放中" || value === "待确认") && <span className="h-1.5 w-1.5 rounded-full bg-current" />}
      {value}
    </span>
  )
}

/** 匹配类型标签 */
function MatchBadge({ value }: { value: string }) {
  const map: Record<string, string> = {
    精准匹配: "bg-brand/10 text-brand",
    广泛匹配: "bg-[#722ed1]/10 text-[#722ed1]",
    词组匹配: "bg-amber-500/10 text-amber-600",
  }
  return (
    <span className={cn("rounded px-2 py-0.5 text-xs font-medium", map[value] ?? "bg-muted text-muted-foreground")}>
      {value}
    </span>
  )
}

/** 筛选下拉 */
function FilterSelect({ label, options }: { label: string; options: string[] }) {
  const [open, setOpen] = useState(false)
  const [value, setValue] = useState(options[0])
  return (
    <div className="relative">
      <button
        onClick={() => setOpen((o) => !o)}
        className="inline-flex items-center gap-1.5 rounded-md border border-border bg-card px-3 py-1.5 text-sm text-foreground transition-colors hover:bg-muted"
      >
        <span className="text-muted-foreground">{label}</span>
        <span className="font-medium">{value}</span>
        <ChevronDown className={cn("h-3.5 w-3.5 text-muted-foreground transition-transform", open && "rotate-180")} />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute left-0 top-full z-20 mt-1 min-w-[160px] rounded-md border border-border bg-card p-1 shadow-lg">
            {options.map((opt) => (
              <button
                key={opt}
                onClick={() => {
                  setValue(opt)
                  setOpen(false)
                }}
                className={cn(
                  "flex w-full items-center justify-between rounded px-2.5 py-1.5 text-left text-sm transition-colors hover:bg-muted",
                  opt === value ? "font-medium text-brand" : "text-foreground",
                )}
              >
                {opt}
                {opt === value && <Check className="h-3.5 w-3.5 text-brand" />}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  )
}

export function AdConsole({ shop, sku }: { shop: string; sku: string }) {
  const [tab, setTab] = useState(consoleTabs[1].key) // 默认广告活动
  const [query, setQuery] = useState("")
  const [selected, setSelected] = useState<Set<number>>(new Set())

  const columns = useMemo(() => getConsoleColumns(tab), [tab])
  const rows = useMemo(() => buildConsoleRows(tab, shop, sku), [tab, shop, sku])

  const filtered = useMemo(() => {
    if (!query.trim()) return rows
    const q = query.trim().toLowerCase()
    return rows.filter((r) =>
      Object.values(r).some((v) => String(v).toLowerCase().includes(q)),
    )
  }, [rows, query])

  function switchTab(key: string) {
    setTab(key)
    setSelected(new Set())
  }

  function toggleRow(i: number) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(i)) next.delete(i)
      else next.add(i)
      return next
    })
  }

  function toggleAll() {
    setSelected((prev) =>
      prev.size === filtered.length ? new Set() : new Set(filtered.map((_, i) => i)),
    )
  }

  const hasSelection = selected.size > 0
  const allChecked = filtered.length > 0 && selected.size === filtered.length

  function renderCell(row: ConsoleRow, col: ReturnType<typeof getConsoleColumns>[number]) {
    const raw = row[col.key]
    if (col.kind === "status") return <StatusBadge value={String(raw)} />
    if (col.kind === "match") return <MatchBadge value={String(raw)} />
    if (col.primary) return <span className="font-medium text-brand">{String(raw)}</span>
    return <span className={cn(col.kind === "acos" ? "" : "", "text-foreground")}>{fmtConsole(raw, col.kind)}</span>
  }

  return (
    <div className="rounded-lg border border-border bg-card p-5 shadow-sm">
      <h3 className="text-sm font-semibold text-foreground">广告看板</h3>

      {/* 顶部筛选行 */}
      <div className="mt-4 flex flex-wrap items-center gap-3">
        <div className="relative">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="搜索"
            className="h-8 w-52 rounded-md border border-border bg-card pl-8 pr-3 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground focus:border-brand"
          />
        </div>
        {consoleFilters.map((f) => (
          <FilterSelect key={f.key} label={f.label} options={f.options} />
        ))}
      </div>

      {/* 实体 Tab 行 */}
      <div className="mt-4 flex flex-wrap items-center gap-1 border-b border-border">
        {consoleTabs.map((t) => {
          const on = t.key === tab
          const count = buildConsoleRows(t.key, shop, sku).length
          return (
            <button
              key={t.key}
              onClick={() => switchTab(t.key)}
              className={cn(
                "relative -mb-px inline-flex items-center gap-1.5 border-b-2 px-3 py-2 text-sm font-medium transition-colors",
                on
                  ? "border-brand text-brand"
                  : "border-transparent text-muted-foreground hover:text-foreground",
              )}
            >
              {t.label}
              <span
                className={cn(
                  "rounded px-1.5 text-xs tabular-nums",
                  on ? "bg-brand/10 text-brand" : "bg-muted text-muted-foreground",
                )}
              >
                {count}
              </span>
              {t.isNew && (
                <span className="rounded bg-down px-1 text-[10px] font-semibold leading-4 text-white">new</span>
              )}
            </button>
          )
        })}
      </div>

      {/* 操作工具栏 */}
      <div className="mt-3 flex flex-wrap items-center gap-2">
        {consoleActions.map((a, i) => {
          // 批量类操作需选中行后可用，设置类始终可用
          const needsSelection = i < 5
          const disabled = needsSelection && !hasSelection
          return (
            <button
              key={a}
              disabled={disabled}
              className={cn(
                "rounded-md border px-3 py-1.5 text-sm font-medium transition-colors",
                disabled
                  ? "cursor-not-allowed border-border bg-muted/40 text-muted-foreground/50"
                  : i === 0 && hasSelection
                    ? "border-brand bg-brand text-white hover:bg-brand/90"
                    : "border-border bg-card text-foreground hover:bg-muted",
              )}
            >
              {a}
              {i === 0 && hasSelection ? ` (${selected.size})` : ""}
            </button>
          )
        })}
      </div>

      {/* 数据表 */}
      <div className="mt-3 overflow-x-auto rounded-md border border-border">
        <table className="w-full min-w-[900px] text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/30 text-left text-xs text-muted-foreground">
              <th className="w-10 px-3 py-2.5">
                <input
                  type="checkbox"
                  checked={allChecked}
                  onChange={toggleAll}
                  className="h-3.5 w-3.5 cursor-pointer accent-[var(--brand)]"
                  aria-label="全选"
                />
              </th>
              {columns.map((c) => (
                <th
                  key={c.key}
                  className={cn("whitespace-nowrap px-3 py-2.5 font-medium", c.align === "right" && "text-right")}
                >
                  {c.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={columns.length + 1} className="px-3 py-10 text-center text-sm text-muted-foreground">
                  未找到匹配「{query}」的数据
                </td>
              </tr>
            ) : (
              filtered.map((row, i) => (
                <tr
                  key={i}
                  className={cn(
                    "border-b border-border last:border-0 transition-colors hover:bg-muted/20",
                    selected.has(i) && "bg-brand/5",
                  )}
                >
                  <td className="px-3 py-2.5">
                    <input
                      type="checkbox"
                      checked={selected.has(i)}
                      onChange={() => toggleRow(i)}
                      className="h-3.5 w-3.5 cursor-pointer accent-[var(--brand)]"
                      aria-label={`选择第 ${i + 1} 行`}
                    />
                  </td>
                  {columns.map((c) => (
                    <td
                      key={c.key}
                      className={cn(
                        "whitespace-nowrap px-3 py-2.5 tabular-nums",
                        c.align === "right" && "text-right",
                      )}
                    >
                      {renderCell(row, c)}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <p className="mt-2 text-xs text-muted-foreground">
        共 {filtered.length} 条 · 已选 {selected.size} 条
      </p>
    </div>
  )
}
