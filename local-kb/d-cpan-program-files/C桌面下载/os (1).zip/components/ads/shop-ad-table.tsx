"use client"

import { useState } from "react"
import { Calendar } from "lucide-react"
import { shopAdRows, adSummary } from "@/lib/mock/ads"
import { cn } from "@/lib/utils"

const ranges = ["近3天", "近7天", "近30天"] as const

const statusStyle: Record<string, string> = {
  正常: "text-up",
  预警: "text-[#faad14]",
  异常: "text-down",
}

const dotStyle: Record<string, string> = {
  正常: "bg-up",
  预警: "bg-[#faad14]",
  异常: "bg-down",
}

export function ShopAdTable() {
  const [range, setRange] = useState<(typeof ranges)[number]>("近7天")

  return (
    <div className="rounded-lg border border-border bg-card shadow-sm">
      {/* Filter bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border px-4 py-3">
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex rounded-md border border-border p-0.5">
            {ranges.map((r) => (
              <button
                key={r}
                onClick={() => setRange(r)}
                className={cn(
                  "rounded px-3 py-1 text-xs transition-colors",
                  range === r ? "bg-brand text-white" : "text-muted-foreground hover:text-foreground",
                )}
              >
                {r}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-1.5 rounded-md border border-border px-2.5 py-1.5 text-xs text-muted-foreground">
            <Calendar className="h-3.5 w-3.5" />
            年/月/日
            <span className="text-border">~</span>
            年/月/日
          </div>
          <button className="rounded-md bg-brand px-4 py-1.5 text-xs font-medium text-white hover:bg-brand/90">
            查询
          </button>
        </div>
        <p className="text-xs text-muted-foreground">
          {adSummary.shopCount} 家店铺 · 合计广告花费{" "}
          <span className="font-medium text-foreground">{adSummary.totalSpend}</span> · 数据截至{" "}
          {adSummary.dataDate}
        </p>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full min-w-[1080px] text-sm">
          <thead>
            <tr className="text-left text-xs text-muted-foreground">
              <th className="px-4 py-2.5 font-medium">店铺</th>
              <th className="px-4 py-2.5 text-right font-medium">广告花费</th>
              <th className="px-4 py-2.5 text-right font-medium">广告销售额</th>
              <th className="px-4 py-2.5 text-right font-medium">ACOS</th>
              <th className="px-4 py-2.5 text-right font-medium">TACOS</th>
              <th className="px-4 py-2.5 text-right font-medium">广告出单</th>
              <th className="px-4 py-2.5 text-right font-medium">广告占比</th>
              <th className="px-4 py-2.5 text-right font-medium">曝光量</th>
              <th className="px-4 py-2.5 text-right font-medium">点击量</th>
              <th className="px-4 py-2.5 text-right font-medium">CTR</th>
              <th className="px-4 py-2.5 text-right font-medium">CPC</th>
              <th className="px-4 py-2.5 text-right font-medium">CVR</th>
              <th className="px-4 py-2.5 text-right font-medium">打满次数</th>
              <th className="px-4 py-2.5 text-center font-medium">健康状态</th>
            </tr>
          </thead>
          <tbody>
            {shopAdRows.map((row) => (
              <tr key={row.shop} className="border-t border-border hover:bg-muted/50">
                <td className="px-4 py-3 whitespace-nowrap">
                  <a className="cursor-pointer font-medium text-brand hover:underline">{row.shop}</a>
                </td>
                <td className="px-4 py-3 text-right tabular-nums text-foreground">{row.spend}</td>
                <td className="px-4 py-3 text-right tabular-nums text-foreground">{row.sales}</td>
                <td className="px-4 py-3 text-right tabular-nums font-medium text-brand">{row.acos}</td>
                <td className="px-4 py-3 text-right tabular-nums text-foreground/80">{row.tacos}</td>
                <td className="px-4 py-3 text-right tabular-nums text-foreground/80">{row.orders}</td>
                <td className="px-4 py-3 text-right tabular-nums text-foreground/80">{row.adRatio}</td>
                <td className="px-4 py-3 text-right tabular-nums text-foreground/80">{row.impressions}</td>
                <td className="px-4 py-3 text-right tabular-nums text-foreground/80">{row.clicks}</td>
                <td className="px-4 py-3 text-right tabular-nums text-foreground/80">{row.ctr}</td>
                <td className="px-4 py-3 text-right tabular-nums text-foreground/80">{row.cpc}</td>
                <td className="px-4 py-3 text-right tabular-nums text-foreground/80">{row.cvr}</td>
                <td className="px-4 py-3 text-right tabular-nums text-foreground/80">{row.budgetHit}</td>
                <td className="px-4 py-3">
                  <div className={cn("flex items-center justify-center gap-1.5", statusStyle[row.status])}>
                    <span className={cn("h-1.5 w-1.5 rounded-full", dotStyle[row.status])} />
                    {row.status}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
