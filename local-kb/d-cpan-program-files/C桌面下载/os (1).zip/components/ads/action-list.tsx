"use client"

import { useMemo, useState } from "react"
import { ChevronDown, Lightbulb, X, FileText, Check, Loader, Undo2, CircleCheckBig } from "lucide-react"
import {
  actionItems as seedItems,
  actionStatusTabs,
  severityColor,
  statusBadge,
  type ActionItem,
  type ActionStatus,
} from "@/lib/mock/action-list"

export function ActionList() {
  const [items, setItems] = useState<ActionItem[]>(seedItems)
  const [status, setStatus] = useState<ActionStatus | "全部">("全部")
  const [asinFilter, setAsinFilter] = useState<string | null>("B0GK****CG")
  const [promptItem, setPromptItem] = useState<ActionItem | null>(null)

  const filtered = useMemo(() => {
    return items.filter((it) => {
      if (status !== "全部" && it.status !== status) return false
      if (asinFilter && it.asin !== asinFilter) return false
      return true
    })
  }, [items, status, asinFilter])

  const pendingCount = filtered.filter((it) => it.status === "待处理").length
  const runningCount = filtered.filter((it) => it.status === "执行中").length

  function updateStatus(id: string, next: ActionStatus) {
    setItems((prev) => prev.map((it) => (it.id === id ? { ...it, status: next } : it)))
  }

  return (
    <div className="space-y-3">
      {/* 筛选栏 */}
      <div className="flex flex-wrap items-center gap-3 rounded-lg border border-border bg-card px-4 py-3 shadow-sm">
        <FilterSelect label="全部店铺" />
        <FilterSelect label="全部团队" />
        <FilterSelect label="全部负责人" />

        {asinFilter && (
          <span className="inline-flex items-center gap-1.5 rounded-md border border-brand/30 bg-brand/5 px-2.5 py-1.5 text-xs font-medium text-brand">
            ASIN：{asinFilter}
            <button onClick={() => setAsinFilter(null)} aria-label="清除 ASIN 筛选" className="hover:text-brand/70">
              <X className="h-3.5 w-3.5" />
            </button>
          </span>
        )}

        <div className="ml-auto flex items-center gap-2">
          <span className="text-xs text-muted-foreground">状态</span>
          <div className="flex items-center gap-1 rounded-md bg-muted p-0.5">
            {actionStatusTabs.map((t) => (
              <button
                key={t.value}
                onClick={() => setStatus(t.value)}
                className={`rounded px-3 py-1 text-xs font-medium transition-colors ${
                  status === t.value ? "bg-brand text-white shadow-sm" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 统计 */}
      <p className="px-1 text-sm text-muted-foreground">
        共 <span className="font-semibold text-foreground">{filtered.length}</span> 条建议 ·{" "}
        <span className="font-semibold text-amber-600">{pendingCount}</span> 条待处理 ·{" "}
        <span className="font-semibold text-brand">{runningCount}</span> 条执行中
      </p>

      {/* 卡片列表 */}
      {filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-border bg-card py-20 text-center shadow-sm">
          <p className="text-sm font-medium text-foreground">暂无符合条件的处理建议</p>
          <p className="mt-1 text-xs text-muted-foreground">尝试调整筛选条件</p>
        </div>
      ) : (
        filtered.map((item) => (
          <ActionCard
            key={item.id}
            item={item}
            onAdopt={() => updateStatus(item.id, "执行中")}
            onIgnore={() => updateStatus(item.id, "已忽略")}
            onComplete={() => updateStatus(item.id, "已采纳")}
            onRevert={() => updateStatus(item.id, "待处理")}
            onViewPrompt={() => setPromptItem(item)}
          />
        ))
      )}

      {promptItem && <PromptModal item={promptItem} onClose={() => setPromptItem(null)} />}
    </div>
  )
}

function FilterSelect({ label }: { label: string }) {
  return (
    <button className="inline-flex items-center gap-1.5 rounded-md border border-input bg-background px-3 py-1.5 text-xs font-medium text-foreground hover:bg-muted">
      {label}
      <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
    </button>
  )
}

function ActionCard({
  item,
  onAdopt,
  onIgnore,
  onComplete,
  onRevert,
  onViewPrompt,
}: {
  item: ActionItem
  onAdopt: () => void
  onIgnore: () => void
  onComplete: () => void
  onRevert: () => void
  onViewPrompt: () => void
}) {
  const [checked, setChecked] = useState<boolean[]>(item.steps.map(() => true))
  const [note, setNote] = useState("")
  const resolved = item.status === "已采纳" || item.status === "已忽略"
  const running = item.status === "执行中"

  function toggle(i: number) {
    setChecked((prev) => prev.map((c, idx) => (idx === i ? !c : c)))
  }

  return (
    <div
      className={`rounded-lg border bg-card p-5 shadow-sm ${
        resolved ? "border-border opacity-60" : running ? "border-brand/40 ring-1 ring-brand/15" : "border-border"
      }`}
    >
      {/* 头部 */}
      <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
        <span className="h-2 w-2 shrink-0 rounded-full bg-down" />
        <span className="text-sm font-semibold text-foreground">{item.asin}</span>
        <span className="text-xs text-muted-foreground">
          · {item.shop} · {item.date}
        </span>
        <span className={`ml-1 rounded px-1.5 py-0.5 text-xs font-semibold ${severityColor[item.severity]}`}>
          {item.title}（{item.severity}）
        </span>
        {item.subtitle && (
          <span className="rounded bg-amber-100 px-1.5 py-0.5 text-xs font-medium text-amber-700">
            {item.subtitle}
          </span>
        )}
        {item.status !== "待处理" && (
          <span
            className={`ml-auto inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-xs font-medium ${statusBadge[item.status]}`}
          >
            {item.status === "已采纳" ? (
              <Check className="h-3 w-3" />
            ) : item.status === "已忽略" ? (
              <X className="h-3 w-3" />
            ) : (
              <Loader className="h-3 w-3 animate-spin" />
            )}
            {item.status}
          </span>
        )}
      </div>

      {/* 指标行 */}
      <div className="mt-2.5 flex flex-wrap items-center gap-2">
        <span className="text-sm font-medium text-foreground">{item.metricLine}</span>
        <span className="rounded bg-amber-100 px-2 py-0.5 text-xs font-medium text-amber-700">
          {item.metricBadge}
        </span>
      </div>

      {/* 灯泡说明 */}
      <div className="mt-3 flex gap-2 rounded-md bg-amber-50 p-3">
        <Lightbulb className="h-4 w-4 shrink-0 text-amber-500" />
        <p className="text-xs leading-relaxed text-foreground">{item.insight}</p>
      </div>

      {/* 动作项 */}
      <div className="mt-3 space-y-2.5">
        {item.steps.map((step, i) => (
          <div key={i} className="flex items-start gap-2.5 rounded-md border border-border/60 bg-background px-3 py-2.5">
            <button
              role="checkbox"
              aria-checked={checked[i]}
              onClick={() => toggle(i)}
              disabled={resolved || running}
              className={`mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded border transition-colors ${
                checked[i] ? "border-brand bg-brand text-white" : "border-input bg-background"
              } disabled:cursor-not-allowed`}
            >
              {checked[i] && <Check className="h-3 w-3" />}
            </button>
            <div className="flex flex-1 flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
              <p className="flex-1 text-xs leading-relaxed text-foreground">
                <span className="mr-1 font-semibold text-brand">{i + 1}</span>
                {step.text}
              </p>
              {step.highlight && (
                <span
                  className={`shrink-0 text-xs font-semibold ${
                    step.highlightTone === "danger" ? "text-down" : "text-brand"
                  }`}
                >
                  {step.highlight}
                </span>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* 历史参考 */}
      {item.history && (
        <p className="mt-3 text-xs leading-relaxed text-muted-foreground">
          <span className="font-medium">历史参考：</span>
          {item.history}
        </p>
      )}

      {/* 补充说明 */}
      <input
        value={note}
        onChange={(e) => setNote(e.target.value)}
        disabled={resolved || running}
        placeholder="补充说明（选填，部分采纳或忽略时必填）"
        className="mt-3 h-9 w-full rounded-md border border-input bg-background px-3 text-xs outline-none placeholder:text-muted-foreground focus:border-brand focus:ring-2 focus:ring-brand/20 disabled:opacity-60"
      />

      {/* 底部按钮 */}
      <div className="mt-3 flex items-center justify-end gap-2">
        {running ? (
          <>
            <button
              onClick={onComplete}
              className="inline-flex items-center gap-1.5 rounded-md bg-up px-4 py-2 text-sm font-medium text-white hover:bg-up/90"
            >
              <CircleCheckBig className="h-4 w-4" />
              标记完成
            </button>
            <button
              onClick={onRevert}
              className="inline-flex items-center gap-1.5 rounded-md border border-border px-4 py-2 text-sm font-medium text-foreground hover:bg-muted"
            >
              <Undo2 className="h-4 w-4 text-muted-foreground" />
              撤销采纳
            </button>
          </>
        ) : (
          <>
            <button
              onClick={onAdopt}
              disabled={resolved}
              className="inline-flex items-center gap-1.5 rounded-md bg-brand px-4 py-2 text-sm font-medium text-white hover:bg-brand/90 disabled:cursor-not-allowed disabled:opacity-50"
            >
              <Check className="h-4 w-4" />
              全部采纳
            </button>
            <button
              onClick={onIgnore}
              disabled={resolved}
              className="inline-flex items-center rounded-md border border-down/40 px-4 py-2 text-sm font-medium text-down hover:bg-down/5 disabled:cursor-not-allowed disabled:opacity-50"
            >
              忽略
            </button>
          </>
        )}
        <button
          onClick={onViewPrompt}
          className="inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-4 py-2 text-sm font-medium text-foreground hover:bg-muted"
        >
          <FileText className="h-4 w-4 text-muted-foreground" />
          查看完整 prompt
        </button>
      </div>
    </div>
  )
}

function PromptModal({ item, onClose }: { item: ActionItem; onClose: () => void }) {
  const prompt = `# 广告诊断 Prompt
ASIN：${item.asin}
店铺：${item.shop}（负责人 ${item.owner}）
诊断日期：${item.date}
问题：${item.title}（严重度：${item.severity}）

## 指标
${item.metricLine}
${item.metricBadge}

## 诊断分析
${item.insight}

## 建议动作
${item.steps.map((s, i) => `${i + 1}. ${s.text}${s.highlight ? `\n   → ${s.highlight}` : ""}`).join("\n")}
${item.history ? `\n## 历史参考\n${item.history}` : ""}`

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 flex max-h-[80vh] w-full max-w-2xl flex-col overflow-hidden rounded-xl bg-card shadow-xl">
        <div className="flex items-center justify-between border-b border-border px-5 py-4">
          <div className="flex items-center gap-2">
            <FileText className="h-4 w-4 text-brand" />
            <h2 className="text-base font-semibold text-foreground">完整 Prompt · {item.asin}</h2>
          </div>
          <button
            onClick={onClose}
            className="rounded-md p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground"
            aria-label="关闭"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-5">
          <pre className="whitespace-pre-wrap rounded-md bg-muted p-4 font-mono text-xs leading-relaxed text-foreground">
            {prompt}
          </pre>
        </div>
      </div>
    </div>
  )
}
