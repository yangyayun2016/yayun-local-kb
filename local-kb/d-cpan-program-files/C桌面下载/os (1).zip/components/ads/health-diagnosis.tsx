"use client"

import { useEffect, useRef, useState } from "react"
import {
  ClipboardList,
  Search,
  CircleCheck,
  RefreshCw,
  Loader2,
  Check,
  Eye,
} from "lucide-react"
import { analysisSteps, healthReports, type HealthReport } from "@/lib/mock/health"
import { ReportModal } from "./report-modal"

export function HealthDiagnosis() {
  const [asin, setAsin] = useState("")
  const [reports, setReports] = useState<HealthReport[]>(healthReports)
  const [scanning, setScanning] = useState(false)
  const [stepIndex, setStepIndex] = useState(0)
  const [active, setActive] = useState<HealthReport | null>(null)
  const scanAsin = useRef("")

  // 扫描动画：scanning 为 true 时按步推进，到末尾后生成报告（仅触发一次）
  useEffect(() => {
    if (!scanning) return
    if (stepIndex >= analysisSteps.length - 1) {
      const t = setTimeout(() => {
        const now = new Date()
        const time = `2026-06-12 ${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`
        const newReport: HealthReport = {
          ...healthReports[0],
          id: `rpt-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
          asin: scanAsin.current,
          time,
          status: "已完成",
        }
        setReports((prev) => [newReport, ...prev])
        setScanning(false)
        setAsin("")
      }, 500)
      return () => clearTimeout(t)
    }
    const t = setTimeout(() => setStepIndex((prev) => prev + 1), 420)
    return () => clearTimeout(t)
  }, [scanning, stepIndex])

  function maskAsin(value: string) {
    const v = value.trim().toUpperCase()
    if (v.length <= 6) return v
    return v.slice(0, 4) + "****" + v.slice(-2)
  }

  function handleSubmit() {
    if (!asin.trim() || scanning) return
    scanAsin.current = maskAsin(asin)
    setStepIndex(0)
    setScanning(true)
  }

  return (
    <div className="space-y-4">
      {/* 提交卡片 */}
      <div className="rounded-lg border border-border bg-card p-5 shadow-sm">
        <div className="mb-3 flex items-center gap-2">
          <ClipboardList className="h-4 w-4 text-brand" />
          <h3 className="text-sm font-semibold text-foreground">提交广告健康诊断</h3>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <input
            value={asin}
            onChange={(e) => setAsin(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
            placeholder="输入 ASIN（如 B0DT****TK）"
            disabled={scanning}
            className="h-9 w-72 rounded-md border border-input bg-background px-3 text-sm outline-none placeholder:text-muted-foreground focus:border-brand focus:ring-2 focus:ring-brand/20 disabled:opacity-60"
          />
          <button
            onClick={handleSubmit}
            disabled={scanning || !asin.trim()}
            className="inline-flex h-9 items-center gap-1.5 rounded-md bg-brand px-4 text-sm font-medium text-white hover:bg-brand/90 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {scanning ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
            {scanning ? "分析中" : "提交分析"}
          </button>
          <button className="inline-flex h-9 items-center gap-1.5 rounded-md border border-border bg-background px-4 text-sm font-medium text-foreground hover:bg-muted">
            <Search className="h-4 w-4 text-muted-foreground" />
            查看竞品
          </button>
        </div>
        <p className="mt-3 text-xs text-muted-foreground">
          提交后扫描窗口将自动执行 13 步广告分析，完成后报告显示在下方列表
        </p>

        {/* 扫描进度 */}
        {scanning && (
          <div className="mt-4 rounded-lg border border-brand/20 bg-brand/5 p-4">
            <div className="mb-2 flex items-center justify-between text-xs">
              <span className="font-medium text-brand">
                正在执行广告分析（{stepIndex + 1}/{analysisSteps.length}）
              </span>
              <span className="text-muted-foreground">
                {Math.round(((stepIndex + 1) / analysisSteps.length) * 100)}%
              </span>
            </div>
            <div className="h-1.5 overflow-hidden rounded-full bg-brand/15">
              <div
                className="h-full rounded-full bg-brand transition-all duration-300"
                style={{ width: `${((stepIndex + 1) / analysisSteps.length) * 100}%` }}
              />
            </div>
            <ul className="mt-3 grid grid-cols-1 gap-1.5 md:grid-cols-2">
              {analysisSteps.map((s, i) => (
                <li key={i} className="flex items-center gap-2 text-xs">
                  {i < stepIndex ? (
                    <Check className="h-3.5 w-3.5 shrink-0 text-up" />
                  ) : i === stepIndex ? (
                    <Loader2 className="h-3.5 w-3.5 shrink-0 animate-spin text-brand" />
                  ) : (
                    <span className="h-3.5 w-3.5 shrink-0 rounded-full border border-border" />
                  )}
                  <span className={i <= stepIndex ? "text-foreground" : "text-muted-foreground"}>
                    {i + 1}. {s}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* 报告列表 */}
      <div className="space-y-2">
        {reports.map((r) => (
          <div
            key={r.id}
            className="flex items-center justify-between rounded-lg border border-border bg-card px-5 py-4 shadow-sm"
          >
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold text-foreground">{r.asin}</span>
                <span className="text-xs text-muted-foreground">
                  {r.shop} · {r.owner}
                </span>
              </div>
              <p className="mt-1 text-xs text-muted-foreground">{r.time}</p>
            </div>
            <div className="flex items-center gap-3">
              <span className="inline-flex items-center gap-1 rounded-md bg-up/10 px-2 py-1 text-xs font-medium text-up">
                <CircleCheck className="h-3.5 w-3.5" />
                {r.status}
              </span>
              <button
                onClick={() => setActive(r)}
                className="inline-flex items-center gap-1.5 rounded-md bg-brand px-3 py-1.5 text-sm font-medium text-white hover:bg-brand/90"
              >
                <Eye className="h-3.5 w-3.5" />
                查看报告
              </button>
            </div>
          </div>
        ))}

        {/* 刷新 */}
        <div className="flex justify-end pt-1">
          <button className="inline-flex items-center gap-1.5 rounded-md border border-border bg-card px-3 py-1.5 text-xs font-medium text-foreground shadow-sm hover:bg-muted">
            <RefreshCw className="h-3.5 w-3.5" />
            刷新
          </button>
        </div>
      </div>

      {active && <ReportModal report={active} onClose={() => setActive(null)} />}
    </div>
  )
}
