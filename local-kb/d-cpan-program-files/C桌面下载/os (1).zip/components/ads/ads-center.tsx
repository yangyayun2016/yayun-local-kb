"use client"

import { useState } from "react"
import { adTabs } from "@/lib/mock/ads"
import { PageHeader } from "@/components/ui/page-header"
import { TabNav } from "@/components/ui/tab-nav"
import { DiagnosisTable } from "./diagnosis-table"
import { ShopAdTable } from "./shop-ad-table"
import { SkuAdTable } from "./sku-ad-table"
import { HealthDiagnosis } from "./health-diagnosis"
import { ActionList } from "./action-list"
import { AdDiagnosis } from "./ad-diagnosis"
import { AsinView } from "./asin-view"
import { AutoRules } from "./auto-rules"
import { RuleSettings } from "./rule-settings"
import { SearchTermAnalysis } from "./search-term-analysis"
import { GainList, StopList, RootAggregation, AnomalyList } from "./ad-modules"
import { AdStoreProvider } from "./ad-store"
import { Bot } from "lucide-react"

export function AdsCenter() {
  const [tab, setTab] = useState<string>(adTabs[0])

  return (
    <AdStoreProvider>
      <PageHeader
        title="广告中心"
        actions={
          <button className="inline-flex items-center gap-1.5 rounded-md bg-brand px-3 py-2 text-sm font-medium text-white hover:bg-brand/90">
            <Bot className="h-4 w-4" />
            AI 广告优化建议
          </button>
        }
      />

      <TabNav tabs={adTabs} active={tab} onChange={setTab} />

      <div className="mt-4 space-y-4">
        {tab === "看板" ? (
          <>
            <DiagnosisTable />
            <ShopAdTable />
            <SkuAdTable />
          </>
        ) : tab === "广告诊断" ? (
          <AdDiagnosis />
        ) : tab === "健康诊断" ? (
          <HealthDiagnosis />
        ) : tab === "关键词机会" ? (
          <SearchTermAnalysis />
        ) : tab === "处理清单" ? (
          <ActionList />
        ) : tab === "ASIN 视图" ? (
          <AsinView />
        ) : tab === "自动规则" ? (
          <AutoRules />
        ) : tab === "规则设置" ? (
          <RuleSettings />
        ) : tab === "待投放（增益）" ? (
          <GainList />
        ) : tab === "否定（止损）" ? (
          <StopList />
        ) : tab === "词根聚合" ? (
          <RootAggregation />
        ) : tab === "异常问题" ? (
          <AnomalyList />
        ) : (
          <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-border bg-card py-24 text-center shadow-sm">
            <p className="text-base font-medium text-foreground">{tab}</p>
            <p className="mt-1 text-sm text-muted-foreground">该子模块开发中，敬请期待</p>
          </div>
        )}
      </div>
    </AdStoreProvider>
  )
}
