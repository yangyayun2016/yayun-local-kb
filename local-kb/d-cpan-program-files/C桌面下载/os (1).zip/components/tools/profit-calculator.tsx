"use client"

import { useMemo, useState } from "react"
import { RotateCcw } from "lucide-react"
import { cn } from "@/lib/utils"
import {
  calcModes,
  defaultsForMode,
  formatValue,
  type CalcMode,
  type FieldDef,
} from "@/lib/calculators/profit-margin"

export function ProfitCalculator() {
  const [modeKey, setModeKey] = useState(calcModes[0].key)
  const mode = calcModes.find((m) => m.key === modeKey) as CalcMode

  // 每个模式独立维护输入值
  const [valuesByMode, setValuesByMode] = useState<Record<string, Record<string, number | string>>>(() => {
    const init: Record<string, Record<string, number | string>> = {}
    for (const m of calcModes) init[m.key] = defaultsForMode(m)
    return init
  })

  const values = valuesByMode[modeKey]

  function setField(key: string, raw: string, type: FieldDef["type"]) {
    setValuesByMode((prev) => ({
      ...prev,
      [modeKey]: {
        ...prev[modeKey],
        [key]: type === "select" ? raw : raw === "" ? "" : Number(raw),
      },
    }))
  }

  function resetMode() {
    setValuesByMode((prev) => ({ ...prev, [modeKey]: defaultsForMode(mode) }))
  }

  const result = useMemo(() => mode.compute(values), [mode, values])

  // 按 group 分组字段
  const groups = useMemo(() => {
    const map = new Map<string, FieldDef[]>()
    for (const f of mode.fields) {
      if (!map.has(f.group)) map.set(f.group, [])
      map.get(f.group)!.push(f)
    }
    return [...map.entries()]
  }, [mode])

  const maxRatio = Math.max(0.0001, ...result.ratios.map((r) => Math.abs(r.value)))

  return (
    <div className="rounded-lg border border-border bg-card shadow-sm">
      {/* 模式切换 */}
      <div className="flex flex-wrap items-center gap-2 border-b border-border p-4">
        {calcModes.map((m) => (
          <button
            key={m.key}
            onClick={() => setModeKey(m.key)}
            className={cn(
              "rounded-md px-3.5 py-1.5 text-sm font-medium transition-colors",
              m.key === modeKey
                ? "bg-brand text-white shadow-sm"
                : "border border-border bg-background text-foreground hover:bg-muted",
            )}
          >
            {m.label}
          </button>
        ))}
        <span className="ml-1 text-xs text-muted-foreground">{mode.desc}</span>
        <button
          onClick={resetMode}
          className="ml-auto inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-3 py-1.5 text-sm font-medium text-foreground transition-colors hover:bg-muted"
        >
          <RotateCcw className="h-3.5 w-3.5" />
          重置
        </button>
      </div>

      <div className="grid grid-cols-1 gap-6 p-4 lg:grid-cols-5">
        {/* 输入区 */}
        <div className="space-y-5 lg:col-span-3">
          {groups.map(([group, fields]) => (
            <div key={group}>
              <h4 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">{group}</h4>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                {fields.map((f) => (
                  <FieldInput
                    key={f.key}
                    field={f}
                    value={values[f.key]}
                    onChange={(raw) => setField(f.key, raw, f.type)}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* 结果区 */}
        <div className="space-y-4 lg:col-span-2">
          {/* 关键指标 */}
          <div className="rounded-lg border border-border bg-muted/20 p-4">
            <h4 className="mb-3 text-sm font-semibold text-foreground">测算结果</h4>
            <div className="grid grid-cols-2 gap-2">
              {result.outputs.map((o) => (
                <div
                  key={o.label}
                  className={cn(
                    "rounded-md border px-3 py-2",
                    o.highlight ? "border-brand/30 bg-brand/5" : "border-border bg-card",
                  )}
                >
                  <p className="text-xs text-muted-foreground">{o.label}</p>
                  <p
                    className={cn(
                      "mt-0.5 text-sm font-semibold tabular-nums",
                      o.highlight
                        ? o.value < 0
                          ? "text-down"
                          : "text-brand"
                        : o.value < 0
                          ? "text-down"
                          : "text-foreground",
                    )}
                  >
                    {formatValue(o.value, o.format, mode.currency)}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* 各费用占比分析 */}
          <div className="rounded-lg border border-border bg-muted/20 p-4">
            <h4 className="mb-3 text-sm font-semibold text-foreground">各费用占比分析</h4>
            <div className="space-y-2">
              {result.ratios.map((r) => (
                <div key={r.label} className="flex items-center gap-3">
                  <span className="w-28 shrink-0 text-xs text-muted-foreground">{r.label}</span>
                  <div className="h-2 flex-1 overflow-hidden rounded-full bg-muted">
                    <div
                      className="h-full rounded-full bg-brand"
                      style={{ width: `${Math.min(100, (Math.abs(r.value) / maxRatio) * 100)}%` }}
                    />
                  </div>
                  <span className="w-14 shrink-0 text-right text-xs font-medium tabular-nums text-foreground">
                    {(r.value * 100).toFixed(2)}%
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function FieldInput({
  field,
  value,
  onChange,
}: {
  field: FieldDef
  value: number | string
  onChange: (raw: string) => void
}) {
  if (field.type === "select") {
    return (
      <label className="block">
        <span className="mb-1 block text-xs text-muted-foreground">{field.label}</span>
        <select
          value={String(value)}
          onChange={(e) => onChange(e.target.value)}
          className="w-full rounded-md border border-border bg-background px-2.5 py-1.5 text-sm text-foreground outline-none focus:border-brand"
        >
          {field.options?.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label}
            </option>
          ))}
        </select>
      </label>
    )
  }

  const isPercent = field.type === "percent"
  // 百分比字段以 % 显示（内部存小数）；用 toFixed(6) 消除浮点误差后再去尾零
  const display = isPercent
    ? value === ""
      ? ""
      : Number((Number(value) * 100).toFixed(6)).toString()
    : value === ""
      ? ""
      : value

  return (
    <label className="block">
      <span className="mb-1 block text-xs text-muted-foreground">
        {field.label}
        {field.hint ? <span className="ml-1 text-[10px] text-muted-foreground/70">({field.hint})</span> : null}
      </span>
      <div className="relative">
        <input
          type="number"
          inputMode="decimal"
          value={display}
          onChange={(e) => {
            const raw = e.target.value
            if (isPercent) onChange(raw === "" ? "" : String(Number(raw) / 100))
            else onChange(raw)
          }}
          className="w-full rounded-md border border-border bg-background px-2.5 py-1.5 pr-7 text-sm tabular-nums text-foreground outline-none focus:border-brand"
        />
        <span className="pointer-events-none absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">
          {isPercent ? "%" : field.suffix}
        </span>
      </div>
    </label>
  )
}
