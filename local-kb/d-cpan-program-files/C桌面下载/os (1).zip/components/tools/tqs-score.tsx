"use client"

import { useMemo, useState } from "react"
import { CheckCircle2, AlertTriangle, XCircle, RotateCcw, ChevronDown } from "lucide-react"
import { cn } from "@/lib/utils"
import {
  analyzeTqs,
  TQS_SAMPLE,
  TITLE_MAX_LENGTH,
  TITLE_CORE_LENGTH,
  TITLE_HIGHLIGHT_LENGTH,
  type TqsInput,
  type DimStatus,
} from "@/lib/calculators/tqs-score"

const STATUS_ICON: Record<DimStatus, typeof CheckCircle2> = {
  pass: CheckCircle2,
  warn: AlertTriangle,
  fail: XCircle,
}
const STATUS_COLOR: Record<DimStatus, string> = {
  pass: "text-up",
  warn: "text-amber-500",
  fail: "text-down",
}

const GRADE_STYLE: Record<"A" | "B" | "C", { bg: string; text: string; ring: string; label: string }> = {
  A: { bg: "bg-up/10", text: "text-up", ring: "ring-up/30", label: "高质量" },
  B: { bg: "bg-amber-500/10", text: "text-amber-600", ring: "ring-amber-500/30", label: "待优化" },
  C: { bg: "bg-down/10", text: "text-down", ring: "ring-down/30", label: "违规 · U级" },
}

export function TqsScore() {
  const [input, setInput] = useState<TqsInput>(TQS_SAMPLE)
  const [openDim, setOpenDim] = useState<string | null>("completeness")

  const result = useMemo(() => analyzeTqs(input), [input])
  const grade = result.grade
  const gradeStyle = GRADE_STYLE[grade]

  function update<K extends keyof TqsInput>(key: K, value: TqsInput[K]) {
    setInput((prev) => ({ ...prev, [key]: value }))
  }

  return (
    <div className="rounded-lg border border-border bg-card shadow-sm">
      {/* 标题栏 */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border px-4 py-3">
        <div>
          <h3 className="text-sm font-semibold text-foreground">TQS 标题质量诊断（A / B / C 评分）</h3>
          <p className="text-xs text-muted-foreground">
            CDQ v3 标题评估体系 · 完整性 / 准确性 / 篇幅 / 大小写 / 关键词标注 / 冗余度 / 内容限制性
          </p>
        </div>
        <button
          onClick={() => setInput(TQS_SAMPLE)}
          className="inline-flex items-center gap-1.5 rounded-md border border-border bg-card px-3 py-1.5 text-sm font-medium text-foreground transition-colors hover:bg-muted"
        >
          <RotateCcw className="h-3.5 w-3.5" />
          示例标题
        </button>
      </div>

      <div className="grid gap-4 p-4 lg:grid-cols-[1.4fr_1fr]">
        {/* 左：输入区 */}
        <div className="space-y-4">
          <div>
            <label className="mb-1.5 block text-xs font-medium text-muted-foreground">商品标题（粘贴前台 Listing 标题）</label>
            <textarea
              value={input.title}
              onChange={(e) => update("title", e.target.value)}
              rows={4}
              className="w-full resize-none rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground outline-none focus:border-brand focus:ring-1 focus:ring-brand"
              placeholder="Brand | Main Keyword, Attribute 1, Attribute 2 ..."
            />
            <LengthMeter length={result.length} core={result.coreLength} highlight={result.highlightLength} />
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="品牌名 Brand">
              <input
                value={input.brand}
                onChange={(e) => update("brand", e.target.value)}
                className="w-full rounded-md border border-border bg-background px-2.5 py-1.5 text-sm text-foreground outline-none focus:border-brand"
              />
            </Field>
            <Field label="主关键词 Main Keyword">
              <input
                value={input.mainKeyword}
                onChange={(e) => update("mainKeyword", e.target.value)}
                className="w-full rounded-md border border-border bg-background px-2.5 py-1.5 text-sm text-foreground outline-none focus:border-brand"
              />
            </Field>
            <Field label="标注核心属性数量">
              <input
                type="number"
                min={0}
                max={10}
                value={input.attributesTagged}
                onChange={(e) => update("attributesTagged", Number(e.target.value))}
                className="w-full rounded-md border border-border bg-background px-2.5 py-1.5 text-sm text-foreground outline-none focus:border-brand"
              />
            </Field>
            <div className="flex flex-col justify-end gap-1.5">
              <Toggle label="标注人群/场景/意图" checked={input.hasAudienceOrScene} onChange={(v) => update("hasAudienceOrScene", v)} />
              <Toggle label="无语法错误" checked={input.grammarOk} onChange={(v) => update("grammarOk", v)} />
              <Toggle label="属性与商品一致（准确性）" checked={input.attributesAccurate} onChange={(v) => update("attributesAccurate", v)} />
            </div>
          </div>
        </div>

        {/* 右：等级总览 */}
        <div className={cn("flex flex-col items-center justify-center gap-3 rounded-lg p-5 ring-1", gradeStyle.bg, gradeStyle.ring)}>
          <span className={cn("flex h-20 w-20 items-center justify-center rounded-full text-4xl font-bold ring-4", gradeStyle.text, gradeStyle.ring)}>
            {grade}
          </span>
          <div className="text-center">
            <p className={cn("text-base font-semibold", gradeStyle.text)}>{result.gradeLabel}</p>
            <p className="mt-0.5 text-xs text-muted-foreground">CDQ 标题质量评分</p>
          </div>
          <div className="grid w-full grid-cols-3 gap-2 text-center">
            <Stat label="CDQ%" value={`${result.cdqPercent}%`} tone={gradeStyle.text} />
            <Stat label="CDQv3 等级" value={result.cdqv3Grade.includes("U") ? "U" : "正常"} tone={gradeStyle.text} />
            <Stat label="评分值" value={result.cdqv3Value} tone={gradeStyle.text} />
          </div>
          {result.violations.length > 0 && (
            <div className="w-full rounded-md bg-down/10 px-3 py-2 text-xs text-down">
              <p className="mb-1 font-semibold">违规点（{result.violations.length}）</p>
              <ul className="list-disc space-y-0.5 pl-4">
                {result.violations.map((v, i) => (
                  <li key={i}>{v}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>

      {/* 判级规则速览 */}
      <div className="grid gap-2 border-t border-border px-4 py-3 sm:grid-cols-3">
        <RuleCard
          grade="A"
          title="A级 · 100%"
          active={grade === "A"}
          rules={["完整性 ≥ 0.6", "冗余度 = 1", "长度 ≤ 200", "管套评分 > 0", "特殊字符 = 1", "限制性 = 1"]}
        />
        <RuleCard
          grade="B"
          title="B级 · ≥50%"
          active={grade === "B"}
          rules={["未违反政策", "至少一个维度未达 A级", "CDQ 标题评分 ≥ 50%"]}
        />
        <RuleCard
          grade="C"
          title="C级 · 0% · U级 · N/A"
          active={grade === "C"}
          rules={["完整性 < 0.4 或", "冗余度 ≤ 0.6 或", "长度 > 200 或", "存在受限短语"]}
        />
      </div>

      {/* 维度明细 */}
      <div className="border-t border-border p-4">
        <h4 className="mb-3 text-sm font-semibold text-foreground">7 维度评估明细</h4>
        <div className="space-y-2">
          {result.dimensions.map((dim) => {
            const Icon = STATUS_ICON[dim.status]
            const open = openDim === dim.key
            return (
              <div key={dim.key} className="overflow-hidden rounded-md border border-border">
                <button
                  onClick={() => setOpenDim(open ? null : dim.key)}
                  className="flex w-full items-center gap-3 bg-muted/30 px-3 py-2.5 text-left transition-colors hover:bg-muted/50"
                >
                  <Icon className={cn("h-4 w-4 shrink-0", STATUS_COLOR[dim.status])} />
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium text-foreground">
                      {dim.label} <span className="text-xs font-normal text-muted-foreground">{dim.en}</span>
                    </p>
                    <p className="truncate text-xs text-muted-foreground">{dim.weightHint}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-1.5 w-16 overflow-hidden rounded-full bg-muted">
                      <div
                        className={cn("h-full rounded-full", dim.status === "pass" ? "bg-up" : dim.status === "warn" ? "bg-amber-500" : "bg-down")}
                        style={{ width: `${Math.round(dim.score * 100)}%` }}
                      />
                    </div>
                    <span className="w-10 text-right text-xs font-semibold tabular-nums text-foreground">{(dim.score * 100).toFixed(0)}%</span>
                    <ChevronDown className={cn("h-4 w-4 text-muted-foreground transition-transform", open && "rotate-180")} />
                  </div>
                </button>
                {open && (
                  <div className="divide-y divide-border border-t border-border">
                    {dim.checks.map((c, i) => {
                      const CIcon = STATUS_ICON[c.status]
                      return (
                        <div key={i} className="flex items-start gap-3 px-3 py-2.5">
                          <CIcon className={cn("mt-0.5 h-3.5 w-3.5 shrink-0", STATUS_COLOR[c.status])} />
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center justify-between gap-2">
                              <p className="text-sm text-foreground">{c.label}</p>
                              <span className={cn("shrink-0 text-xs font-semibold tabular-nums", STATUS_COLOR[c.status])}>{c.scoreText}</span>
                            </div>
                            <p className="mt-0.5 text-xs text-muted-foreground">{c.note}</p>
                            <p className="mt-0.5 text-[11px] text-muted-foreground/70">计分规则：{c.rule}</p>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </div>

      {/* 优化建议 */}
      <div className="border-t border-border p-4">
        <h4 className="mb-2 text-sm font-semibold text-foreground">针对性优化建议</h4>
        <ul className="space-y-1.5">
          {result.suggestions.map((s, i) => (
            <li key={i} className="flex items-start gap-2 text-sm text-foreground">
              <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-brand" />
              {s}
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}

function LengthMeter({ length, core, highlight }: { length: number; core: number; highlight: number }) {
  const over = length > TITLE_MAX_LENGTH
  const corePct = (core / TITLE_MAX_LENGTH) * 100
  const hlPct = (highlight / TITLE_MAX_LENGTH) * 100
  return (
    <div className="mt-2">
      <div className="flex items-center justify-between text-[11px] text-muted-foreground">
        <span>核心 {core}/{TITLE_CORE_LENGTH}</span>
        <span>HIGHLIGHT {highlight}/{TITLE_HIGHLIGHT_LENGTH}</span>
        <span className={cn("font-semibold", over ? "text-down" : "text-foreground")}>{length}/200</span>
      </div>
      <div className="mt-1 flex h-2 w-full overflow-hidden rounded-full bg-muted">
        <div className="h-full bg-brand" style={{ width: `${Math.min(100, corePct)}%` }} />
        <div className="h-full bg-brand/50" style={{ width: `${Math.min(100 - corePct, hlPct)}%` }} />
        {over && <div className="h-full bg-down" style={{ width: `${Math.min(20, ((length - TITLE_MAX_LENGTH) / TITLE_MAX_LENGTH) * 100)}%` }} />}
      </div>
    </div>
  )
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="mb-1 block text-xs font-medium text-muted-foreground">{label}</label>
      {children}
    </div>
  )
}

function Toggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex cursor-pointer items-center gap-2 text-xs text-foreground">
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        className="h-3.5 w-3.5 rounded border-border accent-brand"
      />
      {label}
    </label>
  )
}

function Stat({ label, value, tone }: { label: string; value: string; tone: string }) {
  return (
    <div className="rounded-md bg-card/60 px-2 py-1.5">
      <p className={cn("text-sm font-bold tabular-nums", tone)}>{value}</p>
      <p className="text-[10px] text-muted-foreground">{label}</p>
    </div>
  )
}

function RuleCard({ grade, title, rules, active }: { grade: "A" | "B" | "C"; title: string; rules: string[]; active: boolean }) {
  const s = GRADE_STYLE[grade]
  return (
    <div className={cn("rounded-md border p-3 transition-colors", active ? cn(s.bg, "border-transparent ring-1", s.ring) : "border-border bg-card")}>
      <div className="mb-1.5 flex items-center gap-2">
        <span className={cn("flex h-5 w-5 items-center justify-center rounded text-xs font-bold", s.bg, s.text)}>{grade}</span>
        <span className={cn("text-xs font-semibold", active ? s.text : "text-foreground")}>{title}</span>
      </div>
      <ul className="space-y-0.5">
        {rules.map((r, i) => (
          <li key={i} className="text-[11px] text-muted-foreground">
            {r}
          </li>
        ))}
      </ul>
    </div>
  )
}
