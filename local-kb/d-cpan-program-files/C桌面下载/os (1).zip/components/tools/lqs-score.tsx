"use client"

import { useMemo, useState } from "react"
import {
  Copy,
  Check,
  Download,
  Upload,
  ChevronDown,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  RotateCcw,
  ClipboardList,
  ExternalLink,
} from "lucide-react"
import { cn } from "@/lib/utils"
import {
  computeCdq,
  sampleInput,
  buildV3Link,
  DIMENSION_META,
  GRADE_META,
  type CdqInput,
  type Marketplace,
  type CheckStatus,
  type CheckItem,
} from "@/lib/calculators/cdq-score"

const STATUS_ICON: Record<CheckStatus, typeof CheckCircle2> = {
  pass: CheckCircle2,
  warn: AlertTriangle,
  fail: XCircle,
}
const STATUS_COLOR: Record<CheckStatus, string> = {
  pass: "text-up",
  warn: "text-amber-500",
  fail: "text-down",
}

export function LqsScore() {
  const [input, setInput] = useState<CdqInput>(sampleInput)
  const [doneIds, setDoneIds] = useState<Set<string>>(new Set())
  const [copied, setCopied] = useState(false)
  const [showRaw, setShowRaw] = useState(true)
  const [expanded, setExpanded] = useState<string | null>("structured")

  const result = useMemo(() => computeCdq(input), [input])

  function patch(p: Partial<CdqInput>) {
    setInput((prev) => ({ ...prev, ...p }))
  }

  const v3Link = buildV3Link(input.marketplace, input.asin)

  function copyLink() {
    navigator.clipboard?.writeText(v3Link)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }

  function downloadJson() {
    const blob = new Blob([JSON.stringify({ input, result }, null, 2)], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `CDQ-${input.asin || "asin"}-${input.marketplace}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  function importJson(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result))
        if (parsed.input) setInput(parsed.input)
      } catch {
        /* ignore */
      }
    }
    reader.readAsText(file)
  }

  const todos = result.todos.map((t) => ({ ...t, done: doneIds.has(t.id) }))
  const doneCount = todos.filter((t) => t.done).length

  return (
    <div className="space-y-4">
      {/* —— 顶部：ASIN / 站点 / V3 链接 / 数据源 —— */}
      <div className="rounded-lg border border-border bg-card p-4 shadow-sm">
        <div className="flex flex-wrap items-end gap-3">
          <label className="block">
            <span className="mb-1 block text-xs text-muted-foreground">ASIN</span>
            <input
              value={input.asin}
              onChange={(e) => patch({ asin: e.target.value.toUpperCase() })}
              placeholder="B0XXXXXXXX"
              className="w-40 rounded-md border border-border bg-background px-2.5 py-1.5 text-sm font-medium tabular-nums text-foreground outline-none focus:border-brand"
            />
          </label>
          <label className="block">
            <span className="mb-1 block text-xs text-muted-foreground">站点</span>
            <select
              value={input.marketplace}
              onChange={(e) => patch({ marketplace: e.target.value as Marketplace })}
              className="rounded-md border border-border bg-background px-2.5 py-1.5 text-sm text-foreground outline-none focus:border-brand"
            >
              <option value="US">美国 US</option>
              <option value="EU">欧洲 EU</option>
            </select>
          </label>
          <label className="block">
            <span className="mb-1 block text-xs text-muted-foreground">产品类型 (PT)</span>
            <input
              value={input.productType}
              onChange={(e) => patch({ productType: e.target.value })}
              className="w-36 rounded-md border border-border bg-background px-2.5 py-1.5 text-sm text-foreground outline-none focus:border-brand"
            />
          </label>

          <div className="ml-auto flex items-center gap-2">
            <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-md border border-border bg-background px-3 py-1.5 text-sm font-medium text-foreground transition-colors hover:bg-muted">
              <Upload className="h-3.5 w-3.5" />
              导入原始数据
              <input type="file" accept="application/json" className="hidden" onChange={importJson} />
            </label>
            <button
              onClick={downloadJson}
              className="inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-3 py-1.5 text-sm font-medium text-foreground transition-colors hover:bg-muted"
            >
              <Download className="h-3.5 w-3.5" />
              下载数据源
            </button>
            <button
              onClick={() => {
                setInput(sampleInput())
                setDoneIds(new Set())
              }}
              className="inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-3 py-1.5 text-sm font-medium text-foreground transition-colors hover:bg-muted"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              重置
            </button>
          </div>
        </div>

        {/* V3 属性链接 */}
        <div className="mt-3 flex items-center gap-2 rounded-md border border-dashed border-border bg-muted/30 px-3 py-2">
          <span className="shrink-0 text-xs font-medium text-muted-foreground">V3 属性链接</span>
          <code className="flex-1 truncate text-xs text-foreground">{v3Link}</code>
          <button onClick={copyLink} className="inline-flex shrink-0 items-center gap-1 text-xs font-medium text-brand hover:underline">
            {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
            {copied ? "已复制" : "复制"}
          </button>
          <a
            href={v3Link}
            target="_blank"
            rel="noreferrer"
            className="inline-flex shrink-0 items-center gap-1 text-xs font-medium text-brand hover:underline"
          >
            <ExternalLink className="h-3.5 w-3.5" />
            打开
          </a>
        </div>
        <p className="mt-1.5 text-[11px] text-muted-foreground">
          在亚马逊后台用含 ASIN 的 V3 链接抓取 reconciledDetailsV3 数据，清洗去重后整理填入下方原始数据，由打分引擎按官方 7 维度算法建模评分。
        </p>
      </div>

      {/* —— 总分概览 —— */}
      <ScoreOverview result={result} />

      {/* —— 7 维度明细 —— */}
      <div className="rounded-lg border border-border bg-card shadow-sm">
        <div className="border-b border-border px-4 py-3">
          <h3 className="text-sm font-semibold text-foreground">7 维度评分明细</h3>
          <p className="text-xs text-muted-foreground">点击展开查看每个维度的计分点 / 扣分点</p>
        </div>
        <div className="divide-y divide-border">
          {result.dimensions.map((d) => {
            const open = expanded === d.key
            return (
              <div key={d.key}>
                <button
                  onClick={() => setExpanded(open ? null : d.key)}
                  className="flex w-full items-center gap-3 px-4 py-3 text-left transition-colors hover:bg-muted/30"
                >
                  <ChevronDown className={cn("h-4 w-4 shrink-0 text-muted-foreground transition-transform", open && "rotate-180")} />
                  <div className="flex min-w-0 flex-1 items-center gap-2">
                    <span className="text-sm font-medium text-foreground">{d.label}</span>
                    <span className="text-xs text-muted-foreground">{d.en}</span>
                    {d.bonus && <span className="rounded bg-brand/10 px-1.5 py-0.5 text-[10px] font-medium text-brand">加分项 0-20%</span>}
                    {!d.applicable && <span className="rounded bg-muted px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground">N/A</span>}
                    {d.grade && (
                      <span
                        className={cn(
                          "rounded px-1.5 py-0.5 text-[10px] font-bold",
                          d.grade === "A" ? "bg-up/15 text-up" : d.grade === "B" ? "bg-amber-500/15 text-amber-600" : "bg-down/15 text-down",
                        )}
                      >
                        TQS {d.grade} 级
                      </span>
                    )}
                  </div>
                  <span className="shrink-0 text-xs text-muted-foreground">权重 {d.weight.toFixed(1)}%</span>
                  <div className="hidden w-32 shrink-0 items-center gap-2 sm:flex">
                    <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-muted">
                      <div
                        className={cn("h-full rounded-full", d.score >= 0.85 ? "bg-up" : d.score >= 0.5 ? "bg-amber-500" : "bg-down")}
                        style={{ width: `${d.score * 100}%` }}
                      />
                    </div>
                    <span className="w-9 text-right text-xs font-semibold tabular-nums text-foreground">{(d.score * 100).toFixed(0)}%</span>
                  </div>
                  <span className="w-14 shrink-0 text-right text-sm font-semibold tabular-nums text-brand">{d.points.toFixed(1)}</span>
                </button>
                {open && (
                  <div className="space-y-2 bg-muted/20 px-4 pb-3 pl-11">
                    {d.checks.map((c) => (
                      <CheckRow key={c.label} check={c} />
                    ))}
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {/* —— 诊断与建议 —— */}
        <div className="rounded-lg border border-border bg-card shadow-sm">
          <div className="border-b border-border px-4 py-3">
            <h3 className="text-sm font-semibold text-foreground">针对性诊断与建议</h3>
            <p className="text-xs text-muted-foreground">{result.diagnoses.length} 项待优化</p>
          </div>
          <div className="divide-y divide-border">
            {result.diagnoses.length === 0 && <p className="px-4 py-6 text-center text-sm text-muted-foreground">未发现问题，listing 质量优秀</p>}
            {result.diagnoses.map((d, i) => (
              <div key={i} className="px-4 py-3">
                <div className="flex items-center gap-2">
                  <span
                    className={cn(
                      "rounded px-1.5 py-0.5 text-[10px] font-bold",
                      d.severity === "critical" ? "bg-down/15 text-down" : d.severity === "major" ? "bg-amber-500/15 text-amber-600" : "bg-muted text-muted-foreground",
                    )}
                  >
                    {d.severity === "critical" ? "严重缺陷" : d.severity === "major" ? "重要" : "轻微"}
                  </span>
                  <span className="text-xs font-medium text-muted-foreground">{d.dimension}</span>
                </div>
                <p className="mt-1.5 text-sm font-medium text-foreground">{d.problem}</p>
                <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{d.suggestion}</p>
              </div>
            ))}
          </div>
        </div>

        {/* —— TODOLIST —— */}
        <div className="rounded-lg border border-border bg-card shadow-sm">
          <div className="flex items-center gap-2 border-b border-border px-4 py-3">
            <ClipboardList className="h-4 w-4 text-brand" />
            <h3 className="text-sm font-semibold text-foreground">TODOLIST · 完成情况</h3>
            <span className="ml-auto text-xs font-medium text-muted-foreground">
              {doneCount}/{todos.length} 已完成
            </span>
          </div>
          {/* 进度条 */}
          <div className="px-4 pt-3">
            <div className="h-1.5 overflow-hidden rounded-full bg-muted">
              <div className="h-full rounded-full bg-brand transition-all" style={{ width: `${todos.length ? (doneCount / todos.length) * 100 : 0}%` }} />
            </div>
          </div>
          <div className="divide-y divide-border">
            {todos.length === 0 && <p className="px-4 py-6 text-center text-sm text-muted-foreground">暂无待办事项</p>}
            {todos.map((t) => (
              <label key={t.id} className="flex cursor-pointer items-start gap-3 px-4 py-3 transition-colors hover:bg-muted/30">
                <input
                  type="checkbox"
                  checked={t.done}
                  onChange={() =>
                    setDoneIds((prev) => {
                      const next = new Set(prev)
                      if (next.has(t.id)) next.delete(t.id)
                      else next.add(t.id)
                      return next
                    })
                  }
                  className="mt-0.5 h-4 w-4 shrink-0 accent-[var(--brand)]"
                />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span
                      className={cn(
                        "rounded px-1.5 py-0.5 text-[10px] font-bold",
                        t.priority === "high" ? "bg-down/15 text-down" : t.priority === "medium" ? "bg-amber-500/15 text-amber-600" : "bg-muted text-muted-foreground",
                      )}
                    >
                      {t.priority === "high" ? "高" : t.priority === "medium" ? "中" : "低"}
                    </span>
                    <span className="text-xs font-medium text-muted-foreground">{t.dimension}</span>
                  </div>
                  <p className={cn("mt-1 text-sm font-medium", t.done ? "text-muted-foreground line-through" : "text-foreground")}>{t.action}</p>
                  <p className="mt-0.5 text-[11px] text-muted-foreground">Merchant Action: {t.merchantAction}</p>
                </div>
              </label>
            ))}
          </div>
        </div>
      </div>

      {/* —— 原始数据输入 —— */}
      <div className="rounded-lg border border-border bg-card shadow-sm">
        <button onClick={() => setShowRaw((s) => !s)} className="flex w-full items-center gap-2 border-b border-border px-4 py-3 text-left">
          <ChevronDown className={cn("h-4 w-4 text-muted-foreground transition-transform", showRaw && "rotate-180")} />
          <h3 className="text-sm font-semibold text-foreground">原始数据输入</h3>
          <span className="text-xs text-muted-foreground">前台 listing 数据 + 后台 V3 属性数据，所有字段可配置</span>
        </button>
        {showRaw && <RawDataForm input={input} patch={patch} />}
      </div>
    </div>
  )
}

function ScoreOverview({ result }: { result: ReturnType<typeof computeCdq> }) {
  const g = GRADE_META[result.grade]
  const pct = Math.min(100, (result.total / 120) * 100)
  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
      {/* 总分 */}
      <div className="rounded-lg border border-border bg-card p-5 shadow-sm">
        <p className="text-xs text-muted-foreground">CDQ 综合得分（满分 100-120）</p>
        <div className="mt-2 flex items-end gap-3">
          <span className="text-4xl font-bold tabular-nums text-foreground">{result.total.toFixed(1)}</span>
          <span
            className="mb-1 rounded-md px-2 py-0.5 text-sm font-bold text-white"
            style={{ backgroundColor: g.color }}
          >
            {result.grade} 级
          </span>
        </div>
        <p className="mt-1 text-xs text-muted-foreground">
          {g.label} · 区间 {g.range}
        </p>
        <div className="mt-3 h-2 overflow-hidden rounded-full bg-muted">
          <div className="h-full rounded-full transition-all" style={{ width: `${pct}%`, backgroundColor: g.color }} />
        </div>
        <p className="mt-2 text-xs text-muted-foreground">
          详情页基础分 {result.baseTotal.toFixed(1)} / 100 · 可发现性加分至 120
        </p>
      </div>

      {/* 状态标记 */}
      <div className="rounded-lg border border-border bg-card p-5 shadow-sm">
        <p className="mb-3 text-xs text-muted-foreground">关键风险标记</p>
        <div className="space-y-2">
          <StatusBadge
            ok={!result.policyViolation}
            okText="无政策违规"
            badText="政策违规（标题违规 / 索引抑制）→ U 级"
          />
          <StatusBadge ok={!result.severeDefect} okText="无严重缺陷" badText="存在严重缺陷（Egregious Defect）→ D 级" />
        </div>
        <p className="mt-3 text-[11px] leading-relaxed text-muted-foreground">
          严重缺陷：前 6 RAI 属性错误，或前 10 相关属性完整性 &lt; 50%，或变体严重缺陷。政策违规：标题受限词 / 特殊字符 / 超长 / 堆砌。
        </p>
      </div>

      {/* 等级图例 */}
      <div className="rounded-lg border border-border bg-card p-5 shadow-sm">
        <p className="mb-2 text-xs text-muted-foreground">CDQ v3 等级体系</p>
        <div className="space-y-1.5">
          {(Object.keys(GRADE_META) as (keyof typeof GRADE_META)[]).map((k) => (
            <div key={k} className="flex items-center gap-2 text-xs">
              <span className="inline-block h-2.5 w-2.5 rounded-full" style={{ backgroundColor: GRADE_META[k].color }} />
              <span className={cn("w-9 font-bold", result.grade === k && "text-brand")}>{k}</span>
              <span className="w-20 text-muted-foreground">{GRADE_META[k].range}</span>
              <span className="text-muted-foreground">{GRADE_META[k].label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

function StatusBadge({ ok, okText, badText }: { ok: boolean; okText: string; badText: string }) {
  return (
    <div className="flex items-center gap-2">
      {ok ? <CheckCircle2 className="h-4 w-4 text-up" /> : <XCircle className="h-4 w-4 text-down" />}
      <span className={cn("text-sm font-medium", ok ? "text-foreground" : "text-down")}>{ok ? okText : badText}</span>
    </div>
  )
}

function CheckRow({ check }: { check: CheckItem }) {
  const Icon = STATUS_ICON[check.status]
  return (
    <div className="flex items-start gap-2.5 rounded-md border border-border bg-card px-3 py-2">
      <Icon className={cn("mt-0.5 h-4 w-4 shrink-0", STATUS_COLOR[check.status])} />
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-x-2">
          <span className="text-sm font-medium text-foreground">{check.label}</span>
          <span className="text-xs text-muted-foreground">— {check.detail}</span>
        </div>
        {check.impact && <p className="mt-0.5 text-[11px] text-muted-foreground/80">计分规则：{check.impact}</p>}
      </div>
    </div>
  )
}

/* ============================ 原始数据表单 ============================ */

function RawDataForm({ input, patch }: { input: CdqInput; patch: (p: Partial<CdqInput>) => void }) {
  return (
    <div className="grid grid-cols-1 gap-5 p-4 md:grid-cols-2 lg:grid-cols-3">
      <FormGroup title="标题 Title">
        <TextField label="标题文本" value={input.title} onChange={(v) => patch({ title: v })} textarea />
        <NumField label="标注核心属性数" value={input.titleAttributesTagged} onChange={(v) => patch({ titleAttributesTagged: v })} />
        <BoolField label="以品牌名开头" value={input.titleStartsWithBrand} onChange={(v) => patch({ titleStartsWithBrand: v })} />
      </FormGroup>

      <FormGroup title="结构化属性 Structured Attributes">
        <NumField label="前6 RAI 应填" value={input.top6Total} onChange={(v) => patch({ top6Total: v })} />
        <NumField label="前6 已填写" value={input.top6Filled} onChange={(v) => patch({ top6Filled: v })} />
        <NumField label="前6 正确" value={input.top6Correct} onChange={(v) => patch({ top6Correct: v })} />
        <NumField label="前10 应填" value={input.top10Total} onChange={(v) => patch({ top10Total: v })} />
        <NumField label="前10 已填写" value={input.top10Filled} onChange={(v) => patch({ top10Filled: v })} />
        <NumField label="Band A/B 填充率" value={input.bandABFilledRatio} onChange={(v) => patch({ bandABFilledRatio: v })} step={0.05} />
      </FormGroup>

      <FormGroup title="五点描述 Bullets">
        <NumField label="五点数量" value={input.bulletCount} onChange={(v) => patch({ bulletCount: v })} />
        <BoolField label="含违禁/敏感词" value={input.bulletHasRestrictedWords} onChange={(v) => patch({ bulletHasRestrictedWords: v })} />
      </FormGroup>

      <FormGroup title="图片 Image">
        <NumField label="图片数量" value={input.imageCount} onChange={(v) => patch({ imageCount: v })} />
        <BoolField label="存在图片缺陷" value={input.imageHasDefect} onChange={(v) => patch({ imageHasDefect: v })} />
        <NumField label="主图像素 (px)" value={input.mainImagePx} onChange={(v) => patch({ mainImagePx: v })} step={100} />
        <BoolField label="支持缩放" value={input.imageHasZoom} onChange={(v) => patch({ imageHasZoom: v })} />
        <NumField label="IAI 指数" value={input.iai} onChange={(v) => patch({ iai: v })} step={0.05} />
      </FormGroup>

      <FormGroup title="A+ / 变体 Variation">
        <BoolField label="有 A+ 内容" value={input.hasAPlus} onChange={(v) => patch({ hasAPlus: v })} />
        <BoolField label="高级 A+" value={input.hasPremiumAPlus} onChange={(v) => patch({ hasPremiumAPlus: v })} />
        <BoolField label="是变体家族" value={input.isVariation} onChange={(v) => patch({ isVariation: v })} />
        <NumField label="变体数量" value={input.variationCount} onChange={(v) => patch({ variationCount: v })} />
        <BoolField label="主题属性一致" value={input.variationThemeConsistent} onChange={(v) => patch({ variationThemeConsistent: v })} />
        <BoolField label="变体严重缺陷" value={input.variationHasSevereDefect} onChange={(v) => patch({ variationHasSevereDefect: v })} />
      </FormGroup>

      <FormGroup title="可发现性 Discoverability">
        <BoolField label="有细分叶节点" value={input.hasLeafNode} onChange={(v) => patch({ hasLeafNode: v })} />
        <BoolField label="PT 分类正确" value={input.ptClassificationCorrect} onChange={(v) => patch({ ptClassificationCorrect: v })} />
        <BoolField label="含搜索关键词" value={input.hasSearchKeywords} onChange={(v) => patch({ hasSearchKeywords: v })} />
      </FormGroup>
    </div>
  )
}

function FormGroup({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h4 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">{title}</h4>
      <div className="space-y-2">{children}</div>
    </div>
  )
}

function TextField({ label, value, onChange, textarea }: { label: string; value: string; onChange: (v: string) => void; textarea?: boolean }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs text-muted-foreground">{label}</span>
      {textarea ? (
        <textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          rows={3}
          className="w-full resize-none rounded-md border border-border bg-background px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-brand"
        />
      ) : (
        <input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full rounded-md border border-border bg-background px-2.5 py-1.5 text-sm text-foreground outline-none focus:border-brand"
        />
      )}
    </label>
  )
}

function NumField({ label, value, onChange, step = 1 }: { label: string; value: number; onChange: (v: number) => void; step?: number }) {
  return (
    <label className="flex items-center justify-between gap-2">
      <span className="text-xs text-muted-foreground">{label}</span>
      <input
        type="number"
        step={step}
        value={value}
        onChange={(e) => onChange(e.target.value === "" ? 0 : Number(e.target.value))}
        className="w-20 rounded-md border border-border bg-background px-2 py-1 text-right text-sm tabular-nums text-foreground outline-none focus:border-brand"
      />
    </label>
  )
}

function BoolField({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex cursor-pointer items-center justify-between gap-2">
      <span className="text-xs text-muted-foreground">{label}</span>
      <button
        type="button"
        onClick={() => onChange(!value)}
        className={cn("relative h-5 w-9 shrink-0 rounded-full transition-colors", value ? "bg-brand" : "bg-muted")}
      >
        <span className={cn("absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-all", value ? "left-[18px]" : "left-0.5")} />
      </button>
    </label>
  )
}
