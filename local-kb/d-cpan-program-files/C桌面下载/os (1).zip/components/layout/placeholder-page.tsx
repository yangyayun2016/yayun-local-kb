import type { LucideIcon } from "lucide-react"
import { Construction } from "lucide-react"
import { PageHeader } from "@/components/ui/page-header"

export function PlaceholderPage({
  title,
  icon: Icon,
  modules,
}: {
  title: string
  icon?: LucideIcon
  modules?: string[]
}) {
  const HeaderIcon = Icon ?? Construction
  return (
    <div>
      <PageHeader title={title} description="该模块正在建设中，以下为规划功能预览" />

      {modules && modules.length > 0 && (
        <div className="mb-5 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {modules.map((m) => (
            <div
              key={m}
              className="flex items-center gap-3 rounded-lg border border-border bg-card p-4 shadow-sm"
            >
              <div className="flex h-9 w-9 items-center justify-center rounded-md bg-brand/10 text-brand">
                <HeaderIcon className="h-5 w-5" />
              </div>
              <span className="text-sm font-medium text-foreground">{m}</span>
            </div>
          ))}
        </div>
      )}

      <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-border bg-card py-20 text-center shadow-sm">
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-brand/10 text-brand">
          <HeaderIcon className="h-7 w-7" />
        </div>
        <p className="mt-4 text-base font-medium text-foreground">{title}模块开发中</p>
        <p className="mt-1 max-w-sm text-sm text-muted-foreground">
          完整功能将根据《天机 OS 开发需求表》逐步上线，敬请期待。
        </p>
      </div>
    </div>
  )
}
