"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Bell, HelpCircle, Search, ChevronDown, LogOut } from "lucide-react"
import { useSession } from "@/components/providers/session-provider"

const ROLE_LABEL: Record<string, string> = {
  admin: "超级管理员",
  boss: "老板",
  operator: "运营",
}

export function Topbar() {
  const user = useSession()
  const router = useRouter()
  const [menuOpen, setMenuOpen] = useState(false)
  const [loggingOut, setLoggingOut] = useState(false)

  const name = user.displayName || user.username
  const initial = name.slice(0, 1)

  async function handleLogout() {
    setLoggingOut(true)
    try {
      await fetch("/api/auth/logout", { method: "POST" })
    } finally {
      router.replace("/login")
      router.refresh()
    }
  }

  return (
    <header className="flex h-14 shrink-0 items-center justify-between gap-4 border-b border-border bg-card px-5">
      {/* Search */}
      <div className="flex items-center gap-3">
        <div className="relative hidden sm:block">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            placeholder="搜索 ASIN / 订单 / 功能"
            className="h-9 w-64 rounded-md border border-border bg-page pl-9 pr-3 text-sm text-foreground outline-none placeholder:text-muted-foreground focus:border-brand focus:bg-card"
          />
        </div>
      </div>

      {/* Right */}
      <div className="flex items-center gap-1.5">
        <button
          aria-label="帮助"
          className="flex h-9 w-9 items-center justify-center rounded-md text-muted-foreground hover:bg-muted hover:text-foreground"
        >
          <HelpCircle className="h-[18px] w-[18px]" />
        </button>
        <button
          aria-label="通知"
          className="relative flex h-9 w-9 items-center justify-center rounded-md text-muted-foreground hover:bg-muted hover:text-foreground"
        >
          <Bell className="h-[18px] w-[18px]" />
          <span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-down" />
        </button>
        <div className="mx-1 h-5 w-px bg-border" />

        <div className="relative">
          <button
            onClick={() => setMenuOpen((v) => !v)}
            onBlur={() => setTimeout(() => setMenuOpen(false), 150)}
            className="flex items-center gap-2 rounded-md py-1 pl-1 pr-2 hover:bg-muted"
          >
            <div className="flex h-7 w-7 items-center justify-center rounded-full bg-brand text-xs font-semibold text-white">
              {initial}
            </div>
            <div className="hidden text-left leading-tight sm:block">
              <div className="text-[13px] font-medium text-foreground">
                {name}
                <span className="ml-1 rounded bg-brand/10 px-1 py-0.5 text-[10px] text-brand">
                  {ROLE_LABEL[user.role] || user.role}
                </span>
              </div>
            </div>
            <ChevronDown className="h-4 w-4 text-muted-foreground" />
          </button>

          {menuOpen && (
            <div className="absolute right-0 top-full z-20 mt-1 w-40 rounded-md border border-border bg-card py-1 shadow-lg">
              <div className="border-b border-border px-3 py-2 text-xs text-muted-foreground">
                @{user.username}
              </div>
              <button
                onClick={handleLogout}
                disabled={loggingOut}
                className="flex w-full items-center gap-2 px-3 py-2 text-left text-sm text-foreground hover:bg-muted disabled:opacity-50"
              >
                <LogOut className="h-4 w-4" />
                {loggingOut ? "退出中…" : "退出登录"}
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  )
}
