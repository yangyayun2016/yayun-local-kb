import { asinRows } from "@/lib/mock/sales"
import { cn } from "@/lib/utils"

const statusStyle: Record<string, string> = {
  在售: "bg-up/10 text-up",
  断货预警: "bg-[#faad14]/15 text-[#d48806]",
  已停售: "bg-muted text-muted-foreground",
}

export function AsinTable() {
  return (
    <div className="rounded-lg border border-border bg-card shadow-sm">
      <div className="flex items-center justify-between border-b border-border px-4 py-3">
        <h3 className="text-sm font-semibold text-foreground">ASIN 销售明细</h3>
        <span className="text-xs text-muted-foreground">共 {asinRows.length} 个商品</span>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[860px] text-sm">
          <thead>
            <tr className="text-left text-xs text-muted-foreground">
              <th className="px-4 py-2.5 font-medium">商品 / ASIN</th>
              <th className="px-4 py-2.5 font-medium">店铺</th>
              <th className="px-4 py-2.5 text-right font-medium">销售额</th>
              <th className="px-4 py-2.5 text-right font-medium">销量</th>
              <th className="px-4 py-2.5 text-right font-medium">订单数</th>
              <th className="px-4 py-2.5 text-right font-medium">单价</th>
              <th className="px-4 py-2.5 text-right font-medium">毛利率</th>
              <th className="px-4 py-2.5 text-center font-medium">状态</th>
            </tr>
          </thead>
          <tbody>
            {asinRows.map((row) => (
              <tr key={row.asin} className="border-t border-border hover:bg-muted/50">
                <td className="px-4 py-3">
                  <p className="font-medium text-foreground">{row.name}</p>
                  <p className="text-xs text-brand">{row.asin}</p>
                </td>
                <td className="px-4 py-3 whitespace-nowrap text-foreground/80">{row.shop}</td>
                <td className="px-4 py-3 text-right font-medium tabular-nums text-foreground">{row.sales}</td>
                <td className="px-4 py-3 text-right tabular-nums text-foreground/80">{row.qty}</td>
                <td className="px-4 py-3 text-right tabular-nums text-foreground/80">{row.orders}</td>
                <td className="px-4 py-3 text-right tabular-nums text-foreground/80">{row.price}</td>
                <td className="px-4 py-3 text-right tabular-nums text-foreground/80">{row.margin}</td>
                <td className="px-4 py-3">
                  <div className="flex justify-center">
                    <span className={cn("rounded px-2 py-0.5 text-xs font-medium", statusStyle[row.status])}>
                      {row.status}
                    </span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
