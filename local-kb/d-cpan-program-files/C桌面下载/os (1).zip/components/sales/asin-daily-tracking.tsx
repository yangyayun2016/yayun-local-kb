"use client"

import { useEffect, useMemo, useRef, useState } from "react"
import { Calendar, RefreshCw, SlidersHorizontal, Check, ChevronDown } from "lucide-react"
import { DateRangeDropdown, Segmented } from "@/components/ads/time-filter"
import { compareModes, granularityOptions, type DateRangeOption } from "@/lib/mock/data-detail"
import { columnGroups, trackingRows, trackingSummary, type ColumnDef } from "@/lib/mock/asin-tracking"
import { cn } from "@/lib/utils"

export function AsinDailyTracking() {
  const [range, setRange] = useState<DateRangeOption>("最近30天")
  const [compare, setCompare] = useState<string>("环比")
  const [granularity, setGranularity] = useState<string>("按日")
  const [syncing, setSyncing] = useState(false)

  // 维度分组显隐
  const [activeGroups, setActiveGroups] = useState<Record<string, boolean>>(() =>
    Object.fromEntries(columnGroups.map((g) => [g.id, g.defaultOn])),
  )
  const [configOpen, setConfigOpen] = useState(false)
  const configRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    function onClick(e: MouseEvent) {
      if (configRef.current && !configRef.current.contains(e.target as Node)) setConfigOpen(false)
    }
    document.addEventListener("mousedown", onClick)
    return () => document.removeEventListener("mousedown", onClick)
  }, [])

  function toggleGroup(id: string) {
    const g = columnGroups.find((x) => x.id === id)
    if (g?.locked) return
    setActiveGroups((prev) => ({ ...prev, [id]: !prev[id] }))
  }

  function handleSync() {
    setSyncing(true)
    setTimeout(() => setSyncing(false), 900)
  }

  // 当前展示的列
  const visibleColumns: ColumnDef[] = useMemo(
    () => columnGroups.filter((g) => activeGroups[g.id]).flatMap((g) => g.columns),
    [activeGroups],
  )

  const shownGroupCount = columnGroups.filter((g) => activeGroups[g.id] && !g.locked).length

  return (
    <div className="rounded-lg border border-border bg-card shadow-sm">
      {/* 标题栏 */}
      <div className="flex flex-wrap items-center gap-2 border-b border-border px-4 py-3">
        <h3 className="text-sm font-semibold text-foreground">ASIN 销售明细 · 日常跟踪表</h3>
        <span className="rounded bg-muted px-2 py-0.5 text-xs font-medium text-muted-foreground">
          {trackingSummary.product} · {trackingSummary.asin}
        </span>
        <span className="ml-auto text-xs text-muted-foreground">
          共 {trackingSummary.dayCount} 天记录 · 数据截至 {trackingSummary.dataDate}
        </span>
      </div>

      {/* 筛选行 */}
      <div className="flex flex-wrap items-center gap-3 border-b border-border bg-muted/20 px-4 py-3">
        <DateRangeDropdown value={range} onChange={setRange} />
        <Segmented options={compareModes} value={compare} onChange={setCompare} />
        <Segmented options={granularityOptions} value={granularity} onChange={setGranularity} />

        <div className="inline-flex items-center gap-2 rounded-md border border-border bg-card px-3 py-1.5 text-sm text-muted-foreground">
          <Calendar className="h-3.5 w-3.5" />
          <span>年/月/日</span>
          <span>~</span>
          <span>年/月/日</span>
        </div>

        <button
          onClick={handleSync}
          className="inline-flex items-center gap-1.5 rounded-md bg-brand px-3 py-1.5 text-sm font-medium text-white transition-colors hover:bg-brand/90"
        >
          <RefreshCw className={cn("h-3.5 w-3.5", syncing && "animate-spin")} />
          同步
        </button>

        {/* 维度配置 */}
        <div ref={configRef} className="relative ml-auto">
          <button
            onClick={() => setConfigOpen((o) => !o)}
            className="inline-flex items-center gap-1.5 rounded-md border border-border bg-card px-3 py-1.5 text-sm font-medium text-foreground transition-colors hover:bg-muted"
          >
            <SlidersHorizontal className="h-3.5 w-3.5 text-muted-foreground" />
            维度配置
            <span className="rounded bg-brand/10 px-1.5 text-xs font-semibold text-brand">{shownGroupCount}</span>
            <ChevronDown className={cn("h-3.5 w-3.5 text-muted-foreground transition-transform", configOpen && "rotate-180")} />
          </button>
          {configOpen && (
            <div className="absolute right-0 top-full z-20 mt-1 w-64 rounded-md border border-border bg-card p-2 shadow-lg">
              <p className="px-2 py-1 text-xs text-muted-foreground">选择需要展示的数据维度分组</p>
              {columnGroups.map((g) => {
                const on = activeGroups[g.id]
                return (
                  <button
                    key={g.id}
                    onClick={() => toggleGroup(g.id)}
                    disabled={g.locked}
                    className={cn(
                      "flex w-full items-center justify-between rounded px-2 py-1.5 text-left text-sm transition-colors",
                      g.locked ? "cursor-not-allowed text-muted-foreground" : "text-foreground hover:bg-muted",
                    )}
                  >
                    <span className="flex items-center gap-2">
                      <span
                        className={cn(
                          "flex h-4 w-4 items-center justify-center rounded border",
                          on ? "border-brand bg-brand text-white" : "border-border bg-card",
                        )}
                      >
                        {on && <Check className="h-3 w-3" />}
                      </span>
                      {g.label}
                      <span className="text-xs text-muted-foreground">({g.columns.length})</span>
                    </span>
                    {g.locked && <span className="text-xs text-muted-foreground">固定</span>}
                  </button>
                )
              })}
            </div>
          )}
        </div>
      </div>

      {/* 快捷分组芯片 */}
      <div className="flex flex-wrap items-center gap-2 border-b border-border px-4 py-2.5">
        {columnGroups.map((g) => {
          const on = activeGroups[g.id]
          return (
            <button
              key={g.id}
              onClick={() => toggleGroup(g.id)}
              disabled={g.locked}
              className={cn(
                "inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-xs font-medium transition-colors",
                g.locked
                  ? "cursor-not-allowed border-border bg-muted text-muted-foreground"
                  : on
                    ? "border-brand bg-brand/10 text-brand"
                    : "border-border bg-card text-muted-foreground hover:bg-muted",
              )}
            >
              {on && !g.locked && <Check className="h-3 w-3" />}
              {g.label}
            </button>
          )
        })}
      </div>

      {/* 表格 */}
      <div className="overflow-x-auto">
        <table className="w-full text-sm" style={{ minWidth: visibleColumns.length * 110 }}>
          <thead>
            <tr className="bg-muted/40 text-left text-xs text-muted-foreground">
              {visibleColumns.map((c, idx) => (
                <th
                  key={c.key}
                  className={cn(
                    "whitespace-nowrap px-3 py-2.5 font-medium",
                    idx === 0 && "sticky left-0 z-10 bg-muted/60",
                  )}
                >
                  {c.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {trackingRows.map((row, ri) => (
              <tr key={ri} className="border-t border-border hover:bg-muted/20">
                {visibleColumns.map((c, ci) => {
                  if (c.bar) {
                    const v = Number(row[c.key])
                    return (
                      <td key={c.key} className="px-3 py-2.5">
                        <div className="relative h-5 w-16 overflow-hidden rounded border border-down/30 bg-card">
                          <div className="absolute inset-y-0 left-0 bg-down/20" style={{ width: `${Math.min(100, v * 4)}%` }} />
                          <span className="absolute inset-0 flex items-center justify-center text-xs font-medium text-foreground">
                            {v}%
                          </span>
                        </div>
                      </td>
                    )
                  }
                  return (
                    <td
                      key={c.key}
                      className={cn(
                        "whitespace-nowrap px-3 py-2.5",
                        c.text ? "text-foreground/90" : "text-right tabular-nums text-foreground/80",
                        ci === 0 && "sticky left-0 z-10 bg-card font-medium text-foreground",
                      )}
                    >
                      {row[c.key]}
                    </td>
                  )
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
