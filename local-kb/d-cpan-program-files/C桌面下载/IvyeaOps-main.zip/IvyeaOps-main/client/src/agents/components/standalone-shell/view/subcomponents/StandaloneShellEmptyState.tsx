type StandaloneShellEmptyStateProps = {
  className: string;
};

export default function StandaloneShellEmptyState({ className }: StandaloneShellEmptyStateProps) {
  return (
    <div className={`flex h-full items-center justify-center ${className}`}>
      <div className="text-center text-gray-500 dark:text-gray-400">
        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-gray-100 dark:bg-gray-800">
          <svg className="h-8 w-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 002 2z"
            />
          </svg>
        </div>
        <h3 className="mb-2 text-lg font-semibold">No Project Selected</h3>
        <p>A project is required to open a shell</p>
      </div>
    </div>
  );
}
