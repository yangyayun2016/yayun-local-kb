import { PageHeader } from "@/components/ui/page-header"
import { ProfitCalculator } from "@/components/tools/profit-calculator"

export default function ToolsPage() {
  return (
    <div>
      <PageHeader title="工具箱" description="亚马逊运营常用工具集合" />

      <section>
        <div className="mb-3">
          <h2 className="text-base font-semibold text-foreground">亚马逊利润率计算器</h2>
          <p className="text-sm text-muted-foreground">
            支持美国 SC、美国 VC、欧洲 SC、欧洲 VC 四种模式，完全复刻利润率项目表的测算逻辑
          </p>
        </div>
        <ProfitCalculator />
      </section>
    </div>
  )
}
