import { Users } from "lucide-react"
import { PlaceholderPage } from "@/components/layout/placeholder-page"

export default function TeamPage() {
  return (
    <PlaceholderPage
      title="团队管理"
      icon={Users}
      modules={["成员管理", "角色权限", "数据权限", "操作日志", "绩效看板", "组织架构"]}
    />
  )
}
