export type AsinKpi = {
  label: string
  value: string
  delta: number
  accent: string
}

/** 店铺 / SKU 选项 */
export const shopOptions = [
  "星辰大海-美国-US",
  "星辰大海-德国-DE",
  "海王优选-美国-US",
  "云图电子-日本-JP",
] as const

export const skuOptions = ["SKU-KJ-01", "SKU-KJ-02", "SKU-HW-07", "SKU-YT-12"] as const

/** 顶部时间范围胶囊 */
export const timeRanges = [
  "昨天",
  "最近7天",
  "最近7天（排除最近2天）",
  "上周",
  "本周",
  "最近14天",
  "最近30天",
  "上个月",
  "本月",
  "今年",
  "最近60天",
  "最近12个月",
] as const

export type TimeRange = (typeof timeRanges)[number]

/** 不同时间范围对累积型指标的缩放（时间越长累计越大） */
const rangeScale: Record<TimeRange, number> = {
  昨天: 0.04,
  最近7天: 0.25,
  "最近7天（排除最近2天）": 0.18,
  上周: 0.24,
  本周: 0.2,
  最近14天: 0.5,
  最近30天: 1,
  上个月: 1,
  本月: 0.7,
  今年: 6,
  最近60天: 2,
  最近12个月: 12,
}

/** 稳定字符串哈希，保证 SSR/CSR 一致 */
function hash(s: string): number {
  let h = 0
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0
  return h
}

/** 店铺 + SKU 决定的店铺质量系数 0.70 ~ 1.39 */
function shopFactor(shop: string, sku: string): number {
  return 0.7 + (hash(shop + "|" + sku) % 70) / 100
}

/** 时间范围决定的相位偏移，使折线形态随时间范围变化 */
function rangeShift(range: TimeRange): number {
  return timeRanges.indexOf(range)
}

/* ---------- 数值格式化（欧洲式逗号小数） ---------- */
function fmtK(n: number): string {
  return (n / 1000).toFixed(1).replace(".", ",") + "K"
}
function fmtInt(n: number): string {
  return Math.round(n).toLocaleString("en-US")
}
function fmtEur(n: number): string {
  return "€" + n.toFixed(1).replace(".", ",")
}
function fmtPct(n: number): string {
  return n.toFixed(2).replace(".", ",") + "%"
}

/** 根据店铺 / SKU / 时间范围生成 5 个 KPI */
export function buildKpis(shop: string, sku: string, range: TimeRange): AsinKpi[] {
  const f = shopFactor(shop, sku)
  const r = rangeScale[range] ?? 1
  const imp = 114300 * f * r
  const clk = 1203 * f * r
  const spend = 179.3 * f * r
  const sales = 934.1 * f * r
  // ACOS 为比率型：店铺质量越高越低，不随时间线性增长
  const acos = 14 + (1.39 - f) * 14
  const d = (base: number) => Math.round(base * (0.5 + f) * 10) / 10
  return [
    { label: "曝光量", value: fmtK(imp), delta: d(143.7), accent: "#faad14" },
    { label: "点击量", value: fmtInt(clk), delta: d(144.6), accent: "#52c41a" },
    { label: "花费", value: fmtEur(spend), delta: d(146.4), accent: "#13c2c2" },
    { label: "销售额", value: fmtEur(sales), delta: d(76.1), accent: "#1677ff" },
    { label: "ACOS", value: fmtPct(acos), delta: d(39.9), accent: "#eb2f96" },
  ]
}

/** 多指标折线图的一行数据 */
export type SeriesPoint = {
  date: string
  a: number
  b: number
  c: number
}

const chartDates = [
  "周六,05/30",
  "周一,06/01",
  "周三,06/03",
  "周五,06/05",
  "周日,06/07",
  "周二,06/09",
  "周四,06/11",
  "周六,06/13",
  "周一,06/15",
  "周三,06/17",
  "周五,06/19",
  "周日,06/21",
  "周二,06/23",
]
// 固定的伪随机相位，保证 SSR/CSR 一致
const phaseA = [0.1, 0.5, 0.3, 0.8, 0.45, 0.95, 0.6, 0.2, 0.7, 0.4, 0.85, 0.55, 0.65]
const phaseB = [0.6, 0.3, 0.7, 0.4, 0.9, 0.5, 0.35, 0.8, 0.25, 0.75, 0.45, 0.6, 0.5]
const phaseC = [0.2, 0.7, 0.55, 0.85, 0.3, 0.6, 0.95, 0.4, 0.65, 0.5, 0.2, 0.8, 0.45]

/** 生成三条折线：base/amp 受店铺系数缩放，相位受时间范围偏移 */
function buildSeries(
  base: [number, number, number],
  amp: [number, number, number],
  f: number,
  shift: number,
): SeriesPoint[] {
  const n = chartDates.length
  return chartDates.map((date, i) => {
    const j = (i + shift) % n
    return {
      date,
      a: Math.round((base[0] * f + amp[0] * f * (phaseA[j] - 0.5) * 2) * 10) / 10,
      b: Math.round((base[1] * f + amp[1] * f * (phaseB[j] - 0.5) * 2) * 10) / 10,
      c: Math.round((base[2] * f + amp[2] * f * (phaseC[j] - 0.5) * 2) * 10) / 10,
    }
  })
}

export type ChartPanel = {
  id: string
  title: string
  subtitle?: string
  note?: string
  series: SeriesPoint[]
  legend: { key: "a" | "b" | "c"; label: string; color: string }[]
  modeTabs: ("SP" | "SB")[]
}

/** 面板元信息（结构固定，series 运行时生成） */
type PanelMeta = Omit<ChartPanel, "series"> & {
  base: [number, number, number]
  amp: [number, number, number]
}

const panelMeta: PanelMeta[] = [
  {
    id: "perf",
    title: "绩效",
    base: [4200, 4400, 4000],
    amp: [1400, 1100, 1500],
    legend: [
      { key: "a", label: "销售额", color: "#722ed1" },
      { key: "b", label: "花费", color: "#fa8c16" },
      { key: "c", label: "ACOS", color: "#13c2c2" },
    ],
    modeTabs: [],
  },
  {
    id: "efficiency",
    title: "效率",
    base: [4300, 3800, 4100],
    amp: [1300, 1500, 1400],
    legend: [
      { key: "a", label: "点击成本(CPC)", color: "#fa8c16" },
      { key: "b", label: "单次点击转化(CPA)", color: "#722ed1" },
      { key: "c", label: "转化率(CVR)", color: "#13c2c2" },
    ],
    modeTabs: [],
  },
  {
    id: "placement",
    title: "广告位绩效",
    note: "搜索顶部(TOS)、搜索结果其余位置(ROS)、商品页面(PP)",
    base: [4200, 4400, 4000],
    amp: [1400, 1100, 1500],
    legend: [
      { key: "a", label: "TOS", color: "#722ed1" },
      { key: "b", label: "ROS", color: "#fa8c16" },
      { key: "c", label: "PP", color: "#13c2c2" },
    ],
    modeTabs: ["SP", "SB"],
  },
  {
    id: "profit",
    title: "绩效",
    subtitle: "(盈利指标)",
    note: "ROAS 是 ACoS 的倒数，TACoS，产品毛利率 GPM",
    base: [4200, 4400, 4000],
    amp: [1400, 1100, 1500],
    legend: [
      { key: "a", label: "ROAS", color: "#722ed1" },
      { key: "b", label: "TACoS", color: "#fa8c16" },
      { key: "c", label: "GPM", color: "#13c2c2" },
    ],
    modeTabs: ["SP", "SB"],
  },
  {
    id: "peak",
    title: "广告出单高峰统计",
    note: "销量(小时级)、转化率(小时级)、广告花费(小时级)",
    base: [4200, 4400, 4000],
    amp: [1400, 1100, 1500],
    legend: [
      { key: "a", label: "Orders", color: "#722ed1" },
      { key: "b", label: "CVR", color: "#fa8c16" },
      { key: "c", label: "Hourly Ad Spend", color: "#13c2c2" },
    ],
    modeTabs: ["SP", "SB"],
  },
  {
    id: "ecpm",
    title: "绩效",
    subtitle: "(模拟亚马逊 eCPM 算法)",
    note: "ASIN 整体点击率 整体转化率 自然流量拟合 eCPM",
    base: [4200, 4400, 4000],
    amp: [1400, 1100, 1500],
    legend: [
      { key: "a", label: "CTR", color: "#722ed1" },
      { key: "b", label: "CVR", color: "#fa8c16" },
      { key: "c", label: "eCPM", color: "#13c2c2" },
    ],
    modeTabs: ["SP", "SB"],
  },
]

/** 根据店铺 / SKU / 时间范围生成 6 个图表面板 */
export function buildChartPanels(shop: string, sku: string, range: TimeRange): ChartPanel[] {
  const f = shopFactor(shop, sku)
  const shift = rangeShift(range)
  return panelMeta.map(({ base, amp, ...rest }) => ({
    ...rest,
    series: buildSeries(base, amp, f, shift),
  }))
}

/** SIF 坑位快照 Tab */
export const sifTabs = ["自然位", "SP-常规", "SP-推荐专栏", "SB/SBV"] as const

/** SIF 小时级排名数据（排名越小越靠前，1 为最优） */
export type RankPoint = { time: string; rank: number }

const baseSifRank: RankPoint[] = [
  { time: "06-27 08:00", rank: 3 },
  { time: "06-27 09:00", rank: 3 },
  { time: "06-27 09:30", rank: 24 },
  { time: "06-27 10:00", rank: 24 },
  { time: "06-27 10:30", rank: 3 },
  { time: "06-27 11:00", rank: 3 },
  { time: "06-27 11:30", rank: 4 },
  { time: "06-27 12:00", rank: 4 },
  { time: "06-27 12:30", rank: 3 },
  { time: "06-27 13:00", rank: 3 },
  { time: "06-27 13:30", rank: 24 },
  { time: "06-27 14:00", rank: 24 },
  { time: "06-27 14:30", rank: 4 },
  { time: "06-27 15:00", rank: 4 },
  { time: "06-27 16:00", rank: 4 },
  { time: "06-27 17:00", rank: 4 },
  { time: "06-27 18:00", rank: 4 },
  { time: "06-27 19:00", rank: 2 },
  { time: "06-27 20:00", rank: 2 },
  { time: "06-27 21:00", rank: 2 },
  { time: "06-27 22:00", rank: 2 },
  { time: "06-27 23:00", rank: 2 },
  { time: "06-28 00:00", rank: 2 },
  { time: "06-28 01:00", rank: 2 },
  { time: "06-28 02:00", rank: 2 },
  { time: "06-28 03:00", rank: 1 },
  { time: "06-28 04:00", rank: 1 },
  { time: "06-28 05:00", rank: 1 },
  { time: "06-28 06:00", rank: 1 },
]

/** 根据 SKU + 广告位 Tab 生成排名走势（围绕基线小幅扰动，限定 1~25） */
export function buildSifRank(sku: string, tab: string): RankPoint[] {
  return baseSifRank.map((p, i) => {
    const delta = (hash(sku + tab + i) % 5) - 2
    return { time: p.time, rank: Math.max(1, Math.min(25, p.rank + delta)) }
  })
}

/** 由 SKU 推导出 SIF 当前展示的 ASIN 标签 */
export function skuToAsin(sku: string): string {
  const h = hash(sku).toString(36).toUpperCase().slice(0, 5)
  return "B0" + h
}
