"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { navItems, findNav } from "@/lib/nav"
import { cn } from "@/lib/utils"

export function Sidebar() {
  const pathname = usePathname()
  const active = findNav(pathname)

  return (
    <aside className="hidden md:flex w-56 shrink-0 flex-col border-r border-border bg-card">
      {/* Logo */}
      <div className="flex h-14 items-center gap-2 px-5 border-b border-border">
        <div className="flex h-7 w-7 items-center justify-center rounded-md bg-brand text-[13px] font-bold text-white">
          天
        </div>
        <span className="text-base font-semibold tracking-tight text-foreground">
          天机 <span className="text-brand">OS</span>
        </span>
      </div>

      {/* Menu */}
      <nav className="flex-1 overflow-y-auto no-scrollbar py-3">
        <p className="px-5 pb-2 text-xs font-medium text-muted-foreground">主菜单</p>
        <ul className="space-y-0.5 px-2">
          {navItems.map((item) => {
            const isActive = active?.href === item.href
            const Icon = item.icon
            return (
              <li key={item.href}>
                <Link
                  href={item.href}
                  className={cn(
                    "group flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors",
                    isActive
                      ? "bg-brand/10 font-medium text-brand"
                      : "text-foreground/70 hover:bg-muted hover:text-foreground",
                  )}
                >
                  <Icon
                    className={cn(
                      "h-[18px] w-[18px] shrink-0",
                      isActive ? "text-brand" : "text-muted-foreground group-hover:text-foreground",
                    )}
                  />
                  <span className="flex-1 truncate">{item.title}</span>
                  {item.badge && (
                    <span className="rounded bg-brand px-1.5 py-0.5 text-[10px] font-semibold leading-none text-white">
                      {item.badge}
                    </span>
                  )}
                </Link>
              </li>
            )
          })}
        </ul>
      </nav>
    </aside>
  )
}
