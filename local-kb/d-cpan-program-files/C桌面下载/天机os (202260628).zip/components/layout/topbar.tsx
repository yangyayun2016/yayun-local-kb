"use client"

import { Bell, HelpCircle, Search, ChevronDown } from "lucide-react"

export function Topbar() {
  return (
    <header className="flex h-14 shrink-0 items-center justify-between gap-4 border-b border-border bg-card px-5">
      {/* Search */}
      <div className="flex items-center gap-3">
        <div className="relative hidden sm:block">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            placeholder="搜索 ASIN / 订单 / 功能"
            className="h-9 w-64 rounded-md border border-border bg-page pl-9 pr-3 text-sm text-foreground outline-none placeholder:text-muted-foreground focus:border-brand focus:bg-card"
          />
        </div>
      </div>

      {/* Right */}
      <div className="flex items-center gap-1.5">
        <button
          aria-label="帮助"
          className="flex h-9 w-9 items-center justify-center rounded-md text-muted-foreground hover:bg-muted hover:text-foreground"
        >
          <HelpCircle className="h-[18px] w-[18px]" />
        </button>
        <button
          aria-label="通知"
          className="relative flex h-9 w-9 items-center justify-center rounded-md text-muted-foreground hover:bg-muted hover:text-foreground"
        >
          <Bell className="h-[18px] w-[18px]" />
          <span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-down" />
        </button>
        <div className="mx-1 h-5 w-px bg-border" />
        <button className="flex items-center gap-2 rounded-md py-1 pl-1 pr-2 hover:bg-muted">
          <div className="flex h-7 w-7 items-center justify-center rounded-full bg-brand text-xs font-semibold text-white">
            飞
          </div>
          <div className="hidden text-left leading-tight sm:block">
            <div className="text-[13px] font-medium text-foreground">
              飞** <span className="ml-1 rounded bg-brand/10 px-1 py-0.5 text-[10px] text-brand">老板</span>
            </div>
          </div>
          <ChevronDown className="h-4 w-4 text-muted-foreground" />
        </button>
      </div>
    </header>
  )
}
