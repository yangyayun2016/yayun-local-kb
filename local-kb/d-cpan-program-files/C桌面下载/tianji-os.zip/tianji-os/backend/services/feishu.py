"""
天机智能决策OS - 飞书推送
配置 TIANJI_FEISHU_WEBHOOK 后即可推送到飞书群机器人。
"""
import os
import httpx

WEBHOOK = os.getenv("TIANJI_FEISHU_WEBHOOK", "")


def push_text(text: str) -> dict:
    if not WEBHOOK:
        return {"ok": False, "demo": True, "msg": "未配置 TIANJI_FEISHU_WEBHOOK，演示模式仅记录日志", "preview": text[:200]}
    try:
        r = httpx.post(WEBHOOK, json={"msg_type": "text", "content": {"text": text}}, timeout=15)
        return {"ok": r.status_code == 200, "resp": r.json()}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def push_card(title: str, lines: list[str], level: str = "blue") -> dict:
    """富文本卡片：日报/异常提醒"""
    if not WEBHOOK:
        return {"ok": False, "demo": True, "title": title}
    card = {
        "msg_type": "interactive",
        "card": {
            "header": {"title": {"tag": "plain_text", "content": title},
                       "template": {"info": "blue", "warning": "orange", "danger": "red"}.get(level, "blue")},
            "elements": [{"tag": "div", "text": {"tag": "lark_md", "content": "\n".join(lines)}}],
        },
    }
    try:
        r = httpx.post(WEBHOOK, json=card, timeout=15)
        return {"ok": r.status_code == 200}
    except Exception as e:
        return {"ok": False, "error": str(e)}
