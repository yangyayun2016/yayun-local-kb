---
name: amazon-cdq-listing-quality-score
description: |
  亚马逊CDQ v3 Listing质量得分评估系统。基于亚马逊2025年3月推出的CDQ v3指标，对Listing进行7维度评分（满分100分），
  输出评级（A++/A+/A/B/C/D/U）和优化建议。
  触发词：CDQ打分 / Listing质量评分 / listing quality score / LQS
---

# 亚马逊 CDQ v3 Listing 质量得分评估系统

## 什么时候用这个Skill

当用户需要：
- 对某个ASIN的Listing质量进行评分
- 分析Listing哪些维度需要优化
- 对比竞品Listing质量
- Listing上架前合规检查
- 基于搜索词报告优化Listing

## CDQ v3 评分体系

### 总分构成（满分100分）

| 维度 | 满分 | 评分逻辑 |
|------|------|----------|
| 标题质量 | 20分 | TQS评级：A级满分/B级10分/C级0分 |
| 图片质量 | 20分 | ≥4张 + 无缺陷 + 缩放 + IAI≥0.4 |
| 五点描述 | 15分 | ≥3条bullet + 商品描述 + 无违禁词 |
| A+页面 | 15分 | A+图文10分 + Brand Story 5分 |
| 结构化属性 | 12分 | RAI前6属性 + Band A/B属性完整性×正确性 |
| 变体质量 | 10分 | 主题一致性、属性正确性、无重复 |
| 产品类型 | 8分 | 叶节点正确 + 搜索关键词 |

**满分 = 20 + 20 + 15 + 12 + 15 + 10 + 8 = 100分**

### 评级标准

| 评级 | 分数范围 | 含义 |
|------|----------|------|
| A++ | 88-100 | 极高质量 |
| A+ | 75-87 | 高质量 |
| A | 65-74 | 尚可 |
| B | 50-64 | 低质量-无缺陷 |
| C | 0-49 | 低质量-非严重缺陷 |
| D | 0 | 低质量-严重缺陷 |
| U | N/A | 政策违规 |

## 评估流程

### Step 1: 获取Listing信息

**首选：卖家精灵MCP**
```
mcp_sellersprite_mcp_asin_detail(asin=ASIN, marketplace=站点)
```

**⚠️ 非US站点可能返回"未授权"**（FR/DE/IT/ES等欧洲站经常发生）。此时降级到浏览器抓取：

1. `browser_navigate` 打开 `https://www.amazon.{tld}/gp/product/{ASIN}`
2. 处理 Cookie 弹窗：点击 "Accept" 按钮
3. 用 `browser_console(expression=...)` 执行JS提取核心数据：
```javascript
JSON.stringify({
  title: document.getElementById('productTitle')?.textContent?.trim(),
  brand: document.getElementById('bylineInfo')?.textContent?.trim(),
  price: document.querySelector('#corePrice_feature_div .a-offscreen, .a-price .a-offscreen')?.textContent?.trim(),
  rating: document.getElementById('acrPopover')?.getAttribute('title'),
  reviewCount: document.getElementById('acrCustomerReviewText')?.textContent?.trim(),
  bullets: [...document.querySelectorAll('#feature-bullets li span.a-list-item')].map(el => el.textContent.trim()).filter(t => t.length > 5),
  mainImage: document.getElementById('landingImage')?.src,
  imageCount: document.querySelectorAll('#altImages li.a-spacing-small').length,
  category: document.querySelector('#wayfinding-breadcrumbs_feature_div')?.textContent?.trim()?.replace(/\\s+/g, ' '),
  hasAplus: !!document.getElementById('aplus'),
  hasDescription: !!document.getElementById('productDescription'),
  variationColors: [...document.querySelectorAll('#variation_color_name li')].map(li => ({
    asin: li.getAttribute('data-defaultasin'),
    value: li.querySelector('img')?.alt || li.querySelector('.a-button-text')?.textContent?.trim()
  })).slice(0, 15),
  availability: document.querySelector('#availability span')?.textContent?.trim()
})
```
4. 再次 `browser_scroll` + `browser_console` 补充变体数量、技术规格等

提取关键信息：
- title（标题）
- features（五点）
- imageUrl, imageUrls（图片）
- brand（品牌）
- nodeIdPath, nodeLabelPath（类目）
- variations（变体）
- overviews（产品概述属性）
- badge（标识）
- ebc（A+状态）
- availability（库存状态 — 不影响CDQ评分但需在报告中注明）

### Step 2: 逐维度评分

#### 2.1 结构化属性质量（满分12分）

**RAI核心属性检查：**
- Brand Name 与备案品牌一致 → +2分
- Category 正确叶子节点 → +2分
- Bullet Points 前2条含核心卖点 → +2分
- Main Image 白底85%+占比 → +2分
- Material 正确填写 → +1分

**Band A属性（转化驱动）：**
- Model Number / Special Features / Target Audience → 各+1分

**Band B属性（体验增强）：**
- Usage Scenarios / 其他后台属性完整性 → +1分

**满分 = 2+2+2+2+1+1+1+1 = 12分**

#### 2.2 标题质量（满分20分）— TQS逻辑

**A级（满分20分）标准，需全部满足：**
- 标题完整性评分 ≥ 0.6（≥3个属性标注）
- 标题冗余度评分 = 1（无重复）
- 标题长度 ≤ 200字符
- 管套评分 > 0（含 | 或分隔符）
- 特殊字符评分 = 1（无不可读字符）
- 限制性短语评分 = 1（无违规短语）

**B级（10分）：** 未违规但至少一项未达A级

**C级（0分）：** 违规标题
- 完整性 < 0.4（<2个属性）
- 冗余度 ≤ 0.6（同词>2次重复）
- 长度 > 200
- 存在受限短语

**标题检查清单：**
- [ ] ≤200字符，推荐80-200字符
- [ ] 无特殊字符：! $ ? _ { } ^ ¬
- [ ] 无重复词堆砌（同词≤2次）
- [ ] 无促销语：Best, Free, Cheapest, Top Rated, #1
- [ ] 无竞品品牌/商家名
- [ ] 结构：品牌 + 核心产品名 + 关键属性
- [ ] 以品牌名开头（+5%权重）
- [ ] 无敏感词/违禁词
- [ ] 移动端友好（80-200字符）
- [ ] 使用阿拉伯数字而非英文单词
- [ ] 每词首字母大写（介词连词冠词除外）

**敏感词/违禁词检查：**
- 健康类：antimicrobial, antibacterial, antifungal, anti-mites, sanitize, detoxify
- 促销类：free shipping, 100% quality guaranteed, best seller, top rated
- 评论类：review, testimonial, 评论请求
- 联系类：电话、邮箱、URL
- 违规类：淫秽、冒犯、剧透

#### 2.3 变体质量（满分10分）

**评分标准：**
- 变体主题属性一致性、正确性、无重复 → 满分10分
- 变体数量≥2
- 属性值丰富且准确

**严重缺陷（扣分）：** 错误属性值、单位制混用、变体信息冗余、本地化错误、子项重复

**非严重缺陷（轻微扣分）：** 未标准化值、格式不匹配、变体主题错误

#### 2.4 产品类型分类（满分8分）

- 有分类叶节点（Leaf Node）且正确 → +5分
- 有搜索关键词（Search Terms）→ +3分
- 全无 → 0分

#### 2.5 图片质量（满分20分）

- 主图白底+有效像素≥85% → +6分
- 图片数量 ≥ 4张 → +4分
- 主图有缩放功能（IAI≥0.4）→ +4分
- 图片信息完善度（alt含属性、无缺陷）→ +3分
- 有场景图/信息图 → +3分

#### 2.6 五点描述（满分15分）

- bullet数量 ≥ 3条 → +8分
- 有商品描述（纯文字段落 或 A+图文模块均可） → +4分
- 关键属性完整覆盖 → +3分
- 无违禁关键词

> **商品描述判定：** A+页面中的图文模块（含图片+文字描述）等同于Product Description。Brand Story不计入此项。

#### 2.7 A+页面（满分15分）

- 有A+图文模块（图片+文字描述）→ 10分
- 有Brand Story品牌故事模块 → +5分（需 aplusBrandStory_feature_div 有实际内容且可见）
- 全无 → 0分

**⚠️ A+检测注意事项（2026-05-15 教训）：**
A+内容可能延迟加载，首次抓取时容易漏检。必须多步验证：

1. **首次滚动后等待3秒**再检测，让懒加载内容渲染
2. **检测多个选择器**，不要只查一个：
   - `document.getElementById('aplus')` — 标准A+
   - `document.querySelector('.aplus-v2')` — A+ V2
   - `document.querySelector('[data-csa-c-content-id="aplus"]')` — 备用选择器
   - `document.getElementById('aplus_feature_div')` — 外层容器
3. **确认可见性**：`el.offsetHeight > 0`（排除空div）
4. **确认有图片**：`el.querySelectorAll('img').length > 0`（排除仅CSS骨架）
5. **区分Premium A+**：检查 `.aplus-premium` 类名，Premium A+ 包含全屏背景图/轮播等高级模块
6. **Brand Story 独立检测**：`aplusBrandStory_feature_div` 存在 ≠ 有内容，必须检查 `childElementCount > 0` 且 `offsetHeight > 0`
7. **兜底方案**：如果浏览器抓取不确定，用卖家精灵MCP的 `asin_detail` 返回的 `ebc` 字段交叉验证

### Step 3: 输出报告

报告格式：
```
## CDQ v3 评分报告 — [ASIN]

### 总评分：XX/100 → 评级：X级

| 维度 | 得分 | 满分 | 得分率 | 评级 | 问题 |
|------|------|------|--------|------|------|
| 标题质量 | XX | 20 | XX% | A/B/C | 问题描述 |
| 图片质量 | XX | 20 | XX% | ✓/⚠/✗ | 问题描述 |
| 五点描述 | XX | 15 | XX% | ✓/⚠/✗ | 问题描述 |
| A+页面 | XX | 15 | XX% | ✓/⚠/✗ | 问题描述 |
| 结构化属性 | XX | 12 | XX% | ✓/⚠/✗ | 问题描述 |
| 变体质量 | XX | 10 | XX% | ✓/⚠/✗ | 问题描述 |
| 产品类型 | XX | 8 | XX% | ✓/⚠/✗ | 问题描述 |

### 优化建议（按优先级排序）
P0: 严重缺陷 — 需立即修复
P1: 高权重问题 — 显著影响分数
P2: 中等改进 — 提升体验
P3: 锦上添花 — 长期优化
```

## 高频词埋词策略

基于CDQ报告优化Listing：
1. **标题** — 埋核心关键词（出现第1次）
2. **五点** — 埋核心关键词（出现第2-3次）
3. **Q&A** — 埋核心关键词（出现第4次）
4. **A+** — 埋核心关键词（出现第5次）
5. **图片标签/alt** — 埋关键词（补充频次）

**规则：** 核心关键词在页面出现 ≥ 3次 → 加速亚马逊收录

## 属性填写技巧

- **有下拉框的属性：** 与类目相关的必须选，不相关的可忽略
- **可自编字符的属性：** 尽可能填写相关关键词
- **空值属性：** 填一个空格，避免被系统跳过
- **效果实测：** 属性全填可显著提升结构化属性得分（该部分满分12分）

## PQS广告促销得分

PQS = 0.35 × Brand + 0.45 × Listing + 0.2 × Price

- 品牌权重35% — 新品牌劣势明显
- Listing权重45% — 基本功核心
- 价格权重20% — 高客单价带来更高坑产权重

## 商品信息质量报告使用

1. 从卖家后台下载报告
2. 在"推荐"选项卡的I列（输入属性值）填写正确值
3. 上传到 库存 > 管理库存 > 商品信息质量控制面板
4. 等待30分钟处理，下载处理报告检查错误

## HTML可视化报告生成（必须执行）

评分完成后，必须生成交互式HTML报告并上传。报告模板文件位于 `templates/cdq-report-template.html`。

### 生成流程

1. **读取模板** — `skill_view(name, file_path="templates/cdq-report-template.html")`
2. **替换占位符** — 将模板中的 `{{ASIN}}`、`{{TITLE}}` 等替换为实际数据
3. **写入文件** — 保存到 `/workspace/reports/cdq-scoring-{ASIN}.html`
4. **上传报告** — 使用 `dinzeeagent-fileupload` skill 上传并获取公网链接
5. **发送链接** — 将链接返回给用户

### 模板占位符说明

| 占位符 | 说明 | 示例 |
|--------|------|------|
| `{{ASIN}}` | ASIN编码 | B0CZRQN2M7 |
| `{{CATEGORY}}` | 小类目名 | Close To Ceiling Lights |
| `{{PRICE}}` | 当前价格 | $19.99 |
| `{{RATING}}` | 评分和评论数 | 4.3 (1,487) |
| `{{VARIANT_COUNT}}` | 变体数量 | 6 |
| `{{TOTAL_SCORE}}` | 总得分 | 73 |
| `{{GRADE}}` | 评级字母 | A |
| `{{GRADE_CLASS}}` | CSS class: A/B/C | A |
| `{{SCORE_MSG}}` | 得分下方提示语 | 当前质量"尚可"，修复标题可跳至 A+ |
| `{{DIMENSION_ROWS}}` | 七维度表格行HTML | 见下方模板 |
| `{{TITLE_SECTION}}` | 标题分析区HTML | 见下方模板 |
| `{{STRUCTURED_ATTR_ROWS}}` | 结构化属性行HTML | 见下方模板 |
| `{{VARIANT_ROWS}}` | 变体列表行HTML | 见下方模板 |
| `{{BULLET_ROWS}}` | 五点描述行HTML | 见下方模板 |
| `{{FIX_ROWS}}` | 问题清单行HTML | 见下方模板 |
| `{{EXPECT_ITEMS}}` | 预期得分卡片HTML | 见下方模板 |
| `{{EXPECT_TABLE_ROWS}}` | 预期得分表格行HTML | 见下方模板 |
| `{{GENERATED_DATE}}` | 生成日期 | 2026-05-14 |

### 动态数据生成模板

**维度行模板（循环7个维度）：**
```html
<tr class="dim-row">
  <td>{{DIM_NAME}}</td><td>{{DIM_SCORE}}</td><td>{{DIM_MAX}}</td>
  <td><span class="{{DIM_STATUS_CLASS}}">{{DIM_STATUS_ICON}}</span></td>
  <td><div class="bar-bg"><div class="bar-fill {{DIM_BAR_COLOR}}" style="width:{{DIM_PCT}}%"></div></div></td>
</tr>
```
- `DIM_STATUS_CLASS`: status-ok(绿) / status-warn(橙) / status-err(红)
- `DIM_STATUS_ICON`: ✅ / ⚠️ / ❌ C级 / ✅
- `DIM_BAR_COLOR`: bar-green / bar-orange / bar-red

**标题区模板（仅标题有问题时展示分析区）：**
```html
<div class="title-box">
  <strong>当前标题（{{TITLE_LEN}}字符）：</strong><br>{{TITLE_TEXT}}
</div>
<table>
  <tr><th>检查项</th><th>结果</th><th>说明</th></tr>
  <tr><td>长度 ≤ 200字符</td><td class="{{CHECK_CLASS}}">{{CHECK_RESULT}}</td><td>{{CHECK_NOTE}}</td></tr>
  ... <!-- 完整性、冗余度、特殊字符、受限短语、品牌开头 -->
</table>
<h3 style="margin-top:16px;font-size:15px">✅ 优化后标题建议（~{{OPT_LEN}}字符）：</h3>
<div class="title-box" style="background:#e8f5e9;border-color:#a5d6a7">
  <strong>优化标题：</strong><br>{{OPTIMIZED_TITLE}}
  <br><span style="color:#2e7d32;font-size:12px">✅ 约{{OPT_LEN}}字符 · 无重复词 · {{OLD_GRADE}}级→A级</span>
</div>
```

**问题清单行模板（按P0→P1→P2→P3排序）：**
```html
<tr>
  <td><span class="priority p{{PRI_NUM}}">P{{PRI_NUM}}</span></td>
  <td>{{ISSUE}}</td>
  <td>{{FIX}}</td>
  <td style="font-weight:700;color:{{IMPACT_COLOR}}">+{{IMPACT}}分</td>
</tr>
```

**预期得分卡片模板：**
```html
<div class="expect-item">
  <div class="val" style="color:{{EXP_COLOR}}">{{EXP_SCORE}}</div>
  <div class="lbl">{{EXP_LABEL}}</div>
</div>
```
- 当前得分: #c62828(红)
- 修复P0后: #e65100(橙)
- 全部优化后: #2e7d32(绿)

### 样式规范

报告采用深蓝紫渐变Header + 白色卡片式布局：
- 主色调：#667eea → #764ba2
- 背景色：#f0f2f5
- 卡片：白色圆角16px + 轻阴影
- 进度条：绿色(≥80%) / 橙色(50-80%) / 红色(<50%)
- 字体：-apple-system, BlinkMacSystemFont, sans-serif

### 飞书群聊发送限制绕过

HTML文件超过飞书消息限制时，使用 `dinzeeagent-fileupload` skill 上传到 report.dinzee.ai 获取公网链接，然后发送链接。

## 风险与边界

- CDQ分数无法直接从API获取，需通过卖家后台"商品信息质量报告"或付费经理获取
- 不同类目的属性权重可能不同
- 评分基于可见数据推断，非官方API数据
- **A+检测必须滚动页面后等待懒加载完成再检测，避免误判（B0FGX9SX84教训：Premium A+首次漏检）**
- 建议评分结果与卖家后台实际分数交叉验证
